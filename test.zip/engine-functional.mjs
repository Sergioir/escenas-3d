// Pruebas funcionales de comportamiento real sobre el CÓDIGO REAL del juego exportado (se extrae y
// ejecuta tal cual sale de buildStandaloneGameRuntimeSrc en index.html -- no son reimplementaciones
// aparte, así que un cambio futuro que rompa algo de esto SÍ se detecta aquí). Se ejecuta con
// Three.js real (paquete npm "three") pero sin navegador ni WebGL -- el render se sustituye por un
// objeto vacío, y el DOM por una imitación mínima, porque toda la lógica que probamos aquí es
// matemática/estado (raycasting, posiciones, banderas), no dibujado en pantalla.
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createRequire } from "module";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
globalThis.self = globalThis;
// Node no trae "Image" (es cosa del navegador) -- buildImagePlaneObject/swapImageTexture (motor real,
// sin tocar) lo usan para decodificar el data URL antes de construir la textura. Aquí no hace falta
// decodificar nada de verdad (no dibujamos), así que esta imitación resuelve el onload en un
// microtask (no síncrono EN EL ACTO): igual que un navegador de verdad, el onload de una imagen
// SIEMPRE llega después de que el código que la creó termine de ejecutarse -- resolverlo síncrono
// rompía el orden de reconstrucción de la escena (buildScene recorre PROJECT.objects con forEach; si
// la imagen "carga" antes de que el forEach term ine de recorrer el resto de objetos, finish() se
// dispara antes de tiempo y los objetos que van DESPUÉS del de imagen en la lista nunca se añaden a
// sceneObjects). Un microtask reproduce el orden real sin tener que convertir todo el arnés a
// async/await: dado que buildScene()/runner() se ejecutan síncronos hasta el final antes de que Node
// vacíe la cola de microtasks, el forEach siempre termina antes de que cualquier onload se dispare.
class FakeImage {
  constructor() { this.width = 1; this.height = 1; this._src = ""; this.onload = null; this.onerror = null; }
  set src(v) { this._src = v; const self = this; if (this.onload) queueMicrotask(() => { if (self.onload) self.onload(); }); }
  get src() { return this._src; }
}
globalThis.Image = FakeImage;
// PNG transparente de 1x1 real y válido -- de sobra para probar el intercambio de textura sin
// depender de ningún archivo externo.
const TINY_PNG_DATA_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const INDEX_HTML = path.resolve(__dirname, "..", "index.html");
const TMP = path.join(__dirname, ".tmp");
fs.mkdirSync(TMP, { recursive: true });

let hadFailure = false;
function fail(msg) { console.error("FALLO: " + msg); hadFailure = true; }
function ok(msg) { console.log("OK: " + msg); }
function assert(cond, msg) { if (cond) ok(msg); else fail(msg); }

const html = fs.readFileSync(INDEX_HTML, "utf-8");
const liveMatch = html.match(/<script type="module">([\s\S]*)<\/script>\s*<\/body>/);
const liveSrc = liveMatch[1];

function extractFn(src, name) {
  const idx = src.indexOf("function " + name);
  if (idx === -1) throw new Error("No se encontró function " + name);
  const start = src.indexOf("{", idx);
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === "{") depth++;
    else if (src[i] === "}") { depth--; if (depth === 0) break; }
  }
  return src.slice(idx, i + 1);
}
const fn1 = extractFn(liveSrc, "buildStandaloneGameRuntimeSrc");
const buildersFile = path.join(TMP, "runtime-builder.cjs");
fs.writeFileSync(buildersFile, fn1 + "\nmodule.exports = { buildStandaloneGameRuntimeSrc };");
const { buildStandaloneGameRuntimeSrc } = require(buildersFile);

// ---- Proyecto de prueba: sólo primitivas (sin gltf/imagen/vídeo -> buildScene resuelve en síncrono) ----
const project = {
  objects: [
    {
      id: "player", name: "Jugador", kind: "primitive", primitiveType: "box",
      colorHex: "#ffffff", opacity: 1,
      transform: { position: [0, 0, 0], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "character", size: { x: 0.8, y: 1.6, z: 0.8 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: { enabled: false, kind: "text", radius: 2, prompt: "", text: "", url: "", choices: [], onInteractAction: null, onShotAction: null },
    },
    {
      id: "target", name: "Objetivo", kind: "primitive", primitiveType: "box",
      colorHex: "#ff0000", opacity: 1,
      transform: { position: [0, 1.35, -10], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: {
        enabled: false, kind: "text", radius: 2, prompt: "", text: "", url: "", choices: [], onInteractAction: null,
        onShotAction: { type: "fade", target: "self", to: 0, duration: 0.2, parallel: [] },
      },
    },
    {
      id: "signEmpty", name: "Cartel vacio (solo dispara accion)", kind: "primitive", primitiveType: "box",
      colorHex: "#00ff00", opacity: 1,
      transform: { position: [5, 0, 5], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: {
        enabled: true, kind: "text", radius: 2, prompt: "Interactuar", text: "", url: "", choices: [],
        onInteractAction: { type: "fade", target: "self", to: 0.3, duration: 0.05, parallel: [] },
        onShotAction: null,
      },
    },
    {
      id: "signWithText", name: "Cartel con texto (debe abrir panel)", kind: "primitive", primitiveType: "box",
      colorHex: "#0000ff", opacity: 1,
      transform: { position: [-5, 0, 5], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: {
        enabled: true, kind: "text", radius: 2, prompt: "Leer", text: "Aviso de prueba", url: "", choices: [],
        onInteractAction: null, onShotAction: null,
      },
    },
    {
      id: "signAskInput", name: "Cartel con texto CUYA accion es Preguntar (no debe abrir panel de cartel)", kind: "primitive", primitiveType: "box",
      colorHex: "#ffaa00", opacity: 1,
      transform: { position: [-8, 0, 5], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: {
        enabled: true, kind: "text", radius: 2, prompt: "Hablar", text: "Este texto NO deberia verse en un panel aparte", url: "", choices: [],
        onInteractAction: { type: "askInput", promptText: "Como te llamas?", varName: "nombreDesdeCartel", allowFile: false },
        onShotAction: null,
      },
    },
    {
      id: "imgBoard", name: "Tablon (objeto Imagen de prueba)", kind: "image",
      imageBase64: TINY_PNG_DATA_URL, imageFileName: "placeholder.png",
      transform: { position: [0, 0, 8], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 1, y: 1.5, z: 0.05 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: { enabled: false, kind: "text", radius: 2, prompt: "", text: "", url: "", choices: [], onInteractAction: null, onShotAction: null },
    },
    {
      id: "rotuloVar", name: "Rotulo (objeto Texto 3D de prueba)", kind: "text3d",
      text3d: { text: "Texto original", color: "#ffffff", size: 1, boxWidth: 472 },
      transform: { position: [3, 0, 8], quaternion: [0, 0, 0, 1], scale: [1, 1, 1] },
      collider: { kind: "none", size: { x: 2, y: 1, z: 0.1 }, riskLabel: "" },
      facingOffsetDeg: 0, actions: [],
      interactive: { enabled: false, kind: "text", radius: 2, prompt: "", text: "", url: "", choices: [], onInteractAction: null, onShotAction: null },
    },
  ],
  camera: { position: { x: 0, y: 1.6, z: 5 }, target: { x: 0, y: 1.6, z: 0 } },
  audio: {},
  environment: {
    nightSkyEnabled: false, skyDateMode: "auto", skyManualDate: "", skyManualTime: "",
    skyLongitudeDeg: -3.7, skyUtcOffsetHours: 1, moonTextureBase64: null, moonTextureFileName: null,
    nightBgColor: "#050912",
  },
  groups: [],
};

let runtimeSrc = buildStandaloneGameRuntimeSrc(JSON.stringify(project));

// Quitar los imports ES (THREE/GLTFLoader se inyectan como parámetros de función más abajo).
runtimeSrc = runtimeSrc.replace(/^import[^\n]*\n/gm, "");
// Sustituir el renderer real (necesita WebGL de verdad) por uno inerte -- no probamos dibujado, sólo
// estado/lógica, y todo lo demás del motor sólo llama a renderer.render()/setSize()/setPixelRatio().
runtimeSrc = runtimeSrc.replace(
  'var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });',
  'var renderer = { render: function(cam){ camera.updateMatrixWorld(true); scene.updateMatrixWorld(true); }, setSize: function(){}, setPixelRatio: function(){}, shadowMap: { enabled: false, type: null }, domElement: { style:{}, addEventListener: function(){} } };'
);

// Cortar la cola real (aplica entorno, construye escena y arranca requestAnimationFrame) y sustituirla
// por nuestro propio arnés de pruebas -- todo lo de ARRIBA (funciones, variables) es el código real sin tocar.
const tailAnchor = "applyEnvironment(PROJECT.environment);";
const tailIdx = runtimeSrc.indexOf(tailAnchor);
if (tailIdx === -1) throw new Error("No se encontró el punto de arranque del runtime exportado.");
runtimeSrc = runtimeSrc.slice(0, tailIdx);

const harness = `
applyEnvironment(PROJECT.environment);
var RESULTS = { steps: [] };
function step(name, fn) { try { fn(); RESULTS.steps.push({ name: name, ok: true }); } catch (e) { RESULTS.steps.push({ name: name, ok: false, error: (e && e.stack) || String(e) }); } }
// Version async de step(), para las pruebas que disparan una accion cuyo efecto llega en un
// microtask (p. ej. setImageVar -- construir la textura pasa por el FakeImage del arnes, que ahora
// resuelve el onload en un microtask de verdad, como en un navegador real, no en el acto).
async function stepAsync(name, fn) { try { await fn(); RESULTS.steps.push({ name: name, ok: true }); } catch (e) { RESULTS.steps.push({ name: name, ok: false, error: (e && e.stack) || String(e) }); } }
function nextTick() { return new Promise(function (resolve) { queueMicrotask(resolve); }); }

buildScene(PROJECT, async function () {
  // --- Escena lista (síncrono: sólo primitivas) ---

  step("panel vacio no bloquea y dispara su accion", function () {
    var rec = sceneObjects.get("signEmpty");
    var before = rec.colorMaterials[0].opacity;
    openInteractionPanel("signEmpty");
    if (interactionPanelOpen) throw new Error("interactionPanelOpen quedó a true tras interactuar con un cartel de texto vacío (debería ejecutar la acción y no abrir panel).");
    var afterOneShot = rec.__oneShot;
    if (!afterOneShot) throw new Error("El cartel vacío no disparó ninguna acción (se esperaba un fundido de opacidad).");
  });

  step("panel con texto SI bloquea y se cierra con E/Esc", function () {
    var rec = sceneObjects.get("signWithText");
    openInteractionPanel("signWithText");
    if (!interactionPanelOpen) throw new Error("interactionPanelOpen debería ser true tras interactuar con un cartel CON texto (lectura de cartel).");
    closeInteractionPanel();
    if (interactionPanelOpen) throw new Error("closeInteractionPanel() no dejó interactionPanelOpen en false.");
  });

  step("cartel con texto CUYA accion es 'Preguntar' NO abre el panel de cartel (evita dos overlays a la vez)", function () {
    // Bug real detectado jugando la partida exportada: si el cartel tiene texto Y su accion es
    // askInput/screenMessage, antes se abria el panel de "leer cartel" A LA VEZ que la ventanita de
    // la propia accion -- dos overlays superpuestos. Debe comportarse como el cartel vacio: dispara
    // la accion al instante, sin panel de cartel de por medio.
    askInputActive = false; // por si un test anterior lo dejo a medias
    openInteractionPanel("signAskInput");
    if (interactionPanelOpen) throw new Error("interactionPanelOpen quedo a true -- el panel de 'leer cartel' no deberia abrirse cuando la accion es 'Preguntar' (se solaparia con su propia ventanita).");
    if (!askInputActive) throw new Error("askInput deberia haberse disparado igualmente (askInputActive deberia ser true).");
    // Limpieza: cerramos el askInput abierto para no afectar a los pasos siguientes.
    document.getElementById("askInputCancel").__fire("click");
    if (askInputActive) throw new Error("El askInput de este test no se cerro correctamente (askInputActive deberia volver a false).");
  });

  step("disparo (F) a 10m impacta y dispara onShotAction (huida/fundido)", function () {
    playerRecordId = "player";
    firstPersonMode = true;
    playYaw = 0; playPitch = 0;
    // Un par de "frames" para que cámara y matrices de la escena se asienten, igual que en el juego real.
    for (var i = 0; i < 2; i++) { updatePlayer(0.016); renderer.render(scene, camera); }
    if (nearestShotTargetId !== "target") throw new Error("El objetivo a 10m en línea recta no fue detectado por el rayo de disparo (nearestShotTargetId=" + nearestShotTargetId + ").");
    attemptShoot();
    var rec = sceneObjects.get("target");
    if (!rec.__oneShot) throw new Error("attemptShoot() no generó ninguna animación de una vez sobre el objetivo.");
  });

  step("tras completarse el fundido, el objetivo deja de ser alcanzable (no fantasma)", function () {
    // Simulamos el paso del tiempo hasta que el fundido (duration 0.2s) termine.
    for (var i = 0; i < 30; i++) { updateOneShotAnimations(); }
    // performance.now() avanza solo con el reloj real; forzamos que "termine" reescribiendo el estado
    // directamente si tras 30 pasadas inmediatas (mismo instante) el oneShot no ha progresado --
    // en su lugar, comprobamos el estado esperado tras opacidad 0 manualmente:
    var rec = sceneObjects.get("target");
    // Forzamos el final del fundido (equivalente a que pase el tiempo real) para probar el filtro:
    rec.colorMaterials.forEach(function (m) { m.opacity = 0; m.visible = false; });
    rec.__oneShot = null;
    updatePlayer(0.016);
    if (nearestShotTargetId === "target") throw new Error("El objetivo totalmente desvanecido SIGUE siendo alcanzable por el rayo de disparo (bug del 'fantasma disparable').");
  });

  step("screenMessage: no bloquea, y el next solo se dispara al cerrar (no al mostrarse)", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.quien = "Sergio";
    gameVariables.msgSeen = 0;
    var action = {
      type: "screenMessage", text: "Hola {{quien}}", autoDismissSec: 0,
      next: { type: "setVariable", varName: "msgSeen", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (askInputActive) throw new Error("screenMessage no debe activar askInputActive (no bloquea moverse).");
    if (gameVariables.msgSeen === 1) throw new Error("El 'next' se disparo antes de cerrar el mensaje (deberia esperar al cierre, automatico o manual).");
    document.getElementById("screenMsgCloseBtn").__fire("click");
    if (gameVariables.msgSeen !== 1) throw new Error("El 'next' no se disparo al cerrar el mensaje en pantalla.");
  });

  step("askInput: bloquea mientras esta abierto, guarda la variable y dispara next al enviar", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.nombreJugador = "";
    gameVariables.afterAsk = 0;
    var action = {
      type: "askInput", promptText: "Como te llamas?", varName: "nombreJugador", allowFile: false,
      next: { type: "setVariable", varName: "afterAsk", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (!askInputActive) throw new Error("askInput deberia activar askInputActive mientras esta abierto (bloquea moverse).");
    document.getElementById("askInputText").value = "Sergio";
    document.getElementById("askInputSend").__fire("click");
    if (askInputActive) throw new Error("askInputActive deberia volver a false tras enviar la respuesta.");
    if (gameVariables.nombreJugador !== "Sergio") throw new Error("La variable no guardo el texto introducido (valor: '" + gameVariables.nombreJugador + "').");
    if (gameVariables.afterAsk !== 1) throw new Error("El 'next' no se disparo tras enviar el askInput.");
  });

  step("askInput: Cancelar tambien cierra, desbloquea y SIGUE la secuencia (next), pero SIN guardar la variable", function () {
    // Ojo: Cancelar SI dispara el 'next' (igual que Enviar) -- si no lo hiciera, cancelar dejaria
    // colgada para siempre cualquier secuencia encadenada despues de la pregunta (p. ej. un ascensor
    // que deberia seguir bajando aunque el jugador no responda). Lo unico que cambia es que NO se
    // sobrescribe la variable con el texto sin enviar.
    var rec = sceneObjects.get("signEmpty");
    gameVariables.nombreJugador = "valorPrevio";
    gameVariables.afterAsk = 0;
    var action = {
      type: "askInput", promptText: "Como te llamas?", varName: "nombreJugador", allowFile: false,
      next: { type: "setVariable", varName: "afterAsk", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    document.getElementById("askInputText").value = "Otro nombre";
    document.getElementById("askInputCancel").__fire("click");
    if (askInputActive) throw new Error("askInputActive deberia volver a false tras Cancelar.");
    if (gameVariables.nombreJugador !== "valorPrevio") throw new Error("Cancelar NO deberia sobrescribir la variable con el texto sin enviar.");
    if (gameVariables.afterAsk !== 1) throw new Error("Cancelar deberia igualmente disparar el 'next' -- si no, una secuencia encadenada se quedaria colgada para siempre si el jugador cancela.");
  });

  await stepAsync("setImageVar: cambia la textura de un objeto de Imagen desde una variable y dispara next", async function () {
    var rec = sceneObjects.get("signEmpty");
    var board = sceneObjects.get("imgBoard");
    var meshBefore = board.object3D.children[0];
    var matBefore = meshBefore.material;
    var mapBefore = meshBefore.material.map;
    gameVariables.fotoJugador = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
    gameVariables.afterImg = 0;
    var action = {
      type: "setImageVar", varName: "fotoJugador", target: "imgBoard",
      next: { type: "setVariable", varName: "afterImg", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    // La textura nueva llega en un microtask (FakeImage), como en un navegador real -- esperamos a
    // que se drene antes de comprobar el resultado.
    await nextTick();
    var meshAfter = board.object3D.children[0];
    if (meshAfter.material === matBefore) throw new Error("setImageVar no reemplazo el material del objeto de Imagen (sigue siendo el mismo).");
    if (!meshAfter.material.map || meshAfter.material.map === mapBefore) throw new Error("setImageVar no genero una textura nueva distinta de la anterior.");
    if (board.imageBase64 !== gameVariables.fotoJugador) throw new Error("setImageVar no actualizo rec.imageBase64 con el data URL de la variable.");
    if (gameVariables.afterImg !== 1) throw new Error("El 'next' no se disparo tras cambiar la imagen.");
  });

  step("setImageVar: variable vacia o destino invalido no rompe nada y sigue la secuencia", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.fotoVacia = "";
    gameVariables.afterImg2 = 0;
    var action = {
      type: "setImageVar", varName: "fotoVacia", target: "imgBoard",
      next: { type: "setVariable", varName: "afterImg2", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterImg2 !== 1) throw new Error("Con variable vacia, el 'next' deberia dispararse igualmente (no debe quedarse colgado).");
  });

  step("setTextVar: cambia el texto de un rotulo desde una variable, sin red, y dispara next", function () {
    var rec = sceneObjects.get("signEmpty");
    var label = sceneObjects.get("rotuloVar");
    var meshBefore = label.object3D.children[0];
    var mapBefore = meshBefore.material.map;
    gameVariables.nombreParaRotulo = "Sergio";
    gameVariables.afterTxt = 0;
    var action = {
      type: "setTextVar", varName: "nombreParaRotulo", target: "rotuloVar",
      next: { type: "setVariable", varName: "afterTxt", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (label.text3d.text !== "Sergio") throw new Error("setTextVar no actualizo text3d.text (valor: '" + label.text3d.text + "').");
    var meshAfter = label.object3D.children[0];
    if (!meshAfter.material.map || meshAfter.material.map === mapBefore) throw new Error("setTextVar no genero una textura nueva para el rotulo.");
    if (gameVariables.afterTxt !== 1) throw new Error("El 'next' no se disparo tras setTextVar.");
  });

  step("setTextVar: destino invalido no rompe nada y sigue la secuencia", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.afterTxt2 = 0;
    var action = {
      type: "setTextVar", varName: "nombreParaRotulo", target: "imgBoard", // imgBoard NO es text3d -- destino invalido a proposito
      next: { type: "setVariable", varName: "afterTxt2", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterTxt2 !== 1) throw new Error("Con destino invalido, el 'next' deberia dispararse igualmente (no debe quedarse colgado ni romper).");
  });

  step("texto multilinea: la geometria crece en ALTO segun el numero de lineas (no se aplasta)", function () {
    var rec = sceneObjects.get("signEmpty");
    var label = sceneObjects.get("rotuloVar");
    // Estado previo: el rotulo quedo con "Sergio" (1 sola linea) tras el test anterior de setTextVar.
    var meshUnaLinea = label.object3D.children[0];
    var altoUnaLinea = meshUnaLinea.geometry.parameters.height;
    var anchoUnaLinea = meshUnaLinea.geometry.parameters.width;
    if (Math.abs(altoUnaLinea - 1) > 1e-9) throw new Error("Con 1 sola linea, el alto de la geometria deberia ser exactamente 1*size (regresion en rotulos existentes). Valor: " + altoUnaLinea);

    gameVariables.textoLargo = "Linea uno\\nLinea dos\\nLinea tres";
    gameVariables.afterTxt3 = 0;
    var action = {
      type: "setTextVar", varName: "textoLargo", target: "rotuloVar",
      next: { type: "setVariable", varName: "afterTxt3", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterTxt3 !== 1) throw new Error("El 'next' no se disparo tras setTextVar con texto multilinea.");
    var meshMultilinea = label.object3D.children[0];
    var altoMultilinea = meshMultilinea.geometry.parameters.height;
    var anchoMultilinea = meshMultilinea.geometry.parameters.width;
    // 3 lineas: heightFactor = (3*LINE_HEIGHT+PADDING*2)/(LINE_HEIGHT+PADDING*2) = (3*64+40)/(64+40) = 232/104
    var esperado = 232 / 104;
    if (Math.abs(altoMultilinea - esperado) > 1e-9) throw new Error("El alto de la geometria con 3 lineas no crecio como se esperaba (bug de aplastamiento). Esperado: " + esperado + ", obtenido: " + altoMultilinea);
    if (!(altoMultilinea > altoUnaLinea)) throw new Error("El alto con 3 lineas deberia ser mayor que con 1 sola linea -- el texto se esta aplastando en vez de crecer hacia abajo.");
    // Regresion de distorsion: el ANCHO de la caja (boxWidth fijo) NO debe encogerse al crecer las
    // lineas -- si el ancho usara canvas.width/canvas.height (que se reduce con mas lineas) en vez de
    // canvas.width/REF, la textura se estira (letras angostas y alargadas hacia arriba).
    if (Math.abs(anchoMultilinea - anchoUnaLinea) > 1e-9) throw new Error("El ancho de la geometria NO deberia cambiar entre 1 y 3 lineas (mismo boxWidth) -- si cambia, el texto se distorsiona (encogido en horizontal, alargado en vertical). 1 linea: " + anchoUnaLinea + ", 3 lineas: " + anchoMultilinea);
  });

  var okAll = RESULTS.steps.every(function (s) { return s.ok; });
  __onDone(okAll, RESULTS.steps);
});
`;

// stubEl() lleva un poco de estado real (value/checked/textContent) y un registro de listeners
// (con __fire para disparar un evento "a mano" desde fuera) -- lo mínimo necesario para poder
// simular clics/tecleo reales en las nuevas ventanitas overlay (screenMessage/askInput) sin un
// DOM/navegador de verdad, igual que ya se hacía (sin esto) para el resto del motor.
function stubEl() {
  const state = { value: "", checked: false, textContent: "", innerHTML: "", dataset: {} };
  const listeners = {};
  const handler = {
    get(target, prop) {
      if (prop === "style") return new Proxy({}, handler);
      if (prop === "classList") return { toggle() {}, add() {}, remove() {}, contains() { return false; } };
      if (prop === "dataset") return state.dataset;
      if (prop === "addEventListener") return (type, cb) => { (listeners[type] = listeners[type] || []).push(cb); };
      if (prop === "removeEventListener") return () => {};
      if (prop === "__fire") return (type, evt) => { (listeners[type] || []).forEach((cb) => cb(evt || { preventDefault() {}, stopPropagation() {} })); };
      if (prop === "querySelectorAll") return () => [];
      if (prop === "appendChild" || prop === "focus" || prop === "blur" || prop === "click") return () => {};
      if (prop === "then") return undefined; // evita que Proxy parezca un thenable
      if (prop === "value" || prop === "checked" || prop === "textContent" || prop === "innerHTML") return state[prop];
      if (prop in target) return target[prop];
      return new Proxy(() => new Proxy({}, handler), handler);
    },
    set(target, prop, value) {
      if (prop === "value" || prop === "checked" || prop === "textContent" || prop === "innerHTML") state[prop] = value;
      return true;
    },
    apply() { return new Proxy({}, handler); },
  };
  return new Proxy(function () {}, handler);
}
// getElementById cacheado por id: las ventanitas overlay (showScreenMessage/showAskInput) montan
// su HTML y luego buscan sus propios controles por id (document.getElementById("askInputSend")...)
// -- para poder simular un clic/tecleo desde FUERA de esas funciones (en el test) hace falta que
// ambas llamadas devuelvan el MISMO elemento, no uno nuevo cada vez.
const elCache = new Map();
// buildText3DTexture (motor real, sin tocar) necesita un <canvas> de verdad con getContext("2d") --
// el stubEl() genérico devuelve proxies para todo, y measureText(...).width acaba siendo un proxy en
// vez de un número, lo que revienta la comparación "> maxWidth" con "Cannot convert object to
// primitive value". No hace falta dibujar nada de verdad (no hay pantalla) -- solo que measureText
// devuelva un ancho numérico plausible y que width/height se comporten como números normales.
class FakeCanvasContext {
  measureText(str) { return { width: (str ? String(str).length : 0) * 10 }; }
  fillText() {}
  clearRect() {}
}
class FakeCanvas {
  constructor() { this.width = 0; this.height = 0; }
  getContext() { return new FakeCanvasContext(); }
}
const fakeDocument = {
  getElementById: (id) => { if (!elCache.has(id)) elCache.set(id, stubEl()); return elCache.get(id); },
  addEventListener: () => {},
  createElement: (tag) => (tag === "canvas" ? new FakeCanvas() : stubEl()),
  body: stubEl(),
};
const fakeWindow = {
  addEventListener: () => {},
  innerWidth: 1024, innerHeight: 768, devicePixelRatio: 1,
  matchMedia: () => ({ matches: false }),
  visualViewport: null,
};
const fakeNavigator = { maxTouchPoints: 0, userAgent: "node-test" };

const fullScript = runtimeSrc + harness;
fs.writeFileSync(path.join(TMP, "functional-harness.js"), fullScript);

const runner = new Function(
  "THREE", "GLTFLoader", "document", "window", "navigator", "performance", "__onDone",
  fullScript
);

await new Promise((resolve) => {
  runner(THREE, GLTFLoader, fakeDocument, fakeWindow, fakeNavigator, performance, (okAll, steps) => {
    for (const s of steps) {
      if (s.ok) ok(s.name);
      else fail(s.name + "\n  " + s.error);
    }
    resolve();
  });
});

process.exit(hadFailure ? 1 : 0);
