function huellaObjetoJS(o) {
  if (!o || typeof o !== "object") return JSON.stringify(o);
  const { gltfBase64, imageBase64, videoBase64, textureBase64, ...ligero } = o;
  return JSON.stringify(ligero);
}

function indexarObjetosPorIdJS(objetos) {
  const out = new Map();
  (objetos || []).forEach((o) => { if (o && o.id != null) out.set(o.id, o); });
  return out;
}

function fusionarProyectosJS(base, local, servidor) {
  if (!servidor || !Array.isArray(servidor.objects)) return { proyecto: local, conflictos: [] };
  if (!local || !Array.isArray(local.objects)) return { proyecto: servidor, conflictos: [] };

  const hayBase = !!(base && Array.isArray(base.objects));
  const baseObjs = hayBase ? indexarObjetosPorIdJS(base.objects) : new Map();
  const localObjs = indexarObjetosPorIdJS(local.objects);
  const servObjs = indexarObjetosPorIdJS(servidor.objects);

  const todosLosIds = new Set([...localObjs.keys(), ...servObjs.keys()]);
  const merged = [];
  const conflictos = [];

  for (const id of todosLosIds) {
    const enLocal = localObjs.has(id);
    const enServ = servObjs.has(id);
    const enBase = hayBase && baseObjs.has(id);
    const localCambio = enBase && enLocal && huellaObjetoJS(baseObjs.get(id)) !== huellaObjetoJS(localObjs.get(id));
    const servCambio = enBase && enServ && huellaObjetoJS(baseObjs.get(id)) !== huellaObjetoJS(servObjs.get(id));

    if (enLocal && enServ) {
      if (localCambio && servCambio) { merged.push(servObjs.get(id)); conflictos.push(id); }
      else if (localCambio) merged.push(localObjs.get(id));
      else merged.push(servObjs.get(id));
    } else if (enLocal && !enServ) {
      if (!enBase) merged.push(localObjs.get(id));
      else if (localCambio) { merged.push(localObjs.get(id)); conflictos.push(id); }
      // si no cambió localmente y ya no está en el servidor: lo borró otra persona -- se respeta, se omite
    } else if (!enLocal && enServ) {
      if (!enBase) merged.push(servObjs.get(id));
      else if (servCambio) { merged.push(servObjs.get(id)); conflictos.push(id); }
      // si no cambió en el servidor y yo lo borré localmente: se respeta el borrado, se omite
    }
  }

  const resultado = { ...local, objects: merged };
  for (const campo of ["environment", "audio", "camera"]) {
    const baseVal = hayBase ? base[campo] : null;
    const localVal = local[campo];
    const servVal = servidor[campo];
    const localCambioCampo = hayBase && JSON.stringify(baseVal) !== JSON.stringify(localVal);
    const servCambioCampo = hayBase && JSON.stringify(baseVal) !== JSON.stringify(servVal);
    resultado[campo] = (servCambioCampo && !localCambioCampo) ? servVal : localVal;
    if (localCambioCampo && servCambioCampo && JSON.stringify(localVal) !== JSON.stringify(servVal)) conflictos.push(campo);
  }

  return { proyecto: resultado, conflictos };
}

module.exports = { fusionarProyectosJS };