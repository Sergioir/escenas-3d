
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

/* =========================================================================
   NÚCLEO THREE.JS
   ========================================================================= */
const viewportWrap = document.getElementById("viewportWrap");
const canvas = document.getElementById("viewport");

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0b0f);
scene.fog = new THREE.Fog(0x0a0b0f, 20, 60);

const BASE_FOV = 50; // FOV vertical de referencia con aspect >= 1 (horizontal/cuadrado)
function computeFov(aspect, baseFov) {
  // En pantallas en vertical (aspect < 1) un FOV vertical fijo produce un
  // FOV horizontal muy estrecho ("efecto teleobjetivo" / lupa). Ampliamos el
  // FOV vertical para mantener aproximadamente el mismo campo de visión
  // horizontal que en landscape, evitando esa sensación de zoom excesivo.
  if (aspect >= 1) return baseFov;
  const baseFovRad = THREE.MathUtils.degToRad(baseFov);
  const vFovRad = 2 * Math.atan(Math.tan(baseFovRad / 2) / aspect);
  return Math.min(THREE.MathUtils.radToDeg(vFovRad), 100);
}
const camera = new THREE.PerspectiveCamera(BASE_FOV, 1, 0.1, 500);
const DEFAULT_CAM_POS = new THREE.Vector3(7, 6, 10);
const DEFAULT_CAM_TARGET = new THREE.Vector3(0, 1, 0);
camera.position.copy(DEFAULT_CAM_POS);

const orbitControls = new OrbitControls(camera, renderer.domElement);
orbitControls.target.copy(DEFAULT_CAM_TARGET);
orbitControls.enableDamping = true;

const transformControls = new TransformControls(camera, renderer.domElement);
const multiPivot = new THREE.Object3D();
scene.add(multiPivot);
let multiDragStart = null; // snapshot tomado al empezar a arrastrar con selección múltiple
transformControls.addEventListener("dragging-changed", (e) => {
  orbitControls.enabled = !e.value;
  if (e.value && selectedIds.size >= 1) pushUndo();
  if (selectedIds.size > 1) {
    if (e.value) {
      multiDragStart = {
        pivotPos: multiPivot.position.clone(),
        pivotQuat: multiPivot.quaternion.clone(),
        pivotScale: multiPivot.scale.clone(),
        objects: selectedRecs().map((r) => ({ rec: r, pos: r.object3D.position.clone(), quat: r.object3D.quaternion.clone(), scale: r.object3D.scale.clone() })),
      };
    } else {
      multiDragStart = null;
      // Re-sincroniza el pivote (posición=centroide actual, rotación/escala=identidad) al soltar el
      // arrastre; si no, el siguiente arrastre (rotar/escalar) heredaría la orientación/escala "sucia"
      // del pivote y el grupo podría salir despedido a una posición inesperada.
      updateGizmoAttachment();
    }
  }
});
transformControls.addEventListener("objectChange", () => {
  if (selectedIds.size > 1 && multiDragStart) {
    applyMultiDragDelta();
  } else if (selectedId) {
    if (snapToEdges && transformControls.mode === "translate") {
      const rec = sceneObjects.get(selectedId);
      if (rec) applyEdgeSnap(rec);
    }
    refreshPropsTransformInputsOnly();
  }
});
scene.add(transformControls);

let snapToEdges = false;
const EDGE_SNAP_THRESHOLD = 0.25;
function applyEdgeSnap(rec) {
  const box = new THREE.Box3().setFromObject(rec.object3D);
  if (box.isEmpty()) return;
  let bestDx = null, bestDy = null, bestDz = null;
  for (const other of sceneObjects.values()) {
    if (other.id === rec.id || !other.object3D) continue;
    const obox = new THREE.Box3().setFromObject(other.object3D);
    if (obox.isEmpty()) continue;
    [[box.min.x, obox.min.x], [box.min.x, obox.max.x], [box.max.x, obox.min.x], [box.max.x, obox.max.x]].forEach(([a, b]) => {
      const d = b - a;
      if (Math.abs(d) < EDGE_SNAP_THRESHOLD && (bestDx === null || Math.abs(d) < Math.abs(bestDx))) bestDx = d;
    });
    [[box.min.y, obox.min.y], [box.min.y, obox.max.y], [box.max.y, obox.min.y], [box.max.y, obox.max.y]].forEach(([a, b]) => {
      const d = b - a;
      if (Math.abs(d) < EDGE_SNAP_THRESHOLD && (bestDy === null || Math.abs(d) < Math.abs(bestDy))) bestDy = d;
    });
    [[box.min.z, obox.min.z], [box.min.z, obox.max.z], [box.max.z, obox.min.z], [box.max.z, obox.max.z]].forEach(([a, b]) => {
      const d = b - a;
      if (Math.abs(d) < EDGE_SNAP_THRESHOLD && (bestDz === null || Math.abs(d) < Math.abs(bestDz))) bestDz = d;
    });
  }
  if (bestDx !== null) rec.object3D.position.x += bestDx;
  if (bestDy !== null) rec.object3D.position.y += bestDy;
  if (bestDz !== null) rec.object3D.position.z += bestDz;
}
document.getElementById("snapEdgesToggle").addEventListener("change", (e) => { snapToEdges = e.target.checked; });

function applyMultiDragDelta() {
  const startPivotMatrix = new THREE.Matrix4().compose(multiDragStart.pivotPos, multiDragStart.pivotQuat, multiDragStart.pivotScale);
  const currentPivotMatrix = new THREE.Matrix4().compose(multiPivot.position, multiPivot.quaternion, multiPivot.scale);
  const startInverse = new THREE.Matrix4().copy(startPivotMatrix).invert();
  const deltaMatrix = new THREE.Matrix4().multiplyMatrices(currentPivotMatrix, startInverse);
  multiDragStart.objects.forEach((o) => {
    const startObjMatrix = new THREE.Matrix4().compose(o.pos, o.quat, o.scale);
    const newMatrix = new THREE.Matrix4().multiplyMatrices(deltaMatrix, startObjMatrix);
    const pos = new THREE.Vector3(), quat = new THREE.Quaternion(), scale = new THREE.Vector3();
    newMatrix.decompose(pos, quat, scale);
    o.rec.object3D.position.copy(pos);
    o.rec.object3D.quaternion.copy(quat);
    o.rec.object3D.scale.copy(scale);
  });
}

// Reflejo (escala negativa) de la selección actual alrededor de su centro — un solo objeto se
// refleja sobre sí mismo; un grupo/multi-selección se refleja como conjunto (posiciones relativas
// incluidas), ideal para construir la mitad simétrica de un edificio a partir de una copia.
function mirrorSelected(axis) {
  const recs = selectedRecs();
  if (!recs.length) return;
  pushUndo();
  const center = new THREE.Vector3();
  recs.forEach((r) => center.add(r.object3D.position));
  center.divideScalar(recs.length);
  const sv = axis === "x" ? [-1, 1, 1] : axis === "y" ? [1, -1, 1] : [1, 1, -1];
  const mirrorMat = new THREE.Matrix4().makeScale(sv[0], sv[1], sv[2]);
  const toOrigin = new THREE.Matrix4().makeTranslation(-center.x, -center.y, -center.z);
  const backFromOrigin = new THREE.Matrix4().makeTranslation(center.x, center.y, center.z);
  const fullMirror = new THREE.Matrix4().multiplyMatrices(backFromOrigin, new THREE.Matrix4().multiplyMatrices(mirrorMat, toOrigin));
  recs.forEach((rec) => {
    const oldMatrix = new THREE.Matrix4().compose(rec.object3D.position, rec.object3D.quaternion, rec.object3D.scale);
    const newMatrix = new THREE.Matrix4().multiplyMatrices(fullMirror, oldMatrix);
    const pos = new THREE.Vector3(), quat = new THREE.Quaternion(), scale = new THREE.Vector3();
    newMatrix.decompose(pos, quat, scale);
    rec.object3D.position.copy(pos);
    rec.object3D.quaternion.copy(quat);
    rec.object3D.scale.copy(scale);
    rec.object3D.userData.__origin = { pos: pos.clone(), quat: quat.clone() };
    recomputeCheckpoints(rec);
  });
  recomputeTimelineDuration();
  updateGizmoAttachment(); // el centro del grupo cambia tras reflejar objetos individuales alrededor de un eje distinto a su propio centro; re-sincroniza el gizmo/pivote para evitar que quede "descolgado" en la posición antigua
  renderHierarchy();
  renderProps();
  logInfo("Reflejo aplicado en el eje " + axis.toUpperCase() + ".");
}
document.getElementById("btnMirrorX").addEventListener("click", () => mirrorSelected("x"));
document.getElementById("btnMirrorY").addEventListener("click", () => mirrorSelected("y"));
document.getElementById("btnMirrorZ").addEventListener("click", () => mirrorSelected("z"));

const hemi = new THREE.HemisphereLight(0xdfe8ff, 0x2a2416, 0.9);
scene.add(hemi);
const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
dirLight.position.set(6, 10, 4);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048, 2048);
dirLight.shadow.camera.left = -15;
dirLight.shadow.camera.right = 15;
dirLight.shadow.camera.top = 15;
dirLight.shadow.camera.bottom = -15;
scene.add(dirLight);

let groundGeo = new THREE.PlaneGeometry(40, 40);
const groundMat = new THREE.MeshStandardMaterial({ color: 0x1c2029, roughness: 1 });
let ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);
let grid = new THREE.GridHelper(40, 40, 0x333947, 0x21242e);
scene.add(grid);

// Límite del escenario: la mitad del suelo, con un pequeño margen para no dejar salir al jugador
// justo por el borde visual. Configurable (antes era un ±19 fijo sin relación con el tamaño real del suelo).
function sceneHalfExtent() {
  return Math.max(5, ((sceneEnvironment.groundSize || 40) / 2) - 1);
}
function resizeGroundAndBounds() {
  const size = Math.max(10, sceneEnvironment.groundSize || 40);
  scene.remove(ground); groundGeo.dispose();
  groundGeo = new THREE.PlaneGeometry(size, size);
  ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  scene.remove(grid); grid.geometry.dispose(); grid.material.dispose();
  grid = new THREE.GridHelper(size, size, 0x333947, 0x21242e);
  scene.add(grid);
}

/* =========================================================================
   AMBIENTE DEL ESCENARIO (color de fondo, color del suelo, imagen de horizonte)
   ========================================================================= */
let sceneEnvironment = {
  bgColor: "#0a0b0f", groundColor: "#1c2029", horizonBase64: null, horizonFileName: null, groundSize: 40, fogFar: 60,
  sunColor: "#ffffff", sunIntensity: 1.4, sunElevationDeg: 54, sunAzimuthDeg: 56, // el "Sol" -- la luz direccional global
  sunOrientationOffsetDeg: 0, // solo en modo ciclo/hora real: gira el recorrido del sol respecto al escenario construido
  sunMode: "manual", dayDurationMin: 10, // "manual" (fijo) | "cycle" (ciclo con esta duración) | "realtime" (según el reloj real)
  latitudeDeg: 40, // solo para "realtime": da mas o menos duracion al dia segun la epoca del año (40 ~ España)
  nightSkyEnabled: false, skyDateMode: "auto", skyManualDate: null, skyManualTime: "22:00", // boveda celeste nocturna (estrellas y Luna reales), opcional
  skyLongitudeDeg: -3.7, skyUtcOffsetHours: 1, moonTextureBase64: null, moonTextureFileName: null,
  nightBgColor: "#050912", // color de fondo/niebla cuando el Sol esta bajo (ver applyNightTint) -- ignorado si hay imagen de horizonte
};
let horizonTexture = null;
let dayCycleClock = 0; // segundos reales acumulados desde que empezó el ciclo actual (solo se usa en modo "cycle")
let dayCycleTotalSec = 0; // igual que dayCycleClock pero SIN dar la vuelta -- cuenta el total de segundos reales desde que empezó el modo "cycle", para saber cuántos "días" simulados han pasado (lo usa simulatedSkyDate())

// Convierte altura (elevación sobre el horizonte, 0-90°) y acimut (giro alrededor del escenario,
// 0-360°) en una posición xyz -- así se puede razonar sobre "dónde está el sol" con dos ángulos en
// vez de tres coordenadas sueltas, igual que se haría con la posición real del sol en el cielo.
function sunPositionFromAngles(elevationDeg, azimuthDeg, radius) {
  const elev = deg2rad(elevationDeg), azim = deg2rad(azimuthDeg);
  const r = radius || 12;
  return {
    x: r * Math.cos(elev) * Math.sin(azim),
    y: r * Math.sin(elev),
    z: r * Math.cos(elev) * Math.cos(azim),
  };
}

// Convierte una hora del día (0-24, con decimales) en la altura/acimut del sol y un factor de
// intensidad que se apaga suavemente cerca del horizonte (amanecer/atardecer) sin llegar nunca a
// negro total de noche (deja un 8% de luz -- luna/cielo nocturno simulados con la misma luz).
function sunAnglesFromHour(hour) {
  const angle = (2 * Math.PI * (hour - 6)) / 24;
  const elevationDeg = 80 * Math.sin(angle);
  const azimuthDeg = ((hour / 24) * 360) % 360;
  const intensityFactor = clamp((elevationDeg + 10) / 20, 0.08, 1);
  return { elevationDeg, azimuthDeg, intensityFactor };
}

// Posición astronómica real del sol (aproximación estándar de declinación solar + ángulo horario),
// para que el modo "hora real del sistema" tenga en cuenta la ÉPOCA DEL AÑO -- días largos en
// verano, cortos en invierno -- y no siempre un día de 12h fijas como sunAnglesFromHour(). No
// corrige huso horario/ecuación del tiempo (no es una herramienta de navegación, solo ambiente).
function sunAnglesFromRealDateTime(date, latitudeDeg) {
  const lat = deg2rad(latitudeDeg != null ? latitudeDeg : 40);
  const startOfYear = new Date(date.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((date - startOfYear) / 86400000);
  const decl = deg2rad(23.44 * Math.sin(deg2rad((360 / 365) * (dayOfYear - 81))));
  const hour = date.getHours() + date.getMinutes() / 60 + date.getSeconds() / 3600;
  const hourAngle = deg2rad(15 * (hour - 12));
  const elevRad = Math.asin(Math.sin(lat) * Math.sin(decl) + Math.cos(lat) * Math.cos(decl) * Math.cos(hourAngle));
  const elevationDeg = (elevRad * 180) / Math.PI;
  const azimuthDeg = ((hour / 24) * 360) % 360; // giro simple a lo largo del día -- no hace falta precisión geográfica en una escena ficticia
  const intensityFactor = clamp((elevationDeg + 10) / 20, 0.08, 1);
  return { elevationDeg, azimuthDeg, intensityFactor };
}

// Devuelve la "hora del día" actual (0-24) según el modo del sol, o null en modo manual (no aplica).
// En modo "cycle" avanza un reloj interno propio (dt de este frame) que da la vuelta completa cada
// dayDurationMin minutos reales; en modo "realtime" simplemente lee el reloj del sistema.
function computeSunHourOfDay(dt) {
  if (sceneEnvironment.sunMode === "realtime") {
    const now = new Date();
    return now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600;
  }
  if (sceneEnvironment.sunMode === "cycle") {
    dayCycleClock += dt;
    dayCycleTotalSec += dt;
    const dayLenSec = Math.max(10, (sceneEnvironment.dayDurationMin || 10) * 60);
    dayCycleClock = dayCycleClock % dayLenSec;
    return (dayCycleClock / dayLenSec) * 24;
  }
  return null;
}

// Se llama en cada frame (tanto en el editor como en Modo jugar). En modo manual no hace nada --
// ahí manda applyEnvironment() con los valores fijos de los sliders. En modo "cycle" usa el reloj
// interno simplificado (día siempre de 12h). En modo "realtime" usa la posición astronómica real
// del sol para la fecha de hoy (respeta la época del año: días largos en verano, cortos en invierno).
function updateSunCycle(dt) {
  if (!sceneEnvironment.sunMode || sceneEnvironment.sunMode === "manual") return;
  let result;
  if (sceneEnvironment.sunMode === "realtime") {
    result = sunAnglesFromRealDateTime(new Date(), sceneEnvironment.latitudeDeg);
  } else {
    const hour = computeSunHourOfDay(dt);
    if (hour == null) return;
    result = sunAnglesFromHour(hour);
  }
  const { elevationDeg, intensityFactor } = result;
  // Orientación del escenario: en ciclo/hora real el acimut lo marca el reloj, no un slider directo
  // (a diferencia del modo manual) -- este desfase gira ese recorrido entero para elegir por qué
  // lado del escenario CONSTRUIDO amanece, sin tener que rotar cada objeto.
  const azimuthDeg = (result.azimuthDeg + (sceneEnvironment.sunOrientationOffsetDeg || 0)) % 360;
  dirLight.color.set(sceneEnvironment.sunColor || "#ffffff");
  dirLight.intensity = (sceneEnvironment.sunIntensity != null ? sceneEnvironment.sunIntensity : 1.4) * intensityFactor;
  const sunPos = sunPositionFromAngles(elevationDeg, azimuthDeg);
  dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);
  applyNightTint(elevationDeg);
}

// Da la impresión de que ha anochecido SIN tocar el color de fondo/niebla ni la imagen de horizonte:
// un velo azul marino semitransparente sobre el propio visor (mezcla "multiply", solo oscurece y
// azulea lo que hay debajo, nunca lo tapa del todo). Se intensifica cuanto más bajo está el sol,
// empezando un poco antes del atardecer (10°) y llegando al máximo bien entrada la noche (-20°).
function nightTintFactorFromElevation(elevationDeg) {
  return clamp((10 - elevationDeg) / 30, 0, 1);
}
// Mezcla dos colores hex ("#rrggbb") con un factor 0-1 (0 = colorA, 1 = colorB) -- para el
// color de fondo/niebla día/noche (ver applyNightTint), sin depender de ninguna librería.
function lerpColorHex(hexA, hexB, t) {
  const a = parseInt((hexA || "#000000").replace('#', ''), 16), b = parseInt((hexB || "#000000").replace('#', ''), 16);
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  const r = Math.round(ar + (br - ar) * t), g = Math.round(ag + (bg - ag) * t), bl = Math.round(ab + (bb - ab) * t);
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + bl).toString(16).slice(1);
}
function applyNightTint(elevationDeg) {
  const factor = nightTintFactorFromElevation(elevationDeg);
  const el = document.getElementById("nightTintOverlay");
  if (el) el.style.opacity = String(factor * 0.55);
  // El color de fondo/niebla también vira hacia un azul profundo de noche (no solo se oscurece
  // con el velo de arriba) -- salvo que haya una imagen de horizonte fija, que no tiene un día/
  // noche propio y se dejaría rara mezclada con un fondo que cambia de color detrás.
  if (!sceneEnvironment.horizonBase64) {
    const blended = lerpColorHex(sceneEnvironment.bgColor || "#0a0b0f", sceneEnvironment.nightBgColor || "#050912", factor);
    scene.background = new THREE.Color(blended);
    scene.fog.color.set(blended);
  }
}

function applyEnvironment() {
  if (sceneEnvironment.horizonBase64 && horizonTexture) {
    scene.background = horizonTexture;
  } else {
    scene.background = new THREE.Color(sceneEnvironment.bgColor);
  }
  scene.fog.color.set(sceneEnvironment.bgColor);
  scene.fog.far = Math.max(10, sceneEnvironment.fogFar || 60);
  scene.fog.near = scene.fog.far / 3; // misma proporción que el 20/60 original
  groundMat.color.set(sceneEnvironment.groundColor);
  dirLight.color.set(sceneEnvironment.sunColor || "#ffffff");
  // En modo ciclo/hora real, updateSunCycle() ya se encarga de intensidad, posición y tinte cada
  // frame -- si applyEnvironment() los tocara aquí también (p.ej. al cambiar la niebla) pisaría por
  // un instante la posición/tinte correctos con los valores fijos de los sliders manuales.
  if (!sceneEnvironment.sunMode || sceneEnvironment.sunMode === "manual") {
    dirLight.intensity = sceneEnvironment.sunIntensity != null ? sceneEnvironment.sunIntensity : 1.4;
    const elevationDeg = sceneEnvironment.sunElevationDeg != null ? sceneEnvironment.sunElevationDeg : 54;
    const sunPos = sunPositionFromAngles(elevationDeg, sceneEnvironment.sunAzimuthDeg != null ? sceneEnvironment.sunAzimuthDeg : 56);
    dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);
    applyNightTint(elevationDeg);
  }
}

function updateEnvironmentUI() {
  document.getElementById("envBgColor").value = sceneEnvironment.bgColor;
  document.getElementById("envNightBgColor").value = sceneEnvironment.nightBgColor || "#050912";
  document.getElementById("envGroundColor").value = sceneEnvironment.groundColor;
  document.getElementById("envGroundSize").value = sceneEnvironment.groundSize || 40;
  document.getElementById("envFogFar").value = sceneEnvironment.fogFar || 60;
  document.getElementById("envSunColor").value = sceneEnvironment.sunColor || "#ffffff";
  document.getElementById("envSunIntensity").value = sceneEnvironment.sunIntensity != null ? sceneEnvironment.sunIntensity : 1.4;
  document.getElementById("envSunElevation").value = sceneEnvironment.sunElevationDeg != null ? sceneEnvironment.sunElevationDeg : 54;
  document.getElementById("envSunAzimuth").value = sceneEnvironment.sunAzimuthDeg != null ? sceneEnvironment.sunAzimuthDeg : 56;
  document.getElementById("envSunMode").value = sceneEnvironment.sunMode || "manual";
  document.getElementById("envSunDayDuration").value = sceneEnvironment.dayDurationMin || 10;
  document.getElementById("envSunLatitude").value = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
  document.getElementById("envSunOrientation").value = sceneEnvironment.sunOrientationOffsetDeg || 0;
  updateSunModeUI();
  updateNightSkyUI();
  document.getElementById("envHorizonInfo").textContent = sceneEnvironment.horizonFileName ? ("Archivo actual: " + sceneEnvironment.horizonFileName) : "Sin imagen de horizonte todavía.";
  document.getElementById("envHorizonRemove").style.display = sceneEnvironment.horizonBase64 ? "inline-block" : "none";
}

// Muestra u oculta los sub-bloques del Sol según el modo elegido (manual / ciclo / hora real).
function updateSunModeUI() {
  const mode = sceneEnvironment.sunMode || "manual";
  document.getElementById("envSunManualWrap").style.display = mode === "manual" ? "" : "none";
  document.getElementById("envSunOrientationWrap").style.display = mode === "manual" ? "none" : "";
  document.getElementById("envSunCycleWrap").style.display = mode === "cycle" ? "" : "none";
  document.getElementById("envSunRealtimeWrap").style.display = mode === "realtime" ? "" : "none";
}

document.getElementById("envBgColor").addEventListener("input", (e) => {
  sceneEnvironment.bgColor = e.target.value;
  applyEnvironment();
});
document.getElementById("envNightBgColor").addEventListener("input", (e) => {
  sceneEnvironment.nightBgColor = e.target.value;
  applyEnvironment();
});
document.getElementById("envGroundColor").addEventListener("input", (e) => {
  sceneEnvironment.groundColor = e.target.value;
  applyEnvironment();
});
document.getElementById("envGroundSize").addEventListener("input", (e) => {
  sceneEnvironment.groundSize = Math.max(10, parseFloat(e.target.value) || 40);
  resizeGroundAndBounds();
  applyEnvironment();
});
document.getElementById("envFogFar").addEventListener("input", (e) => {
  sceneEnvironment.fogFar = Math.max(10, parseFloat(e.target.value) || 60);
  applyEnvironment();
});
document.getElementById("envSunColor").addEventListener("input", (e) => {
  sceneEnvironment.sunColor = e.target.value;
  applyEnvironment();
});
document.getElementById("envSunIntensity").addEventListener("input", (e) => {
  sceneEnvironment.sunIntensity = Math.max(0, parseFloat(e.target.value) || 0);
  applyEnvironment();
});
document.getElementById("envSunElevation").addEventListener("input", (e) => {
  sceneEnvironment.sunElevationDeg = parseFloat(e.target.value) || 54;
  applyEnvironment();
});
document.getElementById("envSunAzimuth").addEventListener("input", (e) => {
  sceneEnvironment.sunAzimuthDeg = parseFloat(e.target.value) || 56;
  applyEnvironment();
});
document.getElementById("envSunMode").addEventListener("change", (e) => {
  sceneEnvironment.sunMode = e.target.value;
  dayCycleClock = 0; dayCycleTotalSec = 0; // al cambiar de modo reiniciamos el reloj del ciclo, para no arrancar a media tarde
  updateSunModeUI();
  applyEnvironment();
});
document.getElementById("envSunDayDuration").addEventListener("input", (e) => {
  sceneEnvironment.dayDurationMin = Math.max(0.5, parseFloat(e.target.value) || 10);
});
document.getElementById("envSunLatitude").addEventListener("input", (e) => {
  sceneEnvironment.latitudeDeg = clamp(parseFloat(e.target.value) || 40, -70, 70);
});
document.getElementById("envSunOrientation").addEventListener("input", (e) => {
  sceneEnvironment.sunOrientationOffsetDeg = ((parseFloat(e.target.value) || 0) % 360 + 360) % 360;
});
document.getElementById("envHorizonTrigger").addEventListener("click", () => document.getElementById("envHorizonInput").click());
document.getElementById("envHorizonInput").addEventListener("change", (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    const img = new Image();
    img.onload = () => {
      const tex = new THREE.Texture(img);
      tex.needsUpdate = true;
      if (horizonTexture) horizonTexture.dispose();
      horizonTexture = tex;
      sceneEnvironment.horizonBase64 = dataUrl;
      sceneEnvironment.horizonFileName = f.name;
      applyEnvironment();
      updateEnvironmentUI();
    };
    img.onerror = () => alertBox("No se pudo cargar la imagen " + f.name + ".", "warn");
    img.src = dataUrl;
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + f.name + ".", "warn");
  reader.readAsDataURL(f);
});
document.getElementById("envHorizonRemove").addEventListener("click", () => {
  sceneEnvironment.horizonBase64 = null;
  sceneEnvironment.horizonFileName = null;
  if (horizonTexture) { horizonTexture.dispose(); horizonTexture = null; }
  applyEnvironment();
  updateEnvironmentUI();
});


/* =========================================================================
   BOVEDA CELESTE NOCTURNA (estrellas y Luna reales, opcional por proyecto)
   =========================================================================
   Catalogo de ~757 estrellas reales (posiciones J2000 en grados, RA/Dec) que
   forman las lineas clasicas de las 88 constelaciones IAU, mas los propios
   segmentos de esas lineas -- adaptado de d3-celestial (c) Olaf Frohn, licencia
   MIT, a su vez sobre datos del catalogo Hipparcos. NIGHT_SKY_STARS es un
   array plano [ra,dec,mag, ra,dec,mag, ...]; "mag" aqui es una magnitud
   aproximada por rango de brillo de la CONSTELACION (1/2/3), no una fotometria
   exacta estrella a estrella -- ver README para como ampliarlo. Reservado
   tambien NIGHT_SKY_CONSTELLATIONS (nombre en espanol + segmentos por indice)
   para una futura identificacion de constelaciones con el puntero.
*/
var NIGHT_SKY_STARS = [30.975,42.33,2.0,17.433,35.621,2.0,9.832,30.861,2.0,2.097,29.09,2.0,14.302,23.418,2.0,11.835,24.267,2.0,9.639,29.312,2.0,9.22,33.719,2.0,354.534,43.268,2.0,345.48,42.326,2.0,355.102,44.334,2.0,354.391,46.458,2.0,14.188,38.499,2.0,12.454,41.079,2.0,17.375,47.242,2.0,24.498,48.628,2.0,356.509,46.42,2.0,142.311,-35.951,3.6,156.788,-31.068,3.6,164.179,-37.138,3.6,221.965,-79.045,3.6,245.087,-78.696,3.6,250.769,-77.517,3.6,248.363,-78.897,3.6,311.919,-9.496,2.8,313.163,-8.983,2.8,322.89,-5.571,2.8,331.446,-0.32,2.8,335.414,-1.387,2.8,337.208,-0.02,2.8,338.839,-0.117,2.8,343.154,-7.58,2.8,349.476,-9.182,2.8,347.362,-21.172,2.8,331.609,-13.87,2.8,334.209,-7.783,2.8,336.319,1.377,2.8,350.743,-20.101,2.8,355.441,-17.817,2.8,296.565,10.613,2.0,297.696,8.868,2.0,298.828,6.407,2.0,302.826,-0.822,2.0,298.118,1.006,2.0,291.375,3.115,2.0,286.353,13.864,2.0,286.562,-4.883,2.0,261.349,-56.378,3.6,262.775,-60.684,3.6,252.447,-59.041,3.6,254.655,-55.99,3.6,254.896,-53.16,3.6,262.96,-49.876,3.6,261.325,-55.53,3.6,42.496,27.261,2.0,31.793,23.462,2.0,28.66,20.808,2.0,28.383,19.294,2.0,89.882,44.947,2.0,79.172,45.998,2.0,76.629,41.234,2.0,74.248,33.166,2.0,81.573,28.608,2.0,89.93,37.213,2.0,89.882,54.285,2.0,75.492,43.823,2.0,75.62,41.076,2.0,206.816,17.457,2.0,208.671,18.398,2.0,213.915,19.182,2.0,217.958,30.371,2.0,218.019,38.308,2.0,225.487,40.391,2.0,228.876,33.315,2.0,221.247,27.074,2.0,220.287,13.728,2.0,214.096,46.088,2.0,213.366,51.788,2.0,216.299,51.851,2.0,67.709,-44.954,3.6,70.141,-41.864,3.6,70.514,-37.144,3.6,76.102,-35.483,3.6,74.322,53.752,2.8,75.855,60.442,2.8,73.513,66.343,2.8,57.59,71.332,2.8,57.38,65.526,2.8,52.267,59.94,2.8,94.712,69.32,2.8,105.017,76.977,2.8,134.622,11.858,2.8,131.171,18.154,2.8,130.821,21.468,2.8,131.667,28.765,2.8,124.129,9.185,2.8,194.002,38.315,2.8,188.436,41.358,2.8,95.675,-17.956,2.0,101.287,-16.716,2.0,105.756,-23.833,2.0,107.098,-26.393,2.0,105.43,-27.935,2.0,104.656,-28.972,2.0,95.078,-30.063,2.0,111.024,-29.303,2.0,104.034,-17.054,2.0,105.94,-15.633,2.0,103.547,-12.039,2.0,114.826,5.225,2.8,111.788,8.289,2.8,304.412,-12.508,2.8,305.253,-14.781,2.8,307.215,-17.814,2.8,311.524,-25.271,2.8,312.955,-26.919,2.8,321.667,-22.411,2.8,326.76,-16.127,2.8,325.023,-16.662,2.8,320.562,-16.834,2.8,316.487,-17.233,2.8,99.44,-43.196,2.0,95.988,-52.696,2.0,138.3,-69.717,2.0,153.434,-70.038,2.0,160.739,-64.394,2.0,158.006,-61.685,2.0,154.271,-61.332,2.0,139.273,-59.275,2.0,125.629,-59.51,2.0,119.195,-52.982,2.0,122.383,-47.337,2.0,131.176,-54.709,2.0,166.635,-62.424,2.0,167.142,-61.947,2.0,168.15,-60.318,2.0,167.148,-58.975,2.0,163.374,-58.853,2.0,28.599,63.67,2.0,21.454,60.235,2.0,14.177,60.717,2.0,10.127,56.537,2.0,2.295,59.15,2.0,170.252,-54.491,2.0,182.09,-50.722,2.0,187.01,-50.231,2.0,190.379,-48.96,2.0,204.972,-53.466,2.0,208.885,-47.288,2.0,207.404,-42.474,2.0,207.376,-41.688,2.0,211.671,-36.37,2.0,218.877,-42.158,2.0,224.79,-42.104,2.0,200.149,-36.712,2.0,219.896,-60.837,2.0,210.956,-60.373,2.0,182.913,-52.368,2.0,172.942,-59.442,2.0,307.395,62.994,2.8,311.322,61.839,2.8,319.645,62.586,2.8,325.877,58.78,2.8,333.759,57.044,2.8,332.714,58.201,2.8,337.293,58.415,2.8,342.42,66.2,2.8,354.837,77.632,2.8,322.165,70.561,2.8,40.825,3.236,2.0,38.969,5.593,2.0,37.04,8.46,2.0,41.236,10.114,2.0,44.929,8.907,2.0,45.57,4.09,2.0,39.871,0.329,2.0,34.837,-2.978,2.0,27.865,-10.335,2.0,26.017,-15.938,2.0,10.897,-17.987,2.0,4.857,-8.824,2.0,17.148,-10.182,2.0,21.006,-8.183,2.0,124.632,-76.92,3.6,158.867,-78.608,3.6,161.318,-80.47,3.6,184.587,-79.312,3.6,179.907,-78.222,3.6,229.379,-58.801,3.6,220.627,-64.975,3.6,230.844,-59.321,3.6,95.528,-33.436,3.6,87.74,-35.768,3.6,84.912,-34.074,3.6,82.803,-35.471,3.6,89.787,-42.815,3.6,197.497,17.529,3.6,197.968,27.878,3.6,186.734,28.268,3.6,284.681,-37.107,3.6,286.605,-37.063,3.6,287.368,-37.904,3.6,287.507,-39.341,3.6,287.087,-40.497,3.6,285.779,-42.095,3.6,282.396,-43.434,3.6,278.376,-42.312,3.6,233.232,31.359,2.8,231.957,29.106,2.8,233.672,26.715,2.8,235.686,26.296,2.8,237.399,26.068,2.8,239.397,26.878,2.8,240.361,29.851,2.8,182.103,-24.729,3.6,182.531,-22.62,3.6,183.952,-17.542,3.6,187.466,-16.515,3.6,188.597,-23.397,3.6,174.171,-9.802,3.6,171.153,-10.859,3.6,169.835,-14.778,3.6,164.944,-18.299,3.6,167.915,-22.826,3.6,170.841,-18.78,3.6,171.22,-17.684,3.6,176.191,-18.351,3.6,179.004,-17.151,3.6,191.93,-59.689,2.8,183.786,-58.749,2.8,186.65,-63.099,2.8,187.792,-57.113,2.8,318.234,30.227,2.0,311.553,33.97,2.0,305.557,40.257,2.0,296.244,45.131,2.0,292.427,51.73,2.0,289.276,53.368,2.0,310.358,45.28,2.0,299.077,35.083,2.0,292.68,27.96,2.0,308.303,11.303,3.6,309.387,14.595,3.6,309.909,15.912,3.6,311.662,16.124,3.6,310.865,15.075,3.6,64.007,-51.487,3.6,68.499,-55.045,3.6,83.406,-62.49,3.6,86.193,-65.736,3.6,88.525,-63.09,3.6,76.378,-57.473,3.6,268.382,56.873,2.8,269.151,51.489,2.8,262.608,52.301,2.8,263.067,55.173,2.8,288.139,67.662,2.8,275.189,71.338,2.8,257.197,65.715,2.8,245.998,61.514,2.8,240.472,58.565,2.8,231.232,58.966,2.8,211.097,64.376,2.8,188.371,69.788,2.8,172.851,69.331,2.8,275.264,72.733,2.8,297.043,70.268,2.8,318.956,5.248,3.6,318.62,10.007,3.6,317.585,10.132,3.6,76.962,-5.086,2.0,71.376,-3.255,2.0,69.08,-3.353,2.0,62.966,-6.838,2.0,59.507,-13.508,2.0,56.536,-12.102,2.0,55.812,-9.763,2.0,53.233,-9.458,2.0,44.107,-8.898,2.0,41.031,-13.859,2.0,41.276,-18.573,2.0,45.598,-23.625,2.0,49.879,-21.758,2.0,53.447,-21.633,2.0,56.712,-23.25,2.0,68.888,-30.562,2.0,66.009,-34.017,2.0,64.474,-33.798,2.0,57.364,-36.2,2.0,54.274,-40.275,2.0,49.982,-43.07,2.0,44.565,-40.305,2.0,40.167,-39.855,2.0,36.746,-47.704,2.0,34.127,-51.512,2.0,28.989,-51.609,2.0,24.428,-57.237,2.0,48.019,-28.988,3.6,42.273,-32.406,3.6,31.123,-29.297,3.6,93.719,22.507,2.0,95.74,22.514,2.0,100.983,25.131,2.0,107.785,30.245,2.0,113.649,31.888,2.0,116.329,28.026,2.0,113.981,26.896,2.0,110.031,21.982,2.0,106.027,20.57,2.0,99.428,16.399,2.0,101.322,12.896,2.0,109.523,16.54,2.0,345.22,-52.754,3.6,342.139,-51.317,3.6,340.667,-46.885,3.6,337.439,-43.749,3.6,332.058,-46.961,3.6,337.317,-43.496,3.6,333.904,-41.347,3.6,331.529,-39.543,3.6,328.482,-37.365,3.6,245.48,19.153,2.8,247.555,21.49,2.8,250.322,31.603,2.8,250.724,38.922,2.8,248.526,42.437,2.8,244.935,46.313,2.8,242.192,44.935,2.8,238.169,42.452,2.8,255.072,30.926,2.8,258.762,36.809,2.8,269.063,37.251,2.8,260.921,37.146,2.8,258.758,24.839,2.8,266.615,27.721,2.8,269.441,29.248,2.8,271.886,28.762,2.8,258.662,14.39,2.8,63.501,-42.294,3.6,40.639,-50.8,3.6,39.352,-52.543,3.6,40.165,-54.55,3.6,45.903,-59.738,3.6,44.699,-64.071,3.6,131.694,6.419,2.8,132.108,5.838,2.8,130.806,3.399,2.8,129.689,3.341,2.8,129.414,5.704,2.8,133.848,5.946,2.8,138.591,2.314,2.8,144.964,-1.143,2.8,141.897,-8.659,2.8,147.87,-14.847,2.8,152.647,-12.354,2.8,156.523,-16.836,2.8,162.406,-16.194,2.8,173.25,-31.858,2.8,178.227,-33.908,2.8,199.73,-23.172,2.8,211.593,-26.682,2.8,222.572,-27.96,2.8,6.438,-77.254,3.6,56.81,-74.239,3.6,39.897,-68.267,3.6,35.437,-68.659,3.6,28.734,-67.647,3.6,29.692,-61.57,3.6,309.392,-47.291,3.6,311.01,-51.921,3.6,313.702,-58.454,3.6,329.48,-54.993,3.6,319.967,-53.449,3.6,335.89,52.229,3.6,337.823,50.282,3.6,337.383,47.707,3.6,335.256,46.537,3.6,337.622,43.123,3.6,340.129,44.276,3.6,336.129,49.476,3.6,333.47,39.715,3.6,333.992,37.749,3.6,152.093,11.967,2.0,151.833,16.763,2.0,154.993,19.841,2.0,168.527,20.524,2.0,177.265,14.572,2.0,168.56,15.43,2.0,154.173,23.417,2.0,148.191,26.007,2.0,146.463,23.774,2.0,151.857,35.245,3.6,156.478,33.796,3.6,163.328,34.215,3.6,156.971,36.707,3.6,143.556,36.398,3.6,91.539,-14.935,3.6,89.101,-14.168,3.6,86.739,-14.822,3.6,83.183,-17.822,3.6,78.233,-16.206,3.6,76.365,-22.371,3.6,82.061,-20.759,3.6,86.116,-22.448,3.6,87.83,-20.879,3.6,78.308,-12.941,3.6,79.894,-13.177,3.6,226.018,-25.282,2.8,222.72,-16.042,2.8,229.252,-9.383,2.8,233.882,-14.79,2.8,234.256,-28.135,2.8,234.664,-29.778,2.8,237.74,-33.627,3.6,234.942,-34.412,3.6,230.452,-36.261,3.6,230.343,-40.648,3.6,224.633,-43.134,3.6,220.482,-47.388,3.6,228.071,-52.099,3.6,229.633,-47.875,3.6,230.67,-44.69,3.6,233.785,-41.167,3.6,240.031,-38.397,3.6,241.648,-36.802,3.6,94.906,59.011,3.6,104.319,58.423,3.6,111.678,49.212,3.6,125.709,43.188,3.6,135.16,41.783,3.6,139.711,36.803,3.6,140.264,34.393,3.6,281.193,37.605,2.8,281.095,39.613,2.8,279.235,38.784,2.8,283.626,36.899,2.8,284.736,32.69,2.8,282.52,33.363,2.8,92.56,-74.753,3.6,82.971,-76.341,3.6,73.797,-74.937,3.6,75.679,-71.314,3.6,312.492,-33.78,3.6,312.121,-43.989,3.6,320.19,-40.809,3.6,319.485,-32.172,3.6,315.323,-32.258,3.6,115.312,-9.551,2.8,122.148,-2.984,2.8,107.966,-0.493,2.8,97.204,-7.033,2.8,93.714,-6.275,2.8,101.965,2.412,2.8,95.942,4.593,2.8,98.226,7.333,2.8,100.244,9.896,2.8,176.402,-66.729,3.6,184.393,-67.961,3.6,189.296,-69.136,3.6,191.57,-68.108,3.6,195.568,-71.549,3.6,188.117,-72.133,3.6,241.623,-45.173,3.6,246.796,-47.555,3.6,244.96,-50.156,3.6,240.804,-49.23,3.6,216.73,-83.668,3.6,341.515,-81.382,3.6,325.369,-77.39,3.6,269.757,-9.774,2.8,266.973,2.707,2.8,265.868,4.567,2.8,263.734,12.56,2.8,254.417,9.375,2.8,247.728,1.984,2.8,243.586,-3.694,2.8,244.58,-4.692,2.8,249.29,-10.567,2.8,257.594,-15.725,2.8,247.785,-16.613,2.8,246.756,-18.456,2.8,246.026,-20.037,2.8,246.396,-23.447,2.8,260.502,-25.0,2.8,261.839,-29.867,2.8,91.893,14.768,2.0,88.596,20.276,2.0,90.98,20.139,2.0,92.985,14.209,2.0,90.596,9.647,2.0,88.793,7.407,2.0,81.283,6.35,2.0,73.724,10.151,2.0,74.637,1.714,2.0,73.563,2.441,2.0,72.802,5.605,2.0,72.46,6.961,2.0,72.653,8.9,2.0,74.093,13.514,2.0,76.142,15.404,2.0,77.425,15.597,2.0,78.635,-8.202,2.0,81.119,-2.397,2.0,83.002,-0.299,2.0,83.784,9.934,2.0,85.19,-1.943,2.0,86.939,-9.67,2.0,84.053,-1.202,2.0,306.412,-56.735,2.8,311.24,-66.203,2.8,302.182,-66.182,2.8,283.054,-62.188,2.8,275.807,-61.494,2.8,272.145,-63.669,2.8,266.433,-64.724,2.8,280.759,-71.428,2.8,300.148,-72.91,2.8,321.611,-65.366,2.8,332.497,33.178,2.0,340.751,30.221,2.0,345.944,28.083,2.0,3.309,15.184,2.0,346.19,15.205,2.0,341.673,12.173,2.0,340.365,10.831,2.0,332.55,6.198,2.0,326.046,9.875,2.0,342.501,24.602,2.0,341.633,23.566,2.0,331.753,25.345,2.0,326.161,25.645,2.0,56.08,32.288,2.0,58.533,31.884,2.0,59.741,35.791,2.0,59.464,40.01,2.0,56.298,42.578,2.0,55.731,47.788,2.0,54.122,48.193,2.0,51.081,49.861,2.0,46.199,53.506,2.0,42.674,55.895,2.0,43.564,52.763,2.0,47.267,49.613,2.0,47.374,44.858,2.0,47.042,40.956,2.0,47.822,39.612,2.0,46.294,38.84,2.0,44.69,39.663,2.0,44.916,41.033,2.0,61.646,50.351,2.0,63.724,48.409,2.0,62.165,47.712,2.0,41.05,49.228,2.0,25.915,50.689,2.0,6.571,-42.306,2.8,16.521,-46.718,2.8,22.091,-43.318,2.8,22.813,-49.073,2.8,17.096,-55.246,2.8,2.353,-45.747,2.8,102.048,-61.941,3.6,87.457,-56.167,3.6,86.821,-51.066,3.6,18.437,24.584,2.8,17.915,30.09,2.8,19.867,27.264,2.8,17.863,21.035,2.8,22.871,15.346,2.8,26.349,9.158,2.8,30.512,2.764,2.8,28.389,3.188,2.8,25.358,5.488,2.8,22.546,6.144,2.8,18.433,7.575,2.8,15.736,7.89,2.8,12.171,7.585,2.8,359.828,6.863,2.8,354.988,5.626,2.8,351.992,6.379,2.8,350.086,5.381,2.8,349.291,3.282,2.8,351.733,1.256,2.8,355.512,1.78,2.8,356.598,3.487,2.8,345.969,3.82,2.8,340.164,-27.044,2.8,344.413,-29.622,2.8,343.987,-32.54,2.8,343.131,-32.876,2.8,337.876,-32.346,2.8,332.096,-32.989,2.8,326.237,-33.026,2.8,326.934,-30.898,2.8,109.286,-37.097,2.8,113.845,-28.369,2.8,114.708,-26.804,2.8,117.324,-24.86,2.8,119.215,-22.88,2.8,121.886,-24.304,2.8,120.896,-40.003,2.8,117.022,-25.937,2.8,115.952,-28.955,2.8,130.026,-35.308,3.6,130.898,-33.186,3.6,132.633,-27.71,3.6,63.606,-62.474,3.6,64.121,-59.302,3.6,59.687,-61.4,3.6,56.05,-64.807,3.6,295.024,18.014,3.6,296.847,18.534,3.6,299.689,19.492,3.6,295.262,17.476,3.6,274.407,-36.762,2.0,276.043,-34.385,2.0,275.249,-29.828,2.0,276.993,-25.422,2.0,273.441,-21.059,2.0,290.66,-44.459,2.0,290.972,-40.616,2.0,285.653,-29.88,2.0,281.414,-26.991,2.0,298.815,-41.868,2.0,299.934,-35.276,2.0,298.96,-26.299,2.0,294.177,-24.884,2.0,291.319,-24.509,2.0,288.885,-25.257,2.0,283.816,-26.297,2.0,271.452,-30.424,2.0,286.735,-27.67,2.0,286.171,-21.741,2.0,287.441,-21.024,2.0,289.409,-18.953,2.0,290.418,-17.847,2.0,290.432,-15.955,2.0,284.433,-21.107,2.0,283.542,-22.745,2.0,239.713,-26.114,2.0,240.083,-22.622,2.0,241.359,-19.805,2.0,245.297,-25.593,2.0,247.352,-26.432,2.0,248.971,-28.216,2.0,252.541,-34.293,2.0,252.968,-38.047,2.0,253.646,-42.361,2.0,258.038,-43.239,2.0,264.33,-42.998,2.0,266.896,-40.127,2.0,265.622,-39.03,2.0,263.402,-37.104,2.0,14.652,-29.357,3.6,357.231,-28.13,3.6,349.706,-32.532,3.6,353.243,-37.818,3.6,278.802,-8.244,3.6,281.794,-4.748,3.6,280.568,-9.053,3.6,277.299,-14.566,3.6,236.547,15.422,3.6,235.388,19.67,3.6,237.185,18.142,3.6,239.113,15.662,3.6,233.701,10.539,3.6,236.067,6.426,3.6,237.704,4.478,3.6,264.397,-15.399,3.6,270.77,-8.18,3.6,275.327,-2.899,3.6,284.055,4.204,3.6,151.984,-0.372,3.6,148.127,-8.105,3.6,157.37,-2.739,3.6,157.573,-0.637,3.6,84.411,21.142,2.0,68.98,16.509,2.0,67.166,15.871,2.0,64.948,15.628,2.0,65.734,17.543,2.0,67.154,19.18,2.0,60.17,12.49,2.0,51.792,9.733,2.0,60.789,5.989,2.0,51.203,9.029,2.0,54.218,0.402,2.0,272.807,-45.954,3.6,276.743,-45.968,3.6,277.208,-49.071,3.6,28.27,29.579,3.6,32.386,34.987,3.6,34.329,33.847,3.6,252.166,-69.028,2.8,238.786,-63.431,2.8,229.727,-68.68,2.8,334.625,-60.26,3.6,349.357,-58.236,3.6,7.886,-62.958,3.6,5.018,-64.875,3.6,359.979,-65.577,3.6,336.833,-64.966,3.6,183.857,57.033,2.0,165.932,61.751,2.0,165.46,56.382,2.0,178.458,53.695,2.0,193.507,55.96,2.0,200.981,54.925,2.0,206.885,49.313,2.0,176.513,47.779,2.0,169.62,33.094,2.0,169.547,31.531,2.0,167.416,44.498,2.0,155.582,41.499,2.0,154.274,42.914,2.0,142.882,63.062,2.0,127.566,60.718,2.0,147.747,59.039,2.0,148.026,54.064,2.0,143.214,51.677,2.0,134.802,48.042,2.0,135.906,47.157,2.0,236.015,77.794,2.8,244.376,75.755,2.8,230.182,71.834,2.8,222.676,74.156,2.8,251.493,82.037,2.8,263.054,86.587,2.8,37.955,89.264,2.8,140.528,-55.011,2.8,149.216,-54.568,2.8,161.692,-49.42,2.8,153.684,-42.122,2.8,142.675,-40.467,2.8,136.999,-43.433,2.8,176.465,6.529,2.0,177.674,1.765,2.0,184.976,-0.667,2.0,190.415,-1.449,2.0,197.488,-5.539,2.0,201.298,-11.161,2.0,214.004,-6.0,2.0,220.765,-5.658,2.0,195.544,10.959,2.0,193.901,3.397,2.0,203.673,-0.596,2.0,210.412,1.544,2.0,221.562,1.893,2.0,135.612,-66.396,3.6,126.434,-66.137,3.6,121.983,-68.617,3.6,109.208,-67.957,3.6,107.187,-70.499,3.6,289.054,21.39,3.6,292.176,24.665,3.6,298.365,24.08,3.6,300.275,27.754,3.6,303.942,27.814,3.6];
var NIGHT_SKY_CONSTELLATIONS = [{"id":"And","es":"Andr\u00f3meda","rank":"1","seg":[[0,1],[1,2],[2,3],[4,5],[5,6],[6,2],[2,7],[7,8],[8,9],[8,10],[10,11],[1,12],[12,13],[13,14],[14,15],[10,16]]},{"id":"Ant","es":"M\u00e1quina Neum\u00e1tica","rank":"3","seg":[[17,18],[18,19]]},{"id":"Aps","es":"Ave del Para\u00edso","rank":"3","seg":[[20,21],[21,22],[22,23]]},{"id":"Aqr","es":"Acuario","rank":"2","seg":[[24,25],[25,26],[26,27],[27,28],[28,29],[29,30],[30,31],[31,32],[32,33],[26,34],[27,35],[29,36],[37,32],[32,38]]},{"id":"Aql","es":"\u00c1guila","rank":"1","seg":[[39,40],[40,41],[41,42],[42,43],[43,44],[44,45],[45,40],[40,44],[44,46]]},{"id":"Ara","es":"Altar","rank":"3","seg":[[47,48],[48,49],[49,50],[50,51],[51,52],[52,53]]},{"id":"Ari","es":"Carnero","rank":"1","seg":[[54,55],[55,56],[56,57]]},{"id":"Aur","es":"Cochero","rank":"1","seg":[[58,59],[59,60],[60,61],[61,62],[62,63],[63,58],[58,64],[64,59],[59,65],[65,66]]},{"id":"Boo","es":"Boyero","rank":"1","seg":[[67,68],[68,69],[69,70],[70,71],[71,72],[72,73],[73,74],[74,69],[69,75],[71,76],[76,77],[77,78],[78,76]]},{"id":"Cae","es":"Cincel","rank":"3","seg":[[79,80],[80,81],[81,82]]},{"id":"Cam","es":"Jirafa","rank":"2","seg":[[83,84],[84,85],[85,86],[86,87],[87,88],[85,89],[89,90]]},{"id":"Cnc","es":"Cangrejo","rank":"2","seg":[[91,92],[92,93],[93,94],[92,95]]},{"id":"CVn","es":"Lebreles","rank":"2","seg":[[96,97]]},{"id":"CMa","es":"Perro Mayor","rank":"1","seg":[[98,99],[99,100],[100,101],[101,102],[102,103],[103,104],[105,101],[99,106],[106,107],[107,108],[108,106]]},{"id":"CMi","es":"Perro Menor","rank":"2","seg":[[109,110]]},{"id":"Cap","es":"Capricornio","rank":"2","seg":[[111,112],[112,113],[113,114],[114,115],[115,116],[116,117],[117,118],[118,119],[119,120],[120,111]]},{"id":"Car","es":"Carina","rank":"1","seg":[[121,122],[122,123],[123,124],[124,125],[125,126],[126,127],[127,128],[128,129],[129,130],[130,131],[131,132],[132,128],[125,133],[133,134],[134,135],[135,136],[136,137],[137,126]]},{"id":"Cas","es":"Casiopea","rank":"1","seg":[[138,139],[139,140],[140,141],[141,142]]},{"id":"Cen","es":"Centauro","rank":"1","seg":[[143,144],[144,145],[145,146],[146,147],[147,148],[148,149],[149,150],[150,151],[151,152],[152,153],[150,154],[155,147],[147,156],[145,157],[157,158]]},{"id":"Cep","es":"Cefeo","rank":"2","seg":[[159,160],[160,161],[161,162],[162,163],[163,164],[164,165],[165,166],[166,167],[167,168],[168,161],[168,166]]},{"id":"Cet","es":"Ballena","rank":"1","seg":[[169,170],[170,171],[171,172],[172,173],[173,174],[174,169],[169,175],[175,176],[176,177],[177,178],[178,179],[179,180],[180,181],[181,182],[182,177]]},{"id":"Cha","es":"Camale\u00f3n","rank":"3","seg":[[183,184],[184,185],[185,186],[186,187],[187,184]]},{"id":"Cir","es":"Comp\u00e1s","rank":"3","seg":[[188,189],[189,190]]},{"id":"Col","es":"Paloma","rank":"3","seg":[[191,192],[192,193],[193,194],[192,195]]},{"id":"Com","es":"Pelo de Berenice","rank":"3","seg":[[196,197],[197,198]]},{"id":"CrA","es":"Corona Austral","rank":"3","seg":[[199,200],[200,201],[201,202],[202,203],[203,204],[204,205],[205,206]]},{"id":"CrB","es":"Corona Boreal","rank":"2","seg":[[207,208],[208,209],[209,210],[210,211],[211,212],[212,213]]},{"id":"Crv","es":"Cuervo","rank":"3","seg":[[214,215],[215,216],[216,217],[217,218],[218,215]]},{"id":"Crt","es":"Copa","rank":"3","seg":[[219,220],[220,221],[221,222],[222,223],[223,224],[224,225],[225,226],[226,227],[221,225]]},{"id":"Cru","es":"Cruz del Sur","rank":"2","seg":[[228,229],[230,231]]},{"id":"Cyg","es":"Cisne","rank":"1","seg":[[232,233],[233,234],[234,235],[235,236],[236,237],[238,234],[234,239],[239,240]]},{"id":"Del","es":"Delf\u00edn","rank":"3","seg":[[241,242],[242,243],[243,244],[244,245],[245,242]]},{"id":"Dor","es":"Pez dorado","rank":"3","seg":[[246,247],[247,248],[248,249],[249,250],[250,248],[248,251],[251,247]]},{"id":"Dra","es":"Drag\u00f3n","rank":"2","seg":[[252,253],[253,254],[254,255],[255,252],[252,256],[256,257],[257,258],[258,259],[259,260],[260,261],[261,262],[262,263],[263,264],[257,265],[256,266]]},{"id":"Equ","es":"Caballito","rank":"3","seg":[[267,268],[268,269]]},{"id":"Eri","es":"Er\u00eddano","rank":"1","seg":[[270,271],[271,272],[272,273],[273,274],[274,275],[275,276],[276,277],[277,278],[278,279],[279,280],[280,281],[281,282],[282,283],[283,284],[284,285],[285,286],[286,287],[287,288],[288,289],[289,290],[290,291],[291,292],[292,293],[293,294],[294,295],[295,296]]},{"id":"For","es":"Horno","rank":"3","seg":[[297,298],[298,299]]},{"id":"Gem","es":"Gemelos","rank":"1","seg":[[300,301],[301,302],[302,303],[303,304],[304,305],[305,306],[306,307],[307,308],[308,309],[309,310],[307,311]]},{"id":"Gru","es":"Grulla","rank":"3","seg":[[312,313],[313,314],[314,315],[315,316],[316,314],[317,318],[318,319],[319,320]]},{"id":"Her","es":"H\u00e9rcules","rank":"2","seg":[[321,322],[322,323],[323,324],[324,325],[325,326],[326,327],[327,328],[323,329],[324,330],[331,332],[332,330],[330,329],[329,333],[333,334],[334,335],[335,336],[337,322]]},{"id":"Hor","es":"Reloj","rank":"3","seg":[[338,339],[339,340],[340,341],[341,342],[342,343]]},{"id":"Hya","es":"Hidra","rank":"2","seg":[[344,345],[345,346],[346,347],[347,348],[348,344],[344,349],[349,350],[350,351],[351,352],[352,353],[353,354],[354,355],[355,356],[356,357],[357,358],[358,359],[359,360],[360,361]]},{"id":"Hyi","es":"Hidra Macho","rank":"3","seg":[[362,363],[363,364],[364,365],[365,366],[366,367]]},{"id":"Ind","es":"Indio","rank":"3","seg":[[368,369],[369,370],[370,371],[371,372],[372,368]]},{"id":"Lac","es":"Lagarto","rank":"3","seg":[[373,374],[374,375],[375,376],[376,377],[377,378],[378,375],[375,379],[379,373],[377,380],[380,381]]},{"id":"Leo","es":"Le\u00f3n","rank":"1","seg":[[382,383],[383,384],[384,385],[385,386],[386,387],[387,382],[384,388],[388,389],[389,390]]},{"id":"LMi","es":"Le\u00f3n Menor","rank":"3","seg":[[391,392],[392,393],[393,394],[394,391],[391,395]]},{"id":"Lep","es":"Conejo","rank":"3","seg":[[396,397],[397,398],[398,399],[399,400],[400,401],[401,402],[402,403],[403,404],[405,400],[400,406]]},{"id":"Lib","es":"Balanza","rank":"2","seg":[[407,408],[408,409],[409,410],[410,411],[411,412],[408,410]]},{"id":"Lup","es":"Lobo","rank":"3","seg":[[413,414],[414,415],[415,416],[416,417],[417,418],[418,419],[419,420],[420,421],[421,422],[422,423],[423,424],[416,422]]},{"id":"Lyn","es":"Lince","rank":"3","seg":[[425,426],[426,427],[427,428],[428,429],[429,430],[430,431]]},{"id":"Lyr","es":"Lira","rank":"2","seg":[[432,433],[433,434],[434,432],[432,435],[435,436],[436,437],[437,432]]},{"id":"Men","es":"Mesa","rank":"3","seg":[[438,439],[439,440],[440,441]]},{"id":"Mic","es":"Microscopio","rank":"3","seg":[[442,443],[443,444],[444,445],[445,446],[446,442]]},{"id":"Mon","es":"Unicornio","rank":"2","seg":[[447,448],[448,449],[449,450],[450,451],[449,452],[452,453],[453,454],[454,455]]},{"id":"Mus","es":"Mosca","rank":"3","seg":[[456,457],[457,458],[458,459],[459,460],[460,461],[461,458]]},{"id":"Nor","es":"Escuadra","rank":"3","seg":[[462,463],[463,464],[464,465],[465,462]]},{"id":"Oct","es":"Bast\u00f3n","rank":"3","seg":[[466,467],[467,468],[468,466]]},{"id":"Oph","es":"Ofiuco","rank":"2","seg":[[469,470],[470,471],[471,472],[472,473],[473,474],[474,475],[475,476],[476,477],[477,478],[473,477],[477,479],[479,480],[480,481],[481,482],[471,478],[478,483],[483,484]]},{"id":"Ori","es":"Ori\u00f3n","rank":"1","seg":[[485,486],[486,487],[487,488],[488,489],[489,490],[490,491],[491,492],[493,494],[494,495],[495,496],[496,497],[497,492],[492,498],[498,499],[499,500],[501,502],[502,503],[503,491],[491,504],[504,490],[490,505],[505,506],[505,507],[507,503]]},{"id":"Pav","es":"Pavo","rank":"2","seg":[[508,509],[509,510],[510,511],[511,512],[512,513],[513,514],[514,515],[515,516],[516,509],[509,517]]},{"id":"Peg","es":"Pegaso","rank":"1","seg":[[518,519],[519,520],[520,3],[3,521],[521,522],[522,523],[523,524],[524,525],[525,526],[522,520],[520,527],[527,528],[528,529],[529,530]]},{"id":"Per","es":"Perseo","rank":"1","seg":[[531,532],[532,533],[533,534],[534,535],[535,536],[536,537],[537,538],[538,539],[539,540],[540,541],[541,542],[542,543],[543,544],[544,545],[545,546],[546,547],[547,548],[548,544],[549,550],[550,551],[551,536],[542,552],[552,553]]},{"id":"Phe","es":"F\u00e9nix","rank":"2","seg":[[554,555],[555,556],[556,557],[557,558],[558,555],[555,559],[559,554]]},{"id":"Pic","es":"Caballete del Pintor","rank":"3","seg":[[560,561],[561,562]]},{"id":"Psc","es":"Peces","rank":"2","seg":[[563,564],[564,565],[565,563],[563,566],[566,567],[567,568],[568,569],[569,570],[570,571],[571,572],[572,573],[573,574],[574,575],[575,576],[576,577],[577,578],[578,579],[579,580],[580,581],[581,582],[582,583],[583,577],[580,584]]},{"id":"PsA","es":"Pez Austral","rank":"2","seg":[[585,586],[586,587],[587,588],[588,589],[589,590],[590,591],[591,592],[592,590],[590,585]]},{"id":"Pup","es":"Popa","rank":"2","seg":[[121,593],[593,594],[594,595],[595,596],[596,597],[597,598],[598,599],[599,131],[596,600],[600,601],[601,594]]},{"id":"Pyx","es":"Br\u00fajula","rank":"3","seg":[[599,602],[602,603],[603,604]]},{"id":"Ret","es":"Ret\u00edculo","rank":"3","seg":[[605,606],[606,607],[607,608],[608,605]]},{"id":"Sge","es":"Flecha","rank":"3","seg":[[609,610],[610,611],[612,610]]},{"id":"Sgr","es":"Sagitario","rank":"1","seg":[[613,614],[614,615],[615,616],[616,617],[618,619],[619,620],[620,621],[621,616],[622,623],[623,624],[624,625],[625,626],[626,627],[627,628],[628,621],[621,615],[615,629],[629,614],[614,620],[620,630],[630,628],[628,631],[631,632],[632,633],[633,634],[634,635],[631,636],[636,637],[637,628]]},{"id":"Sco","es":"Escorpi\u00f3n","rank":"1","seg":[[638,639],[639,640],[639,641],[641,642],[642,643],[643,644],[644,645],[645,646],[646,647],[647,648],[648,649],[649,650],[650,651]]},{"id":"Scl","es":"Escultor","rank":"3","seg":[[652,653],[653,654],[654,655]]},{"id":"Sct","es":"Escudo","rank":"3","seg":[[656,657],[657,658],[658,659],[659,656]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[660,661],[661,662],[662,663],[663,660],[660,664],[664,665],[665,666],[666,475]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[478,667],[667,469],[469,668],[668,669],[669,670]]},{"id":"Sex","es":"Sextante","rank":"3","seg":[[671,672],[672,673],[673,674]]},{"id":"Tau","es":"Toro","rank":"1","seg":[[675,676],[676,677],[677,678],[678,679],[679,680],[680,62],[678,681],[681,682],[682,683],[682,684],[684,685]]},{"id":"Tel","es":"Telescopio","rank":"3","seg":[[686,687],[687,688]]},{"id":"Tri","es":"Tri\u00e1ngulo","rank":"3","seg":[[689,690],[690,691],[691,689]]},{"id":"TrA","es":"Tri\u00e1ngulo Austral","rank":"2","seg":[[692,693],[693,694],[694,692]]},{"id":"Tuc","es":"Tuc\u00e1n","rank":"3","seg":[[695,696],[696,697],[697,698],[698,699],[699,700],[700,695]]},{"id":"UMa","es":"Osa Mayor","rank":"1","seg":[[701,702],[702,703],[703,704],[704,701],[701,705],[705,706],[706,707],[704,708],[708,709],[709,710],[708,711],[711,712],[711,713],[702,714],[714,715],[715,716],[716,703],[703,717],[717,718],[718,719],[720,718]]},{"id":"UMi","es":"Osa Menor","rank":"2","seg":[[721,722],[722,723],[723,724],[724,721],[721,725],[725,726],[726,727]]},{"id":"Vel","es":"Vela","rank":"2","seg":[[132,728],[728,729],[729,730],[730,731],[731,732],[732,733],[733,131]]},{"id":"Vir","es":"Virgen","rank":"1","seg":[[734,735],[735,736],[736,737],[737,738],[738,739],[739,740],[740,741],[742,743],[743,737],[738,744],[744,745],[745,746]]},{"id":"Vol","es":"Pez Volador","rank":"3","seg":[[747,748],[748,749],[749,750],[750,751],[751,749],[749,747]]},{"id":"Vul","es":"Zorra","rank":"3","seg":[[752,753],[753,754],[754,755],[755,756]]}];
var NIGHT_SKY_DOME_R = 300; // radio del domo, dentro del far=500 de la camara
var NIGHT_SKY_LIGHT_LAYER = 2; // capa dedicada: solo la ilumina la luz de fase lunar
// Polo norte de la eclíptica en coordenadas ecuatoriales J2000 (RA=18h=270 grados,
// Dec=90-23.439291=66.560709 grados). El eje de rotación real de la Luna esta inclinado
// solo ~1.54 grados respecto a este polo (frente a los ~5.14 grados del polo orbital), asi
// que se usa como aproximacion del "norte selenografico" para orientar la textura -- el
// error que esto introduce (libracion fisica/optica real, +-~8 grados de tambaleo) se ignora
// a proposito: es un efecto menor e imperceptible para un adorno de fondo en el cielo.
var ECLIPTIC_POLE_RA_DEG = 270.0, ECLIPTIC_POLE_DEC_DEG = 66.560709;

function julianDateUTC(date) { return date.getTime() / 86400000 + 2440587.5; }

function gmstDeg(jd) {
  var d = jd - 2451545.0;
  var g = 280.46061837 + 360.98564736629 * d;
  return ((g % 360) + 360) % 360;
}

// Convierte ascension recta/declinacion (grados, J2000) a altura/acimut (grados) para un
// instante (fecha juliana UT), latitud y longitud dadas -- formulas estandar de posicion
// horizontal. El acimut usa el mismo convenio que sunPositionFromAngles() de este proyecto
// (0 dispara hacia +Z, 90 hacia +X): no se corresponde con el norte geografico real de
// ningun escenario en concreto, ya que estos escenarios no tienen una orientacion geografica
// definida -- solo importa que el cielo gire de forma consistente y realista con el tiempo.
function equatorialToAltAz(raDeg, decDeg, jd, latDeg, lonDeg) {
  var lst = (gmstDeg(jd) + (lonDeg || 0)) % 360;
  var haDeg = ((lst - raDeg + 540) % 360) - 180;
  var ha = deg2rad(haDeg), dec = deg2rad(decDeg), lat = deg2rad(latDeg);
  var sinAlt = Math.sin(dec) * Math.sin(lat) + Math.cos(dec) * Math.cos(lat) * Math.cos(ha);
  var alt = Math.asin(clamp(sinAlt, -1, 1));
  var cosAlt = Math.cos(alt) || 1e-9;
  var cosAz = (Math.sin(dec) - Math.sin(alt) * Math.sin(lat)) / (cosAlt * Math.cos(lat) || 1e-9);
  var sinAz = (-Math.sin(ha) * Math.cos(dec)) / cosAlt;
  var az = Math.atan2(sinAz, clamp(cosAz, -1, 1));
  return { altDeg: rad2deg(alt), azDeg: (rad2deg(az) + 360) % 360 };
}

// Posicion geocentrica aparente del Sol, baja precision (~0.01 grados, Meeus cap.25 abreviado).
// Se usa SOLO para iluminar la Luna con su fase real -- es independiente del "sol artistico"
// (sunAnglesFromRealDateTime / modo manual-ciclo-realtime), que ambienta el escenario pero no
// pretende precision astronomica.
function sunEquatorialPosition(jd) {
  var d = jd - 2451545.0;
  var L = ((280.460 + 0.9856474 * d) % 360 + 360) % 360;
  var g = deg2rad(((357.528 + 0.9856003 * d) % 360 + 360) % 360);
  var lambda = deg2rad(L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g));
  var eps = deg2rad(23.439 - 0.0000004 * d);
  var raRad = Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda));
  var decRad = Math.asin(Math.sin(eps) * Math.sin(lambda));
  return { raDeg: (rad2deg(raRad) + 360) % 360, decDeg: rad2deg(decRad) };
}

// Posicion geocentrica de la Luna (serie truncada Meeus/Chapront, terminos principales,
// precision visual ~0.3 grados) + fraccion iluminada real a partir de la elongacion Luna-Sol.
function moonEquatorialPosition(jd) {
  var d = jd - 2451545.0;
  var Lp = ((218.3164477 + 13.17639648 * d) % 360 + 360) % 360;
  var D  = ((297.8501921 + 12.19074912 * d) % 360 + 360) % 360;
  var M  = ((357.5291092 + 0.98560028  * d) % 360 + 360) % 360;
  var Mp = ((134.9633964 + 13.06499295 * d) % 360 + 360) % 360;
  var F  = ((93.2720950  + 13.22935024 * d) % 360 + 360) % 360;
  var rD = deg2rad(D), rM = deg2rad(M), rMp = deg2rad(Mp), rF = deg2rad(F);
  var dL = 6.289 * Math.sin(rMp) - 1.274 * Math.sin(2*rD - rMp) + 0.658 * Math.sin(2*rD)
    - 0.186 * Math.sin(rM) - 0.059 * Math.sin(2*rD - 2*rMp) - 0.057 * Math.sin(2*rD - rM - rMp)
    + 0.053 * Math.sin(2*rD + rMp) + 0.046 * Math.sin(2*rD - rM) - 0.041 * Math.sin(rM - rMp)
    - 0.035 * Math.sin(rD) - 0.031 * Math.sin(rM + rMp) - 0.015 * Math.sin(2*rF - 2*rD)
    + 0.011 * Math.sin(rMp - 4*rD);
  var dB = 5.128 * Math.sin(rF) + 0.281 * Math.sin(rMp + rF) + 0.278 * Math.sin(rMp - rF)
    + 0.173 * Math.sin(2*rD - rF) + 0.055 * Math.sin(2*rD - rMp + rF) + 0.046 * Math.sin(2*rD - rMp - rF)
    + 0.033 * Math.sin(2*rD + rF) + 0.017 * Math.sin(2*rD + rMp + rF);
  var lambda = deg2rad(Lp + dL);
  var beta = deg2rad(dB);
  var eps = deg2rad(23.439 - 0.0000004 * d);
  var decRad = Math.asin(Math.sin(beta) * Math.cos(eps) + Math.cos(beta) * Math.sin(eps) * Math.sin(lambda));
  var y = Math.sin(lambda) * Math.cos(eps) - Math.tan(beta) * Math.sin(eps);
  var x = Math.cos(lambda);
  var raRad = Math.atan2(y, x);
  var elongDeg = ((D % 360) + 360) % 360;
  var illumFrac = (1 - Math.cos(deg2rad(elongDeg))) / 2;
  return {
    raDeg: (rad2deg(raRad) + 360) % 360,
    decDeg: rad2deg(decRad),
    illumFrac: illumFrac,
    waxing: elongDeg < 180,
    elongDeg: elongDeg,
  };
}

function moonPhaseName(elongDeg, illumFrac) {
  if (illumFrac < 0.02) return "Luna nueva";
  if (illumFrac > 0.98) return "Luna llena";
  var waxing = elongDeg < 180;
  if (illumFrac < 0.48) return waxing ? "Luna creciente" : "Luna menguante";
  if (illumFrac > 0.52) return waxing ? "Luna gibosa (creciente)" : "Luna gibosa (menguante)";
  return waxing ? "Cuarto creciente" : "Cuarto menguante";
}

// Fecha/hora "simulada" para sincronizar la Luna (y las estrellas) con el ciclo día/noche RÁPIDO
// (Sol en modo "cycle", días de pocos minutos). Se usa el día de calendario real de hoy (así la
// FASE de la Luna es la real de hoy) pero la hora avanza al ritmo del reloj interno del ciclo
// (dayCycleClock/dayCycleTotalSec) en vez del reloj real -- así el cielo entero (Sol, Luna y
// estrellas) gira junto en cada noche simulada, en vez de quedarse el cielo estelar anclado a la
// hora real de este instante mientras el Sol sí corre rápido.
function simulatedSkyDate() {
  var dayLenSec = Math.max(10, (sceneEnvironment.dayDurationMin || 10) * 60);
  var daysElapsed = Math.floor(dayCycleTotalSec / dayLenSec); // cuantos "días" simulados completos han pasado
  var fracDay = dayCycleClock / dayLenSec; // 0..1 dentro del día simulado actual
  var base = new Date();
  base.setHours(0, 0, 0, 0); // medianoche real de hoy, punto de partida
  return new Date(base.getTime() + daysElapsed * 86400000 + fracDay * 86400000);
}

// Devuelve la fecha/hora (objeto Date, en UTC real) que debe usarse para calcular el cielo:
// una fecha/hora manual fija interpretada en el huso horario indicado (modo "manual" -- para "ver
// el cielo de cierto momento" sin salir de casa); la simulada del ciclo rápido si el Sol está en
// modo "cycle" (ver simulatedSkyDate arriba); o la del sistema en cualquier otro caso (Sol manual
// o "hora real del sistema" -- ahí sí queremos la hora real de verdad, la de "luna real").
function nightSkyDateForNow() {
  if (sceneEnvironment.skyDateMode === "manual" && sceneEnvironment.skyManualDate) {
    var dp = sceneEnvironment.skyManualDate.split("-").map(Number);
    var tp = (sceneEnvironment.skyManualTime || "22:00").split(":").map(Number);
    var utcMs = Date.UTC(dp[0] || 2000, (dp[1] || 1) - 1, dp[2] || 1, tp[0] || 0, tp[1] || 0, 0);
    var offset = sceneEnvironment.skyUtcOffsetHours != null ? sceneEnvironment.skyUtcOffsetHours : 1;
    return new Date(utcMs - offset * 3600000);
  }
  if (sceneEnvironment.sunMode === "cycle") return simulatedSkyDate();
  return new Date();
}

var nightSkyGroup = null, nightSkyStarLayers = [], nightSkyMoonMesh = null, nightSkyMoonLight = null;
var nightSkyStarDirCache = null; // Float32Array de 757*3 vectores unitarios (o NaN si la estrella esta bajo el horizonte), refrescado en cada recalculo -- lo usa el puntero de constelaciones
var nightSkyMoonTexture = null, nightSkyMoonFallbackTexture = null;
var nightSkyClockAccum = 0, nightSkyLastCalcAt = -999;
var nightSkyLastPhaseName = "";
// Subgrupo que gira cada frame para que el movimiento de estrellas/Luna se vea fluido (arco
// continuo) en vez de "saltar" cada segundo, que es cuando de verdad se recalculan las posiciones
// exactas (recomputeNightSkyPositions, caro). La idea: el hueco entre dos recalculos se rellena
// girando este grupo con un cuaternion muestreado sobre la MISMA formula astronomica real
// (equatorialToAltAz), asi que no es una animacion "de mentira" -- es el giro exacto del cielo
// (ha = lst - ra crece igual para TODAS las estrellas, es una rotacion rigida alrededor del eje
// del polo celeste), solo que extrapolado frame a frame en vez de recalculado punto a punto. Cada
// recalculo exacto resetea este giro a identidad (ver recomputeNightSkyPositions).
var nightSkyRotGroup = null;
var nightSkyRotDeltaQuat = new THREE.Quaternion();
var nightSkyRotJdAtRecalc = 0;
var NIGHT_SKY_ROT_EPS_JD = 1 / 86400; // "unidad" de muestreo: 1 segundo de fecha juliana
var _nightSkyRotTmpQuat = new THREE.Quaternion();

function buildFallbackMoonTexture() {
  var c = document.createElement("canvas"); c.width = 256; c.height = 256;
  var ctx = c.getContext("2d");
  ctx.fillStyle = "#dcd7cc"; ctx.fillRect(0, 0, 256, 256);
  var blobs = [[80,70,40],[152,58,28],[192,140,32],[68,162,36],[128,192,24],[40,118,20],[210,90,18]];
  blobs.forEach(function (b) {
    var g = ctx.createRadialGradient(b[0], b[1], 0, b[0], b[1], b[2]);
    g.addColorStop(0, "rgba(88,86,90,.5)"); g.addColorStop(1, "rgba(88,86,90,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b[0], b[1], b[2], 0, Math.PI * 2); ctx.fill();
  });
  for (var i = 0; i < 160; i++) {
    var x = Math.random() * 256, y = Math.random() * 256, r = 1 + Math.random() * 3;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(55,55,60," + (0.12 + Math.random() * 0.25) + ")"; ctx.fill();
  }
  var tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace || tex.colorSpace;
  return tex;
}

function makeNightStarLayer(count, sizePx, color, opacity) {
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(count * 3), 3));
  var mat = new THREE.PointsMaterial({ color: color, size: sizePx, sizeAttenuation: false, transparent: true, opacity: opacity, depthWrite: false, fog: false });
  var pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  pts.userData.baseOpacity = opacity;
  return pts;
}

function buildNightSky() {
  nightSkyGroup = new THREE.Group();
  nightSkyGroup.renderOrder = -1000;
  nightSkyGroup.visible = false;

  // Todo lo que "gira con el cielo" (estrellas + Luna + su luz) vive aqui dentro; nightSkyGroup
  // en si solo sigue a la camara (skybox), nunca gira -- ver nightSkyRotGroup mas arriba.
  nightSkyRotGroup = new THREE.Group();
  nightSkyGroup.add(nightSkyRotGroup);

  var realIdx = { bright: [], mid: [], dim: [] };
  for (var i = 0; i < NIGHT_SKY_STARS.length; i += 3) {
    var mag = NIGHT_SKY_STARS[i + 2];
    (mag <= 2.2 ? realIdx.bright : (mag <= 3.0 ? realIdx.mid : realIdx.dim)).push(i);
  }
  var fillerRaDec = [];
  var FILLER_COUNT = 2200;
  for (var f = 0; f < FILLER_COUNT; f++) {
    var ra = Math.random() * 360;
    var dec = rad2deg(Math.asin(Math.random() * 2 - 1));
    fillerRaDec.push(ra, dec);
  }

  var layerBright = makeNightStarLayer(realIdx.bright.length, 3.2, 0xfff3d8, 0.95);
  var layerMid    = makeNightStarLayer(realIdx.mid.length,    2.3, 0xeef2ff, 0.85);
  var layerDim    = makeNightStarLayer(realIdx.dim.length,    1.7, 0xd7dcf5, 0.7);
  var layerFiller = makeNightStarLayer(FILLER_COUNT,          1.1, 0xaab0cf, 0.45);
  layerBright.userData.starIdx = realIdx.bright;
  layerMid.userData.starIdx = realIdx.mid;
  layerDim.userData.starIdx = realIdx.dim;
  layerFiller.userData.fillerRaDec = fillerRaDec;
  nightSkyStarLayers = [layerBright, layerMid, layerDim, layerFiller];
  nightSkyStarLayers.forEach(function (l) { nightSkyRotGroup.add(l); });

  var moonGeo = new THREE.SphereGeometry(NIGHT_SKY_DOME_R * 0.045, 32, 32);
  nightSkyMoonFallbackTexture = buildFallbackMoonTexture();
  // La fase (terminador dia/noche sobre la esfera) se calcula A MANO en este shader, ya NO con
  // luces de three.js. El intento anterior (comentario que había aquí) daba la Luna por "aislada"
  // metiéndola junto a su propia luz en una capa dedicada (NIGHT_SKY_LIGHT_LAYER) para que solo esa
  // luz la tocase -- pero eso NO es lo que hacen las capas en three.js: Object3D.layers solo decide
  // qué ve la CÁMARA (qué luces/objetos entran siquiera en el render), no qué luces afectan a qué
  // objetos. En cuanto una luz pasa el filtro de cámara, ilumina TODA la escena por igual -- así que
  // "hemi" (HemisphereLight, intensidad 0.9 fija, nunca se atenúa de noche) seguía iluminando la
  // esfera casi por completo y de forma pareja, tapando el terminador real: por eso se veía siempre
  // como una bola gris deslucida, tuviera o no textura, fuera cual fuera la fase calculada.
  // uLightDir (dirección Luna->Sol real) se recalcula 1 vez por segundo en recomputeNightSkyPositions
  // junto al resto de la bóveda, en el espacio LOCAL del propio mesh -- coincide con el espacio local
  // de nightSkyRotGroup porque este mesh no tiene rotación propia, así que el sombreado se mantiene
  // correcto aunque el grupo gire cada frame (ver nightSkyRotGroup).
  var moonMat = new THREE.ShaderMaterial({
    uniforms: {
      map: { value: nightSkyMoonFallbackTexture },
      uLightDir: { value: new THREE.Vector3(1, 0, 0) },
      uAmbient: { value: 0.15 }, // "luz cenicienta"/earthshine: que el lado no iluminado no sea negro puro
      uOpacity: { value: 1 },
    },
    vertexShader: [
      'varying vec3 vNormalObj;',
      'varying vec2 vUv;',
      'void main() {',
      '  vNormalObj = normal;',
      '  vUv = uv;',
      '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);',
      '}',
    ].join('\n'),
    fragmentShader: [
      'uniform sampler2D map;',
      'uniform vec3 uLightDir;',
      'uniform float uAmbient;',
      'uniform float uOpacity;',
      'varying vec3 vNormalObj;',
      'varying vec2 vUv;',
      'void main() {',
      '  vec3 n = normalize(vNormalObj);',
      '  float ndotl = max(dot(n, normalize(uLightDir)), 0.0);',
      '  float shade = uAmbient + (1.0 - uAmbient) * ndotl;',
      '  vec4 tex = texture2D(map, vUv);',
      '  gl_FragColor = vec4(tex.rgb * shade, tex.a * uOpacity);',
      '}',
    ].join('\n'),
    transparent: true,
    fog: false,
  });
  nightSkyMoonMesh = new THREE.Mesh(moonGeo, moonMat);
  if (sceneEnvironment.moonTextureBase64) {
    (function () {
      var img = new Image();
      img.onload = function () {
        var tex = new THREE.Texture(img);
        tex.needsUpdate = true;
        nightSkyMoonTexture = tex;
        moonMat.uniforms.map.value = tex;
      };
      img.src = sceneEnvironment.moonTextureBase64;
    })();
  }
  nightSkyRotGroup.add(nightSkyMoonMesh);

  scene.add(nightSkyGroup);
}

function setNightSkyOpacity(factor) {
  nightSkyStarLayers.forEach(function (l) { l.material.opacity = l.userData.baseOpacity * factor; });
  if (nightSkyMoonMesh) nightSkyMoonMesh.material.uniforms.uOpacity.value = clamp(factor * 1.4, 0, 1);
}

function placeStarLayerByIndices(layer, jd, lat, lon) {
  var idxs = layer.userData.starIdx;
  var arr = layer.geometry.attributes.position.array;
  var visible = 0;
  for (var k = 0; k < idxs.length; k++) {
    var i = idxs[k];
    var hz = equatorialToAltAz(NIGHT_SKY_STARS[i], NIGHT_SKY_STARS[i + 1], jd, lat, lon);
    if (hz.altDeg < -1) continue;
    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);
    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;
    visible++;
  }
  layer.geometry.setDrawRange(0, visible);
  layer.geometry.attributes.position.needsUpdate = true;
}

function placeFillerLayer(layer, jd, lat, lon) {
  var raDec = layer.userData.fillerRaDec;
  var arr = layer.geometry.attributes.position.array;
  var visible = 0;
  for (var k = 0; k < raDec.length; k += 2) {
    var hz = equatorialToAltAz(raDec[k], raDec[k + 1], jd, lat, lon);
    if (hz.altDeg < -1) continue;
    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);
    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;
    visible++;
  }
  layer.geometry.setDrawRange(0, visible);
  layer.geometry.attributes.position.needsUpdate = true;
}

// Recalcula SOLO el catálogo de direcciones de las ~757 estrellas con nombre (nightSkyStarDirCache),
// sin tocar la geometría de render (los ~3000 puntos, Luna, meteoros...) que sí es cara y por eso
// solo se recalcula 1 vez por segundo real (ver recomputeNightSkyPositions). Esto es barato --puro
// producto de trigonometría sobre un array, nada de GPU-- así que puede llamarse mucho más a menudo:
// lo usa tanto el recálculo general como updateSkyPointer() en su propia cadencia (ver más abajo),
// para que el catálogo que usa el puntero de constelaciones nunca tenga más de ~150ms de retraso en
// vez de hasta 1s -- si no, la constelación bajo la mira "saltaba" de golpe cada segundo.
function refreshNightSkyStarDirCache(jd, lat, lon) {
  if (!nightSkyStarDirCache || nightSkyStarDirCache.length !== NIGHT_SKY_STARS.length) nightSkyStarDirCache = new Float32Array(NIGHT_SKY_STARS.length);
  for (var si = 0; si < NIGHT_SKY_STARS.length; si += 3) {
    var shz = equatorialToAltAz(NIGHT_SKY_STARS[si], NIGHT_SKY_STARS[si + 1], jd, lat, lon);
    if (shz.altDeg < 0) { nightSkyStarDirCache[si] = NaN; nightSkyStarDirCache[si + 1] = NaN; nightSkyStarDirCache[si + 2] = NaN; continue; }
    var sp = sunPositionFromAngles(shz.altDeg, shz.azDeg, 1);
    nightSkyStarDirCache[si] = sp.x; nightSkyStarDirCache[si + 1] = sp.y; nightSkyStarDirCache[si + 2] = sp.z;
  }
}

// Muestrea el giro real del cielo en "jd" tomando un punto de referencia (ecuador celeste, lejos
// del polo para evitar casos degenerados) y comparando su posicion en jd frente a jd+EPS: como
// ha = lst - ra crece exactamente igual para cualquier ra/dec (ver equatorialToAltAz), el
// cuaternion resultante describe el giro rigido de TODO el cielo por cada EPS de fecha juliana,
// sea cual sea la estrella. updateNightSky() lo reescala cada frame (slerp) segun el tiempo
// simulado transcurrido desde este recalculo para rellenar el hueco hasta el siguiente.
function updateNightSkyRotationSample(jd, lat, lon) {
  var hz1 = equatorialToAltAz(0, 0, jd, lat, lon);
  var hz2 = equatorialToAltAz(0, 0, jd + NIGHT_SKY_ROT_EPS_JD, lat, lon);
  var p1 = sunPositionFromAngles(hz1.altDeg, hz1.azDeg, 1);
  var p2 = sunPositionFromAngles(hz2.altDeg, hz2.azDeg, 1);
  var v1 = new THREE.Vector3(p1.x, p1.y, p1.z).normalize();
  var v2 = new THREE.Vector3(p2.x, p2.y, p2.z).normalize();
  nightSkyRotDeltaQuat.setFromUnitVectors(v1, v2);
  nightSkyRotJdAtRecalc = jd;
  if (nightSkyRotGroup) nightSkyRotGroup.quaternion.identity();
}

function recomputeNightSkyPositions() {
  var when = nightSkyDateForNow();
  var jd = julianDateUTC(when);
  var lat = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
  var lon = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;

  placeStarLayerByIndices(nightSkyStarLayers[0], jd, lat, lon);
  placeStarLayerByIndices(nightSkyStarLayers[1], jd, lat, lon);
  placeStarLayerByIndices(nightSkyStarLayers[2], jd, lat, lon);
  placeFillerLayer(nightSkyStarLayers[3], jd, lat, lon);

  refreshNightSkyStarDirCache(jd, lat, lon);
  updateNightSkyRotationSample(jd, lat, lon);

  var moonEq = moonEquatorialPosition(jd);
  var moonHz = equatorialToAltAz(moonEq.raDeg, moonEq.decDeg, jd, lat, lon);
  var moonPos = sunPositionFromAngles(moonHz.altDeg, moonHz.azDeg, NIGHT_SKY_DOME_R * 0.9);
  nightSkyMoonMesh.position.set(moonPos.x, moonPos.y, moonPos.z);
  nightSkyMoonMesh.visible = moonHz.altDeg > -2;

  // Orientacion real del disco: antes el mesh se quedaba siempre con la rotacion por defecto de
  // la esfera (un trozo arbitrario y fijo de la textura, sin relacion con la Luna real). Aqui se
  // gira para que el eje local +X (centro de la textura equirectangular, u=0.5 -- el punto
  // subterrestre medio, sin libracion) apunte hacia el observador, y el eje local +Y (borde
  // superior de la textura, v=0 -- el polo norte de la Luna) apunte hacia la proyeccion del polo
  // norte de la eclíptica sobre el disco visible. Con eso queda fijada tanto la cara que se ve
  // como la inclinacion/roll del disco respecto al horizonte (angulo paralactico), que antes no
  // se calculaba en absoluto. NOTA: no se invierte la U de la textura -- u=0 queda a la izquierda
  // tal cual viene la imagen equirectangular.
  var moonPoleHz = equatorialToAltAz(ECLIPTIC_POLE_RA_DEG, ECLIPTIC_POLE_DEC_DEG, jd, lat, lon);
  var moonPolePt = sunPositionFromAngles(moonPoleHz.altDeg, moonPoleHz.azDeg, 1);
  var moonLen = Math.sqrt(moonPos.x * moonPos.x + moonPos.y * moonPos.y + moonPos.z * moonPos.z) || 1;
  var moonToObsX = -moonPos.x / moonLen, moonToObsY = -moonPos.y / moonLen, moonToObsZ = -moonPos.z / moonLen;
  var moonPoleDot = moonPolePt.x * moonToObsX + moonPolePt.y * moonToObsY + moonPolePt.z * moonToObsZ;
  var moonUpX = moonPolePt.x - moonToObsX * moonPoleDot, moonUpY = moonPolePt.y - moonToObsY * moonPoleDot, moonUpZ = moonPolePt.z - moonToObsZ * moonPoleDot;
  var moonUpLen = Math.sqrt(moonUpX * moonUpX + moonUpY * moonUpY + moonUpZ * moonUpZ);
  if (moonUpLen > 1e-6) {
    moonUpX /= moonUpLen; moonUpY /= moonUpLen; moonUpZ /= moonUpLen;
    var moonRgX = moonToObsY * moonUpZ - moonToObsZ * moonUpY,
        moonRgY = moonToObsZ * moonUpX - moonToObsX * moonUpZ,
        moonRgZ = moonToObsX * moonUpY - moonToObsY * moonUpX;
    var moonBasis = new THREE.Matrix4().makeBasis(
      new THREE.Vector3(moonToObsX, moonToObsY, moonToObsZ),
      new THREE.Vector3(moonUpX, moonUpY, moonUpZ),
      new THREE.Vector3(moonRgX, moonRgY, moonRgZ)
    );
    nightSkyMoonMesh.quaternion.setFromRotationMatrix(moonBasis);
  }

  var sunEq = sunEquatorialPosition(jd);
  var sunHz = equatorialToAltAz(sunEq.raDeg, sunEq.decDeg, jd, lat, lon);
  var lightPos = sunPositionFromAngles(sunHz.altDeg, sunHz.azDeg, NIGHT_SKY_DOME_R * 0.9 + 40);
  var mdx = lightPos.x - moonPos.x, mdy = lightPos.y - moonPos.y, mdz = lightPos.z - moonPos.z;
  var mdLen = Math.sqrt(mdx * mdx + mdy * mdy + mdz * mdz) || 1;
  nightSkyMoonMesh.material.uniforms.uLightDir.value.set(mdx / mdLen, mdy / mdLen, mdz / mdLen);

  nightSkyLastPhaseName = moonPhaseName(moonEq.elongDeg, moonEq.illumFrac);

  meteorCurrentInfo = activeMeteorShowerNow(when);
}

// Ayuda de depuración para la bóveda celeste/Luna -- se queda de forma permanente (a diferencia de
// otras ayudas puntuales, esta es útil siempre que algo "no se ve" en el domo: fecha usada, si el
// domo está activo/visible, altitud de la Luna sobre el horizonte y si el propio mesh está visible
// y con qué opacidad). Todo lo de arriba vive dentro de un <script type="module">, así que sus
// variables (sceneEnvironment, dayCycleClock, julianDateUTC...) no llegan solas a window ni las ve
// la consola del navegador, aunque existan -- esta función sí se cuelga de window (se puede hacer
// desde dentro del módulo) para poder inspeccionar el estado real desde fuera.
// Uso: window.debugMoon() en la consola para arrancar el log cada segundo, window.debugMoon(false)
// para pararlo.
window.debugMoon = function (on) {
  if (window.__moonDebugTimer) { clearInterval(window.__moonDebugTimer); window.__moonDebugTimer = null; }
  if (on === false) return;
  window.__moonDebugTimer = setInterval(function () {
    var jd = julianDateUTC(nightSkyDateForNow());
    var lat = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
    var lon = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;
    var moonEq = moonEquatorialPosition(jd);
    var hz = equatorialToAltAz(moonEq.raDeg, moonEq.decDeg, jd, lat, lon);
    var dayLenSec = Math.max(10, (sceneEnvironment.dayDurationMin || 10) * 60);
    console.log(
      "sunMode:", sceneEnvironment.sunMode,
      "| skyDateMode:", sceneEnvironment.skyDateMode,
      "| dayDurationMin:", sceneEnvironment.dayDurationMin,
      "| cicloSeg:", dayCycleClock.toFixed(1) + "/" + dayLenSec,
      "| horaVirtual:", (dayCycleClock / dayLenSec * 24).toFixed(2),
      "| nightSkyEnabled:", sceneEnvironment.nightSkyEnabled,
      "| domoVisible:", !!(nightSkyGroup && nightSkyGroup.visible),
      "| moonAltDeg:", hz.altDeg.toFixed(1),
      "| moonMesh.visible:", !!(nightSkyMoonMesh && nightSkyMoonMesh.visible),
      "| moonMesh.opacity:", nightSkyMoonMesh ? nightSkyMoonMesh.material.opacity.toFixed(2) : "n/a",
      "| fase:", nightSkyLastPhaseName
    );
  }, 1000);
};

// Se llama cada frame (editor y Modo jugar), igual que updateSunCycle(). Recoloca el domo sobre
// la camara (como un skybox) todos los frames, pero solo recalcula posiciones astronomicas una
// vez por segundo real -- el cielo tarda minutos en moverse de forma perceptible, así que no
// hace falta mas resolucion y se ahorra trigonometria de ~3000 puntos cada frame.
function updateNightSky(dt) {
  if (!nightSkyGroup) buildNightSky();
  nightSkyClockAccum += dt;
  var dirLen = dirLight.position.length() || 1;
  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));
  var nightFactor = nightTintFactorFromElevation(elevDeg);
  var enabled = !!sceneEnvironment.nightSkyEnabled;
  nightSkyGroup.visible = enabled && nightFactor > 0.015;
  if (!nightSkyGroup.visible) return;
  nightSkyGroup.position.copy(camera.position);
  setNightSkyOpacity(nightFactor);
  updateMeteorShowers(dt);
  if (nightSkyLastCalcAt < 0 || nightSkyClockAccum - nightSkyLastCalcAt >= 1) {
    nightSkyLastCalcAt = nightSkyClockAccum;
    recomputeNightSkyPositions();
  }
  // Relleno fluido cada frame entre dos recalculos exactos (arriba): gira nightSkyRotGroup segun
  // el tiempo simulado transcurrido desde el ultimo recalculo, extrapolando el cuaternion muestreado
  // en updateNightSkyRotationSample(). Con esto el cielo gira en arco continuo (como una animacion
  // CSS3) en vez de dar saltos de un segundo.
  if (nightSkyRotGroup && nightSkyLastCalcAt >= 0) {
    var jdNow = julianDateUTC(nightSkyDateForNow());
    var frac = (jdNow - nightSkyRotJdAtRecalc) / NIGHT_SKY_ROT_EPS_JD;
    if (frac < 0) frac = 0; // reloj manual o retrocedido: no giramos "hacia atras"
    // (sin techo superior: con un dia simulado rapido, p.ej. 2.5 min, "frac" puede llegar a varios
    // cientos dentro de la misma ventana de 1s -- es correcto, no un desbordamiento; la extrapolacion
    // del cuaternion (slerp) se mantiene precisa mientras el angulo TOTAL girado en ese segundo sea
    // pequeño, que es justo el caso real -- probado numericamente incluso en el dia mas rapido
    // permitido, 0.5 min. Limitar "frac" aqui era el bug: congelaba el giro casi al instante y el
    // resto del segundo se quedaba clavado hasta el siguiente recalculo exacto -- el salto que aun
    // se veia.
    _nightSkyRotTmpQuat.set(0, 0, 0, 1).slerp(nightSkyRotDeltaQuat, frac);
    nightSkyRotGroup.quaternion.copy(_nightSkyRotTmpQuat);
  }
}


function updateNightSkyUI() {
  document.getElementById("envNightSkyEnabled").checked = !!sceneEnvironment.nightSkyEnabled;
  document.getElementById("envNightSkyWrap").style.display = sceneEnvironment.nightSkyEnabled ? "" : "none";
  document.getElementById("envSkyDateMode").value = sceneEnvironment.skyDateMode || "auto";
  document.getElementById("envSkyManualWrap").style.display = sceneEnvironment.skyDateMode === "manual" ? "" : "none";
  document.getElementById("envSkyManualDate").value = sceneEnvironment.skyManualDate || new Date().toISOString().slice(0, 10);
  document.getElementById("envSkyManualTime").value = sceneEnvironment.skyManualTime || "22:00";
  document.getElementById("envSkyLatitude").value = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
  document.getElementById("envSkyLongitude").value = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : -3.7;
  document.getElementById("envSkyUtcOffset").value = sceneEnvironment.skyUtcOffsetHours != null ? sceneEnvironment.skyUtcOffsetHours : 1;
  document.getElementById("envMoonTextureInfo").textContent = sceneEnvironment.moonTextureFileName
    ? ("Textura de Luna: foto real subida (" + sceneEnvironment.moonTextureFileName + ").")
    : "Textura de Luna: imagen genérica generada automáticamente (sin foto real todavía).";
  document.getElementById("envMoonTextureRemove").style.display = sceneEnvironment.moonTextureBase64 ? "inline-block" : "none";
}

document.getElementById("envNightSkyEnabled").addEventListener("change", (e) => {
  sceneEnvironment.nightSkyEnabled = e.target.checked;
  updateNightSkyUI();
});
document.getElementById("envSkyDateMode").addEventListener("change", (e) => {
  sceneEnvironment.skyDateMode = e.target.value;
  updateNightSkyUI();
});
document.getElementById("envSkyManualDate").addEventListener("input", (e) => { sceneEnvironment.skyManualDate = e.target.value; });
document.getElementById("envSkyManualTime").addEventListener("input", (e) => { sceneEnvironment.skyManualTime = e.target.value; });
document.getElementById("envSkyLatitude").addEventListener("input", (e) => {
  sceneEnvironment.latitudeDeg = clamp(parseFloat(e.target.value) || 40, -70, 70);
  document.getElementById("envSunLatitude").value = sceneEnvironment.latitudeDeg;
});
document.getElementById("envSkyLongitude").addEventListener("input", (e) => {
  sceneEnvironment.skyLongitudeDeg = clamp(parseFloat(e.target.value) || 0, -180, 180);
});
document.getElementById("envSkyUtcOffset").addEventListener("input", (e) => {
  sceneEnvironment.skyUtcOffsetHours = clamp(parseFloat(e.target.value) || 0, -12, 14);
});
document.getElementById("envMoonTextureTrigger").addEventListener("click", () => document.getElementById("envMoonTextureInput").click());
document.getElementById("envMoonTextureInput").addEventListener("change", (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    const img = new Image();
    img.onload = () => {
      const tex = new THREE.Texture(img);
      tex.needsUpdate = true;
      if (nightSkyMoonTexture) nightSkyMoonTexture.dispose();
      nightSkyMoonTexture = tex;
      if (nightSkyMoonMesh) nightSkyMoonMesh.material.map = tex;
      if (nightSkyMoonMesh) nightSkyMoonMesh.material.needsUpdate = true;
      sceneEnvironment.moonTextureBase64 = dataUrl;
      sceneEnvironment.moonTextureFileName = f.name;
      updateNightSkyUI();
    };
    img.onerror = () => alertBox("No se pudo cargar la imagen " + f.name + ".", "warn");
    img.src = dataUrl;
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + f.name + ".", "warn");
  reader.readAsDataURL(f);
});
document.getElementById("envMoonTextureRemove").addEventListener("click", () => {
  sceneEnvironment.moonTextureBase64 = null;
  sceneEnvironment.moonTextureFileName = null;
  if (nightSkyMoonTexture) { nightSkyMoonTexture.dispose(); nightSkyMoonTexture = null; }
  if (nightSkyMoonMesh) { nightSkyMoonMesh.material.map = nightSkyMoonFallbackTexture; nightSkyMoonMesh.material.needsUpdate = true; }
  updateNightSkyUI();
});


/* =========================================================================
   IDENTIFICACION DE CONSTELACIONES CON EL PUNTERO (bóveda celeste, fase 2)
   ========================================================================= */
var skyPointerRaycaster = new THREE.Raycaster();
var SKY_POINTER_MAX_BLOCK_DIST = 80; // si hay algo mas cerca que esto en la mira, no se considera "cielo despejado"
var SKY_POINTER_TOLERANCE_DEG = 9; // cono de tolerancia alrededor de la mira para "enganchar" una constelacion
var skyPointerGroup = null;
var skyPointerClockAccum = 0, skyPointerLastCalcAt = -999;
var skyPointerCurrentConst = null;

function ensureSkyPointerGroup() {
  if (skyPointerGroup) return;
  skyPointerGroup = new THREE.Group();
  var mat = new THREE.LineBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, fog: false, depthWrite: false });
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(0), 3));
  var line = new THREE.LineSegments(geo, mat);
  line.frustumCulled = false;
  line.renderOrder = -998;
  skyPointerGroup.add(line);
  skyPointerGroup.userData.lineMesh = line;
  skyPointerGroup.visible = false;
  nightSkyGroup.add(skyPointerGroup);
}

// Busca, entre TODAS las lineas de las 88 constelaciones, la mas cercana angularmente a la
// direccion de mira (aimDir, vector unitario). Usa nightSkyStarDirCache (vectores unitarios ya
// calculados en el ultimo recalculo del cielo -- ver recomputeNightSkyPositions) para que esto
// sea barato (solo productos escalares, sin trigonometria) y pueda llamarse a cada rato mientras
// el jugador mueve la mira.
function findConstellationUnderAim(aimDir) {
  if (!nightSkyStarDirCache) return null;
  var thresholdDot = Math.cos(deg2rad(SKY_POINTER_TOLERANCE_DEG));
  var bestConst = null, bestDot = thresholdDot;
  for (var c = 0; c < NIGHT_SKY_CONSTELLATIONS.length; c++) {
    var con = NIGHT_SKY_CONSTELLATIONS[c];
    for (var s = 0; s < con.seg.length; s++) {
      var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;
      var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];
      if (da === da) {
        var dot1 = da * aimDir.x + db * aimDir.y + dc * aimDir.z;
        if (dot1 > bestDot) { bestDot = dot1; bestConst = con; }
      }
      var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];
      if (ea === ea) {
        var dot2 = ea * aimDir.x + eb * aimDir.y + ec * aimDir.z;
        if (dot2 > bestDot) { bestDot = dot2; bestConst = con; }
      }
    }
  }
  return bestConst;
}

function hideSkyPointerLabel() {
  var el = document.getElementById("constellationPrompt");
  if (el) el.style.display = "none";
}
function showSkyPointerLabel(text) {
  var el = document.getElementById("constellationPrompt");
  if (!el) return;
  el.textContent = "✨ " + text;
  el.style.display = "block";
}

function showSkyPointerConstellation(con) {
  ensureSkyPointerGroup();
  if (!con) {
    skyPointerGroup.visible = false;
    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }
    return;
  }
  if (skyPointerCurrentConst === con) { skyPointerGroup.visible = true; return; }
  skyPointerCurrentConst = con;
  var positions = [];
  for (var s = 0; s < con.seg.length; s++) {
    var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;
    var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];
    var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];
    if (da !== da || ea !== ea) continue;
    positions.push(da * NIGHT_SKY_DOME_R, db * NIGHT_SKY_DOME_R, dc * NIGHT_SKY_DOME_R);
    positions.push(ea * NIGHT_SKY_DOME_R, eb * NIGHT_SKY_DOME_R, ec * NIGHT_SKY_DOME_R);
  }
  var mesh = skyPointerGroup.userData.lineMesh;
  mesh.geometry.dispose();
  mesh.geometry = new THREE.BufferGeometry();
  mesh.geometry.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(positions), 3));
  skyPointerGroup.visible = true;
  showSkyPointerLabel(con.es);
}

// Se llama cada frame en Modo jugar. "active" es el estado del interruptor del puntero (la misma
// tecla L que ya existe: en el editor, el puntero láser multijugador; en el juego exportado, uno
// nuevo dedicado solo a esto, ya que el exportado no tiene multijugador). Con la mira despejada
// (nada de la escena más cerca que SKY_POINTER_MAX_BLOCK_DIST) y apuntando cerca de una figura de
// constelacion, la resalta y muestra su nombre -- como un puntero de clase de astronomia.
function updateSkyPointer(dt, active) {
  if (!nightSkyGroup) return;
  skyPointerClockAccum += dt;
  if (!active || !nightSkyGroup.visible) {
    if (skyPointerGroup && skyPointerGroup.visible) skyPointerGroup.visible = false;
    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }
    return;
  }
  if (skyPointerLastCalcAt >= 0 && skyPointerClockAccum - skyPointerLastCalcAt < 0.15) return;
  skyPointerLastCalcAt = skyPointerClockAccum;

  // Catálogo de direcciones fresco en la propia cadencia del puntero (cada 150ms), no el del
  // recálculo general del cielo (1 vez por segundo) -- ver refreshNightSkyStarDirCache().
  var whenPtr = nightSkyDateForNow();
  var latPtr = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
  var lonPtr = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;
  refreshNightSkyStarDirCache(julianDateUTC(whenPtr), latPtr, lonPtr);

  var aimDir = new THREE.Vector3();
  camera.getWorldDirection(aimDir);

  var blockTargets = [];
  sceneObjects.forEach(function (rec) {
    if (playerRecordId && rec.id === playerRecordId) return;
    if (rec.object3D) blockTargets.push(rec.object3D);
  });
  var blocked = false;
  if (blockTargets.length) {
    skyPointerRaycaster.set(camera.position, aimDir);
    skyPointerRaycaster.far = SKY_POINTER_MAX_BLOCK_DIST;
    blocked = skyPointerRaycaster.intersectObjects(blockTargets, true).length > 0;
  }
  if (blocked) { showSkyPointerConstellation(null); return; }
  showSkyPointerConstellation(findConstellationUnderAim(aimDir));
}


/* =========================================================================
   LLUVIAS DE METEOROS (bóveda celeste, fase 2)
   =========================================================================
   Tabla de las lluvias anuales principales (radiante RA/Dec aproximado y
   rango de fechas activo, valores estándar redondeados -- no cambian de un
   año a otro más que en un par de días). El ZHR (tasa horaria cenital) es
   orientativo, se usa solo para pesar unas lluvias frente a otras, no como
   dato de observación real.
*/
var METEOR_SHOWERS = [
  { name: "Cuadrántidas",   raDeg: 230, decDeg: 49, startMonth: 12, startDay: 28, endMonth: 1,  endDay: 12, peakMonth: 1,  peakDay: 3,  zhr: 110 },
  { name: "Líridas",        raDeg: 271, decDeg: 34, startMonth: 4,  startDay: 16, endMonth: 4,  endDay: 25, peakMonth: 4,  peakDay: 22, zhr: 18 },
  { name: "Eta Acuáridas",  raDeg: 338, decDeg: -1, startMonth: 4,  startDay: 19, endMonth: 5,  endDay: 28, peakMonth: 5,  peakDay: 5,  zhr: 50 },
  { name: "Perseidas",      raDeg: 46,  decDeg: 58, startMonth: 7,  startDay: 17, endMonth: 8,  endDay: 24, peakMonth: 8,  peakDay: 12, zhr: 100 },
  { name: "Oriónidas",      raDeg: 95,  decDeg: 16, startMonth: 10, startDay: 2,  endMonth: 11, endDay: 7,  peakMonth: 10, peakDay: 21, zhr: 20 },
  { name: "Leónidas",       raDeg: 152, decDeg: 22, startMonth: 11, startDay: 6,  endMonth: 11, endDay: 30, peakMonth: 11, peakDay: 18, zhr: 15 },
  { name: "Gemínidas",      raDeg: 112, decDeg: 33, startMonth: 12, startDay: 4,  endMonth: 12, endDay: 17, peakMonth: 12, peakDay: 14, zhr: 150 },
  { name: "Úrsidas",        raDeg: 217, decDeg: 75, startMonth: 12, startDay: 17, endMonth: 12, endDay: 26, peakMonth: 12, peakDay: 22, zhr: 10 },
];
var METEOR_RATE_SCALE = 4; // ajuste de juego: sube/baja lo seguido que se ven fugaces respecto al ZHR real
var METEOR_MAX_ACTIVE = 6;
var METEOR_DOME_R = NIGHT_SKY_DOME_R * 0.95;

function dayOfYearApprox(month, day) {
  var cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  return cum[(month | 0) - 1] + (day | 0);
}

// Devuelve la lluvia activa "ganadora" ahora mismo (la de mayor actividad ponderada por ZHR, si
// hay varias solapadas) y su tasa de aparicion por segundo para el juego, o null si no hay ninguna
// activa en la fecha actual del cielo.
function activeMeteorShowerNow(date) {
  var doy = dayOfYearApprox(date.getMonth() + 1, date.getDate());
  var best = null, bestWeighted = 0, bestActivity = 0;
  for (var i = 0; i < METEOR_SHOWERS.length; i++) {
    var sh = METEOR_SHOWERS[i];
    var s = dayOfYearApprox(sh.startMonth, sh.startDay);
    var e = dayOfYearApprox(sh.endMonth, sh.endDay);
    var p = dayOfYearApprox(sh.peakMonth, sh.peakDay);
    var inRange = s <= e ? (doy >= s && doy <= e) : (doy >= s || doy <= e);
    if (!inRange) continue;
    var span = s <= e ? (e - s) : (366 - s + e);
    var distToPeak = Math.min(Math.abs(doy - p), 366 - Math.abs(doy - p));
    var halfSpan = Math.max(1, span / 2);
    var activity = clamp(1 - distToPeak / halfSpan, 0, 1);
    var weighted = activity * sh.zhr;
    if (weighted > bestWeighted) { bestWeighted = weighted; best = sh; bestActivity = activity; }
  }
  if (!best) return null;
  var ratePerSecond = clamp((bestWeighted / 3600) * METEOR_RATE_SCALE, 0, 0.25);
  return { shower: best, activity: bestActivity, ratePerSecond: ratePerSecond };
}

var meteorPool = [];
var meteorCurrentInfo = null; // { shower, activity, ratePerSecond } o null, refrescado junto al resto del cielo

function meteorMaterial() {
  return new THREE.LineBasicMaterial({ color: 0xfff2cf, transparent: true, opacity: 0, fog: false, depthWrite: false });
}

function ensureMeteorPool() {
  if (meteorPool.length) return;
  for (var i = 0; i < METEOR_MAX_ACTIVE; i++) {
    var geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(6), 3));
    var mesh = new THREE.LineSegments(geo, meteorMaterial());
    mesh.frustumCulled = false;
    mesh.visible = false;
    nightSkyGroup.add(mesh);
    meteorPool.push({ mesh: mesh, age: 0, duration: 0.4, active: false });
  }
}

function spawnMeteor(radiantRaDeg, radiantDecDeg, jd, lat, lon) {
  var hz = equatorialToAltAz(radiantRaDeg, radiantDecDeg, jd, lat, lon);
  var radiantDir = new THREE.Vector3();
  if (hz.altDeg > -20) {
    var rp = sunPositionFromAngles(hz.altDeg, hz.azDeg, 1);
    radiantDir.set(rp.x, rp.y, rp.z);
  } else {
    return; // radiante muy por debajo del horizonte, no merece la pena (rara vez visible igualmente)
  }
  var free = null;
  for (var i = 0; i < meteorPool.length; i++) { if (!meteorPool[i].active) { free = meteorPool[i]; break; } }
  if (!free) return;

  var arbitrary = Math.abs(radiantDir.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
  var axis = new THREE.Vector3().crossVectors(radiantDir, arbitrary).normalize();
  axis.applyAxisAngle(radiantDir, Math.random() * Math.PI * 2);
  var startAngle = deg2rad(15 + Math.random() * 45);
  var streakAngle = deg2rad(5 + Math.random() * 8);
  var startDir = radiantDir.clone().applyAxisAngle(axis, startAngle);
  var endDir = radiantDir.clone().applyAxisAngle(axis, startAngle + streakAngle);
  if (startDir.y < -0.05 && endDir.y < -0.05) return; // por debajo del horizonte, no se ve

  var arr = free.mesh.geometry.attributes.position.array;
  arr[0] = startDir.x * METEOR_DOME_R; arr[1] = startDir.y * METEOR_DOME_R; arr[2] = startDir.z * METEOR_DOME_R;
  arr[3] = endDir.x * METEOR_DOME_R;   arr[4] = endDir.y * METEOR_DOME_R;   arr[5] = endDir.z * METEOR_DOME_R;
  free.mesh.geometry.attributes.position.needsUpdate = true;
  free.mesh.visible = true;
  free.age = 0;
  free.duration = 0.35 + Math.random() * 0.25;
  free.active = true;
}

// Se llama cada frame desde updateNightSky(). La tasa de aparicion (meteorCurrentInfo) solo se
// recalcula una vez por segundo junto al resto del cielo (ver recomputeNightSkyPositions); aqui
// solo se tira "el dado" de aparicion (proceso de Poisson: probabilidad = tasa * dt) y se anima
// el desvanecido de las fugaces ya lanzadas.
function updateMeteorShowers(dt) {
  ensureMeteorPool();
  if (meteorCurrentInfo && meteorCurrentInfo.ratePerSecond > 0 && Math.random() < meteorCurrentInfo.ratePerSecond * dt) {
    var when = nightSkyDateForNow();
    var jd = julianDateUTC(when);
    var lat = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
    var lon = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;
    spawnMeteor(meteorCurrentInfo.shower.raDeg, meteorCurrentInfo.shower.decDeg, jd, lat, lon);
  }
  for (var i = 0; i < meteorPool.length; i++) {
    var m = meteorPool[i];
    if (!m.active) continue;
    m.age += dt;
    var p = m.age / m.duration;
    if (p >= 1) { m.active = false; m.mesh.visible = false; continue; }
    var op = p < 0.15 ? (p / 0.15) : (1 - (p - 0.15) / 0.85);
    m.mesh.material.opacity = clamp(op, 0, 1);
  }
}


/* =========================================================================
   GRILLO NOCTURNO -- canto sintetizado por código (bóveda celeste, fase 2)
   ========================================================================= */
var cricketAudioCtx = null;
var cricketNextChirpMap = new Map(); // id de objeto -> proximo instante (AudioContext.currentTime) de canto
var CRICKET_MAX_SOUNDING = 8;
var CRICKET_HEAR_DIST = 14;

function ensureCricketAudioCtx() {
  if (cricketAudioCtx) return cricketAudioCtx;
  try {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    cricketAudioCtx = new Ctx();
  } catch (e) { cricketAudioCtx = null; }
  return cricketAudioCtx;
}

// Un "canto" de grillo real es un tren de 2-4 pulsos muy cortos y agudos (estridulación). Se
// sintetiza con osciladores cuadrados de vida brevísima -- nada de archivos de audio.
function playCricketChirp(ctx, vol) {
  var now = ctx.currentTime;
  var pulses = 2 + (Math.random() < 0.5 ? 0 : 1);
  for (var p = 0; p < pulses; p++) {
    var t0 = now + p * 0.03;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = "square";
    osc.frequency.value = 4200 + (Math.random() * 300 - 150);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(vol, t0 + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.022);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(t0); osc.stop(t0 + 0.03);
  }
}

// Se llama cada frame (editor y Modo jugar), igual que updateWeatherSystems(). Recorre los objetos
// de la escena buscando prefabs "grillo" visibles; a los que les toque cantar (según su propio
// reloj individual, con algo de aleatoriedad para que no canten todos a la vez) les hace sonar un
// canto con el volumen segun distancia a la camara -- silencioso de dia.
function updateCricketSounds(dt) {
  var dirLen = dirLight.position.length() || 1;
  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));
  var nightFactor = nightTintFactorFromElevation(elevDeg);
  if (nightFactor < 0.2) return;
  var ctx = ensureCricketAudioCtx();
  if (!ctx) return;
  if (ctx.state === "suspended") { ctx.resume().catch(function () {}); }
  var listenerPos = camera.position;
  var sounded = 0;
  var worldPos = new THREE.Vector3();
  sceneObjects.forEach(function (rec) {
    if (sounded >= CRICKET_MAX_SOUNDING) return;
    if (rec.prefabType !== "grillo" || !rec.object3D || !rec.object3D.visible) return;
    var id = rec.id;
    var next = cricketNextChirpMap.get(id);
    if (next == null) { next = ctx.currentTime + Math.random() * 1.5; cricketNextChirpMap.set(id, next); }
    if (ctx.currentTime < next) return;
    rec.object3D.getWorldPosition(worldPos);
    var dist = listenerPos.distanceTo(worldPos);
    cricketNextChirpMap.set(id, ctx.currentTime + 0.6 + Math.random() * 0.9);
    if (dist > CRICKET_HEAR_DIST) return;
    var vol = clamp(1 - dist / CRICKET_HEAR_DIST, 0, 1) * 0.14 * nightFactor;
    if (vol < 0.003) return;
    playCricketChirp(ctx, vol);
    sounded++;
  });
}

function resizeRenderer() {
  let w, h;
  if (isPlayModeActive) {
    // En Modo Jugar el visor SIEMPRE ocupa toda la ventana por CSS (el grid pasa a 0/1fr/0), así
    // que no hace falta medir viewportWrap (un elemento hijo de un grid) para saberlo -- y medirlo
    // resultó ser justo el problema: tras rotar el móvil, ese elemento podía quedarse indicando un
    // tamaño obsoleto de forma persistente (ni una nueva llamada a resizeRenderer() lo corregía; solo
    // una recarga completa de la página lo arreglaba, señal clara de que el propio DOM/layout se
    // quedaba "atascado", no el estado del juego -- que, comprobado con el marcador de depuración,
    // salía siempre correcto). Usamos las dimensiones de la ventana directamente, que el navegador
    // siempre reporta al día, en vez de depender de esa medición indirecta.
    w = (window.visualViewport && window.visualViewport.width) || window.innerWidth;
    h = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
  } else {
    w = viewportWrap.clientWidth; h = viewportWrap.clientHeight;
  }
  // Defensa: en algunos moviles, justo tras un cambio de layout (p.ej. al
  // entrar en Modo Jugar y colapsar el grid), el contenedor puede devolver
  // 0 o valores obsoletos durante un instante. Si eso ocurre, recurrimos al
  // tamano de la ventana para evitar una camara con aspect ratio invalido
  // (pantalla negra / geometria deformada).
  if (!w || !h || !isFinite(w / h)) {
    w = window.innerWidth || w || 1;
    h = window.innerHeight || h || 1;
  }
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.fov = computeFov(camera.aspect, BASE_FOV);
  camera.updateProjectionMatrix();
}
// Al rotar el movil de verdad (no solo cambiar el tamano de la ventana en escritorio), si habia un
// dedo activo sobre el visor arrastrando la mirada o el joystick, ese touch.identifier puede seguir
// "vivo" pero sus coordenadas (clientX/clientY) pasan a referirse a la NUEVA orientacion de golpe --
// el siguiente touchmove ve un salto enorme entre la posicion antigua y la nueva (aunque el dedo no
// se haya movido de verdad), y ese salto se interpreta como "arrastra la mirada muy fuerte", empujando
// playPitch de golpe hasta su tope (mirar al cielo) -- exactamente el "modo dron/spiderman" al volver
// a apaisado. Soltamos el seguimiento tactil ANTES de que llegue ese primer touchmove corrupto; el
// jugador simplemente tiene que volver a tocar para retomar el control, sin ningun salto de camara.
function soltarTactilPorCambioDeOrientacion() {
  touchLookId = null;
  resetTouchJoystick();
}
window.addEventListener("resize", resizeRenderer);
window.addEventListener("orientationchange", () => {
  soltarTactilPorCambioDeOrientacion();
  // Moviles a veces reportan dimensiones antiguas justo tras rotar; forzamos
  // un par de re-calculos con pequeno retardo para que el layout se asiente.
  setTimeout(resizeRenderer, 50);
  setTimeout(resizeRenderer, 300);
});
// ResizeObserver: mas fiable que esperar un tiempo fijo tras "orientationchange" -- reacciona
// exactamente cuando el contenedor del visor cambia de tamano de verdad (tras rotar el movil, tras
// la animacion de la barra de direcciones de Safari al aparecer/ocultarse, etc.), en vez de adivinar
// cuantos milisegundos hace falta esperar. Si el aspect ratio de la camara se queda desincronizado
// del canvas real durante ese hueco, la camara en 3a persona puede acabar calculando una distancia
// de colision incorrecta (con geometria/rayos de una forma que ya no es la real) y terminar metida
// dentro del propio personaje -- lo que se ve como "el personaje ha desaparecido".
if (window.ResizeObserver) {
  new ResizeObserver(() => { soltarTactilPorCambioDeOrientacion(); resizeRenderer(); }).observe(viewportWrap);
}

/* =========================================================================
   UTILIDADES
   ========================================================================= */
let uidCounter = 0;
function uid(prefix) { return prefix + "_" + (++uidCounter) + "_" + Math.random().toString(36).slice(2, 7); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function lerp(a, b, p) { return a + (b - a) * p; }

// Motor de expresiones "seguras" para las acciones Variable/Red (ver triggerOneShotAction): SOLO
// números, nombres de variable (resueltos contra el objeto "vars" que se le pase, NUNCA contra
// window/globalThis), cadenas entre comillas y + - * / (). Nada de acceso a DOM, red, cookies u
// otros objetos -- ni eval() ni new Function() en ningún punto. Es la "caja reducida" de la que no
// se puede salir, algo importante porque los proyectos viajan por enlace compartido o como .html
// exportado: cualquiera que abra uno ejecuta estas expresiones en su propio navegador. Variable no
// definida todavía -> 0 (se "declaran" solas la primera vez que algo las usa, no hace falta un
// panel aparte para darlas de alta). Sintaxis no reconocida -> se ignora ese carácter y sigue, para
// que un despiste de tecleo no rompa la partida entera.
function evalSafeExpr(expr, vars) {
  var s = String(expr == null ? "" : expr);
  var i = 0;
  function peek() { return s[i]; }
  function skipWs() { while (i < s.length && /\s/.test(s[i])) i++; }
  function toNum(v) { var n = typeof v === "number" ? v : parseFloat(v); return isNaN(n) ? 0 : n; }
  function truthy(v) { return typeof v === "string" ? (v !== "" && v !== "0") : !!v; }
  function addVals(a, b) {
    if (typeof a === "string" || typeof b === "string") return String(a == null ? "" : a) + String(b == null ? "" : b);
    return toNum(a) + toNum(b);
  }
  // Compara sin eval: si cualquiera de los dos lados es texto, compara como texto (útil para
  // igualdad de nombres/estados); si no, numérico. Devuelve 1/0 (no boolean) para poder seguir
  // combinando el resultado con + - * / si hiciera falta (p. ej. usar un "if" como interruptor).
  function compareVals(a, b, op) {
    var r;
    if (typeof a === "string" || typeof b === "string") {
      var as = String(a == null ? "" : a), bs = String(b == null ? "" : b);
      if (op === "==") r = as === bs;
      else if (op === "!=") r = as !== bs;
      else if (op === ">") r = as > bs;
      else if (op === "<") r = as < bs;
      else if (op === ">=") r = as >= bs;
      else r = as <= bs;
    } else {
      var an = toNum(a), bn = toNum(b);
      if (op === "==") r = an === bn;
      else if (op === "!=") r = an !== bn;
      else if (op === ">") r = an > bn;
      else if (op === "<") r = an < bn;
      else if (op === ">=") r = an >= bn;
      else r = an <= bn;
    }
    return r ? 1 : 0;
  }
  function parseAtom() {
    skipWs();
    var c = peek();
    if (c === "(") { i++; var v = parseExpr(); skipWs(); if (peek() === ")") i++; return v; }
    if (c === '"' || c === "'") {
      var quote = c; i++; var start = i;
      while (i < s.length && s[i] !== quote) i++;
      var str = s.slice(start, i);
      if (peek() === quote) i++;
      return str;
    }
    if (c >= "0" && c <= "9" || c === ".") {
      var start2 = i;
      while (i < s.length && ((s[i] >= "0" && s[i] <= "9") || s[i] === ".")) i++;
      return parseFloat(s.slice(start2, i));
    }
    if (/[A-Za-z_]/.test(c || "")) {
      var start3 = i;
      while (i < s.length && /[A-Za-z0-9_]/.test(s[i])) i++;
      var name = s.slice(start3, i);
      var val = vars ? vars[name] : undefined;
      return val === undefined ? 0 : val;
    }
    i++; // símbolo no reconocido: se salta sin romper el resto de la expresión
    return 0;
  }
  function parseUnary() {
    skipWs();
    if (peek() === "-") { i++; return -toNum(parseUnary()); }
    if (peek() === "+") { i++; return parseUnary(); }
    if (peek() === "!") { i++; return truthy(parseUnary()) ? 0 : 1; }
    return parseAtom();
  }
  function parseTerm() {
    var v = parseUnary();
    for (;;) {
      skipWs();
      var op = peek();
      if (op === "*" || op === "/" || op === "%") { i++; var rhs = parseUnary(); v = (op === "*") ? (toNum(v) * toNum(rhs)) : (op === "/") ? (toNum(v) / (toNum(rhs) || 1e-9)) : (toNum(v) % (toNum(rhs) || 1e-9)); }
      else break;
    }
    return v;
  }
  function parseAdditive() {
    var v = parseTerm();
    for (;;) {
      skipWs();
      var op = peek();
      if (op === "+" || op === "-") { i++; var rhs = parseTerm(); v = (op === "+") ? addVals(v, rhs) : (toNum(v) - toNum(rhs)); }
      else break;
    }
    return v;
  }
  // Comparación (>, <, >=, <=, ==, !=): un único nivel, no encadenable (a<b<c no funciona como en
  // matemáticas -- como en la mayoría de lenguajes de programación). Devuelve 1/0.
  function parseCompare() {
    var v = parseAdditive();
    skipWs();
    var two = s.substr(i, 2), op = null;
    if (two === ">=" || two === "<=" || two === "==" || two === "!=") { op = two; i += 2; }
    else if (peek() === ">" || peek() === "<") { op = peek(); i += 1; }
    if (op) { skipWs(); var rhs = parseAdditive(); v = compareVals(v, rhs, op); }
    return v;
  }
  function parseAnd() {
    var v = parseCompare();
    for (;;) {
      skipWs();
      if (s.substr(i, 2) === "&&") { i += 2; var rhs = parseCompare(); v = (truthy(v) && truthy(rhs)) ? 1 : 0; }
      else break;
    }
    return v;
  }
  function parseOr() {
    var v = parseAnd();
    for (;;) {
      skipWs();
      if (s.substr(i, 2) === "||") { i += 2; var rhs = parseAnd(); v = (truthy(v) || truthy(rhs)) ? 1 : 0; }
      else break;
    }
    return v;
  }
  function parseExpr() { return parseOr(); }
  try { skipWs(); return s ? parseExpr() : 0; } catch (e) { return 0; }
}

// Sustituye {{nombreDeVariable}} dentro de una URL/plantilla por el valor actual de esa variable
// (codificado para ir seguro en una URL) -- así "https://.../records.php?a={{monedas}}" manda
// parámetros de verdad sin que el autor del escenario tenga que montar la cadena a mano.
function interpolateVars(template, vars) {
  return String(template == null ? "" : template).replace(/\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g, function (m, name) {
    var v = vars ? vars[name] : undefined;
    return encodeURIComponent(v == null ? "" : v);
  });
}
// Igual que interpolateVars pero SIN encodeURIComponent -- para texto que no viaja en una URL
// (portapapeles, rótulos): "%20" en vez de un espacio quedaría feo si no es una URL de verdad.
function interpolateVarsPlain(template, vars) {
  return String(template == null ? "" : template).replace(/\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g, function (m, name) {
    var v = vars ? vars[name] : undefined;
    return v == null ? "" : String(v);
  });
}

function deg2rad(d) { return (d * Math.PI) / 180; }
function rad2deg(r) { return (r * 180) / Math.PI; }
function easeVal(p, kind) {
  if (kind === "smooth") return p * p * (3 - 2 * p);
  return p;
}
function formatTime(s) {
  s = Math.max(0, s || 0);
  const m = Math.floor(s / 60), r = Math.floor(s % 60);
  return m + ":" + String(r).padStart(2, "0");
}
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function arrayBufferToBase64(buf) {
  let binary = "";
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}
function base64ToArrayBuffer(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

/* =========================================================================
   MODELO DE DATOS DE OBJETOS DE ESCENA
   ========================================================================= */
const sceneObjects = new Map(); // id -> record
let sceneOrder = [];            // ids en orden de creación
let selectedId = null;
let selectedIds = new Set();    // selección múltiple (Mayús+clic); selectedId es el último/primario
let objectGroups = new Map();   // groupId -> { id, name, memberIds: [...] } — grupos persistentes (Ctrl+G)
let projectAudio = { musicBase64: null, musicFileName: null, volume: 0.5 }; // música de fondo (Modo jugar / juego exportado)
let bgMusicEl = null;

/* ---- Edición de nodos (forma libre extruida) ---- */
let nodeEditRec = null;         // record actualmente en modo edición de nodos, o null
let nodeEditGroup = null;       // THREE.Group con los marcadores visuales (nodos/manecillas/líneas)
let nodeEditPlane = null;       // THREE.Plane local (en el espacio del objeto) usado para el raycasting
let nodeEditSelIndex = -1;      // índice del nodo seleccionado dentro de rec.extrudeData.nodes, o -1
let nodeEditDrag = null;        // { type: "node"|"handleIn"|"handleOut", index } mientras se arrastra

/* ---- Edición de camino (barrido de una forma libre a lo largo de un trazado) ---- */
let pathEditRec = null;         // record actualmente en modo edición de camino, o null
let pathEditGroup = null;       // THREE.Group con los marcadores visuales del camino
let pathEditPlane = null;       // plano local (XZ, a la altura del origen del objeto) usado para el raycasting
let pathEditSelIndex = -1;      // índice del punto de camino seleccionado, o -1
let pathEditDrag = null;        // { index } mientras se arrastra un punto del camino

function newRecord(partial) {
  const id = uid("obj");
  const rec = Object.assign({
    id, name: "Objeto",
    kind: "primitive",       // primitive | prefab | gltf
    primitiveType: null,
    prefabType: null,
    object3D: null,
    colorMaterials: [],
    opacity: 1,               // opacidad base (0-1), independiente de las acciones "fade" del timeline
    textureBase64: null,      // imagen (ladrillo, teja...) repetida/teselada sobre toda la pieza, o null
    textureRepeatX: 1, textureRepeatY: 1,
    isHazard: false,
    collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" }, // kind: none|volume|character|zone
    facingOffsetDeg: 0,       // solo relevante si collider.kind==="character": corrige el "delante" del modelo
    actions: [],
    checkpoints: null,        // cache, recomputado por recomputeCheckpoints()
    mixer: null,
    clips: [],
    gltfBase64: null,
    gltfFileName: null,
    text3d: null,             // { text, color, size } cuando kind === "text3d"
    extrudeData: null,        // { nodes, depth, bevelEnabled, bevelSize } cuando kind === "extrude"
    imageBase64: null,        // data URL completa (data:image/...;base64,...) cuando kind === "image"
    imageFileName: null,
    videoBase64: null,        // data URL completa cuando kind === "video"
    videoFileName: null,
    videoEl: null,             // <video> real (no serializable, se reconstruye al cargar)
    lightData: null,           // { color, intensity, distance, castShadow } cuando kind === "light"
    cameraPathData: null,      // { path:{nodes,closed}, duration, caption, lookAtTargetId, autoplay } cuando kind === "camerapath"
    weatherData: null,         // { type } cuando kind === "weather" (lluvia/nieve/granizo/tormenta)
    groupId: null,             // id del grupo persistente al que pertenece (Ctrl+G), o null
    interactive: { enabled: false, kind: "text", radius: 2, prompt: "Interactuar", text: "", url: "", choices: [], onInteractAction: null, onShotAction: null }, // kind: text|choice|link
  }, partial);
  // OJO: se registra con rec.id (el id YA FINAL, tras fusionar "partial") y NO con la variable "id"
  // de arriba -- si "partial" trae su propio id (como al cargar un proyecto o pegar un objeto, para
  // conservar el id original), ese id gana la fusión y se convierte en rec.id, pero seguir usando la
  // variable local "id" aquí guardaría el registro bajo un id FANTASMA distinto del real. Con eso,
  // cualquier desplegable que lista objetos para elegir como "target" de una acción (p.ej. "Aplicar
  // a" al configurar un ascensor) ofrecía ese id fantasma como valor -- parecía funcionar en la misma
  // sesión (sceneObjects.get() encontraba el objeto igualmente) pero al guardar y volver a cargar el
  // proyecto (o exportarlo) ese id fantasma no coincidía con nada real, dejando la acción "colgada"
  // sin que el usuario hubiera borrado ni tocado el objeto referenciado.
  sceneObjects.set(rec.id, rec);
  sceneOrder.push(rec.id);
  return rec;
}

function removeRecord(id) {
  const rec = sceneObjects.get(id);
  if (!rec) return;
  if (rec.object3D) scene.remove(rec.object3D);
  sceneObjects.delete(id);
  sceneOrder = sceneOrder.filter((x) => x !== id);
  selectedIds.delete(id);
  if (selectedId === id) selectedId = selectedIds.size ? Array.from(selectedIds).pop() : null;
  if (rec.groupId && objectGroups.has(rec.groupId)) {
    const group = objectGroups.get(rec.groupId);
    group.memberIds = group.memberIds.filter((x) => x !== id);
    if (group.memberIds.length < 2) {
      group.memberIds.forEach((mid) => { const m = sceneObjects.get(mid); if (m) m.groupId = null; });
      objectGroups.delete(rec.groupId);
    }
  }
  recomputeTimelineDuration();
}

function clearAllObjects() {
  [...sceneOrder].forEach(removeRecord);
  eventLogList = [];
  renderEventLog();
}

/* =========================================================================
   PRIMITIVAS Y PREFABS
   ========================================================================= */
function makeStdMat(colorHex) {
  // side: DoubleSide -- un "Plano" (u otra pieza fina, p.ej. paredes hechas con planos)
  // es una sola cara geométrica: por defecto solo se ve/ilumina/proyecta sombra por un
  // lado, y por el otro parece transparente ("le atraviesa la luz"). Con ambas caras
  // pintadas se ve sólido y opaco lo mires por donde lo mires.
  return new THREE.MeshStandardMaterial({ color: colorHex, roughness: 0.85, metalness: 0.05, transparent: true, opacity: 1, side: THREE.DoubleSide });
}

function createPrimitive(kind) {
  let geo;
  let liftY = 0.5;
  switch (kind) {
    case "box": geo = new THREE.BoxGeometry(1, 1, 1); break;
    case "sphere": geo = new THREE.SphereGeometry(0.6, 24, 16); liftY = 0.6; break;
    case "cylinder": geo = new THREE.CylinderGeometry(0.5, 0.5, 1, 24); break;
    case "cone": geo = new THREE.ConeGeometry(0.5, 1, 24); break;
    case "plane": geo = new THREE.PlaneGeometry(1.2, 1.2); liftY = 0; break;
    default: geo = new THREE.BoxGeometry(1, 1, 1);
  }
  const mat = makeStdMat(0x8f97a8);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true; mesh.receiveShadow = true;
  if (kind === "plane") mesh.rotation.x = -Math.PI / 2;
  const group = new THREE.Group();
  group.add(mesh);
  group.position.y = liftY;
  return { object3D: group, colorMaterials: [mat], colliderSize: { x: 1, y: 1, z: 1 } };
}

/* =========================================================================
   FORMA LIBRE EXTRUIDA (nodos + tangentes Bézier -> THREE.Shape -> ExtrudeGeometry)
   ========================================================================= */
// Un nodo: { x, y, handleIn:{x,y}|null, handleOut:{x,y}|null } -- x/y en el plano local del objeto
// (Z=0), handleIn/handleOut son DESPLAZAMIENTOS relativos al nodo (así al mover el nodo sus
// manecillas viajan con él sin recalcular nada). Sin manecilla en un lado, ese tramo es recto.
function defaultExtrudeNodes() {
  return [
    { x: -0.5, y: -0.5, handleIn: null, handleOut: null },
    { x: 0.5, y: -0.5, handleIn: null, handleOut: null },
    { x: 0.5, y: 0.5, handleIn: null, handleOut: null },
    { x: -0.5, y: 0.5, handleIn: null, handleOut: null },
  ];
}

function buildExtrudeShape(nodes) {
  const shape = new THREE.Shape();
  if (!nodes || nodes.length < 2) { shape.moveTo(-0.5, -0.5); shape.lineTo(0.5, -0.5); shape.lineTo(0.5, 0.5); shape.lineTo(-0.5, 0.5); shape.closePath(); return shape; }
  shape.moveTo(nodes[0].x, nodes[0].y);
  for (let i = 1; i <= nodes.length; i++) {
    const prev = nodes[i - 1];
    const curr = nodes[i % nodes.length]; // el último tramo cierra del último nodo de vuelta al primero
    if (prev.handleOut || curr.handleIn) {
      const c1x = prev.x + (prev.handleOut ? prev.handleOut.x : 0);
      const c1y = prev.y + (prev.handleOut ? prev.handleOut.y : 0);
      const c2x = curr.x + (curr.handleIn ? curr.handleIn.x : 0);
      const c2y = curr.y + (curr.handleIn ? curr.handleIn.y : 0);
      shape.bezierCurveTo(c1x, c1y, c2x, c2y, curr.x, curr.y);
    } else {
      shape.lineTo(curr.x, curr.y);
    }
  }
  return shape;
}

function buildExtrudeGeometry(extrudeData) {
  if (extrudeData.path && extrudeData.path.nodes && extrudeData.path.nodes.length >= 2) {
    return buildExtrudeAlongPathGeometry(extrudeData.nodes, extrudeData.path);
  }
  const shape = buildExtrudeShape(extrudeData.nodes);
  const depth = Math.max(0.02, extrudeData.depth || 0.3);
  const bevelEnabled = !!extrudeData.bevelEnabled;
  const bevelSize = Math.max(0.005, Math.min(extrudeData.bevelSize || 0.05, depth / 2 - 0.005));
  return new THREE.ExtrudeGeometry(shape, {
    depth, bevelEnabled,
    bevelThickness: bevelSize, bevelSize, bevelSegments: bevelEnabled ? 3 : 1,
    curveSegments: 16,
  });
}

/* ---- Extrusión "en barrido" siguiendo un camino (para laderas/valles, no solo cajas rectas) ----
   A diferencia de ExtrudeGeometry+extrudePath (que usa marcos de Frenet y puede torcer el perfil en
   curvas), aquí se construyen marcos "siempre en pie": el eje Y del perfil se mantiene lo más vertical
   posible en vez de rotar con la curvatura del camino -- así una ladera no gira sobre sí misma al rodear
   una curva cerrada. */
function buildPathCurve(pathNodes, closed) {
  const pts = pathNodes.map((n) => new THREE.Vector3(n.x, n.y, n.z));
  return new THREE.CatmullRomCurve3(pts, !!closed, "catmullrom", 0.5);
}

function buildSweepFrames(curve, steps) {
  const frames = [];
  const worldUp = new THREE.Vector3(0, 1, 0);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const point = curve.getPointAt(t);
    const tangent = curve.getTangentAt(t).clone().normalize();
    let right = new THREE.Vector3().crossVectors(worldUp, tangent);
    if (right.lengthSq() < 1e-6) {
      // el camino va casi vertical justo en ese punto -- usamos un eje de referencia alternativo
      right = new THREE.Vector3().crossVectors(new THREE.Vector3(1, 0, 0), tangent);
      if (right.lengthSq() < 1e-6) right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 0, 1), tangent);
    }
    right.normalize();
    const up = new THREE.Vector3().crossVectors(tangent, right).normalize();
    frames.push({ point, right, up });
  }
  return frames;
}

function buildExtrudeAlongPathGeometry(nodes, pathData) {
  const profilePts = buildExtrudeShape(nodes).getPoints(Math.max(12, nodes.length * 8));
  const closed = !!pathData.closed;
  const curve = buildPathCurve(pathData.nodes, closed);
  const steps = Math.max(16, pathData.nodes.length * 12);
  const frames = buildSweepFrames(curve, steps);

  const positions = [];
  const uvs = [];
  const indices = [];
  const profCount = profilePts.length;
  const ringCount = frames.length;

  // Coordenadas UV por longitud de arco real (no por índice) -- así un perfil o un camino con tramos muy
  // desiguales no estira ni comprime la textura de forma rara. U recorre el perímetro del perfil (0..1),
  // V recorre el camino (0..1, tantas veces como mida en unidades de escena, para una densidad razonable).
  const profileCum = [0];
  for (let k = 1; k <= profCount; k++) {
    const a = profilePts[k - 1], b = profilePts[k % profCount];
    profileCum.push(profileCum[k - 1] + Math.hypot(b.x - a.x, b.y - a.y));
  }
  const profileLen = Math.max(profileCum[profCount], 0.5) || 1;
  const frameCum = [0];
  for (let k = 1; k < frames.length; k++) {
    frameCum.push(frameCum[k - 1] + frames[k].point.distanceTo(frames[k - 1].point));
  }

  frames.forEach((f, i) => {
    // V en unidades de "vueltas de perfil" (misma densidad de texel que U) en vez de 0..1 fijo --
    // así un camino de 30 unidades con un perfil de 1 unidad de perímetro repite la textura ~30
    // veces en vez de estirarla una sola vez a lo largo de todo el camino.
    const v = frameCum[i] / profileLen;
    profilePts.forEach((p, j) => {
      const wp = new THREE.Vector3()
        .addVectors(f.point, f.right.clone().multiplyScalar(p.x))
        .add(f.up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      uvs.push(profileCum[j] / profileLen, v);
    });
  });

  for (let i = 0; i < ringCount - 1; i++) {
    for (let j = 0; j < profCount; j++) {
      const jNext = (j + 1) % profCount;
      const a = i * profCount + j;
      const b = i * profCount + jNext;
      const c = (i + 1) * profCount + jNext;
      const d = (i + 1) * profCount + j;
      indices.push(a, b, c, a, c, d);
    }
  }

  const positionCountBeforeCaps = positions.length / 3;
  if (!closed) {
    // camino abierto: tapamos los dos extremos con el propio perfil, como las "caps" de una extrusión recta.
    // Estas caras van al final del array de posiciones/uv, con su propio índice base -- no comparten vértices
    // con los anillos (para poder darles una UV plana propia, en vez de la del barrido).
    const minX = Math.min(...profilePts.map((p) => p.x)), maxX = Math.max(...profilePts.map((p) => p.x));
    const minY = Math.min(...profilePts.map((p) => p.y)), maxY = Math.max(...profilePts.map((p) => p.y));
    const capUV = (p) => [(p.x - minX) / Math.max(maxX - minX, 0.001), (p.y - minY) / Math.max(maxY - minY, 0.001)];
    const startBase = positionCountBeforeCaps;
    profilePts.forEach((p) => {
      const wp = new THREE.Vector3().addVectors(frames[0].point, frames[0].right.clone().multiplyScalar(p.x)).add(frames[0].up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      const uv = capUV(p); uvs.push(uv[0], uv[1]);
    });
    const endBase = startBase + profCount;
    const lastFrame = frames[frames.length - 1];
    profilePts.forEach((p) => {
      const wp = new THREE.Vector3().addVectors(lastFrame.point, lastFrame.right.clone().multiplyScalar(p.x)).add(lastFrame.up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      const uv = capUV(p); uvs.push(uv[0], uv[1]);
    });
    const capTris = THREE.ShapeUtils.triangulateShape(profilePts, []);
    capTris.forEach((tri) => { indices.push(startBase + tri[0], startBase + tri[2], startBase + tri[1]); }); // tapa inicial, orden invertido (normal hacia atrás)
    capTris.forEach((tri) => { indices.push(endBase + tri[0], endBase + tri[1], endBase + tri[2]); }); // tapa final
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function buildExtrudeObject(extrudeData) {
  const geo = buildExtrudeGeometry(extrudeData);
  const mat = makeStdMat(0x8f97a8);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true; mesh.receiveShadow = true;
  const group = new THREE.Group();
  group.add(mesh);
  return { object3D: group, colorMaterials: [mat] };
}

function addExtrudeToScene(atPosition) {
  const extrudeData = { nodes: defaultExtrudeNodes(), depth: 0.3, bevelEnabled: false, bevelSize: 0.05 };
  const built = buildExtrudeObject(extrudeData);
  const rec = newRecord({
    name: "Forma libre " + (sceneOrder.length + 1),
    kind: "extrude",
    object3D: built.object3D, colorMaterials: built.colorMaterials,
    collider: { kind: "none", size: { x: 1, y: 1, z: 0.3 }, riskLabel: "" },
    extrudeData,
  });
  placeAndAdd(rec, atPosition);
  return rec;
}
document.getElementById("btnAddExtrude").addEventListener("click", () => { pushUndo(); addExtrudeToScene(); });

function rebuildExtrudeGeometry(rec) {
  const mesh = rec.object3D.children[0];
  if (!mesh) return;
  const oldGeo = mesh.geometry;
  mesh.geometry = buildExtrudeGeometry(rec.extrudeData);
  if (oldGeo) oldGeo.dispose();
}

/* =========================================================================
   RECORRIDO DE CÁMARA (traveling por nodos, estilo Cinemachine)
   ========================================================================= */
// Reutiliza EXACTAMENTE el mismo editor de caminos que ya existía para "extrusión siguiendo un
// camino" (clic para añadir puntos, arrastrar en horizontal, campo de Altura, Catmull-Rom) -- las
// funciones de abajo (pathOwnerPath/pathOwnerRebuild) son la única diferencia: dejan que ese editor
// trabaje tanto sobre una pieza "extrude" (perfil barrido) como sobre un objeto "camerapath" (que no
// tiene perfil ni malla real, solo el camino en sí, visualizado como un tubo fino).
function pathOwnerPath(rec) {
  if (!rec) return null;
  if (rec.kind === "extrude") return rec.extrudeData ? rec.extrudeData.path : null;
  if (rec.kind === "camerapath") return rec.cameraPathData ? rec.cameraPathData.path : null;
  return null;
}
function pathOwnerRebuild(rec) {
  if (rec.kind === "extrude") rebuildExtrudeGeometry(rec);
  else if (rec.kind === "camerapath") rebuildCameraPathVisual(rec);
}

function rebuildCameraPathVisual(rec) {
  const group = rec.object3D;
  const old = group.children.find((ch) => ch.userData && ch.userData.__cameraPathVisual);
  if (old) { group.remove(old); if (old.geometry) old.geometry.dispose(); if (old.material) old.material.dispose(); }
  const pathData = rec.cameraPathData.path;
  if (!pathData.nodes || pathData.nodes.length < 2) return;
  const curve = buildPathCurve(pathData.nodes, pathData.closed);
  const tubeGeo = new THREE.TubeGeometry(curve, Math.max(20, pathData.nodes.length * 8), 0.035, 6, !!pathData.closed);
  const tubeMat = new THREE.MeshBasicMaterial({ color: 0x4fd1c5, transparent: true, opacity: 0.85 });
  const tube = new THREE.Mesh(tubeGeo, tubeMat);
  tube.userData.__cameraPathVisual = true;
  group.add(tube);
}

function defaultCameraPathNodes() {
  return [
    { x: -3, y: 2.6, z: 3 },
    { x: 0, y: 3.2, z: 0 },
    { x: 3, y: 2.6, z: -3 },
  ];
}

function addCameraPathToScene(atPosition) {
  const cameraPathData = { path: { nodes: defaultCameraPathNodes(), closed: false }, duration: 6, caption: "", lookAtTargetId: null, autoplay: false };
  const group = new THREE.Group();
  const rec = newRecord({
    name: "Recorrido de cámara " + (sceneOrder.length + 1),
    kind: "camerapath",
    object3D: group, colorMaterials: [],
    collider: { kind: "none", size: { x: 0.3, y: 0.3, z: 0.3 }, riskLabel: "" },
    cameraPathData,
  });
  rebuildCameraPathVisual(rec);
  placeAndAdd(rec, atPosition);
  logInfo('Recorrido de cámara añadido ("' + rec.name + '"). Edita su camino desde Propiedades y asígnalo con una acción "Recorrido de cámara" (al interactuar, al disparar, o al iniciar la partida).');
  return rec;
}

function addPart(group, mats, geo, color, x, y, z, rx, ry, rz) {
  const mat = makeStdMat(color);
  mats.push(mat);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x, y, z);
  if (rx) mesh.rotation.x = rx;
  if (ry) mesh.rotation.y = ry;
  if (rz) mesh.rotation.z = rz;
  mesh.castShadow = true; mesh.receiveShadow = true;
  group.add(mesh);
  return mesh;
}

function createPrefab(kind) {
  const group = new THREE.Group();
  const mats = [];
  let colliderSize = { x: 1, y: 1, z: 1 };
  let isHazard = false;
  let hazardLabel = "";

  const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
  const cyl = (rt, rb, h, seg) => new THREE.CylinderGeometry(rt, rb, h, seg || 16);

  switch (kind) {
    case "mesa":
      addPart(group, mats, box(1.2, 0.06, 0.7), 0xb98a56, 0, 0.75, 0);
      addPart(group, mats, box(0.06, 0.75, 0.06), 0x5b3f28, -0.55, 0.375, -0.3);
      addPart(group, mats, box(0.06, 0.75, 0.06), 0x5b3f28, 0.55, 0.375, -0.3);
      addPart(group, mats, box(0.06, 0.75, 0.06), 0x5b3f28, -0.55, 0.375, 0.3);
      addPart(group, mats, box(0.06, 0.75, 0.06), 0x5b3f28, 0.55, 0.375, 0.3);
      colliderSize = { x: 1.3, y: 0.8, z: 0.8 };
      break;
    case "silla":
      addPart(group, mats, box(0.45, 0.06, 0.45), 0x6b7280, 0, 0.45, 0);
      addPart(group, mats, box(0.45, 0.5, 0.06), 0x6b7280, 0, 0.7, -0.2);
      addPart(group, mats, box(0.04, 0.45, 0.04), 0x374151, -0.18, 0.22, -0.18);
      addPart(group, mats, box(0.04, 0.45, 0.04), 0x374151, 0.18, 0.22, -0.18);
      addPart(group, mats, box(0.04, 0.45, 0.04), 0x374151, -0.18, 0.22, 0.18);
      addPart(group, mats, box(0.04, 0.45, 0.04), 0x374151, 0.18, 0.22, 0.18);
      colliderSize = { x: 0.5, y: 0.95, z: 0.5 };
      break;
    case "escalera":
      addPart(group, mats, box(0.06, 2, 0.06), 0xd9a441, -0.3, 1, 0);
      addPart(group, mats, box(0.06, 2, 0.06), 0xd9a441, 0.3, 1, 0);
      for (let i = 0; i < 6; i++) addPart(group, mats, box(0.66, 0.05, 0.06), 0xd9a441, 0, 0.25 + i * 0.32, 0);
      colliderSize = { x: 0.7, y: 2, z: 0.4 };
      break;
    case "palet":
      addPart(group, mats, box(1, 0.12, 1.2), 0x9c7b4f, 0, 0.06, 0);
      for (let i = -1; i <= 1; i++) addPart(group, mats, box(0.9, 0.03, 0.12), 0x8a6a41, 0, 0.14, i * 0.5);
      colliderSize = { x: 1, y: 0.3, z: 1.2 };
      break;
    case "valla":
      addPart(group, mats, box(0.08, 1, 0.08), 0xd9a441, -0.9, 0.5, 0);
      addPart(group, mats, box(0.08, 1, 0.08), 0xd9a441, 0.9, 0.5, 0);
      addPart(group, mats, box(1.9, 0.08, 0.08), 0xe2434b, 0, 0.85, 0);
      addPart(group, mats, box(1.9, 0.08, 0.08), 0xffffff, 0, 0.55, 0);
      colliderSize = { x: 2, y: 1, z: 0.3 };
      break;
    case "extintor":
      addPart(group, mats, cyl(0.12, 0.12, 0.55, 16), 0xd21f2b, 0, 0.4, 0);
      addPart(group, mats, cyl(0.03, 0.05, 0.15, 12), 0x2b2b2b, 0, 0.72, 0);
      addPart(group, mats, box(0.16, 0.04, 0.06), 0x2b2b2b, 0, 0.66, 0.09);
      colliderSize = { x: 0.4, y: 0.8, z: 0.4 };
      break;
    case "cable_suelto": {
      const segColor = 0xff6b35;
      const pts = [[-0.6, -0.05], [-0.2, 0.08], [0.15, -0.06], [0.5, 0.04]];
      for (let i = 0; i < pts.length - 1; i++) {
        const [x1, z1] = pts[i], [x2, z2] = pts[i + 1];
        const dx = x2 - x1, dz = z2 - z1;
        const len = Math.sqrt(dx * dx + dz * dz);
        const ang = Math.atan2(dz, dx);
        addPart(group, mats, box(len, 0.03, 0.03), segColor, (x1 + x2) / 2, 0.02, (z1 + z2) / 2, 0, -ang, 0);
      }
      colliderSize = { x: 1.3, y: 0.3, z: 0.4 };
      isHazard = true; hazardLabel = "Riesgo de tropiezo: cable suelto por el suelo";
      break;
    }
    case "grillo": {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), makeStdMat(0x2b2016));
      body.scale.set(1, 0.75, 1.6); body.position.set(0, 0.035, 0);
      body.castShadow = true; body.receiveShadow = true;
      mats.push(body.material); group.add(body);
      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, 0.015, 0.06, -0.05, 1.1, 0, 0.4);
      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, -0.015, 0.06, -0.05, 1.1, 0, -0.4);
      colliderSize = { x: 0.12, y: 0.08, z: 0.18 };
      break;
    }
    case "charco": {
      const mat = makeStdMat(0x3aa0ff);
      mat.opacity = 0.55; mats.push(mat);
      const mesh = new THREE.Mesh(new THREE.CircleGeometry(0.55, 24), mat);
      mesh.rotation.x = -Math.PI / 2; mesh.position.y = 0.011;
      mesh.receiveShadow = true;
      group.add(mesh);
      colliderSize = { x: 1.1, y: 0.2, z: 1.1 };
      isHazard = true; hazardLabel = "Riesgo de resbalón: charco / derrame en el suelo";
      break;
    }
    case "personaje": {
      const bodyGeo = new THREE.CapsuleGeometry(0.22, 0.65, 6, 12);
      addPart(group, mats, bodyGeo, 0x4fd1c5, 0, 0.55, 0);
      const headGeo = new THREE.SphereGeometry(0.15, 16, 12);
      addPart(group, mats, headGeo, 0xf2c9a0, 0, 1.02, 0);
      addPart(group, mats, box(0.3, 0.22, 0.05), 0xff9f1c, 0, 0.62, 0.19);
      colliderSize = { x: 0.5, y: 1.2, z: 0.5 };
      break;
    }
    case "tablon": {
      addPart(group, mats, box(0.06, 1.4, 0.06), 0x6b4a2b, -0.55, 0.7, 0);
      addPart(group, mats, box(0.06, 1.4, 0.06), 0x6b4a2b, 0.55, 0.7, 0);
      addPart(group, mats, box(1.3, 0.9, 0.05), 0x8a6a41, 0, 1.1, 0);
      addPart(group, mats, box(0.5, 0.32, 0.01), 0xf0e6d2, -0.32, 1.3, 0.03);
      addPart(group, mats, box(0.5, 0.32, 0.01), 0xf0e6d2, 0.32, 1.05, 0.03);
      colliderSize = { x: 1.3, y: 1.4, z: 0.4 };
      break;
    }
    case "papel": {
      addPart(group, mats, box(0.28, 0.01, 0.38), 0xf5f0e4, 0, 0.02, 0);
      colliderSize = { x: 0.5, y: 0.4, z: 0.5 };
      break;
    }
    case "cajon": {
      addPart(group, mats, box(0.6, 0.5, 0.5), 0x6b7280, 0, 0.25, 0);
      addPart(group, mats, box(0.56, 0.16, 0.03), 0x4b5563, 0, 0.35, 0.26);
      addPart(group, mats, cyl(0.015, 0.015, 0.1, 8), 0x2b2b2b, 0, 0.35, 0.3, Math.PI / 2);
      colliderSize = { x: 0.7, y: 0.6, z: 0.7 };
      break;
    }
    default:
      addPart(group, mats, box(1, 1, 1), 0x8f97a8, 0, 0.5, 0);
  }
  return { object3D: group, colorMaterials: mats, colliderSize, isHazard, hazardLabel };
}

const PREFAB_LABELS = {
  mesa: "Mesa", silla: "Silla", escalera: "Escalera", palet: "Palé", valla: "Valla",
  extintor: "Extintor", cable_suelto: "Cable suelto", charco: "Charco", personaje: "Trabajador",
  tablon: "Tablón de anuncios", papel: "Papel", cajon: "Cajón",
};

const INTERACTIVE_DEFAULTS = {
  tablon: { enabled: true, kind: "text", radius: 2, prompt: "Leer", text: "Aviso: uso obligatorio de equipo de protección individual (EPI) en esta zona.", choices: [], onInteractAction: null, onShotAction: null },
  papel: { enabled: true, kind: "text", radius: 1.6, prompt: "Leer", text: "Nota manuscrita: revisar el extintor antes de las 9:00.", choices: [], onInteractAction: null, onShotAction: null },
  cajon: { enabled: true, kind: "choice", radius: 1.8, prompt: "Abrir cajón", text: "¿Qué haces con el cajón?", choices: [{ label: "Abrirlo con cuidado", points: 1, action: null }, { label: "Tirar con fuerza", points: -1, action: null }], onInteractAction: null, onShotAction: null },
};
const PRIMITIVE_LABELS = { box: "Caja", sphere: "Esfera", cylinder: "Cilindro", cone: "Cono", plane: "Plano" };

/* =========================================================================
   PUNTOS DE LUZ
   ========================================================================= */
// Construye un THREE.PointLight colocable, envuelto en un Group junto a una pequeña esfera
// "bombilla" que sirve de referencia visual/objetivo de clic en el editor (el PointLight en sí no
// tiene geometría, así que sin esta esfera sería imposible seleccionarlo con el ratón). La esfera
// se oculta al entrar en Modo jugar (ver enterPlayMode/exitPlayMode) y no se incluye en absoluto en
// el videojuego exportado (ver buildLightObject en la plantilla ES5) -- solo es una ayuda de edición.
function buildLightObject(lightData) {
  const ld = Object.assign({ color: "#fff2cc", intensity: 1.2, distance: 8, castShadow: false }, lightData || {});
  const group = new THREE.Group();
  const gizmoMat = new THREE.MeshBasicMaterial({ color: ld.color, transparent: true, opacity: 0.9 });
  const gizmoMesh = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 8), gizmoMat);
  group.add(gizmoMesh);
  const light = new THREE.PointLight(new THREE.Color(ld.color), ld.intensity, ld.distance, 2);
  light.castShadow = !!ld.castShadow;
  if (light.castShadow) light.shadow.mapSize.set(512, 512);
  group.add(light);
  group.userData.__lightObj = light;
  group.userData.__gizmoMesh = gizmoMesh;
  group.userData.__gizmoMat = gizmoMat;
  return { object3D: group, colorMaterials: [], lightData: ld };
}

function addLightToScene(atPosition) {
  const built = buildLightObject({ color: "#fff2cc", intensity: 1.2, distance: 8, castShadow: false });
  built.object3D.position.y = 2.2; // por defecto, elevada -- a ras de suelo apenas ilumina nada
  const rec = newRecord({
    name: "Luz puntual " + (sceneOrder.length + 1),
    kind: "light",
    object3D: built.object3D, colorMaterials: [],
    collider: { kind: "none", size: { x: 0.3, y: 0.3, z: 0.3 }, riskLabel: "" },
    lightData: built.lightData,
  });
  rec.__lightObj = built.object3D.userData.__lightObj;
  rec.__gizmoMesh = built.object3D.userData.__gizmoMesh;
  rec.__gizmoMat = built.object3D.userData.__gizmoMat;
  placeAndAdd(rec, atPosition);
  logInfo('Luz puntual añadida ("' + rec.name + '"). Ajusta color, intensidad y alcance desde Propiedades.');
  return rec;
}

/* =========================================================================
   METEOROLOGÍA (lluvia, nieve, granizo, tormenta)
   ========================================================================= */
// Cada tipo define cuántas partículas, a qué velocidad caen, su color/tamaño/opacidad y cuánto
// "viento" las empuja de lado; "rain" cae recta, "snow" cae despacio con vaivén lateral. La tormenta
// además dispara rayo (destello de luz) + trueno (sonido procedural, sin necesitar ningún archivo de
// audio). El volumen donde caen las partículas es local (WEATHER_AREA_*) -- se cubre la zona deseada
// del escenario moviendo/escalando el objeto, exactamente igual que con cualquier otra pieza.
const WEATHER_TYPES = {
  rain_light: { label: "Lluvia ligera", icon: "🌦️", count: 220, fallSpeed: 9, color: "#9fc6ff", size: 0.045, opacity: 0.5, driftX: 0.4, driftZ: 0.1, kind: "rain" },
  rain_heavy: { label: "Lluvia intensa", icon: "🌧️", count: 600, fallSpeed: 14, color: "#bcdcff", size: 0.05, opacity: 0.62, driftX: 0.9, driftZ: 0.2, kind: "rain" },
  storm: { label: "Tormenta (rayo y trueno)", icon: "⛈️", count: 650, fallSpeed: 15, color: "#cfe3ff", size: 0.05, opacity: 0.65, driftX: 1.7, driftZ: 0.4, kind: "rain", lightning: true },
  hail: { label: "Granizo", icon: "🧊", count: 200, fallSpeed: 16, color: "#eef3fb", size: 0.11, opacity: 0.85, driftX: 0.6, driftZ: 0.2, kind: "rain" },
  snow_light: { label: "Nieve", icon: "🌨️", count: 170, fallSpeed: 1.6, color: "#ffffff", size: 0.09, opacity: 0.85, driftX: 0.5, driftZ: 0.5, kind: "snow" },
  snow_heavy: { label: "Ventisca", icon: "❄️", count: 480, fallSpeed: 3.2, color: "#ffffff", size: 0.1, opacity: 0.9, driftX: 2.2, driftZ: 1.4, kind: "snow" },
};
const WEATHER_AREA_RADIUS = 10, WEATHER_AREA_HEIGHT = 16;

function buildWeatherObject(weatherData) {
  const wd = Object.assign({ type: "rain_light" }, weatherData || {});
  const cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;
  const count = cfg.count;
  const positions = new Float32Array(count * 3);
  const speeds = new Float32Array(count);
  const phases = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    positions[i * 3 + 0] = (Math.random() * 2 - 1) * WEATHER_AREA_RADIUS;
    positions[i * 3 + 1] = Math.random() * WEATHER_AREA_HEIGHT;
    positions[i * 3 + 2] = (Math.random() * 2 - 1) * WEATHER_AREA_RADIUS;
    speeds[i] = 0.75 + Math.random() * 0.5;
    phases[i] = Math.random() * Math.PI * 2;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.PointsMaterial({ color: new THREE.Color(cfg.color), size: cfg.size, transparent: true, opacity: cfg.opacity, depthWrite: false, sizeAttenuation: true });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  const group = new THREE.Group();
  group.add(points);
  group.userData.__weatherPoints = points;
  group.userData.__weatherSpeeds = speeds;
  group.userData.__weatherPhases = phases;
  group.userData.__weatherFlashTimer = 0;
  group.userData.__weatherNextFlash = 2 + Math.random() * 4;
  group.userData.__weatherFlashActive = 0;
  return { object3D: group, colorMaterials: [mat], weatherData: wd };
}

function addWeatherToScene(type, atPosition) {
  const cfg = WEATHER_TYPES[type] || WEATHER_TYPES.rain_light;
  const built = buildWeatherObject({ type });
  const rec = newRecord({
    name: cfg.label + " " + (sceneOrder.length + 1),
    kind: "weather",
    object3D: built.object3D, colorMaterials: built.colorMaterials,
    collider: { kind: "none", size: { x: 1, y: 1, z: 1 }, riskLabel: "" },
    weatherData: built.weatherData,
  });
  placeAndAdd(rec, atPosition);
  logInfo(cfg.label + ' añadida a la escena ("' + rec.name + '"). Muévela/escálala (arriba en Propiedades) para cubrir la zona que quieras -- actívala/desactívala con una acción "Aparecer/desaparecer" como cualquier otro objeto.');
  return rec;
}

// Reconstruye la geometría/material de un objeto de clima ya colocado para cambiarlo de tipo desde
// Propiedades, sin perder su posición/rotación/escala (no se toca el Group, solo lo que hay dentro).
function setWeatherType(rec, type) {
  const built = buildWeatherObject({ type });
  const oldPoints = rec.object3D.userData.__weatherPoints;
  const newPoints = built.object3D.userData.__weatherPoints;
  oldPoints.geometry.dispose();
  oldPoints.material.dispose();
  oldPoints.geometry = newPoints.geometry;
  oldPoints.material = newPoints.material;
  rec.object3D.userData.__weatherSpeeds = built.object3D.userData.__weatherSpeeds;
  rec.object3D.userData.__weatherPhases = built.object3D.userData.__weatherPhases;
  rec.object3D.userData.__weatherFlashTimer = 0;
  rec.object3D.userData.__weatherNextFlash = 2 + Math.random() * 4;
  rec.object3D.userData.__weatherFlashActive = 0;
  rec.weatherData = built.weatherData;
  rec.colorMaterials = [oldPoints.material];
}

let lightningLight = null;
function ensureLightningLight() {
  if (!lightningLight) {
    lightningLight = new THREE.PointLight(0xdfe8ff, 0, 80, 1.5);
    lightningLight.position.set(0, 25, 0);
    scene.add(lightningLight);
  }
  return lightningLight;
}

let sharedWeatherAudioCtx = null;
// Trueno 100% generado por código (ruido blanco con un filtro paso-bajo que se va cerrando + una
// envolvente de volumen) -- así no hace falta empaquetar ningún archivo de audio en el proyecto.
function playThunderSound() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!sharedWeatherAudioCtx) sharedWeatherAudioCtx = new AC();
    const ctx = sharedWeatherAudioCtx;
    const dur = 1.4;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 1.6);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1200, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + dur);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.7, ctx.currentTime + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    src.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
    const delay = 0.25 + Math.random() * 1.2; // el trueno llega un poco despues del rayo (distancia)
    src.start(ctx.currentTime + delay);
  } catch (e) { /* WebAudio no disponible/bloqueado en este navegador: simplemente no habra sonido */ }
}

function updateStormLightning(rec, dt) {
  const ud = rec.object3D.userData;
  const light = ensureLightningLight();
  if (ud.__weatherFlashActive > 0) {
    ud.__weatherFlashActive -= dt;
    light.intensity = Math.max(0, ud.__weatherFlashActive) * 14;
    if (ud.__weatherFlashActive <= 0) { ud.__weatherFlashActive = 0; light.intensity = 0; }
    return;
  }
  ud.__weatherFlashTimer += dt;
  if (ud.__weatherFlashTimer >= ud.__weatherNextFlash) {
    ud.__weatherFlashTimer = 0;
    ud.__weatherNextFlash = 4 + Math.random() * 9;
    ud.__weatherFlashActive = 0.12 + Math.random() * 0.08;
    light.intensity = 14;
    playThunderSound();
  }
}

// Se llama en cada frame (editor y Modo jugar) para TODOS los objetos de clima visibles: hace caer
// las partículas y las envuelve al llegar al suelo/bordes del volumen, y gestiona rayo+trueno en las
// tormentas. Los objetos invisibles (apagados con una acción "Aparecer/desaparecer") no se procesan
// -- así activar/desactivar la lluvia/nieve reutiliza el sistema de acciones ya existente.
function updateWeatherSystems(dt) {
  const t = performance.now() / 1000;
  for (const rec of sceneObjects.values()) {
    if (rec.kind !== "weather" || !rec.object3D.visible) continue;
    const points = rec.object3D.userData.__weatherPoints;
    if (!points) continue;
    const wd = rec.weatherData || { type: "rain_light" };
    const cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;
    const pos = points.geometry.attributes.position.array;
    const speeds = rec.object3D.userData.__weatherSpeeds;
    const phases = rec.object3D.userData.__weatherPhases;
    const count = pos.length / 3;
    const isSnow = cfg.kind === "snow";
    for (let i = 0; i < count; i++) {
      const idx = i * 3;
      pos[idx + 1] -= cfg.fallSpeed * speeds[i] * dt;
      pos[idx + 0] += cfg.driftX * dt * (isSnow ? Math.sin(t + phases[i]) : 1);
      pos[idx + 2] += cfg.driftZ * dt * (isSnow ? Math.cos(t * 0.7 + phases[i]) : 1);
      if (pos[idx + 1] < 0) {
        pos[idx + 1] = WEATHER_AREA_HEIGHT;
        pos[idx + 0] = (Math.random() * 2 - 1) * WEATHER_AREA_RADIUS;
        pos[idx + 2] = (Math.random() * 2 - 1) * WEATHER_AREA_RADIUS;
      }
      const lim = WEATHER_AREA_RADIUS * 1.3;
      if (pos[idx + 0] > lim) pos[idx + 0] = -lim; else if (pos[idx + 0] < -lim) pos[idx + 0] = lim;
      if (pos[idx + 2] > lim) pos[idx + 2] = -lim; else if (pos[idx + 2] < -lim) pos[idx + 2] = lim;
    }
    points.geometry.attributes.position.needsUpdate = true;
    if (cfg.lightning) updateStormLightning(rec, dt);
  }
}

function addPrimitiveToScene(kind, atPosition) {
  const built = createPrimitive(kind);
  const rec = newRecord({
    name: PRIMITIVE_LABELS[kind] + " " + (sceneOrder.length + 1),
    kind: "primitive", primitiveType: kind,
    object3D: built.object3D, colorMaterials: built.colorMaterials,
    collider: { kind: "none", size: built.colliderSize, riskLabel: "" },
  });
  placeAndAdd(rec, atPosition);
  return rec;
}

function addPrefabToScene(kind, atPosition) {
  const built = createPrefab(kind);
  const isCharacter = kind === "personaje";
  const interactiveDefault = INTERACTIVE_DEFAULTS[kind];
  const rec = newRecord({
    name: PREFAB_LABELS[kind] + " " + (sceneOrder.length + 1),
    kind: "prefab", prefabType: kind,
    object3D: built.object3D, colorMaterials: built.colorMaterials,
    isHazard: built.isHazard,
    collider: {
      kind: isCharacter ? "character" : (built.isHazard ? "zone" : "none"),
      size: built.colliderSize,
      riskLabel: built.hazardLabel || "",
    },
    interactive: interactiveDefault
      ? JSON.parse(JSON.stringify(interactiveDefault))
      : { enabled: false, kind: "text", radius: 2, prompt: "Interactuar", text: "", choices: [], onShotAction: null },
  });
  placeAndAdd(rec, atPosition);
  return rec;
}

let placementCounter = 0;
function placeAndAdd(rec, atPosition) {
  if (atPosition) {
    rec.object3D.position.x += atPosition.x;
    rec.object3D.position.z += atPosition.z;
    if (atPosition.y !== undefined) rec.object3D.position.y += atPosition.y;
  } else {
    const ang = placementCounter * 0.9;
    rec.object3D.position.x += Math.cos(ang) * 1.6;
    rec.object3D.position.z += Math.sin(ang) * 1.6;
    placementCounter++;
  }
  scene.add(rec.object3D);
  recomputeCheckpoints(rec);
  recomputeTimelineDuration();
  renderHierarchy();
  selectObject(rec.id);
}

/* =========================================================================
   IMPORTACIÓN GLTF (BLENDER)
   ========================================================================= */
const gltfLoader = new GLTFLoader();

// Recorre un modelo glTF/GLB recién importado y recopila los materiales de sus mallas,
// forzando transparent=true en cada uno (igual que ya hacen los objetos primitivos al crearse)
// para que las acciones "Aparecer/Desaparecer" (fade) y "Destello" (flash) puedan operar sobre
// modelos importados, no solo sobre primitivas.
function collectGltfColorMaterials(inner) {
  const mats = [];
  inner.traverse((o) => {
    if (o.isMesh && o.material) {
      const ms = Array.isArray(o.material) ? o.material : [o.material];
      ms.forEach((m) => {
        m.transparent = true;
        if (!mats.includes(m)) mats.push(m);
      });
    }
  });
  return mats;
}

// Calcula el cajón (bounding box) de un modelo importado para poder normalizar su tamaño.
// Para una malla normal, Box3.setFromObject basta. Pero en un modelo CON ESQUELETO (personaje rigged),
// la geometría "en reposo" (bind pose) no se deforma según los huesos -- Box3 lee siempre los vértices
// crudos, tal cual salieron del exportador, ignorando el esqueleto por completo -- así que si el bind
// pose del archivo no es una postura de pie normal (agachada, en cuclillas...), el cajón puede salir
// ridículamente bajo aunque el personaje mida más de metro y medio en la animación real. Le pasó
// exactamente eso a "CesiumMan": 0.31 unidades de alto en reposo frente a 1.5 de ancho, así que la
// normalización lo dejaba convertido en una lámina casi invisible. Para evitarlo, si el modelo tiene
// huesos y animación, recorremos el clip en varios instantes y usamos la posición real de cada hueso
// en el mundo (que sí seguía la pose, a diferencia de la malla base) para estimar el tamaño real.
function computeModelBounds(inner, mixer, clips) {
  let hasSkinned = false;
  inner.traverse((o) => { if (o.isSkinnedMesh) hasSkinned = true; });
  if (!hasSkinned || !mixer || !clips || !clips.length) {
    return new THREE.Box3().setFromObject(inner);
  }
  const box = new THREE.Box3();
  inner.updateMatrixWorld(true);
  const action = mixer.clipAction(clips[0]);
  action.play();
  const steps = 12;
  const dur = clips[0].duration || 0;
  for (let i = 0; i <= steps; i++) {
    mixer.setTime(dur * i / steps);
    inner.updateMatrixWorld(true);
    inner.traverse((o) => {
      if (o.isSkinnedMesh && o.skeleton) {
        o.skeleton.bones.forEach((b) => box.expandByPoint(b.getWorldPosition(new THREE.Vector3())));
      }
    });
  }
  mixer.setTime(0);
  action.stop();
  mixer.update(0);
  if (box.isEmpty()) return new THREE.Box3().setFromObject(inner);
  // Los huesos marcan el "esqueleto interior", no la piel -- añadimos un margen para cubrir el
  // volumen visual real de la malla alrededor de ellos (grosor del cuerpo, cabeza, manos...).
  box.expandByScalar(0.15);
  return box;
}

function addGltfToScene(arrayBuffer, fileName, base64ForSave) {
  gltfLoader.parse(arrayBuffer, "", (gltf) => {
    const inner = gltf.scene || gltf.scenes[0];
    inner.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    const colorMaterials = collectGltfColorMaterials(inner);

    const clips = gltf.animations || [];
    let mixer = null;
    if (clips.length) mixer = new THREE.AnimationMixer(inner);

    // Normalizar tamaño: si el modelo es enorme o minúsculo, lo escalamos a ~1.6 unidades de alto.
    const box = computeModelBounds(inner, mixer, clips);
    const size = new THREE.Vector3(); box.getSize(size);
    const maxDim = Math.max(size.x, size.y, size.z) || 1;
    const targetH = 1.6;
    const scaleFactor = maxDim > 0 ? targetH / maxDim : 1;
    inner.scale.setScalar(scaleFactor);
    const box2 = computeModelBounds(inner, mixer, clips);
    inner.position.y -= box2.min.y; // apoyar sobre el suelo
    if (mixer) mixer.update(0);

    const group = new THREE.Group();
    group.add(inner);

    const rec = newRecord({
      name: (fileName || "Modelo").replace(/\.(glb|gltf)$/i, "") + " " + (sceneOrder.length + 1),
      kind: "gltf",
      object3D: group, colorMaterials,
      collider: { kind: "none", size: { x: 0.8, y: 1.6, z: 0.8 }, riskLabel: "" },
      mixer, clips,
      gltfBase64: base64ForSave || null,
      gltfFileName: fileName || null,
    });
    placeAndAdd(rec);
    logInfo("Modelo \"" + rec.name + "\" importado" + (clips.length ? (" con " + clips.length + " animación(es).") : "."));
  }, (err) => {
    alertBox("No se pudo interpretar el archivo como glTF/GLB. Si venía de Blender, exporta como glTF binario (.glb) con todo incluido. Detalle: " + (err && err.message ? err.message : err), "warn");
  });
}

function loadGltfFile(file) {
  pushUndo();
  const reader = new FileReader();
  reader.onload = () => {
    const buf = reader.result;
    const b64 = arrayBufferToBase64(buf);
    addGltfToScene(buf, file.name, b64);
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + file.name + ".", "warn");
  reader.readAsArrayBuffer(file);
}

document.getElementById("btnGltfTrigger").addEventListener("click", () => document.getElementById("gltfInput").click());
document.getElementById("gltfInput").addEventListener("change", (e) => {
  if (e.target.files[0]) loadGltfFile(e.target.files[0]);
  e.target.value = "";
});
const dropHint = document.getElementById("dropHint");
["dragenter", "dragover"].forEach((ev) => dropHint.addEventListener(ev, (e) => { e.preventDefault(); dropHint.classList.add("drag"); }));
["dragleave", "drop"].forEach((ev) => dropHint.addEventListener(ev, (e) => { e.preventDefault(); dropHint.classList.remove("drag"); }));
dropHint.addEventListener("drop", (e) => {
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) loadGltfFile(f);
});

/* =========================================================================
   TEXTO 3D (canvas-texture) E IMÁGENES (cartel/póster)
   ========================================================================= */
// Respeta los saltos de línea que el usuario escriba a mano (\n) como línea dura -- cada párrafo se
// envuelve por palabras POR SEPARADO, así que un \n nunca se pierde fundiéndose con el ajuste automático.
function medirLineasTexto(ctx, text, maxWidth) {
  const parrafos = (text || "").split("\n");
  const lines = [];
  parrafos.forEach((parrafo) => {
    const words = parrafo.split(/\s+/).filter(Boolean);
    if (!words.length) { lines.push(""); return; } // línea en blanco intencional, se conserva
    let line = "";
    for (const w of words) {
      const test = line ? line + " " + w : w;
      if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = w; }
      else line = test;
    }
    if (line) lines.push(line);
  });
  if (!lines.length) lines.push("");
  return lines;
}

// El ANCHO de línea lo elige quien edita (boxWidth, en píxeles de lienzo -- 472 por defecto, el mismo
// valor que llevaba siempre este editor, así que si no tocas nada se ve igual que antes). Lo que sí
// se ajusta solo es el ALTO del lienzo, según cuántas líneas hagan falta -- así una frase larga ya no
// se recorta (el fallo original), pero la anchura/proporción que tú fijas ya no cambia sola.
function buildText3DTexture(text, color, boxWidth) {
  const FONT_PX = 56, LINE_HEIGHT = 64, PADDING = 20;
  const anchoLinea = Math.max(60, boxWidth || 472);
  const medir = document.createElement("canvas").getContext("2d");
  medir.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";
  const lines = medirLineasTexto(medir, text || "Texto", anchoLinea);

  const canvas = document.createElement("canvas");
  canvas.width = Math.ceil(anchoLinea + PADDING * 2);
  canvas.height = Math.ceil(lines.length * LINE_HEIGHT + PADDING * 2);
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = color || "#ffffff";
  ctx.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const startY = canvas.height / 2 - ((lines.length - 1) * LINE_HEIGHT) / 2;
  lines.forEach((l, i) => ctx.fillText(l, canvas.width / 2, startY + i * LINE_HEIGHT));
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  // heightFactor: cuánto MUNDO ocupa el alto del lienzo, en las mismas unidades que "size" -- vale
  // exactamente 1 para una sola línea (mismo tamaño de siempre, no cambia nada en los rótulos ya
  // existentes), y crece proporcionalmente con cada línea de más. Sin esto, el plano medía SIEMPRE
  // 1*size de alto (solo el ANCHO seguía al aspecto) -- así que un texto de varias líneas se
  // aplastaba entero dentro de esa misma altura fija en vez de crecer hacia abajo: el "no se separa
  // en líneas hacia abajo... desaparece" que describe el usuario es justo este aplastamiento (la
  // fuente, en unidades de mundo, se hacía cada vez más diminuta cuantas más líneas hacían falta).
  const REF_LINE_CANVAS_PX = LINE_HEIGHT + PADDING * 2; // = alto de lienzo para exactamente 1 línea
  // aspect: el ANCHO de la caja en el mismo "por línea" que heightFactor (canvas.width / REF), NO
  // canvas.width/canvas.height. El ancho del lienzo NO cambia según el número de líneas (el ancho de
  // caja lo fija boxWidth), así que su escala mundo/píxel debe ser la MISMA constante en ambos ejes
  // (x e y) para que la textura no se estire -- si aquí se usa canvas.height (que sí crece con las
  // líneas), la caja se estrecha en horizontal cuantas más líneas hay y la fuente sale angosta y
  // alargada hacia arriba (justo la distorsión que describe el usuario tras el primer arreglo).
  return { texture, aspect: canvas.width / REF_LINE_CANVAS_PX, heightFactor: canvas.height / REF_LINE_CANVAS_PX };
}

function buildText3DObject(text, color, size, boxWidth) {
  const { texture, aspect, heightFactor } = buildText3DTexture(text, color, boxWidth);
  // polygonOffset: el texto suele quedar pegado o muy cerca de otra superficie (un tablón, una
  // pared) -- son dos caras casi coplanares, y a ángulo de cámara rasante (poco ortonormal a la
  // superficie) el z-buffer pierde precisión ahí y parpadea/recorta la una contra la otra. Este
  // desplazamiento de profundidad (no de posición real) acerca el texto al z-buffer sin moverlo
  // en el mundo, el mismo truco de siempre para "calcomanías" sobre una superficie.
  const mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide, opacity: 1, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
  // alphaTest: sin esto, aunque el plano lleve polygonOffset, el relleno TRANSPARENTE de la
  // textura (fuera de las letras) seguía escribiendo profundidad (por ser transparent:true, sin
  // depthWrite:false a propósito -- las "paredes" de este motor también son transparent:true para
  // poder desvanecerse, así que el cartel necesita seguir grabando su propia profundidad para
  // defenderse si el orden de dibujo transparente sale invertido). Con alphaTest, los píxeles casi
  // del todo transparentes se DESCARTAN en vez de mezclarse, así que no tapan lo que hay detrás
  // solo por llevar profundidad escrita.
  mat.alphaTest = 0.5;
  const s = size || 1;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(aspect * s, heightFactor * s), mat);
  const group = new THREE.Group();
  group.add(mesh);
  group.position.y = 1.2;
  return { object3D: group, colorMaterials: [mat], mesh };
}

function rebuildText3D(rec) {
  const mesh = rec.object3D.children[0];
  if (!mesh) return;
  const oldTex = mesh.material.map;
  const { texture, aspect, heightFactor } = buildText3DTexture(rec.text3d.text, rec.text3d.color, rec.text3d.boxWidth);
  mesh.material.map = texture;
  mesh.material.needsUpdate = true;
  if (oldTex) oldTex.dispose();
  const s = rec.text3d.size || 1;
  mesh.geometry.dispose();
  mesh.geometry = new THREE.PlaneGeometry(aspect * s, heightFactor * s);
}

function addText3DToScene(atPosition) {
  const text3d = { text: "Texto 3D", color: "#ffffff", size: 1, boxWidth: 472 };
  const built = buildText3DObject(text3d.text, text3d.color, text3d.size, text3d.boxWidth);
  const rec = newRecord({
    name: "Texto 3D " + (sceneOrder.length + 1),
    kind: "text3d",
    object3D: built.object3D, colorMaterials: built.colorMaterials,
    collider: { kind: "none", size: { x: 2, y: 1, z: 0.1 }, riskLabel: "" },
    text3d,
  });
  placeAndAdd(rec, atPosition);
  return rec;
}
document.getElementById("btnAddText3D").addEventListener("click", () => { pushUndo(); addText3DToScene(); });

function buildImagePlaneObject(dataUrl, height, onReady) {
  const img = new Image();
  img.onload = () => {
    const texture = new THREE.Texture(img);
    texture.needsUpdate = true;
    const aspect = (img.width / img.height) || 1;
    const h = height || 1.5;
    const w = h * aspect;
    const mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide });
    // Mismo ajuste de profundidad que el texto 3D (ver buildText3DObject): una imagen pegada a una
    // pared/tablón también podía parpadear/recortarse contra ella en ángulos rasantes.
    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;
    mat.alphaTest = 0.5;
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    const group = new THREE.Group();
    group.add(mesh);
    group.position.y = h / 2;
    onReady({ object3D: group, colorMaterials: [mat], mesh, aspect });
  };
  img.onerror = () => onReady(null);
  img.src = dataUrl;
}

// Reutilizado tanto por replaceImageForRecord (reemplazo manual desde el editor) como por la acción
// "Imagen desde variable" y el modo "imagen" de la acción Red (ver triggerOneShotAction) -- cambia la
// textura de un objeto de Imagen YA existente a partir de un data URL, liberando la textura vieja.
// Asíncrono (construir la nueva textura implica esperar a que la imagen cargue, aunque sea un data
// URL) -- por eso lleva un onDone(ok) en vez de devolver nada.
function swapImageTexture(rec, dataUrl, onDone) {
  buildImagePlaneObject(dataUrl, null, (built) => {
    if (!built) { if (onDone) onDone(false); return; }
    const mesh = rec.object3D.children[0];
    mesh.geometry.dispose();
    if (mesh.material.map) mesh.material.map.dispose();
    mesh.material.dispose();
    mesh.geometry = built.mesh.geometry;
    mesh.material = built.mesh.material;
    rec.colorMaterials = [mesh.material];
    rec.imageBase64 = dataUrl;
    if (onDone) onDone(true);
  });
}

function loadImageFile(file) {
  pushUndo();
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    buildImagePlaneObject(dataUrl, null, (built) => {
      if (!built) { alertBox("No se pudo cargar la imagen " + file.name + ".", "warn"); return; }
      const rec = newRecord({
        name: (file.name || "Imagen").replace(/\.[a-z0-9]+$/i, "") + " " + (sceneOrder.length + 1),
        kind: "image",
        object3D: built.object3D, colorMaterials: built.colorMaterials,
        collider: { kind: "none", size: { x: 1, y: 1.5, z: 0.05 }, riskLabel: "" },
        imageBase64: dataUrl, imageFileName: file.name,
      });
      placeAndAdd(rec);
    });
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + file.name + ".", "warn");
  reader.readAsDataURL(file);
}
document.getElementById("btnImageTrigger").addEventListener("click", () => document.getElementById("imageInput").click());
document.getElementById("imageInput").addEventListener("change", (e) => {
  if (e.target.files[0]) loadImageFile(e.target.files[0]);
  e.target.value = "";
});

function replaceImageForRecord(rec, file) {
  pushUndo();
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    swapImageTexture(rec, dataUrl, (ok) => {
      if (!ok) { alertBox("No se pudo cargar la imagen " + file.name + ".", "warn"); return; }
      rec.imageFileName = file.name;
      renderProps();
    });
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + file.name + ".", "warn");
  reader.readAsDataURL(file);
}

function buildVideoPlaneObject(dataUrl, height, onReady) {
  const videoEl = document.createElement("video");
  videoEl.src = dataUrl;
  videoEl.loop = true;
  videoEl.muted = false;
  videoEl.playsInline = true;
  videoEl.crossOrigin = "anonymous";
  videoEl.pause();
  const finish = () => {
    const texture = new THREE.VideoTexture(videoEl);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    const aspect = (videoEl.videoWidth / videoEl.videoHeight) || (16 / 9);
    const h = height || 1.5;
    const w = h * aspect;
    const mat = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide, transparent: true });
    // Mismo ajuste de profundidad que el texto 3D/imagen (ver buildText3DObject).
    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;
    mat.alphaTest = 0.5;
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    const group = new THREE.Group();
    group.add(mesh);
    group.position.y = h / 2;
    onReady({ object3D: group, colorMaterials: [mat], mesh, aspect, videoEl });
  };
  videoEl.addEventListener("loadedmetadata", finish, { once: true });
  videoEl.addEventListener("error", () => onReady(null), { once: true });
}

function loadVideoFile(file) {
  pushUndo();
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    buildVideoPlaneObject(dataUrl, null, (built) => {
      if (!built) { alertBox("No se pudo cargar el vídeo " + file.name + ".", "warn"); return; }
      const rec = newRecord({
        name: (file.name || "Video").replace(/\.[a-z0-9]+$/i, "") + " " + (sceneOrder.length + 1),
        kind: "video",
        object3D: built.object3D, colorMaterials: built.colorMaterials,
        collider: { kind: "none", size: { x: 1, y: 1.5, z: 0.05 }, riskLabel: "" },
        videoBase64: dataUrl, videoFileName: file.name, videoEl: built.videoEl,
        interactive: { enabled: true, kind: "text", radius: 2.5, prompt: "Reproducir / pausar vídeo", text: "", choices: [], onShotAction: null },
      });
      placeAndAdd(rec);
    });
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + file.name + ".", "warn");
  reader.readAsDataURL(file);
}
document.getElementById("btnVideoTrigger").addEventListener("click", () => document.getElementById("videoInput").click());
document.getElementById("videoInput").addEventListener("change", (e) => {
  if (e.target.files[0]) loadVideoFile(e.target.files[0]);
  e.target.value = "";
});

function replaceVideoForRecord(rec, file) {
  pushUndo();
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    buildVideoPlaneObject(dataUrl, null, (built) => {
      if (!built) { alertBox("No se pudo cargar el vídeo " + file.name + ".", "warn"); return; }
      const mesh = rec.object3D.children[0];
      mesh.geometry.dispose();
      if (mesh.material.map) mesh.material.map.dispose();
      mesh.material.dispose();
      if (rec.videoEl) { rec.videoEl.pause(); rec.videoEl.src = ""; }
      mesh.geometry = built.mesh.geometry;
      mesh.material = built.mesh.material;
      rec.colorMaterials = [mesh.material];
      rec.videoBase64 = dataUrl;
      rec.videoFileName = file.name;
      rec.videoEl = built.videoEl;
      renderProps();
    });
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + file.name + ".", "warn");
  reader.readAsDataURL(file);
}

function toggleVideoPlayback(rec) {
  if (!rec.videoEl) return;
  if (rec.videoEl.paused) { rec.videoEl.play().catch(() => {}); playFeedToast("▶ Vídeo: " + rec.name); }
  else { rec.videoEl.pause(); playFeedToast("⏸ Vídeo: " + rec.name); }
}

/* =========================================================================
   MÚSICA DE FONDO
   ========================================================================= */
function updateMusicUI() {
  document.getElementById("musicInfo").textContent = projectAudio.musicFileName ? ("Archivo actual: " + projectAudio.musicFileName) : "Sin música todavía.";
  document.getElementById("btnMusicRemove").style.display = projectAudio.musicBase64 ? "inline-block" : "none";
}
document.getElementById("btnMusicTrigger").addEventListener("click", () => document.getElementById("musicInput").click());
document.getElementById("musicInput").addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    projectAudio.musicBase64 = reader.result;
    projectAudio.musicFileName = f.name;
    updateMusicUI();
  };
  reader.onerror = () => alertBox("No se pudo leer el archivo " + f.name + ".", "warn");
  reader.readAsDataURL(f);
  e.target.value = "";
});
document.getElementById("btnMusicRemove").addEventListener("click", () => {
  projectAudio.musicBase64 = null; projectAudio.musicFileName = null;
  updateMusicUI();
});
document.getElementById("musicVolume").addEventListener("input", (e) => {
  projectAudio.volume = parseFloat(e.target.value);
  if (bgMusicEl) bgMusicEl.volume = projectAudio.volume;
});

function startBgMusic() {
  if (!projectAudio.musicBase64) return;
  stopBgMusic();
  bgMusicEl = new Audio(projectAudio.musicBase64);
  bgMusicEl.loop = true;
  bgMusicEl.volume = projectAudio.volume !== undefined ? projectAudio.volume : 0.5;
  bgMusicEl.play().catch(() => {});
}
function stopBgMusic() {
  if (bgMusicEl) { bgMusicEl.pause(); bgMusicEl = null; }
}

/* =========================================================================
   MARCADOR DE DESTINO Y RESALTADO (ayuda visual al editar acciones "Mover a punto")
   ========================================================================= */
const destMarkerGroup = new THREE.Group();
const destMarkerRing = new THREE.Mesh(
  new THREE.RingGeometry(0.22, 0.3, 24),
  new THREE.MeshBasicMaterial({ color: 0xffdd33, side: THREE.DoubleSide, transparent: true, opacity: 0.9, depthTest: false })
);
destMarkerRing.rotation.x = -Math.PI / 2;
const destMarkerStick = new THREE.Mesh(
  new THREE.CylinderGeometry(0.02, 0.02, 1, 8),
  new THREE.MeshBasicMaterial({ color: 0xffdd33, transparent: true, opacity: 0.6, depthTest: false })
);
const destMarkerDot = new THREE.Mesh(
  new THREE.SphereGeometry(0.09, 14, 10),
  new THREE.MeshBasicMaterial({ color: 0xffdd33, depthTest: false })
);
destMarkerGroup.add(destMarkerRing, destMarkerStick, destMarkerDot);
destMarkerGroup.renderOrder = 999;
destMarkerGroup.visible = false;
scene.add(destMarkerGroup);

function showDestMarker(pos) {
  destMarkerGroup.visible = true;
  destMarkerGroup.position.set(pos.x, 0, pos.z);
  destMarkerDot.position.set(0, pos.y, 0);
  destMarkerStick.position.set(0, pos.y / 2, 0);
  destMarkerStick.scale.y = Math.max(0.001, Math.abs(pos.y));
}
function hideDestMarker() { destMarkerGroup.visible = false; }

let highlightHelper = null;
function showTargetHighlight(object3D) {
  hideTargetHighlight();
  const box = new THREE.Box3().setFromObject(object3D);
  if (box.isEmpty()) return;
  highlightHelper = new THREE.Box3Helper(box, new THREE.Color(0xffdd33));
  highlightHelper.material.depthTest = false;
  highlightHelper.renderOrder = 998;
  scene.add(highlightHelper);
}
function hideTargetHighlight() {
  if (highlightHelper) { scene.remove(highlightHelper); highlightHelper = null; }
}
function hideActionEditHelpers() { hideDestMarker(); hideTargetHighlight(); }

/* =========================================================================
   EDICIÓN DE NODOS (forma libre extruida — Bézier)
   ========================================================================= */
function refreshNodeEditPlane() {
  if (!nodeEditRec) { nodeEditPlane = null; return; }
  const obj = nodeEditRec.object3D;
  obj.updateMatrixWorld(true);
  const origin = obj.localToWorld(new THREE.Vector3(0, 0, 0));
  const normal = new THREE.Vector3(0, 0, 1).transformDirection(obj.matrixWorld).normalize();
  nodeEditPlane = new THREE.Plane().setFromNormalAndCoplanarPoint(normal, origin);
}

function pointerToNodeEditLocalXY(e) {
  if (!nodeEditPlane || !nodeEditRec) return null;
  const rect = canvas.getBoundingClientRect();
  const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  const worldPt = new THREE.Vector3();
  if (!raycaster.ray.intersectPlane(nodeEditPlane, worldPt)) return null;
  return nodeEditRec.object3D.worldToLocal(worldPt.clone());
}

function defaultHandleOffset(nodes, i, hkey) {
  const node = nodes[i];
  const neighbor = hkey === "handleOut" ? nodes[(i + 1) % nodes.length] : nodes[(i - 1 + nodes.length) % nodes.length];
  const dx = neighbor.x - node.x, dy = neighbor.y - node.y;
  const dist = Math.hypot(dx, dy) || 1;
  const len = Math.min(0.3, dist * 0.35);
  return { x: (dx / dist) * len, y: (dy / dist) * len };
}

function findClosestContourSegmentPoint(nodes, local) {
  if (!nodes || nodes.length < 2) return null;
  let best = null;
  for (let i = 0; i < nodes.length; i++) {
    const a = nodes[i];
    const b = nodes[(i + 1) % nodes.length];
    let curve;
    if (a.handleOut || b.handleIn) {
      const c1 = new THREE.Vector2(a.x + (a.handleOut ? a.handleOut.x : 0), a.y + (a.handleOut ? a.handleOut.y : 0));
      const c2 = new THREE.Vector2(b.x + (b.handleIn ? b.handleIn.x : 0), b.y + (b.handleIn ? b.handleIn.y : 0));
      curve = new THREE.CubicBezierCurve(new THREE.Vector2(a.x, a.y), c1, c2, new THREE.Vector2(b.x, b.y));
    } else {
      curve = new THREE.LineCurve(new THREE.Vector2(a.x, a.y), new THREE.Vector2(b.x, b.y));
    }
    curve.getPoints(20).forEach((p) => {
      const d = Math.hypot(p.x - local.x, p.y - local.y);
      if (!best || d < best.dist) best = { dist: d, x: p.x, y: p.y, afterIndex: i };
    });
  }
  return best;
}

function rebuildNodeEditVisuals() {
  if (!nodeEditGroup) return;
  while (nodeEditGroup.children.length) {
    const c = nodeEditGroup.children.pop();
    if (c.geometry) c.geometry.dispose();
    if (c.material) c.material.dispose();
  }
  if (!nodeEditRec) return;
  const nodes = nodeEditRec.extrudeData.nodes;
  const Z = -0.02;

  const shape = buildExtrudeShape(nodes);
  const pts = shape.getPoints(64).map((p) => new THREE.Vector3(p.x, p.y, Z));
  const outline = new THREE.LineLoop(
    new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineBasicMaterial({ color: 0x33ddff, depthTest: false, transparent: true, opacity: 0.95 })
  );
  outline.renderOrder = 998;
  nodeEditGroup.add(outline);

  nodes.forEach((node, i) => {
    const selected = i === nodeEditSelIndex;
    const nodeMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.055, 14, 10),
      new THREE.MeshBasicMaterial({ color: selected ? 0xffdd33 : 0xffffff, depthTest: false })
    );
    nodeMesh.position.set(node.x, node.y, Z);
    nodeMesh.renderOrder = 999;
    nodeMesh.userData.nodeEditType = "node";
    nodeMesh.userData.nodeEditIndex = i;
    nodeEditGroup.add(nodeMesh);

    ["handleIn", "handleOut"].forEach((hkey) => {
      const real = node[hkey];
      if (!real && !selected) return; // sin manecilla creada todavía: solo se muestra (como "estirable") en el nodo seleccionado
      const h = real || defaultHandleOffset(nodes, i, hkey);
      const hx = node.x + h.x, hy = node.y + h.y;
      const col = real ? 0xff8833 : 0xffb877;
      const op = real ? 0.85 : 0.4;
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(node.x, node.y, Z), new THREE.Vector3(hx, hy, Z)]),
        new THREE.LineBasicMaterial({ color: col, depthTest: false, transparent: true, opacity: op })
      );
      line.renderOrder = 998;
      nodeEditGroup.add(line);

      const hMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.035, 10, 8),
        new THREE.MeshBasicMaterial({ color: col, depthTest: false, transparent: true, opacity: real ? 1 : 0.6 })
      );
      hMesh.position.set(hx, hy, Z);
      hMesh.renderOrder = 999;
      hMesh.userData.nodeEditType = hkey;
      hMesh.userData.nodeEditIndex = i;
      nodeEditGroup.add(hMesh);
    });
  });
}

function enterNodeEditMode(rec) {
  if (!rec || rec.kind !== "extrude" || nodeEditRec === rec) return;
  exitNodeEditMode();
  exitPathEditMode();
  selectSingleWithinGroup(rec.id);
  transformControls.detach();
  hideActionEditHelpers();
  nodeEditRec = rec;
  nodeEditSelIndex = -1;
  nodeEditDrag = null;
  nodeEditGroup = new THREE.Group();
  rec.object3D.add(nodeEditGroup);
  refreshNodeEditPlane();
  rebuildNodeEditVisuals();
  renderProps();
  logInfo("Modo edición de nodos: clic en el contorno para añadir un nodo, arrastra para mover, Supr para borrar.");
}

function exitNodeEditMode() {
  if (!nodeEditRec) return;
  if (nodeEditGroup) {
    nodeEditRec.object3D.remove(nodeEditGroup);
    nodeEditGroup.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  }
  nodeEditRec = null;
  nodeEditGroup = null;
  nodeEditPlane = null;
  nodeEditSelIndex = -1;
  nodeEditDrag = null;
  orbitControls.enabled = true;
  updateGizmoAttachment();
  renderProps();
}

function onNodeEditPointerDown(e) {
  pointerDownPos = { x: e.clientX, y: e.clientY };
  const rect = canvas.getBoundingClientRect();
  pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointerNdc, camera);
  const hits = raycaster.intersectObjects(nodeEditGroup.children, false).filter((h) => h.object.userData.nodeEditType);
  if (hits.length) {
    const ud = hits[0].object.userData;
    pushUndo();
    nodeEditDrag = { type: ud.nodeEditType, index: ud.nodeEditIndex };
    nodeEditSelIndex = ud.nodeEditIndex;
    orbitControls.enabled = false;
    rebuildNodeEditVisuals();
  }
}

function onNodeEditPointerMove(e) {
  if (!nodeEditDrag || !nodeEditRec) return;
  const local = pointerToNodeEditLocalXY(e);
  if (!local) return;
  const node = nodeEditRec.extrudeData.nodes[nodeEditDrag.index];
  if (!node) return;
  if (nodeEditDrag.type === "node") {
    node.x = local.x; node.y = local.y;
  } else if (nodeEditDrag.type === "handleIn") {
    node.handleIn = { x: local.x - node.x, y: local.y - node.y };
  } else if (nodeEditDrag.type === "handleOut") {
    node.handleOut = { x: local.x - node.x, y: local.y - node.y };
  }
  rebuildExtrudeGeometry(nodeEditRec);
  rebuildNodeEditVisuals();
}

function onNodeEditPointerUp(e) {
  if (nodeEditDrag) {
    const drag = nodeEditDrag;
    if ((drag.type === "handleIn" || drag.type === "handleOut") && nodeEditRec) {
      const node = nodeEditRec.extrudeData.nodes[drag.index];
      const h = node && node[drag.type];
      if (h && Math.hypot(h.x, h.y) < 0.04) {
        node[drag.type] = null; // arrastrada de vuelta casi al propio nodo: se interpreta como "quitar la curva"
        rebuildExtrudeGeometry(nodeEditRec);
        rebuildNodeEditVisuals();
      }
    }
    nodeEditDrag = null;
    orbitControls.enabled = true;
    pointerDownPos = null;
    return;
  }
  if (!pointerDownPos) return;
  const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
  pointerDownPos = null;
  if (moved > 5 || !nodeEditRec) return;

  const local = pointerToNodeEditLocalXY(e);
  if (local) {
    const ins = findClosestContourSegmentPoint(nodeEditRec.extrudeData.nodes, local);
    if (ins && ins.dist < 0.35) {
      pushUndo();
      nodeEditRec.extrudeData.nodes.splice(ins.afterIndex + 1, 0, { x: ins.x, y: ins.y, handleIn: null, handleOut: null });
      nodeEditSelIndex = ins.afterIndex + 1;
      rebuildExtrudeGeometry(nodeEditRec);
      rebuildNodeEditVisuals();
      return;
    }
  }
  nodeEditSelIndex = -1;
  rebuildNodeEditVisuals();
}

function deleteSelectedNode() {
  if (!nodeEditRec || nodeEditSelIndex < 0) return;
  const nodes = nodeEditRec.extrudeData.nodes;
  if (nodes.length <= 3) { logInfo("Una forma necesita al menos 3 nodos."); return; }
  pushUndo();
  nodes.splice(nodeEditSelIndex, 1);
  nodeEditSelIndex = -1;
  rebuildExtrudeGeometry(nodeEditRec);
  rebuildNodeEditVisuals();
}

/* ---- Edición de camino en el visor: dibuja el trazado (recto o en bucle) que sigue la extrusión ----
   A diferencia del perfil (plano local XY, con manecillas Bézier), el camino vive en el plano local XZ
   (una vista "en planta") y la altura (Y) de cada punto se ajusta aparte con un campo numérico -- así se
   puede trazar con el ratón sin perder precisión vertical. Se suaviza automáticamente con Catmull-Rom,
   sin necesidad de manecillas manuales. */
function refreshPathEditPlane() {
  if (!pathEditRec) { pathEditPlane = null; return; }
  const obj = pathEditRec.object3D;
  obj.updateMatrixWorld(true);
  const origin = obj.localToWorld(new THREE.Vector3(0, 0, 0));
  const normal = new THREE.Vector3(0, 1, 0).transformDirection(obj.matrixWorld).normalize();
  pathEditPlane = new THREE.Plane().setFromNormalAndCoplanarPoint(normal, origin);
}

function pointerToPathEditLocalXZ(e) {
  if (!pathEditPlane || !pathEditRec) return null;
  const rect = canvas.getBoundingClientRect();
  const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  const worldPt = new THREE.Vector3();
  if (!raycaster.ray.intersectPlane(pathEditPlane, worldPt)) return null;
  const local = pathEditRec.object3D.worldToLocal(worldPt.clone());
  return { x: local.x, z: local.z };
}

function findClosestPathSegmentPoint(nodes, closed, local) {
  if (!nodes || nodes.length < 2) return null;
  let best = null;
  const count = closed ? nodes.length : nodes.length - 1;
  for (let i = 0; i < count; i++) {
    const a = nodes[i];
    const b = nodes[(i + 1) % nodes.length];
    const abx = b.x - a.x, abz = b.z - a.z;
    const lenSq = abx * abx + abz * abz || 1;
    let t = ((local.x - a.x) * abx + (local.z - a.z) * abz) / lenSq;
    t = Math.max(0, Math.min(1, t));
    const px = a.x + abx * t, pz = a.z + abz * t;
    const d = Math.hypot(px - local.x, pz - local.z);
    if (!best || d < best.dist) best = { dist: d, x: px, z: pz, afterIndex: i };
  }
  return best;
}

function rebuildPathEditVisuals() {
  if (!pathEditGroup) return;
  while (pathEditGroup.children.length) {
    const c = pathEditGroup.children.pop();
    if (c.geometry) c.geometry.dispose();
    if (c.material) c.material.dispose();
  }
  if (!pathEditRec || !pathOwnerPath(pathEditRec)) return;
  const pathData = pathOwnerPath(pathEditRec);
  const nodes = pathData.nodes;

  if (nodes.length >= 2) {
    const curve = buildPathCurve(nodes, pathData.closed);
    const pts = curve.getSpacedPoints(Math.max(24, nodes.length * 16));
    const LineType = pathData.closed ? THREE.LineLoop : THREE.Line;
    const line = new LineType(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: 0x66ff99, depthTest: false, transparent: true, opacity: 0.9 })
    );
    line.renderOrder = 998;
    pathEditGroup.add(line);
  }

  nodes.forEach((node, i) => {
    const selected = i === pathEditSelIndex;
    const nodeMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 14, 10),
      new THREE.MeshBasicMaterial({ color: selected ? 0xffdd33 : 0x66ff99, depthTest: false })
    );
    nodeMesh.position.set(node.x, node.y, node.z);
    nodeMesh.renderOrder = 999;
    nodeMesh.userData.pathEditIndex = i;
    pathEditGroup.add(nodeMesh);
  });
}

function enterPathEditMode(rec) {
  if (!rec || !pathOwnerPath(rec) || pathEditRec === rec) return;
  exitPathEditMode();
  exitNodeEditMode();
  selectSingleWithinGroup(rec.id);
  transformControls.detach();
  hideActionEditHelpers();
  pathEditRec = rec;
  pathEditSelIndex = -1;
  pathEditDrag = null;
  pathEditGroup = new THREE.Group();
  rec.object3D.add(pathEditGroup);
  refreshPathEditPlane();
  rebuildPathEditVisuals();
  renderProps();
  logInfo("Modo edición de camino: clic para añadir puntos (en el tramo más cercano, o al final si no hay ninguno cerca), arrastra un punto para moverlo en horizontal -- la altura se ajusta con el campo numérico. Supr borra el punto seleccionado (mínimo 2).");
}

function exitPathEditMode() {
  if (!pathEditRec) return;
  if (pathEditGroup) {
    pathEditRec.object3D.remove(pathEditGroup);
    pathEditGroup.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  }
  pathEditRec = null;
  pathEditGroup = null;
  pathEditPlane = null;
  pathEditSelIndex = -1;
  pathEditDrag = null;
  orbitControls.enabled = true;
  updateGizmoAttachment();
  renderProps();
}

function onPathEditPointerDown(e) {
  pointerDownPos = { x: e.clientX, y: e.clientY };
  const rect = canvas.getBoundingClientRect();
  pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointerNdc, camera);
  const hits = raycaster.intersectObjects(pathEditGroup.children, false).filter((h) => h.object.userData.pathEditIndex !== undefined);
  if (hits.length) {
    pushUndo();
    pathEditDrag = { index: hits[0].object.userData.pathEditIndex };
    pathEditSelIndex = hits[0].object.userData.pathEditIndex;
    orbitControls.enabled = false;
    rebuildPathEditVisuals();
    renderProps();
  }
}

function onPathEditPointerMove(e) {
  if (!pathEditDrag || !pathEditRec) return;
  const local = pointerToPathEditLocalXZ(e);
  if (!local) return;
  const node = pathOwnerPath(pathEditRec).nodes[pathEditDrag.index];
  if (!node) return;
  node.x = local.x; node.z = local.z;
  pathOwnerRebuild(pathEditRec);
  rebuildPathEditVisuals();
}

function onPathEditPointerUp(e) {
  if (pathEditDrag) {
    pathEditDrag = null;
    orbitControls.enabled = true;
    pointerDownPos = null;
    return;
  }
  if (!pointerDownPos) return;
  const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
  pointerDownPos = null;
  if (moved > 5 || !pathEditRec) return;

  const local = pointerToPathEditLocalXZ(e);
  if (local) {
    const nodes = pathOwnerPath(pathEditRec).nodes;
    const closed = pathOwnerPath(pathEditRec).closed;
    const ins = findClosestPathSegmentPoint(nodes, closed, local);
    if (ins && ins.dist < 0.4) {
      pushUndo();
      const prevNode = nodes[ins.afterIndex];
      const nextNode = nodes[(ins.afterIndex + 1) % nodes.length];
      nodes.splice(ins.afterIndex + 1, 0, { x: ins.x, y: (prevNode.y + nextNode.y) / 2, z: ins.z });
      pathEditSelIndex = ins.afterIndex + 1;
      pathOwnerRebuild(pathEditRec);
      rebuildPathEditVisuals();
      renderProps();
      return;
    } else if (nodes.length < 40) {
      // no cerca de ningún tramo existente: se interpreta como "seguir trazando" y se añade al final
      pushUndo();
      nodes.push({ x: local.x, y: nodes.length ? nodes[nodes.length - 1].y : 0, z: local.z });
      pathEditSelIndex = nodes.length - 1;
      pathOwnerRebuild(pathEditRec);
      rebuildPathEditVisuals();
      renderProps();
      return;
    }
  }
  pathEditSelIndex = -1;
  rebuildPathEditVisuals();
  renderProps();
}

function deleteSelectedPathNode() {
  if (!pathEditRec || pathEditSelIndex < 0) return;
  const nodes = pathOwnerPath(pathEditRec).nodes;
  if (nodes.length <= 2) { logInfo("Un camino necesita al menos 2 puntos."); return; }
  pushUndo();
  nodes.splice(pathEditSelIndex, 1);
  pathEditSelIndex = -1;
  pathOwnerRebuild(pathEditRec);
  rebuildPathEditVisuals();
  renderProps();
}

canvas.addEventListener("pointermove", (e) => {
  if (nodeEditRec) onNodeEditPointerMove(e);
  if (pathEditRec) onPathEditPointerMove(e);
});

/* =========================================================================
   SELECCIÓN, RAYCAST Y GIZMO
   ========================================================================= */
const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();
let pointerDownPos = null;

function objectForMesh(mesh) {
  let o = mesh;
  while (o) {
    for (const [id, rec] of sceneObjects) if (rec.object3D === o) return id;
    o = o.parent;
  }
  return null;
}

canvas.addEventListener("pointerdown", (e) => {
  // salaModoVisitante: sala protegida con PIN sin desbloquear -- ni siquiera cuando no hay Modo jugar
  // disponible (sin objeto "Personaje") debe poder seleccionarse/arrastrarse nada con el ratón.
  if (isPlayModeActive || salaModoVisitante) return;
  if (nodeEditRec) { onNodeEditPointerDown(e); return; }
  if (pathEditRec) { onPathEditPointerDown(e); return; }
  pointerDownPos = { x: e.clientX, y: e.clientY };
});
canvas.addEventListener("pointerup", (e) => {
  if (isPlayModeActive || salaModoVisitante) return;
  if (nodeEditRec) { onNodeEditPointerUp(e); return; }
  if (pathEditRec) { onPathEditPointerUp(e); return; }
  if (!pointerDownPos) return;
  const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
  pointerDownPos = null;
  if (moved > 5) return; // fue un arrastre de órbita, no un clic de selección
  if (transformControls.dragging) return;
  const rect = canvas.getBoundingClientRect();
  pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointerNdc, camera);
  const meshes = [];
  for (const rec of sceneObjects.values()) if (rec.object3D) meshes.push(rec.object3D);
  const hits = raycaster.intersectObjects(meshes, true);
  if (hits.length) {
    const id = objectForMesh(hits[0].object);
    if (e.shiftKey) toggleSelectObject(id);
    else selectObject(id);
  } else if (!e.shiftKey) {
    selectObject(null);
  }
});

function selectedRecs() {
  return Array.from(selectedIds).map((id) => sceneObjects.get(id)).filter(Boolean);
}

function updateGizmoAttachment() {
  const recs = selectedRecs();
  if (!recs.length) {
    transformControls.detach();
  } else if (recs.length === 1) {
    transformControls.attach(recs[0].object3D);
  } else {
    const center = new THREE.Vector3();
    recs.forEach((r) => center.add(r.object3D.position));
    center.divideScalar(recs.length);
    multiPivot.position.copy(center);
    multiPivot.quaternion.identity();
    multiPivot.scale.set(1, 1, 1);
    transformControls.attach(multiPivot);
  }
}

function selectObject(id) {
  if (nodeEditRec && id !== nodeEditRec.id) exitNodeEditMode(); // cambiar de objeto sale del modo edición de nodos de la pieza anterior
  if (pathEditRec && id !== pathEditRec.id) exitPathEditMode(); // igual para el modo edición de camino
  const rec = id ? sceneObjects.get(id) : null;
  const group = rec && rec.groupId ? objectGroups.get(rec.groupId) : null;
  selectedId = id;
  selectedIds = new Set(group ? group.memberIds : (id ? [id] : []));
  hideActionEditHelpers(); // por si había un marcador/resaltado de una acción a medio editar en el objeto anterior
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
}

function toggleSelectObject(id) {
  if (!id) return;
  if (nodeEditRec && id !== nodeEditRec.id) exitNodeEditMode();
  if (pathEditRec && id !== pathEditRec.id) exitPathEditMode();
  const rec = sceneObjects.get(id);
  const group = rec && rec.groupId ? objectGroups.get(rec.groupId) : null;
  const idsToToggle = group ? group.memberIds : [id];
  const allSelected = idsToToggle.every((mid) => selectedIds.has(mid));
  if (allSelected) idsToToggle.forEach((mid) => selectedIds.delete(mid));
  else idsToToggle.forEach((mid) => selectedIds.add(mid));
  selectedId = selectedIds.size ? Array.from(selectedIds).pop() : null;
  hideActionEditHelpers();
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
}

function currentSelectionGroup() {
  if (selectedIds.size < 2) return null;
  const ids = Array.from(selectedIds);
  const firstRec = sceneObjects.get(ids[0]);
  if (!firstRec || !firstRec.groupId) return null;
  const group = objectGroups.get(firstRec.groupId);
  if (!group || group.memberIds.length !== ids.length) return null;
  const sameGroup = ids.every((id) => { const r = sceneObjects.get(id); return r && r.groupId === firstRec.groupId; });
  return sameGroup ? group : null;
}

function groupSelected() {
  if (selectedIds.size < 2) return;
  pushUndo();
  const memberIds = Array.from(selectedIds);
  const oldGroupIds = new Set();
  memberIds.forEach((id) => { const rec = sceneObjects.get(id); if (rec && rec.groupId) oldGroupIds.add(rec.groupId); });
  oldGroupIds.forEach((gid) => objectGroups.delete(gid));
  const groupId = uid("grp");
  objectGroups.set(groupId, { id: groupId, name: "Grupo " + (objectGroups.size + 1), memberIds });
  memberIds.forEach((id) => { const rec = sceneObjects.get(id); if (rec) rec.groupId = groupId; });
  selectedIds = new Set(memberIds);
  selectedId = memberIds[memberIds.length - 1];
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
  logInfo("Grupo creado con " + memberIds.length + " objetos.");
}

function ungroupSelected() {
  const group = currentSelectionGroup();
  if (!group) return;
  pushUndo();
  group.memberIds.forEach((id) => { const r = sceneObjects.get(id); if (r) r.groupId = null; });
  objectGroups.delete(group.id);
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
  logInfo("Grupo deshecho.");
}

// Selecciona un único objeto aunque pertenezca a un grupo, sin expandir a todo el conjunto —
// para poder inspeccionarlo/editarlo/eliminarlo/sacarlo del grupo individualmente (icono 📦 en la jerarquía).
function selectSingleWithinGroup(id) {
  if (!id) return;
  if (nodeEditRec && id !== nodeEditRec.id) exitNodeEditMode();
  if (pathEditRec && id !== pathEditRec.id) exitPathEditMode();
  selectedId = id;
  selectedIds = new Set([id]);
  hideActionEditHelpers();
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
}

function removeFromGroup(id) {
  const rec = sceneObjects.get(id);
  if (!rec || !rec.groupId) return;
  pushUndo();
  const group = objectGroups.get(rec.groupId);
  if (group) {
    group.memberIds = group.memberIds.filter((x) => x !== id);
    if (group.memberIds.length < 2) {
      group.memberIds.forEach((mid) => { const m = sceneObjects.get(mid); if (m) m.groupId = null; });
      objectGroups.delete(group.id);
    }
  }
  rec.groupId = null;
  renderHierarchy();
  renderProps();
  logInfo("Objeto sacado del grupo.");
}

document.getElementById("modeMove").addEventListener("click", () => transformControls.setMode("translate"));
document.getElementById("modeRotate").addEventListener("click", () => transformControls.setMode("rotate"));
document.getElementById("modeScale").addEventListener("click", () => transformControls.setMode("scale"));
document.getElementById("btnResetCam").addEventListener("click", () => {
  camera.position.copy(DEFAULT_CAM_POS);
  orbitControls.target.copy(DEFAULT_CAM_TARGET);
});

window.addEventListener("keydown", (e) => {
  if (isPlayModeActive || salaModoVisitante) return;
  const tag = document.activeElement && document.activeElement.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
  if (nodeEditRec || pathEditRec) {
    if (e.key === "Delete" || e.key === "Backspace") {
      e.preventDefault();
      if (nodeEditRec) deleteSelectedNode(); else deleteSelectedPathNode();
      return;
    }
    if (e.key === "Escape") { if (nodeEditRec) exitNodeEditMode(); else exitPathEditMode(); return; }
    const isUndoRedoKey = (e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === "z" || e.key.toLowerCase() === "y");
    if (!isUndoRedoKey) return;
    // Deshacer/rehacer reconstruye TODA la escena (importProject) -- si nos quedáramos en modo edición,
    // nodeEditRec/pathEditRec seguirían apuntando a una pieza ya descartada. Salimos primero, limpiamente,
    // y dejamos que el atajo caiga al bloque general de abajo.
    if (nodeEditRec) exitNodeEditMode();
    if (pathEditRec) exitPathEditMode();
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
    e.preventDefault();
    if (e.shiftKey) performRedo(); else performUndo();
    return;
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "y") {
    e.preventDefault();
    performRedo();
    return;
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "g") {
    e.preventDefault();
    if (e.shiftKey) ungroupSelected(); else groupSelected();
    return;
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c" && selectedIds.size) {
    e.preventDefault();
    copySelectionToClipboard();
    return;
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") {
    e.preventDefault();
    pasteSelectionFromClipboard();
    return;
  }
  if (e.key === "g") transformControls.setMode("translate");
  if (e.key === "r") transformControls.setMode("rotate");
  if (e.key === "s") transformControls.setMode("scale");
  if ((e.key === "Delete" || e.key === "Backspace") && selectedIds.size) deleteSelected();
});

// Mayús mantenido: ajusta la rotación del gizmo a incrementos de 15° (ángulos "redondos": 0, 15, 30, 45...)
window.addEventListener("keydown", (e) => {
  if (isPlayModeActive || salaModoVisitante) return;
  if (e.key === "Shift") transformControls.setRotationSnap(THREE.MathUtils.degToRad(15));
});
window.addEventListener("keyup", (e) => {
  if (e.key === "Shift") transformControls.setRotationSnap(null);
});

function deleteSelected() {
  pushUndo();
  Array.from(selectedIds).forEach((id) => removeRecord(id));
  selectedIds = new Set();
  selectedId = null;
  updateGizmoAttachment();
  renderHierarchy();
  renderProps();
}
document.getElementById("btnDelete").addEventListener("click", () => { if (selectedIds.size) deleteSelected(); });
function finishDuplicate(clone, src, opts) {
  clone.object3D.position.copy(src.object3D.position).add(new THREE.Vector3(0.8, 0, 0.8));
  clone.object3D.quaternion.copy(src.object3D.quaternion);
  clone.object3D.scale.copy(src.object3D.scale);
  clone.collider = JSON.parse(JSON.stringify(src.collider));
  clone.actions = JSON.parse(JSON.stringify(src.actions));
  clone.interactive = JSON.parse(JSON.stringify(src.interactive));
  recomputeCheckpoints(clone);
  recomputeTimelineDuration();
  renderHierarchy();
  if (!opts || !opts.skipSelect) selectObject(clone.id);
}

function duplicateOne(src, onDone) {
  if (src.kind === "primitive") { const c = addPrimitiveToScene(src.primitiveType); finishDuplicate(c, src, { skipSelect: true }); onDone(c.id); }
  else if (src.kind === "prefab") { const c = addPrefabToScene(src.prefabType); finishDuplicate(c, src, { skipSelect: true }); onDone(c.id); }
  else if (src.kind === "text3d") { const c = addText3DToScene(); finishDuplicate(c, src, { skipSelect: true }); onDone(c.id); }
  else if (src.kind === "extrude" && src.extrudeData) {
    const c = addExtrudeToScene();
    c.extrudeData = JSON.parse(JSON.stringify(src.extrudeData));
    rebuildExtrudeGeometry(c);
    finishDuplicate(c, src, { skipSelect: true });
    onDone(c.id);
  }
  else if (src.kind === "image" && src.imageBase64) {
    buildImagePlaneObject(src.imageBase64, null, (built) => {
      if (!built) { alertBox("No se pudo duplicar la imagen.", "warn"); onDone(null); return; }
      const clone = newRecord({ name: src.name + " copia", kind: "image", object3D: built.object3D, colorMaterials: built.colorMaterials, imageBase64: src.imageBase64, imageFileName: src.imageFileName });
      scene.add(clone.object3D);
      finishDuplicate(clone, src, { skipSelect: true });
      onDone(clone.id);
    });
  } else if (src.kind === "video" && src.videoBase64) {
    buildVideoPlaneObject(src.videoBase64, null, (built) => {
      if (!built) { alertBox("No se pudo duplicar el vídeo.", "warn"); onDone(null); return; }
      const clone = newRecord({ name: src.name + " copia", kind: "video", object3D: built.object3D, colorMaterials: built.colorMaterials, videoBase64: src.videoBase64, videoFileName: src.videoFileName, videoEl: built.videoEl });
      scene.add(clone.object3D);
      finishDuplicate(clone, src, { skipSelect: true });
      onDone(clone.id);
    });
  } else if (src.kind === "light") {
    const built = buildLightObject(JSON.parse(JSON.stringify(src.lightData || {})));
    const clone = newRecord({ name: src.name + " copia", kind: "light", object3D: built.object3D, colorMaterials: [], lightData: built.lightData });
    clone.__lightObj = built.object3D.userData.__lightObj;
    clone.__gizmoMesh = built.object3D.userData.__gizmoMesh;
    clone.__gizmoMat = built.object3D.userData.__gizmoMat;
    scene.add(clone.object3D);
    finishDuplicate(clone, src, { skipSelect: true });
    onDone(clone.id);
  } else if (src.kind === "camerapath") {
    const group = new THREE.Group();
    const clone = newRecord({ name: src.name + " copia", kind: "camerapath", object3D: group, colorMaterials: [], cameraPathData: JSON.parse(JSON.stringify(src.cameraPathData)) });
    rebuildCameraPathVisual(clone);
    scene.add(clone.object3D);
    finishDuplicate(clone, src, { skipSelect: true });
    onDone(clone.id);
  } else if (src.kind === "weather") {
    const built = buildWeatherObject(JSON.parse(JSON.stringify(src.weatherData || {})));
    const clone = newRecord({ name: src.name + " copia", kind: "weather", object3D: built.object3D, colorMaterials: built.colorMaterials, weatherData: built.weatherData });
    scene.add(clone.object3D);
    finishDuplicate(clone, src, { skipSelect: true });
    onDone(clone.id);
  } else {
    alertBox("Los modelos importados (.glb) no se pueden duplicar todavía; vuelve a importar el archivo.", "info");
    onDone(null);
  }
}

function clonarEnSerieDesdeSeleccion(n, dx, dy, dz, rotYDeg, escalaFactor) {
  const srcs = selectedRecs();
  if (!srcs.length) return;
  pushUndo();
  const wasGroup = currentSelectionGroup();
  // Ancla = centro del conjunto de origen (mismo criterio que usa el gizmo con selección múltiple):
  // cada copia gira/escala el conjunto como un bloque alrededor de su propio centro, no pieza a pieza.
  const anchor = new THREE.Vector3();
  srcs.forEach((r) => anchor.add(r.object3D.position));
  anchor.divideScalar(srcs.length);

  let doneTotal = 0;
  for (let i = 1; i <= n; i++) {
    const offset = new THREE.Vector3(dx * i, dy * i, dz * i);
    const rotDelta = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, deg2rad(rotYDeg * i), 0));
    const scaleFactor = Math.pow(escalaFactor, i);
    const newIds = [];
    let pending = srcs.length;
    srcs.forEach((src) => {
      duplicateOne(src, (newId) => {
        if (newId) {
          const rec = sceneObjects.get(newId);
          const rel = src.object3D.position.clone().sub(anchor).applyQuaternion(rotDelta).multiplyScalar(scaleFactor);
          rec.object3D.position.copy(anchor).add(rel).add(offset);
          rec.object3D.quaternion.copy(src.object3D.quaternion).premultiply(rotDelta);
          rec.object3D.scale.copy(src.object3D.scale).multiplyScalar(scaleFactor);
          rec.object3D.userData.__origin = { pos: rec.object3D.position.clone(), quat: rec.object3D.quaternion.clone() };
          recomputeCheckpoints(rec);
          newIds.push(newId);
        }
        pending--;
        if (pending > 0) return;
        if (srcs.length > 1) {
          const groupId = uid("grp");
          objectGroups.set(groupId, { id: groupId, name: (wasGroup ? wasGroup.name : srcs[0].name) + " copia " + i, memberIds: newIds.slice() });
          newIds.forEach((id) => { const r = sceneObjects.get(id); if (r) r.groupId = groupId; });
        }
        doneTotal++;
        if (doneTotal === n) {
          renderHierarchy();
          recomputeTimelineDuration();
          logInfo("Clonado en serie: " + n + " copia(s) creada(s).");
        }
      });
    });
  }
}

function abrirFormularioClonarEnSerie() {
  if (!selectedIds.size) { alertBox("Selecciona primero el objeto (o grupo) que quieres clonar en serie.", "info"); return; }
  const panel = document.getElementById("propsPanel");
  const wrap = document.createElement("div");
  wrap.className = "card";
  wrap.innerHTML =
    '<b>🧬 Clonar en serie</b><br><br>' +
    '<label class="field"><span>Número de copias</span><input type="number" step="1" min="1" max="100" id="cs_n" value="5"></label>' +
    '<label class="field"><span>Desplazamiento por copia (x, y, z)</span><div class="row3">' +
      '<input type="number" step="0.1" id="cs_dx" value="1"><input type="number" step="0.1" id="cs_dy" value="0"><input type="number" step="0.1" id="cs_dz" value="0">' +
    '</div></label>' +
    '<label class="field"><span>Rotación extra por copia (grados, eje Y)</span><input type="number" step="1" id="cs_rot" value="0"></label>' +
    '<label class="field"><span>Escala por copia (factor, 1 = igual)</span><input type="number" step="0.05" min="0.05" id="cs_scale" value="1"></label>' +
    '<p class="sub">Cada copia se acumula sobre la anterior (copia 3 = 3 veces el desplazamiento/rotación/escala). Si tienes seleccionado un grupo, se clona como bloque, manteniendo las piezas juntas.</p>' +
    '<div class="flexRow" style="margin-top:8px;"><button class="small primary grow" id="cs_confirm">Clonar</button><button class="small grow" id="cs_cancel">Cancelar</button></div>';
  panel.prepend(wrap);
  document.getElementById("cs_cancel").addEventListener("click", () => wrap.remove());
  document.getElementById("cs_confirm").addEventListener("click", () => {
    const n = Math.max(1, Math.min(100, parseInt(document.getElementById("cs_n").value, 10) || 1));
    const dx = parseFloat(document.getElementById("cs_dx").value) || 0;
    const dy = parseFloat(document.getElementById("cs_dy").value) || 0;
    const dz = parseFloat(document.getElementById("cs_dz").value) || 0;
    const rot = parseFloat(document.getElementById("cs_rot").value) || 0;
    const scale = Math.max(0.05, parseFloat(document.getElementById("cs_scale").value) || 1);
    wrap.remove();
    clonarEnSerieDesdeSeleccion(n, dx, dy, dz, rot, scale);
  });
}
document.getElementById("btnCloneSeries").addEventListener("click", abrirFormularioClonarEnSerie);

document.getElementById("btnDuplicate").addEventListener("click", () => {
  const srcs = selectedRecs();
  if (!srcs.length) return;
  pushUndo();
  const wasGroup = currentSelectionGroup();
  let pending = srcs.length;
  const newIds = [];
  srcs.forEach((src) => {
    duplicateOne(src, (newId) => {
      if (newId) newIds.push(newId);
      pending--;
      if (pending > 0) return;
      if (newIds.length === 1) {
        selectObject(newIds[0]);
      } else if (newIds.length > 1) {
        if (wasGroup) {
          const groupId = uid("grp");
          objectGroups.set(groupId, { id: groupId, name: wasGroup.name + " copia", memberIds: newIds.slice() });
          newIds.forEach((id) => { const r = sceneObjects.get(id); if (r) r.groupId = groupId; });
        }
        selectedIds = new Set(newIds);
        selectedId = newIds[newIds.length - 1];
        updateGizmoAttachment();
        renderHierarchy();
        renderProps();
      }
    });
  });
});

/* =========================================================================
   COPIAR / PEGAR PREFABS VÍA PORTAPAPELES (Ctrl+C / Ctrl+V, entre pestañas o proyectos distintos)
   ========================================================================= */
function collectGroupsForClipboard(recs) {
  const idSet = new Set(recs.map((r) => r.id));
  const seen = new Set();
  const groups = [];
  recs.forEach((rec) => {
    if (rec.groupId && !seen.has(rec.groupId)) {
      seen.add(rec.groupId);
      const g = objectGroups.get(rec.groupId);
      if (g && g.memberIds.length && g.memberIds.every((mid) => idSet.has(mid))) {
        groups.push({ id: g.id, name: g.name, memberIds: g.memberIds.slice() });
      }
    }
  });
  return groups;
}

function copySelectionToClipboardData() {
  const recs = selectedRecs();
  if (!recs.length) return null;
  const groups = collectGroupsForClipboard(recs);
  const groupIdsKept = new Set(groups.map((g) => g.id));
  const objects = recs.map((rec) => ({
    id: rec.id, name: rec.name, kind: rec.kind,
    primitiveType: rec.primitiveType, prefabType: rec.prefabType,
    gltfBase64: rec.gltfBase64, gltfFileName: rec.gltfFileName,
    text3d: rec.text3d, imageBase64: rec.imageBase64, imageFileName: rec.imageFileName,
    videoBase64: rec.videoBase64, videoFileName: rec.videoFileName,
    extrudeData: rec.extrudeData,
    colorHex: (rec.colorMaterials.length && rec.kind !== "text3d" && rec.kind !== "image" && rec.kind !== "video") ? "#" + rec.colorMaterials[0].color.getHexString() : null,
    transform: {
      position: rec.object3D.position.toArray(),
      quaternion: rec.object3D.quaternion.toArray(),
      scale: rec.object3D.scale.toArray(),
    },
    collider: rec.collider, actions: rec.actions, interactive: rec.interactive,
    groupId: (rec.groupId && groupIdsKept.has(rec.groupId)) ? rec.groupId : null,
  }));
  return { don_claude_3d_clip: true, version: 1, objects, groups };
}

// Reescribe action.target (y sus .next/.parallel[] encadenados) usando idMap -- SOLO si el target
// era uno de los objetos que se están pegando ahora mismo (referencia "interna" del prefab, p.ej. la
// carrocería de un coche apuntando a sus propias ruedas por id). Un target hacia algo YA existente en la
// escena (fuera del prefab pegado) se deja tal cual, porque no está en idMap.
function remapActionTargetsForPaste(action, idMap) {
  if (!action) return action;
  if (action.target && idMap.has(action.target)) action.target = idMap.get(action.target);
  if (action.next) remapActionTargetsForPaste(action.next, idMap);
  if (Array.isArray(action.parallel)) action.parallel.forEach((pa) => remapActionTargetsForPaste(pa, idMap));
  return action;
}

function pasteSelectionFromClipboardData(jsonText) {
  let payload;
  try { payload = JSON.parse(jsonText); }
  catch (e) { alertBox("El portapapeles no contiene un prefab válido de Don Claude 3D (JSON inválido).", "warn"); return; }
  if (!payload || !payload.don_claude_3d_clip || !Array.isArray(payload.objects) || !payload.objects.length) {
    alertBox("El portapapeles no contiene un prefab válido de Don Claude 3D.", "warn");
    return;
  }
  pushUndo();
  const idMap = new Map();
  payload.objects.forEach((o) => idMap.set(o.id, uid("obj")));
  const groupIdMap = new Map();
  (payload.groups || []).forEach((g) => groupIdMap.set(g.id, uid("grp")));
  const OFFSET = new THREE.Vector3(0.8, 0, 0.8);
  let pending = 0, done = 0;
  const newIds = [];

  const finish = () => {
    (payload.groups || []).forEach((g) => {
      const newGid = groupIdMap.get(g.id);
      const memberIds = g.memberIds.map((mid) => idMap.get(mid)).filter(Boolean);
      if (memberIds.length >= 2) {
        objectGroups.set(newGid, { id: newGid, name: (g.name || "Grupo") + " copia", memberIds });
        memberIds.forEach((mid) => { const r = sceneObjects.get(mid); if (r) r.groupId = newGid; });
      }
    });
    recomputeTimelineDuration();
    selectedIds = new Set(newIds);
    selectedId = newIds.length ? newIds[newIds.length - 1] : null;
    updateGizmoAttachment();
    renderHierarchy();
    renderProps();
    logInfo("📋 Pegado(s) " + newIds.length + " objeto(s) desde el portapapeles.");
  };

  const applyOffsetAndTrack = (newId) => {
    const rec = sceneObjects.get(newId);
    if (!rec) return;
    rec.object3D.position.add(OFFSET);
    recomputeCheckpoints(rec);
    newIds.push(newId);
  };

  payload.objects.forEach((o) => {
    const newId = idMap.get(o.id);
    const oo = Object.assign({}, o, {
      id: newId,
      groupId: (o.groupId && groupIdMap.has(o.groupId)) ? groupIdMap.get(o.groupId) : null,
      actions: (o.actions || []).map((a) => remapActionTargetsForPaste(JSON.parse(JSON.stringify(a)), idMap)),
      interactive: o.interactive
        ? Object.assign({}, o.interactive, {
            onInteractAction: o.interactive.onInteractAction ? remapActionTargetsForPaste(JSON.parse(JSON.stringify(o.interactive.onInteractAction)), idMap) : null,
          })
        : o.interactive,
    });
    if (oo.kind === "gltf" && oo.gltfBase64) {
      pending++;
      gltfLoader.parse(base64ToArrayBuffer(oo.gltfBase64), "", (gltf) => {
        const inner = gltf.scene || gltf.scenes[0];
        inner.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
        const group = new THREE.Group(); group.add(inner);
        const clips = gltf.animations || [];
        const mixer = clips.length ? new THREE.AnimationMixer(inner) : null;
        applyImportedObject(oo, group, collectGltfColorMaterials(inner), mixer, clips, oo.gltfBase64, oo.gltfFileName);
        applyOffsetAndTrack(newId);
        done++; if (done === pending) finish();
      }, () => { done++; if (done === pending) finish(); });
    } else if (oo.kind === "image" && oo.imageBase64) {
      pending++;
      buildImagePlaneObject(oo.imageBase64, null, (built) => {
        if (built) { applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null); applyOffsetAndTrack(newId); }
        done++; if (done === pending) finish();
      });
    } else if (oo.kind === "video" && oo.videoBase64) {
      pending++;
      buildVideoPlaneObject(oo.videoBase64, null, (built) => {
        if (built) { applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null, built.videoEl); applyOffsetAndTrack(newId); }
        done++; if (done === pending) finish();
      });
    } else if (oo.kind === "text3d") {
      const t3 = oo.text3d || { text: "Texto", color: "#ffffff", size: 1 };
      const built = buildText3DObject(t3.text, t3.color, t3.size, t3.boxWidth);
      applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "extrude" && oo.extrudeData) {
      const built = buildExtrudeObject(oo.extrudeData);
      applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "primitive") {
      const built = createPrimitive(oo.primitiveType);
      applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "prefab") {
      const built = createPrefab(oo.prefabType);
      applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "light") {
      const built = buildLightObject(oo.lightData);
      applyImportedObject(oo, built.object3D, [], null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "camerapath") {
      applyImportedObject(oo, new THREE.Group(), [], null, [], null, null);
      applyOffsetAndTrack(newId);
    } else if (oo.kind === "weather") {
      const built = buildWeatherObject(oo.weatherData);
      applyImportedObject(oo, built.object3D, built.colorMaterials, null, [], null, null);
      applyOffsetAndTrack(newId);
    }
  });
  if (pending === 0) finish();
}

function showClipboardFallback(mode, prefill) {
  const existing = document.getElementById("clipFallback");
  if (existing) existing.remove();
  const overlay = document.createElement("div");
  overlay.id = "clipFallback";
  overlay.style.cssText = "position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:1000; display:flex; align-items:center; justify-content:center;";
  const box = document.createElement("div");
  box.style.cssText = "background:var(--panel); border:1px solid var(--border); border-radius:8px; padding:16px; width:min(520px,90vw); color:var(--text); font-family:inherit;";
  const title = mode === "copy" ? "📋 Copiar prefab (modo manual)" : "📋 Pegar prefab (modo manual)";
  const hint = mode === "copy"
    ? "El navegador no permitió el acceso directo al portapapeles (pasa a veces abriendo el archivo con doble clic, sin https). El texto ya está seleccionado: copia con Ctrl+C / Cmd+C y cierra esta ventana."
    : "El navegador no permitió el acceso directo al portapapeles. Pega aquí (Ctrl+V / Cmd+V) el texto que copiaste antes y pulsa \"Pegar\".";
  box.innerHTML = '<h3 style="margin-top:0;">' + title + '</h3><p class="sub">' + hint + '</p>' +
    '<textarea id="clipFallbackText" rows="8" style="width:100%; background:#0f1116; color:var(--text); border:1px solid var(--border); border-radius:5px; padding:8px; font-family:monospace; font-size:12px;"></textarea>' +
    '<div class="flexRow" style="margin-top:10px; gap:8px;">' +
    (mode === "paste" ? '<button type="button" class="small primary grow" id="clipFallbackConfirm">Pegar</button>' : "") +
    '<button type="button" class="small grow" id="clipFallbackClose">' + (mode === "copy" ? "Cerrar" : "Cancelar") + '</button></div>';
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  const ta = document.getElementById("clipFallbackText");
  if (mode === "copy") { ta.value = prefill || ""; ta.focus(); ta.select(); }
  else { ta.value = ""; ta.focus(); }
  document.getElementById("clipFallbackClose").addEventListener("click", () => overlay.remove());
  const confirmBtn = document.getElementById("clipFallbackConfirm");
  if (confirmBtn) confirmBtn.addEventListener("click", () => { pasteSelectionFromClipboardData(ta.value); overlay.remove(); });
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

function copySelectionToClipboard() {
  const payload = copySelectionToClipboardData();
  if (!payload) { alertBox("No hay ningún objeto seleccionado para copiar.", "info"); return; }
  const json = JSON.stringify(payload);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(json)
      .then(() => logInfo("📋 " + payload.objects.length + " objeto(s) copiado(s) al portapapeles."))
      .catch(() => showClipboardFallback("copy", json));
  } else {
    showClipboardFallback("copy", json);
  }
}

function pasteSelectionFromClipboard() {
  if (navigator.clipboard && navigator.clipboard.readText) {
    navigator.clipboard.readText()
      .then((text) => pasteSelectionFromClipboardData(text))
      .catch(() => showClipboardFallback("paste"));
  } else {
    showClipboardFallback("paste");
  }
}

/* =========================================================================
   PANEL: JERARQUÍA
   ========================================================================= */
function iconFor(rec) {
  if (rec.collider.kind === "character") return "🚶";
  if (rec.interactive && rec.interactive.enabled) return "💬";
  if (rec.collider.kind === "zone") return "⚠️";
  if (rec.collider.kind === "solid") return "🧱";
  if (rec.collider.kind === "ground") return "🟫";
  if (rec.kind === "light") return "💡";
  if (rec.kind === "camerapath") return "🎥";
  if (rec.kind === "weather") return (WEATHER_TYPES[(rec.weatherData || {}).type] || WEATHER_TYPES.rain_light).icon;
  if (rec.kind === "text3d") return "🔤";
  if (rec.kind === "image") return "🖼️";
  if (rec.kind === "video") return "🎞️";
  if (rec.kind === "extrude") return "✏️";
  if (rec.kind === "gltf") return "🧊";
  if (rec.kind === "prefab") return "🧩";
  return "◆";
}
function renderHierarchy() {
  const box = document.getElementById("hierarchyList");
  if (!sceneOrder.length) { box.innerHTML = '<div id="emptyHint">La escena está vacía. Añade formas o prefabs desde la Biblioteca.</div>'; return; }
  box.innerHTML = sceneOrder.map((id) => {
    const rec = sceneObjects.get(id);
    const sel = selectedIds.has(id) ? " selected" : "";
    const grp = rec.groupId && objectGroups.has(rec.groupId) ? '<span class="tag grpBadge" data-grpid="' + id + '" title="Forma parte de \'' + objectGroups.get(rec.groupId).name.replace(/"/g, "&quot;") + "'. Clic aquí para seleccionar solo esta pieza (sin expandir a todo el grupo).\">📦</span>" : "";
    const tag = rec.actions.length ? rec.actions.length + " acc." : "";
    return '<div class="hItem' + sel + '" data-id="' + id + '"><span>' + iconFor(rec) + '</span><span class="nm">' + rec.name + '</span>' + grp + (tag ? '<span class="tag">' + tag + "</span>" : "") + "</div>";
  }).join("");
  box.querySelectorAll(".hItem").forEach((el) => el.addEventListener("click", (e) => {
    if (e.target.closest(".grpBadge")) return; // gestionado por su propio listener, evita expandir a todo el grupo
    if (e.shiftKey) toggleSelectObject(el.dataset.id);
    else selectObject(el.dataset.id);
  }));
  box.querySelectorAll(".grpBadge").forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation();
    selectSingleWithinGroup(el.dataset.grpid);
  }));
}

/* =========================================================================
   PANEL: PROPIEDADES (transform, color, colisionador, acciones)
   ========================================================================= */
function refreshPropsTransformInputsOnly() {
  if (!selectedId) return;
  const rec = sceneObjects.get(selectedId);
  ["px", "py", "pz", "rx", "ry", "rz", "sx", "sy", "sz"].forEach((k) => {
    const el = document.getElementById("prop_" + k);
    if (!el) return;
    if (k[0] === "p") el.value = rec.object3D.position[k[1]].toFixed(2);
    if (k[0] === "r") el.value = rad2deg(rec.object3D.rotation[k[1]]).toFixed(1);
    if (k[0] === "s") el.value = rec.object3D.scale[k[1]].toFixed(2);
  });
}

function renderProps() {
  const panel = document.getElementById("propsPanel");
  if (selectedIds.size > 1) {
    const esc0 = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;");
    const group = currentSelectionGroup();
    const recs = selectedRecs();
    let msg = '<b>' + selectedIds.size + ' objetos seleccionados.</b> Muévelos, rótalos o escálalos juntos con el gizmo (G/R/S) — pivotan sobre el centro del grupo.';
    if (group) {
      msg += ' Forman el grupo permanente "<b>' + esc0(group.name) + '</b>" — al hacer clic en cualquiera de sus piezas se selecciona todo el grupo. <b>Ctrl+Mayús+G</b> para desagruparlo.';
    } else {
      msg += ' <b>Ctrl+G</b> agrupa esta selección de forma permanente (así no hace falta volver a Mayús+clic cada pieza cada vez).';
    }
    msg += ' Para editar propiedades individuales de cada pieza (acciones, interacción, texto/imagen/vídeo...), selecciona uno solo (clic sin Mayús)' + (group ? " tras desagrupar" : "") + '. Supr elimina todos los seleccionados.';
    let html = '<p class="sub">' + msg + '</p>';

    const colorable = recs.filter((r) => r.colorMaterials.length && r.kind !== "text3d" && r.kind !== "image" && r.kind !== "video");
    if (colorable.length) {
      html += '<h3>Color del conjunto</h3>';
      html += '<input type="color" id="groupColor" value="#' + colorable[0].colorMaterials[0].color.getHexString() + '" style="width:100%; height:30px;">';
      html += '<p class="sub">Se aplica a los ' + colorable.length + ' objeto(s) de la selección con color propio (' + (recs.length - colorable.length ? (recs.length - colorable.length) + " sin color propio, p.ej. texto/imagen/vídeo, no se ven afectados" : "todos") + ').</p>';
    }

    const opacitable = recs.filter((r) => r.colorMaterials.length);
    if (opacitable.length) {
      const opacidadInicial = (opacitable[0].opacity != null ? opacitable[0].opacity : 1);
      html += '<h3>Opacidad del conjunto</h3>';
      html += '<label class="field"><div class="row3" style="grid-template-columns: 1fr auto;"><input type="range" id="groupOpacity" min="0" max="1" step="0.01" value="' + opacidadInicial + '"><span id="groupOpacityVal" style="min-width:2.5em; text-align:right;">' + Math.round(opacidadInicial * 100) + '%</span></div></label>';
      html += '<p class="sub">Se aplica a los ' + opacitable.length + ' objeto(s) de la selección (incluye texto 3D, imágenes y vídeos -- todos admiten opacidad). Muestra la opacidad del primero; al mover el control, iguala todos.</p>';
    }

    html += '<h3>Colisionador del conjunto</h3>';
    html += '<label class="field"><span>Aplicar tipo a todos los seleccionados</span><select id="groupColliderKind">' +
      ['__nochange__:No cambiar (dejar cada uno como está)', 'none:Ninguno', 'volume:Volumen (referencia visual)', 'solid:Sólido (bloquea el paso)', 'ground:Suelo/rampa (se puede pisar)', 'character:Personaje (detector)', 'zone:Zona de riesgo (disparador)']
        .map((o) => { const [v, l] = o.split(":"); return '<option value="' + v + '">' + l + "</option>"; }).join("") +
      "</select></label>";
    html += '<p class="sub">Cada objeto conserva su propio tamaño de colisionador — solo cambia el tipo (p. ej. marcar todo un edificio agrupado como "Sólido" u "Suelo/rampa" de una vez).</p>';
    html += '<div id="groupRiskLabelWrap" style="display:none;"><label class="field"><span>Etiqueta de riesgo (si eliges "Zona de riesgo")</span><input type="text" id="groupRiskLabel" value=""></label></div>';

    panel.innerHTML = html;

    const groupColorEl = document.getElementById("groupColor");
    if (groupColorEl) groupColorEl.addEventListener("input", (e) => {
      colorable.forEach((r) => r.colorMaterials.forEach((m) => m.color.set(e.target.value)));
    });
    const groupOpacityEl = document.getElementById("groupOpacity");
    if (groupOpacityEl) groupOpacityEl.addEventListener("input", (e) => {
      const v = parseFloat(e.target.value);
      opacitable.forEach((r) => {
        r.opacity = v;
        r.colorMaterials.forEach((m) => { m.opacity = v; m.visible = v > 0.01; });
        recomputeCheckpoints(r);
      });
      const lbl = document.getElementById("groupOpacityVal");
      if (lbl) lbl.textContent = Math.round(v * 100) + "%";
    });
    const groupColliderKindEl = document.getElementById("groupColliderKind");
    groupColliderKindEl.addEventListener("change", (e) => {
      document.getElementById("groupRiskLabelWrap").style.display = e.target.value === "zone" ? "block" : "none";
      if (e.target.value === "__nochange__") return;
      recs.forEach((r) => { r.collider.kind = e.target.value; });
      renderHierarchy();
    });
    const groupRiskLabelEl = document.getElementById("groupRiskLabel");
    if (groupRiskLabelEl) groupRiskLabelEl.addEventListener("input", (e) => {
      recs.forEach((r) => { if (r.collider.kind === "zone") r.collider.riskLabel = e.target.value; });
    });
    return;
  }
  if (!selectedId) { panel.innerHTML = '<p class="sub">Selecciona un objeto en la jerarquía o en el visor para editar sus propiedades. Mayús+clic selecciona varios a la vez para moverlos juntos.</p>'; return; }
  const rec = sceneObjects.get(selectedId);
  const esc = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;");
  let html = "";
  if (rec.groupId && objectGroups.has(rec.groupId)) {
    html += '<p class="sub">📦 Forma parte del grupo "<b>' + esc(objectGroups.get(rec.groupId).name) + '</b>". <button type="button" class="small" id="btnLeaveGroup" style="margin-left:6px;">Sacar del grupo</button></p>';
  }
  html += '<h3>Nombre</h3><input type="text" id="propName" value="' + rec.name.replace(/"/g, "&quot;") + '">';

  html += '<h3>Transformación</h3>';
  html += '<label class="field"><span>Posición (x, y, z)</span><div class="row3">' +
    ["x", "y", "z"].map((a) => '<input type="number" step="0.1" id="prop_p' + a + '" value="' + rec.object3D.position[a].toFixed(2) + '">').join("") + "</div></label>";
  html += '<label class="field"><span>Rotación en grados (x, y, z)</span><div class="row3">' +
    ["x", "y", "z"].map((a) => '<input type="number" step="1" id="prop_r' + a + '" value="' + rad2deg(rec.object3D.rotation[a]).toFixed(1) + '">').join("") + "</div></label>";
  html += '<label class="field"><span>Escala (x, y, z)</span><div class="row3">' +
    ["x", "y", "z"].map((a) => '<input type="number" step="0.05" id="prop_s' + a + '" value="' + rec.object3D.scale[a].toFixed(2) + '">').join("") + "</div></label>";

  if (rec.kind === "weather") {
    const wd = rec.weatherData || { type: "rain_light" };
    html += '<h3>Meteorología</h3>';
    html += '<label class="field"><span>Tipo</span><select id="weatherType">' +
      Object.keys(WEATHER_TYPES).map((k) => '<option value="' + k + '"' + (wd.type === k ? " selected" : "") + '>' + WEATHER_TYPES[k].icon + ' ' + WEATHER_TYPES[k].label + '</option>').join("") +
      '</select></label>';
    html += '<p class="sub">Mueve y escala este objeto (con los controles de arriba) para cubrir la zona del escenario que quieras. Actívalo/desactívalo con una acción "Aparecer / desaparecer" -- por ejemplo al entrar en una zona, o automáticamente al empezar la partida. La tormenta añade rayo (destello de luz) y trueno (sonido).</p>';
    panel.innerHTML = html;
    wirePropsEvents(rec);
    return;
  }
  if (rec.kind === "light") {
    const ld = rec.lightData || { color: "#fff2cc", intensity: 1.2, distance: 8, castShadow: false };
    html += '<h3>Luz puntual</h3>';
    html += '<label class="field"><span>Color</span><input type="color" id="lightColor" value="' + ld.color + '" style="width:100%; height:30px;"></label>';
    html += '<label class="field"><span>Intensidad</span><input type="number" step="0.1" min="0" id="lightIntensity" value="' + ld.intensity + '"></label>';
    html += '<label class="field"><span>Alcance en metros (0 = sin límite, se apaga con la distancia igualmente por física)</span><input type="number" step="0.5" min="0" id="lightDistance" value="' + ld.distance + '"></label>';
    html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="lightCastShadow" style="width:auto;"' + (ld.castShadow ? " checked" : "") + '> <span style="margin:0;">Proyecta sombra (más coste -- actívalo solo si hace falta)</span></label>';
    html += '<p class="sub">La bola pequeña que ves aquí en el editor es solo una referencia de posición para poder seleccionar la luz con el ratón -- no aparece ni en Modo jugar ni en el videojuego exportado.</p>';
    panel.innerHTML = html;
    wirePropsEvents(rec);
    return;
  }
  if (rec.kind === "camerapath") {
    const cpd = rec.cameraPathData;
    const hasSel = pathEditRec === rec && pathEditSelIndex >= 0 && cpd.path.nodes[pathEditSelIndex];
    html += '<h3>Recorrido de cámara</h3>';
    html += '<button type="button" class="small primary" id="btnEditPath" style="width:100%;">' + (pathEditRec === rec ? "✅ Cerrar edición del camino" : "🛤️ Editar camino") + '</button>';
    html += '<p class="sub" style="margin-top:4px;">' + (pathEditRec === rec
      ? 'Clic en un tramo para añadir un punto, arrastra un punto para moverlo en horizontal (usa el campo Altura para la vertical), Supr borra el punto seleccionado (mínimo 2).'
      : 'Traza el recorrido que seguirá la cámara: cada punto es una posición por la que pasa. Se suaviza automáticamente.') + '</p>';
    html += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="pathClosed" style="width:auto;"' + (cpd.path.closed ? " checked" : "") + '> <span style="margin:0;">Camino cerrado (bucle)</span></label>';
    if (hasSel) {
      html += '<label class="field"><span>Altura del punto seleccionado (Y)</span><input type="number" step="0.1" id="pathNodeY" value="' + cpd.path.nodes[pathEditSelIndex].y.toFixed(2) + '"></label>';
    }
    html += '<h3>Reproducción</h3>';
    html += '<label class="field"><span>Duración del recorrido (segundos)</span><input type="number" step="0.5" min="0.5" id="cpDuration" value="' + (cpd.duration || 6) + '"></label>';
    html += '<label class="field"><span>Texto en pantalla durante el recorrido (opcional)</span><input type="text" id="cpCaption" value="' + esc(cpd.caption || "") + '"></label>';
    html += '<label class="field"><span>Mirar hacia (opcional)</span><select id="cpLookAt"><option value="">Dirección del camino (por defecto)</option>';
    sceneOrder.forEach((oid) => {
      if (oid === rec.id) return;
      const o = sceneObjects.get(oid);
      html += '<option value="' + oid + '"' + (cpd.lookAtTargetId === oid ? " selected" : "") + '>' + o.name.replace(/"/g, "&quot;") + '</option>';
    });
    html += '</select></label>';
    html += '<p class="sub">Si eliges un objeto, la cámara lo mantiene centrado durante todo el recorrido en vez de mirar simplemente hacia donde avanza.</p>';
    html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="cpAutoplay" style="width:auto;"' + (cpd.autoplay ? " checked" : "") + '> <span style="margin:0;">▶ Reproducir automáticamente al iniciar la partida</span></label>';
    html += '<p class="sub">También se puede disparar como cualquier otra acción: "Aplicar a" → este objeto → tipo "🎥 Recorrido de cámara", desde Interacción (E), Disparo (F), o en cadena/paralelo.</p>';
    panel.innerHTML = html;
    wirePropsEvents(rec);
    return;
  }
  if (rec.kind === "text3d") {
    html += '<h3>Texto 3D</h3>';
    html += '<label class="field"><span>Texto (Intro = salto de línea manual)</span><textarea id="text3dContent" rows="3" style="width:100%; background:#0f1116; color:var(--text); border:1px solid var(--border); border-radius:5px; padding:6px;">' + esc(rec.text3d.text) + '</textarea></label>';
    html += '<label class="field"><span>Color</span><input type="color" id="text3dColor" value="' + rec.text3d.color + '" style="width:100%; height:30px;"></label>';
    html += '<label class="field"><span>Tamaño</span><input type="number" step="0.1" min="0.2" id="text3dSize" value="' + rec.text3d.size + '"></label>';
    html += '<label class="field"><span>Ancho del texto (px de lienzo -- controla dónde ajusta la línea)</span><input type="number" step="20" min="60" id="text3dBoxWidth" value="' + (rec.text3d.boxWidth || 472) + '"></label>';
    html += '<p class="sub">El alto se ajusta solo según cuántas líneas hagan falta (no se recorta). El ancho lo fijas tú aquí -- más estrecho ajusta antes, más ancho deja frases más largas en una sola línea.</p>';
  }
  if (rec.kind === "image") {
    html += '<h3>Imagen</h3>';
    html += '<p class="sub">Archivo actual: ' + esc(rec.imageFileName || "—") + '</p>';
    html += '<input type="file" id="imageReplaceInput" accept="image/*" style="display:none;">';
    html += '<button type="button" class="small" id="btnReplaceImage">Reemplazar imagen</button>';
  }
  if (rec.kind === "video") {
    html += '<h3>Vídeo</h3>';
    html += '<p class="sub">Archivo actual: ' + esc(rec.videoFileName || "—") + '. Se reproduce/pausa al interactuar (tecla E) en Modo jugar.</p>';
    html += '<input type="file" id="videoReplaceInput" accept="video/*" style="display:none;">';
    html += '<button type="button" class="small" id="btnReplaceVideo">Reemplazar vídeo</button>';
  }
  if (rec.kind === "extrude") {
    html += '<h3>Forma libre</h3>';
    html += '<button type="button" class="small primary" id="btnEditNodes" style="width:100%;">' + (nodeEditRec === rec ? "✅ Cerrar edición del perfil" : "✏️ Editar perfil (contorno)") + '</button>';
    html += '<p class="sub" style="margin-top:4px;">' + (nodeEditRec === rec
      ? 'Clic en un tramo del contorno para añadir un nodo · arrastra un nodo (esfera blanca/amarilla) para moverlo · al seleccionar un nodo aparecen dos manecillas naranjas tenues junto a él: arrástralas hacia fuera para curvar ese tramo (Bézier), o arrástralas de vuelta al nodo para quitar la curva · con un nodo seleccionado, Supr lo borra (mínimo 3 nodos).'
      : 'El "perfil" es la silueta 2D de esta pieza (lo que ves al mirarla de frente). Edítalo para darle forma antes de extruirlo.') + '</p>';

    const hasPath = !!(rec.extrudeData.path && rec.extrudeData.path.nodes && rec.extrudeData.path.nodes.length >= 2);
    if (!hasPath) {
      html += '<label class="field" style="margin-top:8px;"><span>Profundidad de extrusión</span><input type="number" step="0.05" min="0.02" id="extrudeDepth" value="' + (rec.extrudeData.depth || 0.3) + '"></label>';
      html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="extrudeBevel" style="width:auto;"' + (rec.extrudeData.bevelEnabled ? " checked" : "") + '> <span style="margin:0;">Bisel en los bordes</span></label>';
      html += '<div id="extrudeBevelSizeWrap" style="display:' + (rec.extrudeData.bevelEnabled ? "block" : "none") + ';"><label class="field"><span>Tamaño del bisel</span><input type="number" step="0.01" min="0.005" id="extrudeBevelSize" value="' + (rec.extrudeData.bevelSize || 0.05) + '"></label></div>';
      html += '<button type="button" class="small" id="btnAddPath" style="width:100%; margin-top:6px;">🛤️ Extruir siguiendo un camino…</button>';
      html += '<p class="sub">En vez de una profundidad recta, la pieza puede "barrerse" a lo largo de un camino (recto o en bucle cerrado) -- útil para laderas de montaña, muros que rodean un valle, carreteras... El perfil se mantiene siempre en pie (no gira) a lo largo del camino.</p>';
    } else {
      html += '<button type="button" class="small primary" id="btnEditPath" style="width:100%; margin-top:8px;">' + (pathEditRec === rec ? "✅ Cerrar edición del camino" : "🛤️ Editar camino") + '</button>';
      html += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="pathClosed" style="width:auto;"' + (rec.extrudeData.path.closed ? " checked" : "") + '> <span style="margin:0;">Camino cerrado (bucle -- para rodear un valle)</span></label>';
      if (pathEditRec === rec && pathEditSelIndex >= 0 && rec.extrudeData.path.nodes[pathEditSelIndex]) {
        html += '<label class="field"><span>Altura del punto seleccionado (Y)</span><input type="number" step="0.1" id="pathNodeY" value="' + rec.extrudeData.path.nodes[pathEditSelIndex].y.toFixed(2) + '"></label>';
      }
      html += '<button type="button" class="small" id="btnRemovePath" style="width:100%; margin-top:6px;">❌ Quitar camino (volver a extrusión recta)</button>';
      html += '<p class="sub">' + (pathEditRec === rec
        ? 'Clic para añadir puntos del camino (visto en planta, sobre el plano horizontal de la pieza) · arrastra un punto (esfera verde/amarilla) para moverlo · usa el campo "Altura" de arriba para su elevación · Supr borra el punto seleccionado (mínimo 2).'
        : 'El camino define la ruta que sigue la extrusión. Actívalo y edítalo para trazarlo.') + '</p>';
    }
  }

  if (rec.colorMaterials.length && rec.kind !== "text3d" && rec.kind !== "image" && rec.kind !== "video") {
    html += '<h3>Color</h3><input type="color" id="propColor" value="#' + rec.colorMaterials[0].color.getHexString() + '" style="width:100%; height:30px;">';
  }
  if (rec.colorMaterials.length) {
    // A diferencia del Color (arriba, restringido a piezas sin color propio ya dedicado -- el texto 3D
    // tiene el suyo, imagen/vídeo son la foto/vídeo tal cual), la Opacidad vale para CUALQUIER pieza con
    // material: los tres tipos ya llevan transparent:true desde que se crean, así que un cartel o un
    // texto 3D pueden aparecer/desaparecer exactamente igual que un cubo.
    const opacidadVal = (rec.opacity != null ? rec.opacity : 1);
    html += '<h3>Opacidad</h3><label class="field"><div class="row3" style="grid-template-columns: 1fr auto;"><input type="range" id="propOpacity" min="0" max="1" step="0.01" value="' + opacidadVal + '"><span id="propOpacityVal" style="min-width:2.5em; text-align:right;">' + Math.round(opacidadVal * 100) + '%</span></div></label>';
    html += '<p class="sub">100% = opaco, 0% = invisible. No afecta al rendimiento (la transparencia ya está activada en todos los materiales).</p>';
  }
  if (rec.colorMaterials.length && rec.kind !== "text3d" && rec.kind !== "image" && rec.kind !== "video") {
    html += '<h3>Textura de imagen</h3>';
    if (rec.textureBase64) html += '<img src="' + rec.textureBase64 + '" style="width:100%; max-height:80px; object-fit:cover; border-radius:5px; margin-bottom:6px; display:block;">';
    html += '<input type="file" id="propTextureInput" accept="image/*" style="display:none;">';
    html += '<div class="flexRow" style="gap:6px;"><button type="button" class="small" id="propTextureTrigger">' + (rec.textureBase64 ? "Cambiar textura" : "Subir textura (ladrillo, teja…)") + '</button>' +
      (rec.textureBase64 ? '<button type="button" class="small danger" id="propTextureQuitar">Quitar</button>' : "") + '</div>';
    if (rec.textureBase64) {
      html += '<label class="field" style="margin-top:6px;"><span>Repetición horizontal / vertical (nº de veces que tesela la pieza)</span><div class="row2"><input type="number" step="0.5" min="0.1" id="propTexRepX" value="' + (rec.textureRepeatX || 1) + '"><input type="number" step="0.5" min="0.1" id="propTexRepY" value="' + (rec.textureRepeatY || 1) + '"></div></label>';
    }
    html += '<p class="sub">Se repite igual sobre todas las caras de la pieza (envoltorio uniforme, tipo pared de ladrillo). El color de arriba actúa como tinte por debajo de la imagen.</p>';
  }

  html += '<h3>Colisionador</h3>';
  html += '<label class="field"><span>Tipo</span><select id="colliderKind">' +
    ['none:Ninguno', 'volume:Volumen (referencia visual)', 'solid:Sólido (bloquea el paso)', 'ground:Suelo/rampa (se puede pisar)', 'character:Personaje (detector)', 'zone:Zona de riesgo (disparador)']
      .map((o) => { const [v, l] = o.split(":"); return '<option value="' + v + '"' + (rec.collider.kind === v ? " selected" : "") + ">" + l + "</option>"; }).join("") +
    "</select></label>";
  html += '<div id="colliderExtra" style="display:' + (rec.collider.kind === "none" ? "none" : "block") + ';">';
  if (rec.collider.kind === "solid" || rec.collider.kind === "ground") {
    html += '<p class="sub">' + (rec.collider.kind === "solid"
      ? 'El bloqueo usa el tamaño real de la malla (se adapta automáticamente si escalas o rotas el objeto con el gizmo) — no hace falta fijar un tamaño a mano.'
      : 'El personaje se apoya sobre la superficie real de la malla (sirve para rampas, escaleras o pisos superiores) — no bloquea el paso horizontal, solo sostiene verticalmente. No hace falta fijar un tamaño a mano.') + '</p>';
  } else {
    html += '<label class="field"><span>Tamaño del colisionador (x, y, z)</span><div class="row3">' +
      ["x", "y", "z"].map((a) => '<input type="number" step="0.1" min="0.05" id="collSize_' + a + '" value="' + rec.collider.size[a] + '">').join("") + "</div></label>";
  }
  html += '<div id="riskLabelWrap" style="display:' + (rec.collider.kind === "zone" ? "block" : "none") + ';"><label class="field"><span>Etiqueta de riesgo (aparece en el registro de eventos)</span><input type="text" id="riskLabel" value="' + (rec.collider.riskLabel || "").replace(/"/g, "&quot;") + '"></label></div>';
  html += '<div id="facingOffsetWrap" style="display:' + (rec.collider.kind === "character" ? "block" : "none") + ';"><label class="field"><span>Corrección de orientación al caminar (°)</span><input type="number" step="15" id="facingOffsetDeg" value="' + (rec.facingOffsetDeg || 0) + '"></label><p class="sub">Al moverse, el personaje gira para mirar hacia donde camina asumiendo que su "cara" mira en -Z de fábrica — si el modelo (sobre todo uno importado en .glb) fue modelado mirando hacia otro lado y ves que anda de espaldas o de lado, prueba 180° (o el ángulo que corresponda) aquí para corregirlo, en vez de rotarlo a mano (esa rotación se sobrescribe en cuanto se mueve).</p></div>';
  html += "</div>";

  html += '<h3>Interacción (Modo jugar)</h3>';
  if (rec.kind === "video") {
    html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="interactiveEnabled" ' + (rec.interactive.enabled ? "checked" : "") + ' style="width:auto;"> <span style="margin:0;">Objeto interactivo (tecla E)</span></label>';
    html += '<div id="interactiveExtra" style="display:' + (rec.interactive.enabled ? "block" : "none") + ';">';
    html += '<p class="sub">Al pulsar E cerca del vídeo, este se reproduce o se pausa (alternando). No usa panel de texto ni decisiones.</p>';
    html += '<label class="field"><span>Texto del aviso en pantalla</span><input type="text" id="interactivePrompt" value="' + (rec.interactive.prompt || "").replace(/"/g, "&quot;") + '"></label>';
    html += '<label class="field"><span>Radio de detección (unidades)</span><input type="number" step="0.1" min="0.3" id="interactiveRadius" value="' + rec.interactive.radius + '"></label>';
    html += '</div>';
  } else {
  html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="interactiveEnabled" ' + (rec.interactive.enabled ? "checked" : "") + ' style="width:auto;"> <span style="margin:0;">Objeto interactivo (tecla E)</span></label>';
  html += '<div id="interactiveExtra" style="display:' + (rec.interactive.enabled ? "block" : "none") + ';">';
  html += '<label class="field"><span>Texto del aviso en pantalla (ej. "Leer", "Abrir cajón")</span><input type="text" id="interactivePrompt" value="' + (rec.interactive.prompt || "").replace(/"/g, "&quot;") + '"></label>';
  html += '<label class="field"><span>Radio de detección (unidades)</span><input type="number" step="0.1" min="0.3" id="interactiveRadius" value="' + rec.interactive.radius + '"></label>';
  html += '<label class="field"><span>Tipo</span><select id="interactiveKind"><option value="text"' + (rec.interactive.kind === "text" ? " selected" : "") + '>Texto (leer)</option><option value="choice"' + (rec.interactive.kind === "choice" ? " selected" : "") + '>Decisión (elegir opción)</option><option value="link"' + (rec.interactive.kind === "link" ? " selected" : "") + '>Enlace (abrir URL)</option></select></label>';
  html += '<div id="interactiveTextWrap" style="display:' + (rec.interactive.kind === "text" ? "block" : "none") + ';"><label class="field"><span>Texto a mostrar</span><textarea id="interactiveText" rows="3" style="width:100%; background:#0f1116; color:var(--text); border:1px solid var(--border); border-radius:5px; padding:6px;">' + esc(rec.interactive.text) + '</textarea></label>';
  html += '<div class="flexRow" style="margin-top:6px; align-items:center; gap:8px;"><button type="button" class="small" id="btnOnReadAction">' + (rec.interactive.onInteractAction ? "🎬 Editar acción al leer" : "🎬 Añadir acción al leer") + '</button>' +
    (rec.interactive.onInteractAction ? '<span class="sub">' + describeInteractAction(rec.interactive.onInteractAction) + describeParallelSuffix(rec.interactive.onInteractAction) + '</span>' : '') + '</div>';
  if (rec.interactive.onInteractAction) {
    html += '<div class="flexRow" style="margin-top:4px; align-items:center; gap:8px;"><button type="button" class="small" id="btnChainReadAction">🔗 ' + (rec.interactive.onInteractAction.next ? "Editar" : "Encadenar") + ' acción al terminar</button>' +
      (rec.interactive.onInteractAction.next ? '<span class="sub">' + describeInteractAction(rec.interactive.onInteractAction.next) + '</span>' : '') + '</div>';
  }
  html += '</div>';
  html += '<div id="interactiveChoiceWrap" style="display:' + (rec.interactive.kind === "choice" ? "block" : "none") + ';">';
  html += '<label class="field"><span>Pregunta / texto de la decisión</span><textarea id="interactiveQuestion" rows="2" style="width:100%; background:#0f1116; color:var(--text); border:1px solid var(--border); border-radius:5px; padding:6px;">' + esc(rec.interactive.text) + '</textarea></label>';
  html += '<div id="choicesList"></div>';
  html += '<button id="btnAddChoice" class="small">+ Añadir opción (máx. 4)</button>';
  html += '</div>';
  html += '<div id="interactiveLinkWrap" style="display:' + (rec.interactive.kind === "link" ? "block" : "none") + ';">';
  html += '<label class="field"><span>URL a abrir en pestaña nueva</span><input type="url" id="interactiveUrl" placeholder="https://..." value="' + (rec.interactive.url || "").replace(/"/g, "&quot;") + '"></label>';
  html += '<p class="sub">Al pulsar E cerca del objeto se abre este enlace en una pestaña nueva — sin panel ni pausa. Útil para un cuestionario, una plataforma de curso, o para "encadenar" a otro escenario .html exportado (una puerta de salida, por ejemplo).</p>';
  html += '</div>';
  html += '</div>';
  }

  html += '<div style="margin-top:10px; padding-top:8px; border-top:1px solid var(--border);">';
  html += '<h3>🎯 Disparo a distancia (rayo)</h3>';
  html += '<p class="sub">Independiente de la tecla E: si el jugador apunta a este objeto con la mira y dispara (tecla F / botón 🎯 en táctil), se ejecuta esta acción al instante, sin panel ni pausa -- funciona a distancia, no requiere acercarse. Ideal para "explota", destellos, o para disparar la acción de OTRA pieza desde lejos.</p>';
  html += '<div class="flexRow" style="align-items:center; gap:8px;"><button type="button" class="small" id="btnOnShotAction">' + (rec.interactive.onShotAction ? "🎯 Editar acción al disparar" : "🎯 Añadir acción al disparar") + '</button>' +
    (rec.interactive.onShotAction ? '<span class="sub">' + describeInteractAction(rec.interactive.onShotAction) + describeParallelSuffix(rec.interactive.onShotAction) + '</span>' : '') + '</div>';
  if (rec.interactive.onShotAction) {
    html += '<button type="button" class="small danger" id="btnRemoveShotAction" style="margin-top:4px;">Quitar acción al disparar</button>';
  }
  html += '</div>';

  html += '<h3>Acciones (' + rec.actions.length + ')</h3>';
  html += '<div id="actionsList"></div>';
  html += '<div class="row2">' +
    '<select id="newActionType">' +
      '<option value="moveTo">Mover a punto</option>' +
      '<option value="rotateTo">Rotar a ángulo</option>' +
      '<option value="wait">Esperar</option>' +
      '<option value="fade">Aparecer / desaparecer</option>' +
      '<option value="flash">Destello de alerta</option>' +
      (rec.clips && rec.clips.length ? '<option value="playClip">Reproducir animación</option>' : '') +
      '<option value="setVariable">🔢 Variable (asignar/sumar)</option>' +
      '<option value="fetchUrl">🌐 Red (enviar/recibir datos)</option>' +
      '<option value="screenMessage">💬 Mensaje en pantalla</option>' +
      '<option value="askInput">⌨️ Preguntar (entrada libre)</option>' +
      (sceneOrder.some((oid) => { const o = sceneObjects.get(oid); return o && o.kind === "image"; }) ? '<option value="setImageVar">🖼️ Imagen desde variable</option>' : '') +
      (sceneOrder.some((oid) => { const o = sceneObjects.get(oid); return o && o.kind === "text3d"; }) ? '<option value="setTextVar">🔤 Rótulo desde variable</option>' : '') +
    '</select>' +
    '<button id="btnAddAction" class="small">+ Añadir acción</button>' +
  '</div>';
  html += '<p class="sub">Las acciones de un objeto se ejecutan en orden, una después de otra. Consejo: mueve el objeto con el gizmo hasta el punto deseado y pulsa "usar posición actual" al crear una acción "Mover a punto". Las de Variable/Red son instantáneas (sin duración): se disparan en cuanto les llega el turno.</p>';

  panel.innerHTML = html;
  renderActionsList(rec);
  renderChoicesList(rec);
  wirePropsEvents(rec);
}

function describeInteractAction(a) {
  if (!a || !a.type) return "";
  if (a.type === "sound") return "🔊 Sonido" + (a.soundFileName ? " (" + a.soundFileName + ")" : " (sin archivo)");
  let who = "";
  if (a.target === "player") who = "[Personaje] ";
  else if (a.target === "__group__") who = "[Todo el grupo] ";
  else if (a.target && a.target !== "self") { const t = sceneObjects.get(a.target); who = "[" + (t ? t.name : "objeto eliminado") + "] "; }
  if (a.type === "moveTo") return who + (a.relative ? "Mover (relativo) " : "Mover a ") + "(" + a.to.x.toFixed(1) + ", " + a.to.y.toFixed(1) + ", " + a.to.z.toFixed(1) + ") en " + a.duration + "s";
  if (a.type === "rotateTo") return who + (a.relative ? "Rotar (relativo) " : "Rotar a ") + "(" + a.to.x + "°, " + a.to.y + "°, " + a.to.z + "°) en " + a.duration + "s";
  if (a.type === "fade") return who + (a.to === 1 ? "Aparecer" : "Desaparecer") + " en " + a.duration + "s";
  if (a.type === "flash") return who + "Destello " + a.color + " ×" + a.repeat + " en " + a.duration + "s";
  if (a.type === "spin") return who + "Girar sin parar (eje " + (a.axis || "y").toUpperCase() + ", " + (a.speed || 0) + "°/s) durante " + a.duration + "s";
  if (a.type === "toggleVideo") return who + "🎬 Reproducir/pausar vídeo";
  if (a.type === "playClip") return who + "🎬 Animación \"" + (a.clipName || "?") + "\"" + (a.loop ? " (en bucle)" : " (" + (a.duration || 1) + "s)");
  if (a.type === "setVariable") return "🔢 " + (a.varName || "?") + " = " + (a.expr || "0");
  if (a.type === "fetchUrl") return "🌐 " + ((a.url || "").indexOf("mailto:") === 0 ? "correo" : (a.method || "GET")) + " " + (a.url || "(sin URL)") + (a.responseMode === "label" ? " → rótulo en " + (who || "[este objeto] ") : a.responseMode === "imagen" ? " → imagen en " + (who || "[este objeto] ") : a.responseMode === "variables" ? " → variables" : "");
  if (a.type === "setImageVar") { const tImg = a.target ? sceneObjects.get(a.target) : null; return "🖼️ Imagen: variable \"" + (a.varName || "?") + "\" → " + (tImg ? tImg.name : "(sin destino)"); }
  if (a.type === "setTextVar") { const tTxt = a.target ? sceneObjects.get(a.target) : null; return "🔤 Rótulo: variable \"" + (a.varName || "?") + "\" → " + (tTxt ? tTxt.name : "(sin destino)"); }
  if (a.type === "copyToClipboard") return "📋 Copiar \"" + (a.text || "") + "\"";
  if (a.type === "if") return "🔀 Si (" + (a.expr || "?") + ") → " + (a.then ? describeInteractAction(a.then) : "nada") + " / si no → " + (a.else ? describeInteractAction(a.else) : "nada");
  if (a.type === "for") return "🔁 Repetir " + (a.count != null ? a.count : "?") + (a.varName ? " (" + a.varName + ")" : "") + ": " + (a.body ? describeInteractAction(a.body) : "nada");
  if (a.type === "screenMessage") return "💬 Mensaje en pantalla: \"" + (a.text || "") + "\"" + (a.autoDismissSec ? " (" + a.autoDismissSec + "s)" : " (manual)");
  if (a.type === "askInput") return "⌨️ Preguntar → " + (a.varName || "?") + (a.allowFile ? " (+ imagen → " + (a.fileVarName || "?") + ")" : "");
  return "";
}
function describeParallelSuffix(a) {
  return (a && a.parallel && a.parallel.length) ? " (+" + a.parallel.length + " en paralelo)" : "";
}

function openInteractTriggerForm(rec, getAction, setAction, isNested) {
  const panel = document.getElementById("propsPanel");
  const wrap = document.createElement("div");
  wrap.className = "card";
  const existing = getAction();
  const current = existing || { type: "moveTo", target: "self" };
  let pendingSoundBase64 = current.type === "sound" ? current.soundBase64 : null;
  let pendingSoundFileName = current.type === "sound" ? current.soundFileName : null;
  let pendingParallel = (current.parallel || []).slice();
  let pendingThen = current.type === "if" ? (current.then || null) : null;
  let pendingElse = current.type === "if" ? (current.else || null) : null;
  let pendingBody = current.type === "for" ? (current.body || null) : null;
  let inner = '<b>Acción al interactuar</b><br><br>';
  const grupoDeRec = (rec.groupId && objectGroups.has(rec.groupId)) ? objectGroups.get(rec.groupId) : null;
  // Resuelve a qué OBJETO concreto apunta el destino elegido (string "self"/"player"/"__group__"/id) --
  // se usa para saber qué acciones PARTICULARES de ese objeto tienen sentido ofrecer (p. ej. sólo
  // tiene sentido "reproducir animación" si el destino tiene clips importados, o "vídeo" si es un
  // objeto de tipo vídeo). "__group__" no resuelve a una pieza concreta -- se trata como el propio
  // objeto que lleva el disparador, ya que las acciones particulares (vídeo/clip) son por-objeto,
  // no tiene sentido "toda la animación del grupo".
  function resolveTargetRec(t) {
    if (t === "player") return findCharacterRecord() || rec;
    if (t === "self" || t === "__group__") return rec;
    return sceneObjects.get(t) || rec;
  }
  function tipoOpcionesHtml(target, tipoActual) {
    const todas = [['moveTo', 'Mover a punto'], ['rotateTo', 'Rotar a ángulo'], ['fade', 'Aparecer / desaparecer'], ['flash', 'Destello de alerta'], ['spin', 'Girar sin parar (bucle)'], ['sound', '🔊 Reproducir sonido']];
    const refT = resolveTargetRec(target);
    if (refT.kind === "video") todas.push(['toggleVideo', '🎬 Reproducir / pausar vídeo']);
    if (refT.clips && refT.clips.length) todas.push(['playClip', '🎬 Reproducir animación']);
    if (refT.kind === "camerapath") todas.push(['cameraPath', '🎥 Recorrido de cámara']);
    todas.push(['setVariable', '🔢 Variable (asignar/sumar)']);
    todas.push(['fetchUrl', '🌐 Red (enviar/recibir datos)']);
    todas.push(['copyToClipboard', '📋 Copiar al portapapeles']);
    todas.push(['if', '🔀 Si (condición)']);
    todas.push(['for', '🔁 Repetir (bucle)']);
    todas.push(['screenMessage', '💬 Mensaje en pantalla']);
    todas.push(['askInput', '⌨️ Preguntar (entrada libre)']);
    if (sceneOrder.some((oid) => { const o = sceneObjects.get(oid); return o && o.kind === "image"; })) {
      todas.push(['setImageVar', '🖼️ Imagen desde variable']);
    }
    if (sceneOrder.some((oid) => { const o = sceneObjects.get(oid); return o && o.kind === "text3d"; })) {
      todas.push(['setTextVar', '🔤 Rótulo desde variable']);
    }
    return todas.map((o) => '<option value="' + o[0] + '"' + (tipoActual === o[0] ? " selected" : "") + '>' + o[1] + "</option>").join("");
  }
  inner += '<div id="itf_targetWrap"><label class="field"><span>Aplicar a</span><select id="itf_target">';
  inner += '<option value="self"' + (!current.target || current.target === "self" ? " selected" : "") + '>Este objeto</option>';
  inner += '<option value="player"' + (current.target === "player" ? " selected" : "") + '>El personaje (jugador)</option>';
  if (grupoDeRec) {
    inner += '<option value="__group__"' + (current.target === "__group__" ? " selected" : "") + '>📦 Todo el grupo "' + grupoDeRec.name.replace(/"/g, "&quot;") + '"</option>';
  }
  sceneOrder.forEach((oid) => {
    if (oid === rec.id || oid === playerRecordId) return;
    const o = sceneObjects.get(oid);
    inner += '<option value="' + oid + '"' + (current.target === oid ? " selected" : "") + '>' + o.name.replace(/"/g, "&quot;") + '</option>';
  });
  inner += '</select></label></div>';
  inner += '<label class="field"><span>Tipo</span><select id="itf_type">' + tipoOpcionesHtml(current.target || "self", current.type) + "</select></label>";
  inner += '<div id="itf_fields"></div>';
  inner += '<div style="margin-top:10px; padding-top:8px; border-top:1px solid var(--border);"><b>⚡ En paralelo</b><p class="sub" style="margin:2px 0 4px;">Se disparan en el mismo instante que esta acción, sin esperar a que termine (ideal para que varias piezas se muevan/giren/aparezcan a la vez).</p><div id="itf_parallelList"></div><button type="button" class="small" id="itf_addParallel" style="margin-top:6px;">+ Añadir acción en paralelo</button></div>';
  inner += '<div class="flexRow" style="margin-top:8px;"><button class="small primary grow" id="itf_confirm">Guardar</button>' +
    (existing ? '<button class="small danger" id="itf_remove">Quitar acción</button>' : "") +
    '<button class="small grow" id="itf_cancel">Cancelar</button></div>';
  wrap.innerHTML = inner;
  panel.prepend(wrap);

  function refRecord() {
    const t = wrap.querySelector('[id="itf_target"]').value;
    if (t === "player") return findCharacterRecord() || rec;
    if (t === "self" || t === "__group__") return rec;
    return sceneObjects.get(t) || rec;
  }

  function renderFields() {
    const type = wrap.querySelector('[id="itf_type"]').value;
    const target = wrap.querySelector('[id="itf_target"]').value;
    const ref = refRecord();
    const fbox = wrap.querySelector('[id="itf_fields"]');
    // "Aplicar a" no tiene sentido para "Variable" (no actúa sobre ningún objeto, es un valor
    // aparte) -- se oculta para no dar a entender que hace algo que no hace. Para "Red" sí se
    // reutiliza: es a qué objeto de texto va el rótulo si el modo de respuesta es "Mostrar como
    // rótulo".
    const targetWrap = wrap.querySelector('[id="itf_targetWrap"]');
    if (targetWrap) targetWrap.style.display = (type === "setVariable" || type === "if" || type === "for" || type === "screenMessage" || type === "askInput" || type === "setImageVar" || type === "setTextVar") ? "none" : "";
    let html = "";
    if (type === "setVariable") {
      html += '<p class="sub">Asigna a una variable con nombre el resultado de una expresión sencilla -- puede referenciarse a sí misma (para sumar/restar) u otras variables. Una variable no usada todavía vale 0. Solo números, texto entre comillas y + − × ÷ () -- nada de código.</p>';
      html += '<label class="field"><span>Nombre de la variable</span><input type="text" id="itf_varName" placeholder="monedas" value="' + (current.type === "setVariable" && current.varName ? current.varName.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<label class="field"><span>Nuevo valor (expresión)</span><input type="text" id="itf_expr" placeholder="monedas + 1" value="' + (current.type === "setVariable" && current.expr ? current.expr.replace(/"/g, "&quot;") : "") + '"></label>';
    } else if (type === "fetchUrl") {
      html += '<p class="sub">⚠️ Apagado por defecto para quien juega: la primera vez que se dispare de verdad, se le preguntará si permite que este escenario se conecte a esa dirección (como el JS de un PDF). Puedes usar <code>{{nombreDeVariable}}</code> dentro de la URL para mandar el valor actual como parámetro.</p>';
      html += '<label class="field"><span>URL</span><input type="text" id="itf_url" placeholder="https://tuweb.com/records.php?monedas={{monedas}}" value="' + (current.type === "fetchUrl" && current.url ? current.url.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<label class="field"><span>Método</span><select id="itf_method"><option value="GET"' + (current.type !== "fetchUrl" || !current.method || current.method === "GET" ? " selected" : "") + '>GET (parámetros en la URL)</option><option value="POST"' + (current.type === "fetchUrl" && current.method === "POST" ? " selected" : "") + '>POST</option></select></label>';
      const respMode = current.type === "fetchUrl" ? (current.responseMode || "none") : "none";
      html += '<label class="field"><span>Qué hacer con la respuesta</span><select id="itf_respMode">' +
        '<option value="none"' + (respMode === "none" ? " selected" : "") + '>Nada -- solo enviar</option>' +
        '<option value="label"' + (respMode === "label" ? " selected" : "") + '>Mostrar como rótulo (usa "Aplicar a": un objeto de Texto 3D)</option>' +
        '<option value="imagen"' + (respMode === "imagen" ? " selected" : "") + '>Poner como imagen (usa "Aplicar a": un objeto de Imagen)</option>' +
        '<option value="variables"' + (respMode === "variables" ? " selected" : "") + '>Guardar en variables (respuesta en JSON)</option>' +
        '</select></label>';
      html += '<div id="itf_varMapWrap" style="display:' + (respMode === "variables" ? "block" : "none") + ';"><label class="field"><span>Campo del JSON = nombre de variable (uno por línea)</span><textarea id="itf_varMap" rows="3" placeholder="total=puntosServidor">' + (current.type === "fetchUrl" && current.varMap ? current.varMap.replace(/</g, "&lt;") : "") + '</textarea></label></div>';
      html += '<p class="sub">También admite <code>mailto:correo@dominio.com?subject=...&amp;body={{variable}}</code> -- en vez de enviar la petición se abre el cliente de correo del jugador con ese asunto/cuerpo ya rellenados (el texto de las variables se codifica automáticamente para viajar seguro en la URL).</p>';
      if (respMode === "imagen") {
        html += '<p class="sub">⚠️ El endpoint debe responder con el data URL COMPLETO como texto plano (<code>data:image/png;base64,...</code>), no con los bytes de la imagen en crudo -- igual que "rótulo" espera texto, no HTML renderizado.</p>';
      }
    } else if (type === "copyToClipboard") {
      html += '<p class="sub">Copia un texto al portapapeles del jugador (por ejemplo, para que pegue su puntuación en otro sitio). Puedes usar <code>{{nombreDeVariable}}</code> dentro del texto.</p>';
      html += '<label class="field"><span>Texto a copiar</span><input type="text" id="itf_clipText" placeholder="Mi puntuación: {{puntos}}" value="' + (current.type === "copyToClipboard" && current.text ? current.text.replace(/"/g, "&quot;") : "") + '"></label>';
    } else if (type === "if") {
      html += '<p class="sub">Si la condición es cierta, dispara la rama "si cierto"; si no, la rama "si no" (cualquiera de las dos puede quedar vacía). Admite comparaciones (&gt; &lt; &gt;= &lt;= == !=), && (y), || (o), ! (no), además de + − × ÷ % () -- todo evaluado en una caja segura, sin ejecutar código. Ejemplo par/impar: <code>i % 2 == 0</code>.</p>';
      html += '<label class="field"><span>Condición (expresión)</span><input type="text" id="itf_expr" placeholder="monedas >= 10" value="' + (current.type === "if" && current.expr ? current.expr.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<div class="flexRow" style="margin-top:8px; align-items:center; gap:8px;"><button type="button" class="small" id="itf_editThen">' + (pendingThen ? "✏️ Editar" : "+ Añadir") + ' acción si CIERTO</button>' + (pendingThen ? '<span class="sub" style="flex:1;">' + describeInteractAction(pendingThen) + '</span><button type="button" class="small danger" id="itf_delThen">✕</button>' : '') + '</div>';
      html += '<div class="flexRow" style="margin-top:6px; align-items:center; gap:8px;"><button type="button" class="small" id="itf_editElse">' + (pendingElse ? "✏️ Editar" : "+ Añadir") + ' acción si NO</button>' + (pendingElse ? '<span class="sub" style="flex:1;">' + describeInteractAction(pendingElse) + '</span><button type="button" class="small danger" id="itf_delElse">✕</button>' : '') + '</div>';
    } else if (type === "for") {
      html += '<p class="sub">Repite la acción de abajo el número de veces indicado (tope de seguridad: 1000). Si pones un nombre de variable de bucle, esa variable vale 0, 1, 2... en cada vuelta -- útil dentro de la acción repetida. Caso especial: si la acción repetida es "Mover a punto" o "Rotar a ángulo" en modo <b>relativo</b>, los N pasos se encadenan de verdad uno tras otro (no todos a la vez) -- así "un cilindro da 5 vueltas" se ve girar 5 veces seguidas de verdad, tardando 5 × la duración configurada en total (no solo la duración de un paso).</p>';
      html += '<label class="field"><span>Repeticiones (número o expresión)</span><input type="text" id="itf_forCount" placeholder="5" value="' + (current.type === "for" && current.count != null ? String(current.count).replace(/"/g, "&quot;") : "5") + '"></label>';
      html += '<label class="field"><span>Nombre de variable de bucle (opcional)</span><input type="text" id="itf_forVar" placeholder="i" value="' + (current.type === "for" && current.varName ? current.varName.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<div class="flexRow" style="margin-top:8px; align-items:center; gap:8px;"><button type="button" class="small" id="itf_editBody">' + (pendingBody ? "✏️ Editar" : "+ Añadir") + ' acción a repetir</button>' + (pendingBody ? '<span class="sub" style="flex:1;">' + describeInteractAction(pendingBody) + '</span><button type="button" class="small danger" id="itf_delBody">✕</button>' : '') + '</div>';
    } else if (type === "screenMessage") {
      html += '<p class="sub">Muestra un cuadro centrado en pantalla con un texto (como un narrador) -- NO bloquea moverse ni el resto del juego mientras está abierto. Puedes usar <code>{{nombreDeVariable}}</code> dentro del texto.</p>';
      html += '<label class="field"><span>Texto</span><input type="text" id="itf_msgText" placeholder="Ahora te bañas en la piscina" value="' + (current.type === "screenMessage" && current.text ? current.text.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<label class="field"><span>Cerrar solo tras (segundos, 0 = a mano con el botón/E/Esc)</span><input type="number" step="0.5" min="0" id="itf_msgAutoDismiss" value="' + (current.type === "screenMessage" && current.autoDismissSec ? current.autoDismissSec : 0) + '"></label>';
    } else if (type === "askInput") {
      html += '<p class="sub">Abre un cuadro centrado con un campo de texto libre (y, si quieres, un adjunto de imagen) -- a diferencia del mensaje, SÍ bloquea moverse mientras está abierto, como el panel de un objeto interactivo. Lo que escriba el jugador queda en la variable indicada, lista para usarse luego (p. ej. en una acción "Red").</p>';
      html += '<label class="field"><span>Pregunta / texto de ayuda</span><input type="text" id="itf_askPrompt" placeholder="¿Cómo te llamas?" value="' + (current.type === "askInput" && current.promptText ? current.promptText.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<label class="field"><span>Variable donde guardar el texto</span><input type="text" id="itf_askVar" placeholder="nombreJugador" value="' + (current.type === "askInput" && current.varName ? current.varName.replace(/"/g, "&quot;") : "") + '"></label>';
      html += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="itf_askAllowFile"' + (current.type === "askInput" && current.allowFile ? " checked" : "") + ' style="width:auto;"> <span style="margin:0;">Permitir adjuntar una imagen (máx. 350KB, como en el chat)</span></label>';
      html += '<div id="itf_askFileVarWrap" style="display:' + (current.type === "askInput" && current.allowFile ? "block" : "none") + ';"><label class="field"><span>Variable donde guardar la imagen (data URL)</span><input type="text" id="itf_askFileVar" placeholder="fotoJugador" value="' + (current.type === "askInput" && current.fileVarName ? current.fileVarName.replace(/"/g, "&quot;") : "") + '"></label><p class="sub">Para enviarla de verdad hace falta una acción "Red" en modo POST (nunca GET: una imagen en base64 es demasiado larga para cualquier URL).</p></div>';
    } else if (type === "setImageVar") {
      html += '<p class="sub">Pone en un objeto de Imagen el contenido de una variable que ya tenga guardado un data URL de imagen -- por ejemplo, la que rellena "Preguntar" cuando permites adjuntar una foto. Solo dura mientras juegas: al volver al editor, la imagen original se restaura sola (como el resto de elementos animados).</p>';
      html += '<label class="field"><span>Variable con la imagen</span><input type="text" id="itf_imgVar" placeholder="fotoJugador" value="' + (current.type === "setImageVar" && current.varName ? current.varName.replace(/"/g, "&quot;") : "") + '"></label>';
      const imageOptsITF = [];
      sceneOrder.forEach((oid) => {
        const o = sceneObjects.get(oid);
        if (o && o.kind === "image") imageOptsITF.push([oid, o.name]);
      });
      html += '<label class="field"><span>Imagen destino</span><select id="itf_imgTarget">' +
        (imageOptsITF.length ? imageOptsITF.map((o) => '<option value="' + o[0] + '"' + (current.type === "setImageVar" && current.target === o[0] ? " selected" : "") + '>' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Imagen en la escena)</option>') +
        '</select></label>';
    } else if (type === "setTextVar") {
      html += '<p class="sub">Pone en un objeto de Texto 3D el contenido de una variable -- directo, sin red de por medio (a diferencia de la acción Red en modo "rótulo"). Útil para mostrar lo que escribió el jugador en "Preguntar", o cualquier valor calculado.</p>';
      html += '<label class="field"><span>Variable con el texto</span><input type="text" id="itf_txtVar" placeholder="nombreJugador" value="' + (current.type === "setTextVar" && current.varName ? current.varName.replace(/"/g, "&quot;") : "") + '"></label>';
      const text3dOptsITF = [];
      sceneOrder.forEach((oid) => {
        const o = sceneObjects.get(oid);
        if (o && o.kind === "text3d") text3dOptsITF.push([oid, o.name]);
      });
      html += '<label class="field"><span>Rótulo destino</span><select id="itf_txtTarget">' +
        (text3dOptsITF.length ? text3dOptsITF.map((o) => '<option value="' + o[0] + '"' + (current.type === "setTextVar" && current.target === o[0] ? " selected" : "") + '>' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Texto 3D en la escena)</option>') +
        '</select></label>';
    } else if (type === "moveTo") {
      const refOriginPos = ref.object3D.userData.__origin ? ref.object3D.userData.__origin.pos : ref.object3D.position;
      const showAbsPos = (a) => {
        if (current.type === "moveTo" && current.to && current.target === target) {
          return current.relative ? (refOriginPos[a] + current.to[a]) : current.to[a];
        }
        return ref.object3D.position[a];
      };
      html += '<p class="sub" id="itf_targetInfo">🎯 Moviendo: <b>' + ref.name.replace(/</g, "&lt;") + '</b>' + (target === "__group__" ? ' — todo el grupo la acompaña, manteniendo la posición relativa de cada pieza' : ' (marcado en el visor)') + '</p>';
      html += '<div class="row3">' + ["x", "y", "z"].map((a) => '<input type="number" step="0.1" id="itf_' + a + '" value="' + showAbsPos(a).toFixed(2) + '">').join("") + "</div>";
      html += '<button type="button" class="small" id="itf_useCurrent" style="margin-top:6px;">usar posición actual de ' + (target === "self" ? "este objeto" : ref.name) + '</button>';
      if (target !== "__group__") {
        html += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="itf_relative"' + (current.relative ? " checked" : "") + ' style="width:auto;"> <span style="margin:0;">Relativo a su posición de partida (recomendado si vas a duplicar este objeto)</span></label>';
      }
    } else if (type === "rotateTo") {
      const refOriginQuat = ref.object3D.userData.__origin ? ref.object3D.userData.__origin.quat : ref.object3D.quaternion;
      const refOriginEuler = new THREE.Euler().setFromQuaternion(refOriginQuat);
      const showAbsRot = (a) => {
        if (current.type === "rotateTo" && current.to && current.target === target) {
          return current.relative ? (rad2deg(refOriginEuler[a]) + current.to[a]) : current.to[a];
        }
        return rad2deg(ref.object3D.rotation[a]);
      };
      if (target === "__group__") html += '<p class="sub">El grupo entero gira como un solo bloque alrededor de <b>' + ref.name.replace(/</g, "&lt;") + '</b>.</p>';
      html += '<div class="row3">' + ["x", "y", "z"].map((a) => '<input type="number" step="1" id="itf_' + a + '" value="' + showAbsRot(a).toFixed(0) + '">').join("") + "</div>";
      if (target !== "__group__") {
        html += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="itf_relative"' + (current.relative ? " checked" : "") + ' style="width:auto;"> <span style="margin:0;">Relativo a su rotación de partida (recomendado si vas a duplicar este objeto)</span></label>';
      }
    } else if (type === "fade") {
      html += '<label class="field"><span>Efecto</span><select id="itf_to"><option value="0"' + (current.to === 0 ? " selected" : "") + '>Desaparecer</option><option value="1"' + (current.to === 1 ? " selected" : "") + '>Aparecer</option></select></label>';
    } else if (type === "flash") {
      html += '<label class="field"><span>Color</span><input type="color" id="itf_color" value="' + (current.color || "#ff3b3b") + '"></label>';
      html += '<label class="field"><span>Repeticiones</span><input type="number" step="1" min="1" id="itf_repeat" value="' + (current.repeat || 3) + '"></label>';
    } else if (type === "spin") {
      if (target === "__group__") html += '<p class="sub">Cada pieza del grupo gira sobre su PROPIO eje (no alrededor de un punto común) -- así varias ruedas giran cada una en su sitio.</p>';
      html += '<label class="field"><span>Eje de giro (local)</span><select id="itf_axis"><option value="x"' + (current.axis === "x" ? " selected" : "") + '>X</option><option value="y"' + (!current.axis || current.axis === "y" ? " selected" : "") + '>Y (vertical)</option><option value="z"' + (current.axis === "z" ? " selected" : "") + '>Z</option></select></label>';
      html += '<label class="field"><span>Velocidad (°/segundo, negativo = sentido contrario)</span><input type="number" step="10" id="itf_speed" value="' + (current.speed !== undefined ? current.speed : 180) + '"></label>';
      html += '<p class="sub">Gira sin parar durante la duración de abajo -- pon la misma duración que la acción a la que quieras que acompañe (p. ej. el "Mover a punto" del grupo) para que pare a la vez.</p>';
    } else if (type === "sound") {
      html += '<p class="sub" id="itf_soundInfo">' + (pendingSoundFileName ? "Archivo actual: " + pendingSoundFileName : "Sin archivo todavía.") + '</p>';
      html += '<input type="file" id="itf_soundFile" accept="audio/*" style="display:none;">';
      html += '<button type="button" class="small" id="itf_soundTrigger">Subir sonido corto</button>';
      html += '<label class="field" style="margin-top:8px;"><span>Volumen</span><input type="range" id="itf_volume" min="0" max="1" step="0.05" value="' + (current.type === "sound" && current.volume !== undefined ? current.volume : 1) + '"></label>';
    } else if (type === "toggleVideo") {
      html += '<p class="sub">Al dispararse, alterna reproducir/pausar el vídeo de destino (como pulsar E encima, pero desde otra pieza o a distancia).</p>';
    } else if (type === "cameraPath") {
      html += '<p class="sub">Al dispararse, la cámara viaja por el camino del objeto de destino (duración, texto en pantalla y a qué mirar se configuran en las Propiedades de ese propio objeto "Recorrido de cámara") y, al terminar, te devuelve el control.</p>';
    } else if (type === "playClip") {
      if (!ref.clips || !ref.clips.length) {
        html += '<p class="sub">Este objeto no tiene animaciones (clips) importadas.</p>';
      } else {
        html += '<label class="field"><span>Animación</span><select id="itf_clip">' + ref.clips.map((c) => '<option value="' + c.name + '"' + (current.type === "playClip" && current.clipName === c.name ? " selected" : "") + '>' + c.name + " (" + c.duration.toFixed(1) + "s)</option>").join("") + '</select></label>';
      }
      html += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="itf_loop"' + (current.type === "playClip" && current.loop ? " checked" : "") + ' style="width:auto;"> <span style="margin:0;">En bucle mientras dure</span></label>';
      html += '<p class="sub">Reproduce esa animación una vez (o en bucle) al dispararse -- desde la E de otro objeto, un disparo a distancia, o en paralelo con otra acción.</p>';
    }
    if (type !== "sound" && type !== "toggleVideo" && type !== "setVariable" && type !== "fetchUrl" && type !== "copyToClipboard" && type !== "if" && type !== "for" && type !== "screenMessage" && type !== "askInput" && type !== "setImageVar" && type !== "setTextVar") {
      html += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="itf_dur" value="' + (current.duration || 1) + '"></label>';
    }
    fbox.innerHTML = html;
    if (type === "fetchUrl") {
      const respSel = wrap.querySelector('[id="itf_respMode"]');
      if (respSel) respSel.addEventListener("change", () => {
        const w = wrap.querySelector('[id="itf_varMapWrap"]');
        if (w) w.style.display = respSel.value === "variables" ? "block" : "none";
      });
    }
    if (type === "if") {
      wrap.querySelector('[id="itf_editThen"]').addEventListener("click", () => {
        openInteractTriggerForm(rec, () => pendingThen, (a) => { pendingThen = a; renderFields(); }, true);
      });
      const delThenBtn = wrap.querySelector('[id="itf_delThen"]');
      if (delThenBtn) delThenBtn.addEventListener("click", () => { pendingThen = null; renderFields(); });
      wrap.querySelector('[id="itf_editElse"]').addEventListener("click", () => {
        openInteractTriggerForm(rec, () => pendingElse, (a) => { pendingElse = a; renderFields(); }, true);
      });
      const delElseBtn = wrap.querySelector('[id="itf_delElse"]');
      if (delElseBtn) delElseBtn.addEventListener("click", () => { pendingElse = null; renderFields(); });
    }
    if (type === "for") {
      wrap.querySelector('[id="itf_editBody"]').addEventListener("click", () => {
        openInteractTriggerForm(rec, () => pendingBody, (a) => { pendingBody = a; renderFields(); }, true);
      });
      const delBodyBtn = wrap.querySelector('[id="itf_delBody"]');
      if (delBodyBtn) delBodyBtn.addEventListener("click", () => { pendingBody = null; renderFields(); });
    }
    if (type === "askInput") {
      const allowFileChk = wrap.querySelector('[id="itf_askAllowFile"]');
      if (allowFileChk) allowFileChk.addEventListener("change", () => {
        const w = wrap.querySelector('[id="itf_askFileVarWrap"]');
        if (w) w.style.display = allowFileChk.checked ? "block" : "none";
      });
    }
    if (type === "moveTo") {
      showTargetHighlight(ref.object3D);
      const updateMarker = () => {
        const x = parseFloat(wrap.querySelector('[id="itf_x"]').value) || 0;
        const y = parseFloat(wrap.querySelector('[id="itf_y"]').value) || 0;
        const z = parseFloat(wrap.querySelector('[id="itf_z"]').value) || 0;
        showDestMarker({ x, y, z });
      };
      updateMarker();
      ["x", "y", "z"].forEach((a) => { wrap.querySelector('[id="itf_' + a + '"]').addEventListener("input", updateMarker); });
      wrap.querySelector('[id="itf_useCurrent"]').addEventListener("click", () => {
        const r = refRecord();
        ["x", "y", "z"].forEach((a) => { wrap.querySelector('[id="itf_' + a + '"]').value = r.object3D.position[a].toFixed(2); });
        updateMarker();
      });
    } else {
      hideActionEditHelpers();
    }
    if (type === "sound") {
      wrap.querySelector('[id="itf_soundTrigger"]').addEventListener("click", () => wrap.querySelector('[id="itf_soundFile"]').click());
      wrap.querySelector('[id="itf_soundFile"]').addEventListener("change", (e) => {
        const f = e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
          pendingSoundBase64 = reader.result;
          pendingSoundFileName = f.name;
          const info = wrap.querySelector('[id="itf_soundInfo"]');
          if (info) info.textContent = "Archivo actual: " + f.name;
        };
        reader.readAsDataURL(f);
      });
    }
  }
  wrap.querySelector('[id="itf_type"]').addEventListener("change", renderFields);
  wrap.querySelector('[id="itf_target"]').addEventListener("change", () => {
    const typeSel = wrap.querySelector('[id="itf_type"]');
    const nuevoTarget = wrap.querySelector('[id="itf_target"]').value;
    typeSel.innerHTML = tipoOpcionesHtml(nuevoTarget, typeSel.value);
    renderFields();
  });
  renderFields();

  function refreshParallelList() {
    const box = wrap.querySelector('[id="itf_parallelList"]');
    if (!box) return;
    if (!pendingParallel.length) { box.innerHTML = '<p class="sub">Ninguna todavía.</p>'; return; }
    box.innerHTML = pendingParallel.map((pa, i) => '<div class="flexRow" style="align-items:center; gap:6px; margin-top:4px;"><span class="sub" style="flex:1;">' + describeInteractAction(pa) + describeParallelSuffix(pa) + '</span><button type="button" class="small" data-pe="' + i + '">✏️</button><button type="button" class="small danger" data-pd="' + i + '">✕</button></div>').join("");
    box.querySelectorAll("button[data-pe]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.pe, 10);
        openInteractTriggerForm(rec, () => pendingParallel[i], (a) => { pendingParallel[i] = a; refreshParallelList(); }, true);
      });
    });
    box.querySelectorAll("button[data-pd]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.pd, 10);
        pendingParallel.splice(i, 1);
        refreshParallelList();
      });
    });
  }
  refreshParallelList();
  wrap.querySelector('[id="itf_addParallel"]').addEventListener("click", () => {
    openInteractTriggerForm(rec, () => null, (a) => { pendingParallel.push(a); refreshParallelList(); }, true);
  });

  wrap.querySelector('[id="itf_cancel"]').addEventListener("click", () => { hideActionEditHelpers(); wrap.remove(); });
  const removeBtn = wrap.querySelector('[id="itf_remove"]');
  if (removeBtn) removeBtn.addEventListener("click", () => { hideActionEditHelpers(); setAction(null); wrap.remove(); if (!isNested) renderProps(); });
  wrap.querySelector('[id="itf_confirm"]').addEventListener("click", () => {
    const type = wrap.querySelector('[id="itf_type"]').value;
    const target = wrap.querySelector('[id="itf_target"]').value;
    if (type === "sound" && !pendingSoundBase64) { alertBox("Sube un archivo de sonido antes de guardar.", "info"); return; }
    if (type === "setVariable" && !(wrap.querySelector('[id="itf_varName"]').value || "").trim()) { alertBox("Escribe un nombre para la variable antes de guardar.", "info"); return; }
    if (type === "fetchUrl" && !(wrap.querySelector('[id="itf_url"]').value || "").trim()) { alertBox("Escribe una URL antes de guardar.", "info"); return; }
    if (type === "copyToClipboard" && !(wrap.querySelector('[id="itf_clipText"]').value || "").trim()) { alertBox("Escribe el texto a copiar antes de guardar.", "info"); return; }
    if (type === "if" && !(wrap.querySelector('[id="itf_expr"]').value || "").trim()) { alertBox("Escribe una condición antes de guardar.", "info"); return; }
    if (type === "screenMessage" && !(wrap.querySelector('[id="itf_msgText"]').value || "").trim()) { alertBox("Escribe el texto del mensaje antes de guardar.", "info"); return; }
    if (type === "askInput" && !(wrap.querySelector('[id="itf_askVar"]').value || "").trim()) { alertBox("Escribe un nombre de variable donde guardar la respuesta.", "info"); return; }
    if (type === "setImageVar" && !(wrap.querySelector('[id="itf_imgVar"]').value || "").trim()) { alertBox("Escribe un nombre de variable con la imagen antes de guardar.", "info"); return; }
    if (type === "setImageVar" && !(wrap.querySelector('[id="itf_imgTarget"]').value || "")) { alertBox("Elige un objeto de Imagen destino antes de guardar (crea uno primero si no tienes ninguno en la escena).", "info"); return; }
    if (type === "setTextVar" && !(wrap.querySelector('[id="itf_txtVar"]').value || "").trim()) { alertBox("Escribe un nombre de variable con el texto antes de guardar.", "info"); return; }
    if (type === "setTextVar" && !(wrap.querySelector('[id="itf_txtTarget"]').value || "")) { alertBox("Elige un objeto de Texto 3D destino antes de guardar (crea uno primero si no tienes ninguno en la escena).", "info"); return; }
    const action = { type, target };
    if (type === "moveTo" || type === "rotateTo") {
      const absVals = { x: parseFloat(wrap.querySelector('[id="itf_x"]').value) || 0, y: parseFloat(wrap.querySelector('[id="itf_y"]').value) || 0, z: parseFloat(wrap.querySelector('[id="itf_z"]').value) || 0 };
      const relCheckbox = wrap.querySelector('[id="itf_relative"]');
      if (relCheckbox && relCheckbox.checked) {
        const ref = refRecord();
        if (type === "moveTo") {
          const originPos = ref.object3D.userData.__origin ? ref.object3D.userData.__origin.pos : ref.object3D.position;
          action.to = { x: absVals.x - originPos.x, y: absVals.y - originPos.y, z: absVals.z - originPos.z };
        } else {
          const originQuat = ref.object3D.userData.__origin ? ref.object3D.userData.__origin.quat : ref.object3D.quaternion;
          const oe = new THREE.Euler().setFromQuaternion(originQuat);
          action.to = { x: absVals.x - rad2deg(oe.x), y: absVals.y - rad2deg(oe.y), z: absVals.z - rad2deg(oe.z) };
        }
        action.relative = true;
      } else {
        action.to = absVals;
      }
    } else if (type === "fade") {
      action.to = parseInt(wrap.querySelector('[id="itf_to"]').value, 10);
    } else if (type === "flash") {
      action.color = wrap.querySelector('[id="itf_color"]').value;
      action.repeat = Math.max(1, parseInt(wrap.querySelector('[id="itf_repeat"]').value, 10) || 3);
    } else if (type === "spin") {
      action.axis = wrap.querySelector('[id="itf_axis"]').value;
      action.speed = parseFloat(wrap.querySelector('[id="itf_speed"]').value) || 0;
    } else if (type === "sound") {
      action.soundBase64 = pendingSoundBase64;
      action.soundFileName = pendingSoundFileName;
      action.volume = parseFloat(wrap.querySelector('[id="itf_volume"]').value);
      if (isNaN(action.volume)) action.volume = 1;
    } else if (type === "playClip") {
      const clipSel = wrap.querySelector('[id="itf_clip"]');
      action.clipName = clipSel ? clipSel.value : null;
      const loopChk = wrap.querySelector('[id="itf_loop"]');
      action.loop = loopChk ? loopChk.checked : false;
    } else if (type === "setVariable") {
      action.varName = (wrap.querySelector('[id="itf_varName"]').value || "").trim();
      action.expr = wrap.querySelector('[id="itf_expr"]').value || "0";
      delete action.target; // no aplica a ningún objeto -- ver el toggle de itf_targetWrap arriba
    } else if (type === "fetchUrl") {
      action.url = (wrap.querySelector('[id="itf_url"]').value || "").trim();
      action.method = wrap.querySelector('[id="itf_method"]').value === "POST" ? "POST" : "GET";
      action.responseMode = wrap.querySelector('[id="itf_respMode"]').value || "none";
      action.varMap = wrap.querySelector('[id="itf_varMap"]') ? wrap.querySelector('[id="itf_varMap"]').value : "";
    } else if (type === "copyToClipboard") {
      action.text = wrap.querySelector('[id="itf_clipText"]').value || "";
      delete action.target;
    } else if (type === "if") {
      action.expr = wrap.querySelector('[id="itf_expr"]').value || "0";
      action.then = pendingThen;
      action.else = pendingElse;
      delete action.target;
    } else if (type === "for") {
      action.count = (wrap.querySelector('[id="itf_forCount"]').value || "5").trim();
      action.varName = (wrap.querySelector('[id="itf_forVar"]').value || "").trim();
      action.body = pendingBody;
      delete action.target;
    } else if (type === "screenMessage") {
      action.text = wrap.querySelector('[id="itf_msgText"]').value || "";
      action.autoDismissSec = parseFloat(wrap.querySelector('[id="itf_msgAutoDismiss"]').value) || 0;
      delete action.target;
    } else if (type === "askInput") {
      action.promptText = wrap.querySelector('[id="itf_askPrompt"]').value || "";
      action.varName = (wrap.querySelector('[id="itf_askVar"]').value || "").trim();
      action.allowFile = wrap.querySelector('[id="itf_askAllowFile"]').checked;
      action.fileVarName = (wrap.querySelector('[id="itf_askFileVar"]').value || "").trim();
      delete action.target;
    } else if (type === "setImageVar") {
      action.varName = (wrap.querySelector('[id="itf_imgVar"]').value || "").trim();
      action.target = wrap.querySelector('[id="itf_imgTarget"]').value || null;
    } else if (type === "setTextVar") {
      action.varName = (wrap.querySelector('[id="itf_txtVar"]').value || "").trim();
      action.target = wrap.querySelector('[id="itf_txtTarget"]').value || null;
    }
    if (type !== "sound" && type !== "toggleVideo" && type !== "setVariable" && type !== "fetchUrl" && type !== "copyToClipboard" && type !== "if" && type !== "for" && type !== "screenMessage" && type !== "askInput" && type !== "setImageVar" && type !== "setTextVar") {
      action.duration = Math.max(0.05, parseFloat(wrap.querySelector('[id="itf_dur"]').value) || 1);
    }
    action.parallel = pendingParallel;
    // Preserva el encadenado "al terminar" (action.next) que ya tuviera esta acción: este formulario
    // edita el TIPO y sus campos propios (URL, destino, ángulo...), y hasta ahora reconstruía el
    // objeto de acción desde cero sin volver a copiar el .next existente -- así que con solo tocar
    // un campo cualquiera (p. ej. cambiar https por http en una URL) se perdía en silencio la acción
    // encadenada después de ella (el 🔗 "al terminar" se edita en un formulario aparte, pero su
    // resultado vive en esta MISMA propiedad .next del objeto, y aquí se estaba pisando con nada).
    action.next = current.next || null;
    setAction(action);
    hideActionEditHelpers();
    wrap.remove();
    // OJO: si este formulario es "anidado" (se abrió desde dentro de OTRO formulario de
    // acción que aún está abierto sin guardar -- p. ej. "+ Añadir acción en paralelo" o
    // editar una de las ya añadidas), NO llamamos a renderProps() aquí: esa función
    // reconstruye TODO el panel de propiedades desde cero (panel.innerHTML = ...), lo que
    // destruiría el formulario EXTERIOR todavía abierto (con sus propios cambios sin
    // guardar) antes de que el usuario pulsara su "Guardar". Antes de este arreglo, eso
    // hacía que una acción en paralelo recién añadida (p. ej. mover al personaje sobre el
    // coche) pareciera "no guardarse": el setAction() de arriba SÍ la añadía a la lista
    // pendiente del formulario exterior, pero ese formulario desaparecía del todo antes de
    // que su propio Guardar pudiera persistirla en el objeto real.
    if (!isNested) renderProps();
  });
}

function renderChoicesList(rec) {
  const box = document.getElementById("choicesList");
  if (!box) return;
  if (!rec.interactive.choices) rec.interactive.choices = [];
  if (!rec.interactive.choices.length) { box.innerHTML = '<p class="sub">Sin opciones todavía.</p>'; }
  else {
    box.innerHTML = rec.interactive.choices.map((c, i) => {
      return '<div class="actionRow"><div class="hdr"><b>Opción ' + (i + 1) + '</b><div class="btns"><button class="small" data-cai="' + i + '">🎬</button>' +
        (c.action ? '<button class="small" data-cci="' + i + '">🔗</button>' : '') +
        '<button class="small danger" data-ci="' + i + '">✕</button></div></div>' +
        '<div class="row2"><input type="text" data-cf="label" data-ci="' + i + '" placeholder="Texto de la opción" value="' + (c.label || "").replace(/"/g, "&quot;") + '">' +
        '<input type="number" step="1" data-cf="points" data-ci="' + i + '" placeholder="Puntos" value="' + (c.points || 0) + '"></div>' +
        (c.action ? '<p class="sub" style="margin-top:4px;">🎬 ' + describeInteractAction(c.action) + describeParallelSuffix(c.action) + '</p>' : '') +
        (c.action && c.action.next ? '<p class="sub" style="margin-top:2px;">🔗 ' + describeInteractAction(c.action.next) + '</p>' : '') +
        '</div>';
    }).join("");
    box.querySelectorAll("button[data-ci]").forEach((btn) => {
      btn.addEventListener("click", () => {
        rec.interactive.choices.splice(parseInt(btn.dataset.ci, 10), 1);
        renderProps();
      });
    });
    box.querySelectorAll("button[data-cai]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.cai, 10);
        openInteractTriggerForm(rec, () => rec.interactive.choices[i].action || null, (a) => { rec.interactive.choices[i].action = a; });
      });
    });
    box.querySelectorAll("button[data-cci]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.cci, 10);
        const parent = rec.interactive.choices[i].action;
        if (!parent) return;
        openInteractTriggerForm(rec, () => parent.next || null, (a) => { parent.next = a; });
      });
    });
    box.querySelectorAll("input[data-cf]").forEach((inp) => {
      inp.addEventListener("input", () => {
        const i = parseInt(inp.dataset.ci, 10);
        if (inp.dataset.cf === "label") rec.interactive.choices[i].label = inp.value;
        if (inp.dataset.cf === "points") rec.interactive.choices[i].points = parseInt(inp.value, 10) || 0;
      });
    });
  }
  const addBtn = document.getElementById("btnAddChoice");
  if (addBtn) addBtn.disabled = rec.interactive.choices.length >= 4;
}

function renderActionsList(rec) {
  const box = document.getElementById("actionsList");
  if (!box) return;
  if (!rec.actions.length) { box.innerHTML = '<p class="sub">Sin acciones. Este objeto permanecerá estático durante la reproducción.</p>'; return; }
  box.innerHTML = rec.actions.map((a, i) => {
    let desc = "";
    if (a.type === "moveTo") desc = (a.relative ? "Mover (relativo) " : "Mover a ") + "(" + a.to.x.toFixed(1) + ", " + a.to.y.toFixed(1) + ", " + a.to.z.toFixed(1) + ") en " + a.duration + "s";
    else if (a.type === "rotateTo") desc = (a.relative ? "Rotar (relativo) " : "Rotar a ") + "(" + a.to.x + "°, " + a.to.y + "°, " + a.to.z + "°) en " + a.duration + "s";
    else if (a.type === "wait") desc = "Esperar " + a.duration + "s";
    else if (a.type === "fade") desc = (a.to === 1 ? "Aparecer" : "Desaparecer") + " en " + a.duration + "s";
    else if (a.type === "flash") desc = "Destello " + a.color + " ×" + a.repeat + " en " + a.duration + "s";
    else if (a.type === "playClip") desc = "Animación \"" + a.clipName + "\" (" + a.duration.toFixed(1) + "s" + (a.loop ? ", en bucle" : "") + ")";
    else if (a.type === "setVariable" || a.type === "fetchUrl" || a.type === "copyToClipboard" || a.type === "if" || a.type === "for" || a.type === "screenMessage" || a.type === "askInput" || a.type === "setImageVar" || a.type === "setTextVar") desc = describeInteractAction(a);
    // Cada acción principal puede llevar sus propias acciones "en paralelo" colgando directamente
    // de ELLA (a.parallel), no solo de la que se dispara "al terminar" (a.next.parallel). Antes esto
    // se guardaba y ejecutaba bien, pero no se mostraba en ningún sitio del panel -- si tenía más de
    // una, solo se veía/editaba la primera indirectamente y el resto quedaba invisible, sin forma de
    // reabrirlas para editarlas (había que reconstruirlas desde cero). Ahora se listan todas, cada
    // una con su propio editar/quitar, igual que las del bloque "al terminar".
    const parallelItems = (a.parallel || []).map((pa, j) =>
      '<div class="flexRow" style="align-items:center; gap:6px; margin-top:3px;"><span class="sub" style="flex:1;">⚡ ' + describeInteractAction(pa) + describeParallelSuffix(pa) + '</span>' +
      '<button class="small" data-pe="' + i + '_' + j + '">✏️</button>' +
      '<button class="small danger" data-pd="' + i + '_' + j + '">✕</button></div>'
    ).join("");
    return '<div class="actionRow"><div class="hdr"><b>' + (i + 1) + ". " + a.type + '</b><div class="btns">' +
      (i > 0 ? '<button class="small" data-act="up" data-i="' + i + '">↑</button>' : "") +
      (i < rec.actions.length - 1 ? '<button class="small" data-act="down" data-i="' + i + '">↓</button>' : "") +
      '<button class="small" data-chain="' + i + '">🔗</button>' +
      '<button class="small danger" data-act="del" data-i="' + i + '">✕</button>' +
      "</div></div>" + desc +
      (parallelItems ? '<div style="margin-top:4px;">' + parallelItems + '</div>' : "") +
      '<button class="small" data-addp="' + i + '" style="margin-top:4px;">⚡ + Añadir en paralelo a esta</button>' +
      (a.next ? '<p class="sub" style="margin-top:4px;">🔗 al terminar: ' + describeInteractAction(a.next) + describeParallelSuffix(a.next) + '</p>' : "") +
      "</div>";
  }).join("");
  box.querySelectorAll("button[data-act]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = parseInt(btn.dataset.i, 10);
      if (btn.dataset.act === "del") rec.actions.splice(i, 1);
      if (btn.dataset.act === "up") [rec.actions[i - 1], rec.actions[i]] = [rec.actions[i], rec.actions[i - 1]];
      if (btn.dataset.act === "down") [rec.actions[i + 1], rec.actions[i]] = [rec.actions[i], rec.actions[i + 1]];
      recomputeCheckpoints(rec); recomputeTimelineDuration();
      renderHierarchy(); renderProps();
    });
  });
  box.querySelectorAll("button[data-chain]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = parseInt(btn.dataset.chain, 10);
      openInteractTriggerForm(rec, () => rec.actions[i].next || null, (a) => {
        rec.actions[i].next = a;
        recomputeTimelineDuration();
      });
    });
  });
  box.querySelectorAll("button[data-addp]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = parseInt(btn.dataset.addp, 10);
      openInteractTriggerForm(rec, () => null, (a) => {
        if (!rec.actions[i].parallel) rec.actions[i].parallel = [];
        rec.actions[i].parallel.push(a);
        renderProps();
      });
    });
  });
  box.querySelectorAll("button[data-pe]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const [i, j] = btn.dataset.pe.split("_").map((n) => parseInt(n, 10));
      openInteractTriggerForm(rec, () => rec.actions[i].parallel[j], (a) => {
        rec.actions[i].parallel[j] = a;
        renderProps();
      });
    });
  });
  box.querySelectorAll("button[data-pd]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const [i, j] = btn.dataset.pd.split("_").map((n) => parseInt(n, 10));
      rec.actions[i].parallel.splice(j, 1);
      renderProps();
    });
  });
}

function wirePropsEvents(rec) {
  document.getElementById("propName").addEventListener("input", (e) => { rec.name = e.target.value; renderHierarchy(); });

  const btnLeaveGroup = document.getElementById("btnLeaveGroup");
  if (btnLeaveGroup) btnLeaveGroup.addEventListener("click", () => removeFromGroup(rec.id));

  const syncOrigin = () => {
    rec.object3D.userData.__origin = { pos: rec.object3D.position.clone(), quat: rec.object3D.quaternion.clone() };
    recomputeCheckpoints(rec);
  };
  ["x", "y", "z"].forEach((a) => {
    document.getElementById("prop_p" + a).addEventListener("input", (e) => { rec.object3D.position[a] = parseFloat(e.target.value) || 0; syncOrigin(); });
    document.getElementById("prop_r" + a).addEventListener("input", (e) => { rec.object3D.rotation[a] = deg2rad(parseFloat(e.target.value) || 0); syncOrigin(); });
    document.getElementById("prop_s" + a).addEventListener("input", (e) => { rec.object3D.scale[a] = Math.max(0.02, parseFloat(e.target.value) || 1); });
  });

  const cpDurationInput = document.getElementById("cpDuration");
  if (cpDurationInput) cpDurationInput.addEventListener("input", (e) => {
    rec.cameraPathData.duration = Math.max(0.5, parseFloat(e.target.value) || 6);
  });
  const cpCaptionInput = document.getElementById("cpCaption");
  if (cpCaptionInput) cpCaptionInput.addEventListener("input", (e) => { rec.cameraPathData.caption = e.target.value; });
  const cpLookAtInput = document.getElementById("cpLookAt");
  if (cpLookAtInput) cpLookAtInput.addEventListener("change", (e) => { rec.cameraPathData.lookAtTargetId = e.target.value || null; });
  const cpAutoplayInput = document.getElementById("cpAutoplay");
  if (cpAutoplayInput) cpAutoplayInput.addEventListener("change", (e) => { rec.cameraPathData.autoplay = e.target.checked; });

  const weatherTypeInput = document.getElementById("weatherType");
  if (weatherTypeInput) weatherTypeInput.addEventListener("change", (e) => {
    setWeatherType(rec, e.target.value);
    renderHierarchy();
  });

  const lightColorInput = document.getElementById("lightColor");
  if (lightColorInput) lightColorInput.addEventListener("input", (e) => {
    rec.lightData.color = e.target.value;
    if (rec.__lightObj) rec.__lightObj.color.set(e.target.value);
    if (rec.__gizmoMat) rec.__gizmoMat.color.set(e.target.value);
  });
  const lightIntensityInput = document.getElementById("lightIntensity");
  if (lightIntensityInput) lightIntensityInput.addEventListener("input", (e) => {
    const v = Math.max(0, parseFloat(e.target.value) || 0);
    rec.lightData.intensity = v;
    if (rec.__lightObj) rec.__lightObj.intensity = v;
  });
  const lightDistanceInput = document.getElementById("lightDistance");
  if (lightDistanceInput) lightDistanceInput.addEventListener("input", (e) => {
    const v = Math.max(0, parseFloat(e.target.value) || 0);
    rec.lightData.distance = v;
    if (rec.__lightObj) rec.__lightObj.distance = v;
  });
  const lightCastShadowInput = document.getElementById("lightCastShadow");
  if (lightCastShadowInput) lightCastShadowInput.addEventListener("change", (e) => {
    rec.lightData.castShadow = e.target.checked;
    if (rec.__lightObj) {
      rec.__lightObj.castShadow = e.target.checked;
      if (e.target.checked) rec.__lightObj.shadow.mapSize.set(512, 512);
    }
  });

  const colorInput = document.getElementById("propColor");
  if (colorInput) colorInput.addEventListener("input", (e) => { rec.colorMaterials.forEach((m) => m.color.set(e.target.value)); });

  const opacityInput = document.getElementById("propOpacity");
  if (opacityInput) opacityInput.addEventListener("input", (e) => {
    const v = parseFloat(e.target.value);
    rec.opacity = v;
    rec.colorMaterials.forEach((m) => { m.opacity = v; m.visible = v > 0.01; });
    const lbl = document.getElementById("propOpacityVal");
    if (lbl) lbl.textContent = Math.round(v * 100) + "%";
    recomputeCheckpoints(rec);
  });

  const textureTrigger = document.getElementById("propTextureTrigger");
  if (textureTrigger) textureTrigger.addEventListener("click", () => document.getElementById("propTextureInput").click());
  const textureInput = document.getElementById("propTextureInput");
  if (textureInput) textureInput.addEventListener("change", (e) => {
    const f = e.target.files[0];
    e.target.value = "";
    if (!f) return;
    redimensionarImagenParaTextura(f, (err, dataUrl) => {
      if (err) { alertBox("No se pudo usar esa imagen como textura.", "warn"); return; }
      pushUndo();
      aplicarTexturaAPieza(rec, dataUrl);
      renderProps();
    });
  });
  const textureQuitar = document.getElementById("propTextureQuitar");
  if (textureQuitar) textureQuitar.addEventListener("click", () => {
    pushUndo();
    aplicarTexturaAPieza(rec, null);
    renderProps();
  });
  const texRepX = document.getElementById("propTexRepX");
  if (texRepX) texRepX.addEventListener("input", (e) => {
    rec.textureRepeatX = parseFloat(e.target.value) || 1;
    rec.colorMaterials.forEach((m) => { if (m.map) { m.map.repeat.x = rec.textureRepeatX; m.map.needsUpdate = true; } });
  });
  const texRepY = document.getElementById("propTexRepY");
  if (texRepY) texRepY.addEventListener("input", (e) => {
    rec.textureRepeatY = parseFloat(e.target.value) || 1;
    rec.colorMaterials.forEach((m) => { if (m.map) { m.map.repeat.y = rec.textureRepeatY; m.map.needsUpdate = true; } });
  });

  const t3Content = document.getElementById("text3dContent");
  if (t3Content) t3Content.addEventListener("input", (e) => { rec.text3d.text = e.target.value; rebuildText3D(rec); });
  const t3Color = document.getElementById("text3dColor");
  if (t3Color) t3Color.addEventListener("input", (e) => { rec.text3d.color = e.target.value; rebuildText3D(rec); });
  const t3Size = document.getElementById("text3dSize");
  if (t3Size) t3Size.addEventListener("input", (e) => { rec.text3d.size = Math.max(0.2, parseFloat(e.target.value) || 1); rebuildText3D(rec); });
  const t3BoxWidth = document.getElementById("text3dBoxWidth");
  if (t3BoxWidth) t3BoxWidth.addEventListener("input", (e) => { rec.text3d.boxWidth = Math.max(60, parseFloat(e.target.value) || 472); rebuildText3D(rec); });
  const btnReplaceImage = document.getElementById("btnReplaceImage");
  if (btnReplaceImage) btnReplaceImage.addEventListener("click", () => document.getElementById("imageReplaceInput").click());
  const imageReplaceInput = document.getElementById("imageReplaceInput");
  if (imageReplaceInput) imageReplaceInput.addEventListener("change", (e) => { if (e.target.files[0]) replaceImageForRecord(rec, e.target.files[0]); e.target.value = ""; });
  const btnReplaceVideo = document.getElementById("btnReplaceVideo");
  if (btnReplaceVideo) btnReplaceVideo.addEventListener("click", () => document.getElementById("videoReplaceInput").click());
  const videoReplaceInput = document.getElementById("videoReplaceInput");
  if (videoReplaceInput) videoReplaceInput.addEventListener("change", (e) => { if (e.target.files[0]) replaceVideoForRecord(rec, e.target.files[0]); e.target.value = ""; });

  const btnEditNodes = document.getElementById("btnEditNodes");
  if (btnEditNodes) btnEditNodes.addEventListener("click", () => {
    if (nodeEditRec === rec) exitNodeEditMode(); else enterNodeEditMode(rec);
  });
  const extrudeDepth = document.getElementById("extrudeDepth");
  if (extrudeDepth) extrudeDepth.addEventListener("input", (e) => {
    rec.extrudeData.depth = Math.max(0.02, parseFloat(e.target.value) || 0.3);
    rebuildExtrudeGeometry(rec);
    if (nodeEditRec === rec) rebuildNodeEditVisuals();
  });
  const extrudeBevel = document.getElementById("extrudeBevel");
  if (extrudeBevel) extrudeBevel.addEventListener("change", (e) => {
    rec.extrudeData.bevelEnabled = e.target.checked;
    rebuildExtrudeGeometry(rec);
    renderProps();
  });
  const extrudeBevelSize = document.getElementById("extrudeBevelSize");
  if (extrudeBevelSize) extrudeBevelSize.addEventListener("input", (e) => {
    rec.extrudeData.bevelSize = Math.max(0.005, parseFloat(e.target.value) || 0.05);
    rebuildExtrudeGeometry(rec);
  });
  const btnAddPath = document.getElementById("btnAddPath");
  if (btnAddPath) btnAddPath.addEventListener("click", () => {
    pushUndo();
    rec.extrudeData.path = { nodes: [{ x: -0.6, y: 0, z: 0 }, { x: 0.6, y: 0, z: 0 }], closed: false };
    rebuildExtrudeGeometry(rec);
    enterPathEditMode(rec);
  });
  const btnEditPath = document.getElementById("btnEditPath");
  if (btnEditPath) btnEditPath.addEventListener("click", () => {
    if (pathEditRec === rec) exitPathEditMode(); else enterPathEditMode(rec);
  });
  const pathClosed = document.getElementById("pathClosed");
  if (pathClosed) pathClosed.addEventListener("change", (e) => {
    pathOwnerPath(rec).closed = e.target.checked;
    pathOwnerRebuild(rec);
    if (pathEditRec === rec) rebuildPathEditVisuals();
  });
  const pathNodeY = document.getElementById("pathNodeY");
  if (pathNodeY) pathNodeY.addEventListener("input", (e) => {
    if (pathEditRec === rec && pathEditSelIndex >= 0 && pathOwnerPath(rec).nodes[pathEditSelIndex]) {
      pathOwnerPath(rec).nodes[pathEditSelIndex].y = parseFloat(e.target.value) || 0;
      pathOwnerRebuild(rec);
      rebuildPathEditVisuals();
    }
  });
  const btnRemovePath = document.getElementById("btnRemovePath");
  if (btnRemovePath) btnRemovePath.addEventListener("click", () => {
    pushUndo();
    if (pathEditRec === rec) exitPathEditMode();
    rec.extrudeData.path = null;
    rebuildExtrudeGeometry(rec);
    renderProps();
  });

  document.getElementById("colliderKind").addEventListener("change", (e) => {
    rec.collider.kind = e.target.value;
    renderProps(); renderHierarchy();
  });
  ["x", "y", "z"].forEach((a) => {
    const el = document.getElementById("collSize_" + a);
    if (el) el.addEventListener("input", (e) => { rec.collider.size[a] = Math.max(0.05, parseFloat(e.target.value) || 0.1); });
  });
  const riskEl = document.getElementById("riskLabel");
  if (riskEl) riskEl.addEventListener("input", (e) => { rec.collider.riskLabel = e.target.value; });
  const facingEl = document.getElementById("facingOffsetDeg");
  if (facingEl) facingEl.addEventListener("input", (e) => { rec.facingOffsetDeg = parseFloat(e.target.value) || 0; });

  const intEnabled = document.getElementById("interactiveEnabled");
  if (intEnabled) intEnabled.addEventListener("change", (e) => { rec.interactive.enabled = e.target.checked; renderProps(); renderHierarchy(); });
  const intPrompt = document.getElementById("interactivePrompt");
  if (intPrompt) intPrompt.addEventListener("input", (e) => { rec.interactive.prompt = e.target.value; });
  const intRadius = document.getElementById("interactiveRadius");
  if (intRadius) intRadius.addEventListener("input", (e) => { rec.interactive.radius = Math.max(0.3, parseFloat(e.target.value) || 2); });
  const intKind = document.getElementById("interactiveKind");
  if (intKind) intKind.addEventListener("change", (e) => { rec.interactive.kind = e.target.value; renderProps(); });
  const intText = document.getElementById("interactiveText");
  if (intText) intText.addEventListener("input", (e) => { rec.interactive.text = e.target.value; });
  const intQuestion = document.getElementById("interactiveQuestion");
  if (intQuestion) intQuestion.addEventListener("input", (e) => { rec.interactive.text = e.target.value; });
  const intUrl = document.getElementById("interactiveUrl");
  if (intUrl) intUrl.addEventListener("input", (e) => { rec.interactive.url = e.target.value; });
  const btnOnReadAction = document.getElementById("btnOnReadAction");
  if (btnOnReadAction) btnOnReadAction.addEventListener("click", () => {
    openInteractTriggerForm(rec, () => rec.interactive.onInteractAction || null, (a) => { rec.interactive.onInteractAction = a; });
  });
  const btnOnShotAction = document.getElementById("btnOnShotAction");
  if (btnOnShotAction) btnOnShotAction.addEventListener("click", () => {
    openInteractTriggerForm(rec, () => rec.interactive.onShotAction || null, (a) => { rec.interactive.onShotAction = a; });
  });
  const btnRemoveShotAction = document.getElementById("btnRemoveShotAction");
  if (btnRemoveShotAction) btnRemoveShotAction.addEventListener("click", () => { rec.interactive.onShotAction = null; renderProps(); });
  const btnChainReadAction = document.getElementById("btnChainReadAction");
  if (btnChainReadAction) btnChainReadAction.addEventListener("click", () => {
    const parent = rec.interactive.onInteractAction;
    if (!parent) return;
    openInteractTriggerForm(rec, () => parent.next || null, (a) => { parent.next = a; });
  });
  const btnAddChoice = document.getElementById("btnAddChoice");
  if (btnAddChoice) btnAddChoice.addEventListener("click", () => {
    if (rec.interactive.choices.length >= 4) return;
    rec.interactive.choices.push({ label: "Nueva opción", points: 0, action: null });
    renderProps();
  });

  document.getElementById("btnAddAction").addEventListener("click", () => {
    const type = document.getElementById("newActionType").value;
    openActionForm(rec, type);
  });
}

function openActionForm(rec, type) {
  const panel = document.getElementById("propsPanel");
  const wrap = document.createElement("div");
  wrap.className = "card";
  let inner = '<b>Nueva acción: ' + type + '</b><br><br>';
  if (type === "moveTo") {
    inner += '<p class="sub">🎯 Moviendo: <b>' + rec.name.replace(/</g, "&lt;") + '</b> (marcado en el visor)</p>';
    inner += '<div class="row3">' + ["x", "y", "z"].map((a) => '<input type="number" step="0.1" id="af_' + a + '" value="' + rec.object3D.position[a].toFixed(2) + '">').join("") + "</div>";
    inner += '<button class="small" id="af_useCurrent" style="margin-top:6px;">usar posición actual del objeto</button>';
    inner += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="af_relative" style="width:auto;"> <span style="margin:0;">Relativo a su posición de partida (recomendado si vas a duplicar este objeto -- así cada copia sube/se mueve desde SU sitio, no al punto absoluto del original)</span></label>';
    inner += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="1.5"></label>';
    inner += '<label class="field"><span>Suavizado</span><select id="af_ease"><option value="smooth">suave</option><option value="linear">lineal</option></select></label>';
  } else if (type === "rotateTo") {
    inner += '<div class="row3">' + ["x", "y", "z"].map((a) => '<input type="number" step="1" id="af_' + a + '" value="' + rad2deg(rec.object3D.rotation[a]).toFixed(0) + '">').join("") + "</div>";
    inner += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="af_relative" style="width:auto;"> <span style="margin:0;">Relativo a su rotación de partida (recomendado si vas a duplicar este objeto)</span></label>';
    inner += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="1"></label>';
  } else if (type === "wait") {
    inner += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="1"></label>';
  } else if (type === "fade") {
    inner += '<label class="field"><span>Objetivo</span><select id="af_to"><option value="0">Desaparecer</option><option value="1">Aparecer</option></select></label>';
    inner += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="1"></label>';
  } else if (type === "flash") {
    inner += '<label class="field"><span>Color</span><input type="color" id="af_color" value="#ff3b3b"></label>';
    inner += '<label class="field"><span>Repeticiones</span><input type="number" step="1" min="1" id="af_repeat" value="3"></label>';
    inner += '<label class="field"><span>Duración (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="1.5"></label>';
  } else if (type === "playClip") {
    inner += '<label class="field"><span>Clip</span><select id="af_clip">' + rec.clips.map((c) => '<option value="' + c.name + '">' + c.name + " (" + c.duration.toFixed(1) + "s)</option>").join("") + "</select></label>";
    inner += '<label class="field"><span>Duración a usar (s)</span><input type="number" step="0.1" min="0.1" id="af_dur" value="' + (rec.clips[0] ? rec.clips[0].duration.toFixed(1) : "1") + '"></label>';
    inner += '<label class="field" style="display:flex; align-items:center; gap:6px;"><input type="checkbox" id="af_loop" style="width:auto;"> <span style="margin:0;">en bucle mientras dure</span></label>';
  } else if (type === "setVariable") {
    inner += '<label class="field"><span>Nombre de la variable</span><input type="text" id="af_varName" placeholder="monedas"></label>';
    inner += '<label class="field"><span>Nuevo valor (expresión)</span><input type="text" id="af_expr" placeholder="monedas + 1"></label>';
    inner += '<p class="sub">Instantánea: se dispara en cuanto llega su turno en la secuencia, sin duración propia.</p>';
  } else if (type === "fetchUrl") {
    inner += '<label class="field"><span>URL</span><input type="text" id="af_url" placeholder="https://tuweb.com/records.php?monedas={{monedas}}"></label>';
    inner += '<label class="field"><span>Método</span><select id="af_method"><option value="GET" selected>GET (parámetros en la URL)</option><option value="POST">POST</option></select></label>';
    inner += '<label class="field"><span>Qué hacer con la respuesta</span><select id="af_respMode">' +
      '<option value="none" selected>Nada</option>' +
      '<option value="label">Poner el texto en un rótulo (Texto 3D)</option>' +
      '<option value="imagen">Poner como imagen (objeto de Imagen)</option>' +
      '<option value="variables">Guardar en variables (JSON)</option>' +
    '</select></label>';
    // "responseMode: label" necesita saber EN QUÉ objeto de Texto 3D poner la respuesta -- sin esto
    // se aplicaba en silencio a "este objeto" (rec), y si rec no era un Texto 3D no pasaba nada
    // visible, sin ningún aviso de por qué. Se listan solo los objetos de Texto 3D de la escena.
    const text3dOptsAF = [];
    if (rec.kind === "text3d") text3dOptsAF.push(['self', 'Este objeto (' + rec.name + ')']);
    sceneOrder.forEach((oid) => {
      if (oid === rec.id) return;
      const o = sceneObjects.get(oid);
      if (o && o.kind === "text3d") text3dOptsAF.push([oid, o.name]);
    });
    inner += '<div id="af_labelTargetWrap" style="display:none;"><label class="field"><span>Rótulo destino</span><select id="af_labelTarget">' +
      (text3dOptsAF.length ? text3dOptsAF.map((o) => '<option value="' + o[0] + '">' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Texto 3D en la escena)</option>') +
      '</select></label></div>';
    // Mismo motivo que arriba, pero para "Poner como imagen": lista solo objetos de Imagen.
    const imageOptsAF = [];
    if (rec.kind === "image") imageOptsAF.push(['self', 'Este objeto (' + rec.name + ')']);
    sceneOrder.forEach((oid) => {
      if (oid === rec.id) return;
      const o = sceneObjects.get(oid);
      if (o && o.kind === "image") imageOptsAF.push([oid, o.name]);
    });
    inner += '<div id="af_imageTargetWrap" style="display:none;"><label class="field"><span>Imagen destino</span><select id="af_imageTarget">' +
      (imageOptsAF.length ? imageOptsAF.map((o) => '<option value="' + o[0] + '">' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Imagen en la escena)</option>') +
      '</select></label><p class="sub">⚠️ El endpoint debe responder con el data URL COMPLETO como texto plano (<code>data:image/png;base64,...</code>), no con los bytes de la imagen en crudo.</p></div>';
    inner += '<div id="af_varMapWrap" style="display:none;"><label class="field"><span>Campo del JSON = nombre de variable (uno por línea)</span><textarea id="af_varMap" rows="3" placeholder="total=puntosServidor"></textarea></label></div>';
    inner += '<p class="sub">Instantánea: se dispara en cuanto llega su turno en la secuencia, sin duración propia. La petición solo sale si quien juega la partida acepta el aviso de red. Ojo: si la URL es una página web normal (no un endpoint tuyo), lo más probable es que el navegador bloquee la petición por CORS (protección estándar contra que una web lea el contenido de otra sin permiso) -- y si la deja pasar, lo que llega es el HTML en crudo (con etiquetas y todo), no la página "renderizada".</p>';
  } else if (type === "setImageVar") {
    inner += '<label class="field"><span>Variable con la imagen</span><input type="text" id="af_imgVar" placeholder="fotoJugador"></label>';
    const imageOptsAF2 = [];
    if (rec.kind === "image") imageOptsAF2.push(['self', 'Este objeto (' + rec.name + ')']);
    sceneOrder.forEach((oid) => {
      if (oid === rec.id) return;
      const o = sceneObjects.get(oid);
      if (o && o.kind === "image") imageOptsAF2.push([oid, o.name]);
    });
    inner += '<label class="field"><span>Imagen destino</span><select id="af_imgTarget">' +
      (imageOptsAF2.length ? imageOptsAF2.map((o) => '<option value="' + o[0] + '">' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Imagen en la escena)</option>') +
      '</select></label>';
    inner += '<p class="sub">Instantánea, sin duración propia. Pone en el objeto elegido el data URL de imagen que ya tenga guardado la variable -- por ejemplo, la que rellena "Preguntar" al adjuntar una foto. Se restaura sola al volver al editor.</p>';
  } else if (type === "setTextVar") {
    inner += '<label class="field"><span>Variable con el texto</span><input type="text" id="af_txtVar" placeholder="nombreJugador"></label>';
    const text3dOptsAF2 = [];
    if (rec.kind === "text3d") text3dOptsAF2.push(['self', 'Este objeto (' + rec.name + ')']);
    sceneOrder.forEach((oid) => {
      if (oid === rec.id) return;
      const o = sceneObjects.get(oid);
      if (o && o.kind === "text3d") text3dOptsAF2.push([oid, o.name]);
    });
    inner += '<label class="field"><span>Rótulo destino</span><select id="af_txtTarget">' +
      (text3dOptsAF2.length ? text3dOptsAF2.map((o) => '<option value="' + o[0] + '">' + o[1].replace(/</g, "&lt;") + '</option>').join("") : '<option value="">(no hay objetos de Texto 3D en la escena)</option>') +
      '</select></label>';
    inner += '<p class="sub">Instantánea, sin duración propia y sin red de por medio (a diferencia de la acción Red en modo "rótulo"). Pone en el objeto elegido el texto que ya tenga guardado la variable.</p>';
  } else if (type === "screenMessage") {
    inner += '<label class="field"><span>Texto</span><input type="text" id="af_msgText" placeholder="Ahora te bañas en la piscina"></label>';
    inner += '<label class="field"><span>Cerrar solo tras (segundos, 0 = a mano)</span><input type="number" step="0.5" min="0" id="af_msgAutoDismiss" value="0"></label>';
    inner += '<p class="sub">Un cuadro centrado en pantalla, como un narrador -- no bloquea moverse mientras está abierto.</p>';
  } else if (type === "askInput") {
    inner += '<label class="field"><span>Pregunta / texto de ayuda</span><input type="text" id="af_askPrompt" placeholder="¿Cómo te llamas?"></label>';
    inner += '<label class="field"><span>Variable donde guardar el texto</span><input type="text" id="af_askVar" placeholder="nombreJugador"></label>';
    inner += '<label class="field" style="display:flex; align-items:center; gap:6px; margin-top:6px;"><input type="checkbox" id="af_askAllowFile" style="width:auto;"> <span style="margin:0;">Permitir adjuntar una imagen (máx. 350KB)</span></label>';
    inner += '<div id="af_askFileVarWrap" style="display:none;"><label class="field"><span>Variable donde guardar la imagen (data URL)</span><input type="text" id="af_askFileVar" placeholder="fotoJugador"></label></div>';
    inner += '<p class="sub">Bloquea moverse mientras está abierto (como el panel de un objeto interactivo). Para enviar la imagen de verdad hace falta una acción "Red" en modo POST.</p>';
  }
  inner += '<div class="flexRow" style="margin-top:8px;"><button class="small primary grow" id="af_confirm">Añadir</button><button class="small grow" id="af_cancel">Cancelar</button></div>';
  wrap.innerHTML = inner;
  panel.prepend(wrap);

  if (type === "moveTo") {
    showTargetHighlight(rec.object3D);
    const updateMarker = () => {
      const x = parseFloat(document.getElementById("af_x").value) || 0;
      const y = parseFloat(document.getElementById("af_y").value) || 0;
      const z = parseFloat(document.getElementById("af_z").value) || 0;
      showDestMarker({ x, y, z });
    };
    updateMarker();
    ["x", "y", "z"].forEach((a) => { document.getElementById("af_" + a).addEventListener("input", updateMarker); });
    document.getElementById("af_useCurrent").addEventListener("click", () => {
      ["x", "y", "z"].forEach((a) => { document.getElementById("af_" + a).value = rec.object3D.position[a].toFixed(2); });
      updateMarker();
    });
  }
  if (type === "fetchUrl") {
    const respSel = document.getElementById("af_respMode");
    respSel.addEventListener("change", () => {
      document.getElementById("af_varMapWrap").style.display = respSel.value === "variables" ? "block" : "none";
      document.getElementById("af_labelTargetWrap").style.display = respSel.value === "label" ? "block" : "none";
      document.getElementById("af_imageTargetWrap").style.display = respSel.value === "imagen" ? "block" : "none";
    });
  }
  if (type === "askInput") {
    const allowFileChk = document.getElementById("af_askAllowFile");
    allowFileChk.addEventListener("change", () => {
      document.getElementById("af_askFileVarWrap").style.display = allowFileChk.checked ? "block" : "none";
    });
  }
  document.getElementById("af_cancel").addEventListener("click", () => { hideActionEditHelpers(); wrap.remove(); });
  document.getElementById("af_confirm").addEventListener("click", () => {
    if (type === "setVariable" && !(document.getElementById("af_varName").value || "").trim()) { alertBox("Escribe un nombre para la variable antes de guardar.", "info"); return; }
    if (type === "fetchUrl" && !(document.getElementById("af_url").value || "").trim()) { alertBox("Escribe una URL antes de guardar.", "info"); return; }
    if (type === "screenMessage" && !(document.getElementById("af_msgText").value || "").trim()) { alertBox("Escribe el texto del mensaje antes de guardar.", "info"); return; }
    if (type === "askInput" && !(document.getElementById("af_askVar").value || "").trim()) { alertBox("Escribe un nombre de variable donde guardar la respuesta.", "info"); return; }
    if (type === "setImageVar" && !(document.getElementById("af_imgVar").value || "").trim()) { alertBox("Escribe un nombre de variable con la imagen antes de guardar.", "info"); return; }
    if (type === "setImageVar" && !(document.getElementById("af_imgTarget").value || "")) { alertBox("Elige un objeto de Imagen destino antes de guardar (crea uno primero si no tienes ninguno en la escena).", "info"); return; }
    if (type === "setTextVar" && !(document.getElementById("af_txtVar").value || "").trim()) { alertBox("Escribe un nombre de variable con el texto antes de guardar.", "info"); return; }
    if (type === "setTextVar" && !(document.getElementById("af_txtTarget").value || "")) { alertBox("Elige un objeto de Texto 3D destino antes de guardar (crea uno primero si no tienes ninguno en la escena).", "info"); return; }
    let action = { type };
    if (type === "moveTo") {
      const abs = { x: parseFloat(document.getElementById("af_x").value) || 0, y: parseFloat(document.getElementById("af_y").value) || 0, z: parseFloat(document.getElementById("af_z").value) || 0 };
      if (document.getElementById("af_relative").checked) {
        const originPos = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.pos : rec.object3D.position;
        action.to = { x: abs.x - originPos.x, y: abs.y - originPos.y, z: abs.z - originPos.z };
        action.relative = true;
      } else {
        action.to = abs;
      }
      action.duration = Math.max(0.05, parseFloat(document.getElementById("af_dur").value) || 1);
      action.ease = document.getElementById("af_ease").value;
    } else if (type === "rotateTo") {
      const absDeg = { x: parseFloat(document.getElementById("af_x").value) || 0, y: parseFloat(document.getElementById("af_y").value) || 0, z: parseFloat(document.getElementById("af_z").value) || 0 };
      if (document.getElementById("af_relative").checked) {
        const originQuat = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.quat : rec.object3D.quaternion;
        const oe = new THREE.Euler().setFromQuaternion(originQuat);
        action.to = { x: absDeg.x - rad2deg(oe.x), y: absDeg.y - rad2deg(oe.y), z: absDeg.z - rad2deg(oe.z) };
        action.relative = true;
      } else {
        action.to = absDeg;
      }
      action.duration = Math.max(0.05, parseFloat(document.getElementById("af_dur").value) || 1);
      action.ease = "smooth";
    } else if (type === "wait") {
      action.duration = Math.max(0.05, parseFloat(document.getElementById("af_dur").value) || 1);
    } else if (type === "fade") {
      action.to = parseInt(document.getElementById("af_to").value, 10);
      action.duration = Math.max(0.05, parseFloat(document.getElementById("af_dur").value) || 1);
    } else if (type === "flash") {
      action.color = document.getElementById("af_color").value;
      action.repeat = Math.max(1, parseInt(document.getElementById("af_repeat").value, 10) || 3);
      action.duration = Math.max(0.05, parseFloat(document.getElementById("af_dur").value) || 1);
    } else if (type === "playClip") {
      action.clipName = document.getElementById("af_clip").value;
      action.duration = Math.max(0.1, parseFloat(document.getElementById("af_dur").value) || 1);
      action.loop = document.getElementById("af_loop").checked;
    } else if (type === "setVariable") {
      action.varName = (document.getElementById("af_varName").value || "").trim();
      action.expr = document.getElementById("af_expr").value || "0";
    } else if (type === "fetchUrl") {
      action.url = (document.getElementById("af_url").value || "").trim();
      action.method = document.getElementById("af_method").value === "POST" ? "POST" : "GET";
      action.responseMode = document.getElementById("af_respMode").value || "none";
      action.varMap = document.getElementById("af_varMap") ? document.getElementById("af_varMap").value : "";
      if (action.responseMode === "label") {
        const labelTargetVal = document.getElementById("af_labelTarget") ? document.getElementById("af_labelTarget").value : "";
        if (labelTargetVal) action.target = labelTargetVal;
      } else if (action.responseMode === "imagen") {
        const imageTargetVal = document.getElementById("af_imageTarget") ? document.getElementById("af_imageTarget").value : "";
        if (imageTargetVal) action.target = imageTargetVal;
      }
    } else if (type === "screenMessage") {
      action.text = document.getElementById("af_msgText").value || "";
      action.autoDismissSec = parseFloat(document.getElementById("af_msgAutoDismiss").value) || 0;
    } else if (type === "askInput") {
      action.promptText = document.getElementById("af_askPrompt").value || "";
      action.varName = (document.getElementById("af_askVar").value || "").trim();
      action.allowFile = document.getElementById("af_askAllowFile").checked;
      action.fileVarName = (document.getElementById("af_askFileVar").value || "").trim();
    } else if (type === "setImageVar") {
      action.varName = (document.getElementById("af_imgVar").value || "").trim();
      action.target = document.getElementById("af_imgTarget").value || null;
    } else if (type === "setTextVar") {
      action.varName = (document.getElementById("af_txtVar").value || "").trim();
      action.target = document.getElementById("af_txtTarget").value || null;
    }
    rec.actions.push(action);
    recomputeCheckpoints(rec); recomputeTimelineDuration();
    hideActionEditHelpers();
    renderHierarchy(); renderProps();
  });
}

/* =========================================================================
   LÍNEA DE TIEMPO: CHECKPOINTS, EVALUACIÓN Y REPRODUCCIÓN
   ========================================================================= */
function recomputeCheckpoints(rec) {
  const originPos = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.pos.clone() : rec.object3D.position.clone();
  const originQuat = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.quat.clone() : rec.object3D.quaternion.clone();
  if (!rec.object3D.userData.__origin) rec.object3D.userData.__origin = { pos: originPos.clone(), quat: originQuat.clone() };

  const cps = [{ t: 0, pos: originPos.clone(), quat: originQuat.clone(), opacity: (rec.opacity != null ? rec.opacity : 1), ease: "linear", flashDef: null, clipDef: null }];
  for (const a of rec.actions) {
    const prev = cps[cps.length - 1];
    const dur = a.duration || 0;
    const next = { t: prev.t + dur, pos: prev.pos.clone(), quat: prev.quat.clone(), opacity: prev.opacity, ease: a.ease || "linear", flashDef: null, clipDef: null };
    if (a.type === "moveTo") {
      if (a.relative) next.pos.copy(originPos).add(new THREE.Vector3(a.to.x, a.to.y, a.to.z));
      else next.pos.set(a.to.x, a.to.y, a.to.z);
    }
    if (a.type === "rotateTo") {
      if (a.relative) {
        const oe = new THREE.Euler().setFromQuaternion(originQuat);
        const ne = new THREE.Euler(oe.x + deg2rad(a.to.x), oe.y + deg2rad(a.to.y), oe.z + deg2rad(a.to.z));
        next.quat.setFromEuler(ne);
      } else {
        const e = new THREE.Euler(deg2rad(a.to.x), deg2rad(a.to.y), deg2rad(a.to.z));
        next.quat.setFromEuler(e);
      }
    }
    if (a.type === "fade") next.opacity = a.to;
    if (a.type === "flash") next.flashDef = { color: a.color, repeat: a.repeat || 3 };
    if (a.type === "playClip") next.clipDef = { name: a.clipName, duration: a.duration, loop: a.loop };
    cps.push(next);
  }
  rec.checkpoints = cps;
}

function totalDurationOf(rec) {
  if (!rec.checkpoints || !rec.checkpoints.length) return 0;
  return rec.checkpoints[rec.checkpoints.length - 1].t;
}

function evaluateRecord(rec, t) {
  const cps = rec.checkpoints;
  if (!cps || cps.length < 2) return null;
  const last = cps[cps.length - 1].t;
  const tt = clamp(t, 0, last || 0);
  let i = 0;
  while (i < cps.length - 2 && cps[i + 1].t < tt) i++;
  const segStart = cps[i], segEnd = cps[i + 1];
  const segDur = (segEnd.t - segStart.t) || 1e-6;
  const p = clamp((tt - segStart.t) / segDur, 0, 1);
  const pe = easeVal(p, segEnd.ease);
  const pos = segStart.pos.clone().lerp(segEnd.pos, pe);
  const quat = segStart.quat.clone().slerp(segEnd.quat, pe);
  const opacity = lerp(segStart.opacity, segEnd.opacity, pe);
  let flashIntensity = 0, flashColor = null;
  if (segEnd.flashDef) { flashIntensity = Math.abs(Math.sin(p * Math.PI * segEnd.flashDef.repeat)); flashColor = segEnd.flashDef.color; }
  let clipInfo = null;
  if (segEnd.clipDef) clipInfo = { name: segEnd.clipDef.name, localTime: p * segEnd.clipDef.duration, loop: segEnd.clipDef.loop };
  return { pos, quat, opacity, flashIntensity, flashColor, clipInfo };
}

function recomputeTimelineDuration() {
  let max = 0;
  for (const rec of sceneObjects.values()) max = Math.max(max, totalDurationOf(rec));
  timelineDuration = Math.max(max, 0.01);
  document.getElementById("scrubber").max = String(timelineDuration);
  updateTimeLabel();
  recomputeChainTriggers();
}

// Acciones del guion (rec.actions[i].next) que, al completarse ese paso durante la reproducción/Modo jugar,
// disparan una acción encadenada (posiblemente en OTRO objeto) vía el mismo sistema de acciones one-shot.
// Las propias acciones "setVariable"/"fetchUrl" en la línea de tiempo también se disparan así (una vez,
// al llegar su turno) en vez de interpolarse como moveTo/fade/etc. -- no tienen estado visual que animar.
let chainTriggers = [];
function recomputeChainTriggers() {
  const triggers = [];
  for (const rec of sceneObjects.values()) {
    if (!rec.checkpoints) continue;
    rec.actions.forEach((a, i) => {
      if (!a || !rec.checkpoints[i + 1]) return;
      if (a.type === "setVariable" || a.type === "fetchUrl" || a.type === "copyToClipboard" || a.type === "if" || a.type === "for" || a.type === "screenMessage" || a.type === "askInput" || a.type === "setImageVar" || a.type === "setTextVar") {
        triggers.push({ time: rec.checkpoints[i + 1].t, chainRec: rec, action: a });
      }
      if (a.next) {
        triggers.push({ time: rec.checkpoints[i + 1].t, chainRec: rec, action: a.next });
      }
    });
  }
  triggers.sort((a, b) => a.time - b.time);
  chainTriggers = triggers;
}
// Dispara los disparadores cuyo tiempo cae en (fromT, toT] avanzando en el tiempo; si toT < fromT el reloj ha
// completado un bucle y ha vuelto a 0 — en ese caso dispara lo pendiente hasta el final y lo ya alcanzado desde 0.
function fireDueChainTriggers(fromT, toT) {
  if (!chainTriggers.length) return;
  if (toT >= fromT) {
    chainTriggers.forEach((tr) => { if (tr.time > fromT && tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });
  } else {
    chainTriggers.forEach((tr) => { if (tr.time > fromT || tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });
  }
}

let timelineDuration = 0.01;
let currentTime = 0;
let isPlaying = false;
let playStartClock = 0;
let playStartTimeline = 0;
let overlapState = new Map(); // "charId|zoneId" -> bool
let eventLogList = [];

// Variables con nombre para las acciones "Variable"/"Red" (ver triggerOneShotAction). Solo viven
// durante la partida (se reinician a {} en enterPlayMode, como playScore) -- una variable no
// declarada expresamente en ningún panel se crea sola la primera vez que una acción la usa, con
// valor 0. No se guardan en el proyecto: son estado de PARTIDA, no de escena.
let gameVariables = {};
// Puerta de permiso de red para la acción "Red" (fetchUrl): como el JS de un lector de PDF, apagada
// de fábrica -- la decide quien ABRE el proyecto (no quien lo creó), la primera vez que una acción
// de red intenta dispararse de verdad durante ESTA sesión de juego. Se le muestra la lista de URLs
// que el escenario podría llamar antes de que salga ninguna petición. Ver gateNetworkActions().
let networkActionsAllowed = false;
let networkGateAsked = false;

/* =========================================================================
   MODO JUGAR (previsualización interactiva con teclado + ratón)
   ========================================================================= */
let isPlayModeActive = false;
let multiPanelInputActive = false; // true mientras el panel de sala/chat tiene el foco (pausa el juego)
let playYaw = 0, playPitch = -0.25;
let playOrientationLocked = false; // true si screen.orientation.lock() tuvo éxito al entrar en Modo Jugar
let playKeys = { w: false, a: false, s: false, d: false, shift: false, space: false, arrowUp: false, arrowDown: false, arrowLeft: false, arrowRight: false };
let playerRecordId = null;
let firstPersonMode = false;
let npcClockTime = 0;
let prePlayState = null;
let playScore = 0;
let interactionPanelOpen = false;
// true mientras el overlay de "Preguntar (entrada libre)" tiene el foco -- igual que
// multiPanelInputActive, pausa WASD/puntero mientras el jugador escribe su respuesta.
let askInputActive = false;
const MAX_ASK_ARCHIVO_BYTES = 350 * 1024; // mismo tope que el chat (MAX_ARCHIVO_BYTES en mundo-multi.js)
let nearestInteractiveId = null;
let nearestShotTargetId = null; // objeto apuntado con la mira para el disparo a distancia (independiente de la proximidad)
let punteroLaserActivo = false; // interruptor del puntero láser multiusuario -- tecla L / botón táctil, apagado por defecto
let playVelY = 0;
let playGrounded = true;
let playCamDist = 4.5; // distancia de cámara suavizada (evita el "temblor" al variar sobre terreno ondulado)
const WALK_SPEED = 3.2, RUN_SPEED = 6.2, CHASE_RADIUS = 4.5, GRAVITY = -18, JUMP_SPEED = 6.5, TURN_SPEED = 2.4;
// Modo dron: cámara de inspección libre, desconectada del personaje -- sin suelo, sin colisión,
// sin disparo ni interacción de juego (tecla C / botón táctil 🛸). El personaje se queda quieto
// donde estaba; solo la vista "vuela". Pensado para presentaciones/webinars y para revisar el
// escenario desde cualquier ángulo, no para jugar.
let droneModeActive = false;
const droneCamPos = new THREE.Vector3();
const DRONE_SPEED = 5;
// Recorrido de cámara en curso (null si no hay ninguno reproduciéndose). Tiene prioridad absoluta
// sobre el personaje y el Modo dron: mientras dura, el juego queda "en pausa" -- solo se mueve la
// cámara por el camino trazado, sin colisión ni interacción, y al terminar se devuelve el control
// exactamente al modo de vista (1ª/3ª persona o dron) que hubiera antes de empezar.
let cameraPathActive = null;
let catDisguiseActive = false; // huevo de pascua: teclea "miau" en Modo Jugar
let catKeyBuffer = "";

// Controles táctiles (móvil/tablet): joystick virtual para moverse + arrastre en el resto del visor
// para mirar, ya que no hay pointer lock ni teclado. Cada uno se ata a su propio touch.identifier
// para no interferir entre sí si el jugador usa dos dedos a la vez.
function isTouchDevice() {
  return (window.matchMedia && window.matchMedia("(pointer: coarse)").matches) || "ontouchstart" in window || (navigator.maxTouchPoints || 0) > 0;
}
let touchJoystickId = null;
let touchJoystickVec = { x: 0, y: 0 }; // -1..1, y positivo = adelante
let touchLookId = null;
let touchLookLast = { x: 0, y: 0 };

function findCharacterRecord() {
  for (const rec of sceneObjects.values()) if (rec.collider.kind === "character") return rec;
  return null;
}

// Huevo de pascua — al estilo del "clip" de Word: solo vive aquí, en el editor (Modo Jugar), nunca
// se copia al videojuego .html exportado. Diseño propio de gatita kawaii (no es una copia de ningún
// personaje registrado), construida con las mismas primitivas que el resto de prefabs.
function buildEasterEggCat() {
  const group = new THREE.Group();
  const mats = [];
  const white = 0xfff7f0, pink = 0xffb6c9, black = 0x2b2b2b, blush = 0xffc9d6, ribbon = 0xff7fa0;
  // Nota de orientación: el motor gira el personaje para que su eje local -Z apunte hacia donde se
  // mueve (ver targetQuat en updatePlayMode), así que la "cara" de la gatita va en z NEGATIVO y la
  // cola en z positivo — si no, camina de espaldas (como reportó Sergio, ¡buen ojo!).
  addPart(group, mats, new THREE.CapsuleGeometry(0.24, 0.5, 6, 12), white, 0, 0.5, 0);
  addPart(group, mats, new THREE.SphereGeometry(0.26, 20, 16), white, 0, 1.0, 0);
  addPart(group, mats, new THREE.ConeGeometry(0.09, 0.16, 12), white, -0.17, 1.22, 0, 0, 0, 0.35);
  addPart(group, mats, new THREE.ConeGeometry(0.09, 0.16, 12), white, 0.17, 1.22, 0, 0, 0, -0.35);
  addPart(group, mats, new THREE.ConeGeometry(0.045, 0.08, 12), pink, -0.17, 1.2, -0.03, 0, 0, 0.35);
  addPart(group, mats, new THREE.ConeGeometry(0.045, 0.08, 12), pink, 0.17, 1.2, -0.03, 0, 0, -0.35);
  addPart(group, mats, new THREE.SphereGeometry(0.035, 10, 8), black, -0.09, 1.02, -0.23);
  addPart(group, mats, new THREE.SphereGeometry(0.035, 10, 8), black, 0.09, 1.02, -0.23);
  addPart(group, mats, new THREE.ConeGeometry(0.025, 0.03, 8), pink, 0, 0.97, -0.255, -Math.PI / 2, 0, 0);
  addPart(group, mats, new THREE.SphereGeometry(0.04, 10, 8), blush, -0.17, 0.96, -0.19);
  addPart(group, mats, new THREE.SphereGeometry(0.04, 10, 8), blush, 0.17, 0.96, -0.19);
  addPart(group, mats, new THREE.ConeGeometry(0.05, 0.09, 8), pink, -0.02, 1.16, -0.14, 0, 0, Math.PI / 2.3);
  addPart(group, mats, new THREE.ConeGeometry(0.05, 0.09, 8), pink, 0.06, 1.16, -0.14, 0, 0, -Math.PI / 2.3);
  addPart(group, mats, new THREE.SphereGeometry(0.025, 8, 8), ribbon, 0.02, 1.16, -0.15);
  addPart(group, mats, new THREE.CylinderGeometry(0.02, 0.04, 0.4, 8), white, 0, 0.55, 0.25, -Math.PI / 3, 0, 0);
  group.name = "__easterEggCat";
  return { object3D: group, colorMaterials: mats };
}

function toggleCatEasterEgg() {
  const player = sceneObjects.get(playerRecordId);
  if (!player) return;
  catDisguiseActive = !catDisguiseActive;
  if (catDisguiseActive) {
    if (!player.__catGroupObj) {
      const cat = buildEasterEggCat();
      player.__catGroupObj = cat.object3D;
      player.object3D.add(cat.object3D);
    }
    player.object3D.children.forEach((c) => { if (c !== player.__catGroupObj) c.visible = false; });
    player.__catGroupObj.visible = !firstPersonMode;
    const verEnSala = window.MundoMulti && MundoMulti.estaActivo();
    playFeedToast(verEnSala ? "🐱 ¡Miau! (los demás en la sala también te ven así)" : "🐱 ¡Miau! (huevo de pascua — solo aquí en el editor)");
  } else {
    if (player.__catGroupObj) player.__catGroupObj.visible = false;
    player.object3D.children.forEach((c) => { if (c !== player.__catGroupObj) c.visible = true; });
    playFeedToast("🚶 De vuelta al trabajador.");
  }
}

/* =========================================================================
   MULTIJUGADOR (avatares + chat) -- ver multi/mundo-multi.js
   ========================================================================= */
function hashHue(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h % 360;
}

function buildNameSprite(text) {
  const cnv = document.createElement("canvas");
  cnv.width = 256; cnv.height = 64;
  const ctx = cnv.getContext("2d");
  ctx.fillStyle = "rgba(10,11,15,.55)";
  if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(0, 8, 256, 48, 12); ctx.fill(); }
  else { ctx.fillRect(0, 8, 256, 48); }
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 28px -apple-system, Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText((text || "?").slice(0, 18), 128, 34);
  const texture = new THREE.CanvasTexture(cnv);
  texture.needsUpdate = true;
  const mat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.name = "__nameSprite";
  sprite.scale.set(1.1, 0.28, 1);
  sprite.position.y = 1.55;
  return sprite;
}

// Reconstruye (la primera vez) y muestra/oculta el disfraz de gatito en un avatar remoto, según lo
// que ese visitante reporte por el canal de posición -- mismo "huevo de pascua" que buildEasterEggCat(),
// pero aplicado a otro Object3D. Nunca oculta el "__nameSprite": el nombre se sigue viendo por encima.
function actualizarDisfrazRemoto(avatarObj3D, disfraz) {
  if (!avatarObj3D) return;
  const activo = disfraz === "gato";
  if (activo && !avatarObj3D.__catGroupObj) {
    const cat = buildEasterEggCat();
    avatarObj3D.__catGroupObj = cat.object3D;
    avatarObj3D.add(cat.object3D);
  }
  if (avatarObj3D.__catGroupObj) avatarObj3D.__catGroupObj.visible = activo;
  avatarObj3D.children.forEach((c) => {
    if (c === avatarObj3D.__catGroupObj || c.name === "__nameSprite") return;
    c.visible = !activo;
  });
}

// Redimensiona/recorta a un cuadrado 256x256 -- suficiente detalle para una textura de ladrillo/teja
// que se repite (tesela) sobre la superficie, sin disparar el peso del proyecto al compartirlo.
function redimensionarImagenParaTextura(file, callback) {
  if (!file || !file.type || !file.type.startsWith("image/")) { callback(new Error("no es una imagen")); return; }
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      const lado = Math.min(img.width, img.height);
      const ox = (img.width - lado) / 2, oy = (img.height - lado) / 2;
      const cnv = document.createElement("canvas");
      cnv.width = 256; cnv.height = 256;
      const ctx = cnv.getContext("2d");
      ctx.drawImage(img, ox, oy, lado, lado, 0, 0, 256, 256);
      callback(null, cnv.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = () => callback(new Error("no se pudo decodificar la imagen"));
    img.src = e.target.result;
  };
  reader.onerror = () => callback(new Error("no se pudo leer el archivo"));
  reader.readAsDataURL(file);
}

// Aplica (o quita, con dataUrl=null) una textura teselada a todos los materiales de la pieza. El color
// propio del objeto sigue actuando como tinte multiplicativo por debajo de la imagen (Three.js combina
// material.color * material.map de forma nativa), así que el control de Color de arriba sigue sirviendo.
function aplicarTexturaAPieza(rec, dataUrl) {
  if (!dataUrl) {
    rec.colorMaterials.forEach((m) => { if (m.map) { m.map.dispose(); m.map = null; m.needsUpdate = true; } });
    rec.textureBase64 = null;
    return;
  }
  const tex = new THREE.TextureLoader().load(dataUrl);
  if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(rec.textureRepeatX || 1, rec.textureRepeatY || 1);
  rec.colorMaterials.forEach((m) => { m.map = tex; m.needsUpdate = true; });
  rec.textureBase64 = dataUrl;
}

// Un cilindro fino y hueco (sin tapas) alrededor del torso, en vez de pintar la textura
// directamente sobre la cápsula: la cápsula mapea su textura envolviendo también los remates
// redondeados de arriba/abajo, así que la imagen se "estira/pellizca" ahí. Un cilindro sin polos
// envuelve limpio, sin esa distorsión.
function crearEnvolturaTextura(imagenB64) {
  const tex = new THREE.TextureLoader().load(imagenB64);
  if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
  const geo = new THREE.CylinderGeometry(0.226, 0.226, 0.62, 24, 1, true); // openEnded: sin tapas circulares
  const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85, metalness: 0.05, side: THREE.DoubleSide });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(0, 0.55, 0); // mismo centro que el cuerpo (cápsula) del prefab "personaje"
  mesh.castShadow = true;
  return mesh;
}

function crearAvatarRemoto(nombre, imagenB64) {
  const built = createPrefab("personaje");
  const hue = hashHue(nombre || "?");
  const color = new THREE.Color("hsl(" + hue + ", 65%, 55%)");
  built.colorMaterials.forEach((m) => { if (m.color) m.color.copy(color); });
  if (imagenB64) built.object3D.add(crearEnvolturaTextura(imagenB64));
  built.object3D.add(buildNameSprite(nombre));
  return built.object3D;
}

// Aplica (o quita, si imagenB64 es null) la misma envoltura al propio Trabajador que controlas --
// solo se ve en 3ª persona (tecla V), pero así los demás no son los únicos con vista previa.
function aplicarTexturaJugadorPropio(imagenB64) {
  const player = sceneObjects.get(playerRecordId);
  if (!player || !player.object3D) return;
  if (player.__texturaEnvoltura) {
    player.object3D.remove(player.__texturaEnvoltura);
    player.__texturaEnvoltura.geometry.dispose();
    if (player.__texturaEnvoltura.material.map) player.__texturaEnvoltura.material.map.dispose();
    player.__texturaEnvoltura.material.dispose();
    player.__texturaEnvoltura = null;
  }
  if (imagenB64) {
    player.__texturaEnvoltura = crearEnvolturaTextura(imagenB64);
    player.object3D.add(player.__texturaEnvoltura);
  }
}

// Dibuja/actualiza el "puntero láser" de un visitante remoto: una línea roja fina desde
// aproximadamente su cabeza hasta el punto del mundo que reporta estar mirando, más un
// puntito en el destino -- para presentaciones multiusuario (formación en grupo, señalar un
// riesgo concreto sin tener que describirlo por chat). Si punteroPoint es null (no está
// apuntando a nada, o dejó de mandar datos), se oculta sin destruir los objetos (se
// reutilizan en la siguiente actualización, más barato que crear/tirar cada frame).
function actualizarPunteroRemoto(avatarObj3D, punteroPoint) {
  if (!avatarObj3D) return;
  if (!avatarObj3D.__laserLine) {
    const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    const mat = new THREE.LineBasicMaterial({ color: 0xff3b3b, transparent: true, opacity: 0.85 });
    const line = new THREE.Line(geo, mat);
    line.frustumCulled = false;
    line.visible = false;
    scene.add(line);
    avatarObj3D.__laserLine = line;
    const dotGeo = new THREE.SphereGeometry(0.06, 12, 12);
    const dotMat = new THREE.MeshBasicMaterial({ color: 0xff3b3b });
    const dot = new THREE.Mesh(dotGeo, dotMat);
    dot.visible = false;
    scene.add(dot);
    avatarObj3D.__laserDot = dot;
  }
  const line = avatarObj3D.__laserLine, dot = avatarObj3D.__laserDot;
  if (!punteroPoint || typeof punteroPoint.x !== "number") {
    line.visible = false;
    dot.visible = false;
    return;
  }
  const origen = avatarObj3D.position.clone();
  origen.y += 1.5; // altura aproximada de los "ojos" del avatar (prefab "personaje")
  const destino = new THREE.Vector3(punteroPoint.x, punteroPoint.y, punteroPoint.z);
  line.geometry.setFromPoints([origen, destino]);
  line.visible = true;
  dot.position.copy(destino);
  dot.visible = true;
}

function quitarAvatarRemoto(obj3D) {
  if (obj3D.__laserLine) { scene.remove(obj3D.__laserLine); obj3D.__laserLine.geometry.dispose(); obj3D.__laserLine.material.dispose(); obj3D.__laserLine = null; }
  if (obj3D.__laserDot) { scene.remove(obj3D.__laserDot); obj3D.__laserDot.geometry.dispose(); obj3D.__laserDot.material.dispose(); obj3D.__laserDot = null; }
  obj3D.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      mats.forEach((m) => { if (m.map) m.map.dispose(); m.dispose(); });
    }
  });
}

// escPlayHtml ya escapa texto suelto; para el nombre de archivo (que también viene de fuera, del
// otro visitante) se reutiliza igual antes de meterlo en atributos/textContent.
function multiChatAgregarMensaje(nombre, texto, esMio, extra) {
  const log = document.getElementById("multiChatLog");
  if (!log) return;
  extra = extra || {};
  const div = document.createElement("div");
  div.className = "msg" + (esMio ? " mio" : "") + (extra.privado ? " privado" : "");
  let html = "<b>" + escPlayHtml(nombre) + ":</b> ";
  if (texto) html += escPlayHtml(texto);
  div.innerHTML = html;
  if (extra.archivo) div.appendChild(multiCrearNodoArchivo(extra.archivo));
  log.appendChild(div);
  while (log.children.length > 40) log.removeChild(log.firstChild);
  log.scrollTop = log.scrollHeight;
}

// Adjunto recibido/enviado: si es una imagen se muestra como miniatura, si no como enlace de
// descarga (data URL directamente en href -- nada que subir/servir aparte, ya viaja completo en el
// propio mensaje de chat).
function multiCrearNodoArchivo(archivo) {
  const cont = document.createElement("span");
  cont.className = "archivoAdjunto";
  // "datos" viene de OTRO peer (o del respaldo por servidor) -- no confiar en que sea de verdad un
  // data: URL antes de meterlo en src/href. Un peer malicioso podría mandar cualquier esquema ahí
  // (javascript:, etc.); los navegadores modernos ya no lo ejecutan desde img.src/a.href, pero es
  // gratis comprobarlo aquí y no depender solo de esa protección del navegador.
  if (!/^data:/i.test(archivo.datos || "")) {
    const span = document.createElement("span");
    span.textContent = "📎 (adjunto no válido)";
    cont.appendChild(span);
    return cont;
  }
  const esImagen = (archivo.mime || "").indexOf("image/") === 0;
  if (esImagen) {
    const img = document.createElement("img");
    img.src = archivo.datos;
    img.alt = archivo.nombre || "imagen";
    cont.appendChild(img);
  } else {
    const a = document.createElement("a");
    a.href = archivo.datos;
    a.download = archivo.nombre || "archivo";
    a.textContent = "📎 " + (archivo.nombre || "archivo");
    cont.appendChild(a);
  }
  return cont;
}

// Repuebla el selector "Para" (a quién va el próximo mensaje/archivo) con la lista de visitantes
// conectados ahora mismo -- conserva la selección si esa persona sigue en la sala, y la resetea a
// "Todos (público)" si se fue (para no quedarse "hablándole a la pared" sin darse cuenta).
function multiActualizarSelectorPara(lista) {
  const sel = document.getElementById("multiChatPara");
  if (!sel) return;
  const anterior = sel.value;
  sel.innerHTML = "";
  const optTodos = document.createElement("option");
  optTodos.value = ""; optTodos.textContent = "📢 Todos (público)";
  sel.appendChild(optTodos);
  (lista || []).forEach((p) => {
    const opt = document.createElement("option");
    opt.value = p.sid; opt.textContent = "🔒 " + p.nombre;
    sel.appendChild(opt);
  });
  sel.value = Array.from(sel.options).some((o) => o.value === anterior) ? anterior : "";
}

let miTexturaAvatar = null; // base64 pequeño (160x160 JPEG) o null

// Redimensiona/recorta cualquier imagen a un cuadrado pequeño en base64 -- mismo criterio que
// usa compañía.es para la foto de perfil: ligera, cómoda de mandar en cada ciclo de presencia.
function redimensionarImagenParaAvatar(file, callback) {
  if (!file || !file.type || !file.type.startsWith("image/")) { callback(new Error("no es una imagen")); return; }
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      const lado = Math.min(img.width, img.height);
      const ox = (img.width - lado) / 2, oy = (img.height - lado) / 2;
      const cnv = document.createElement("canvas");
      cnv.width = 160; cnv.height = 160;
      const ctx = cnv.getContext("2d");
      ctx.drawImage(img, ox, oy, lado, lado, 0, 0, 160, 160);
      callback(null, cnv.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = () => callback(new Error("no se pudo decodificar la imagen"));
    img.src = e.target.result;
  };
  reader.onerror = () => callback(new Error("no se pudo leer el archivo"));
  reader.readAsDataURL(file);
}

document.getElementById("multiTexturaTrigger")?.addEventListener("click", () => document.getElementById("multiTexturaInput").click());
document.getElementById("multiTexturaInput")?.addEventListener("change", (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  redimensionarImagenParaAvatar(f, (err, dataUrl) => {
    if (err) { document.getElementById("multiEstado").textContent = "No se pudo usar esa imagen."; return; }
    miTexturaAvatar = dataUrl;
    localStorage.setItem("mundo3d_textura", dataUrl);
    const prev = document.getElementById("multiTexturaPreview");
    prev.src = dataUrl; prev.style.display = "inline-block";
    document.getElementById("multiTexturaQuitar").style.display = "inline-block";
    if (window.MundoMulti && MundoMulti.estaActivo()) aplicarTexturaJugadorPropio(miTexturaAvatar);
  });
});
document.getElementById("multiTexturaQuitar")?.addEventListener("click", () => {
  miTexturaAvatar = null;
  localStorage.removeItem("mundo3d_textura");
  document.getElementById("multiTexturaPreview").style.display = "none";
  document.getElementById("multiTexturaQuitar").style.display = "none";
  aplicarTexturaJugadorPropio(null);
});

if (window.MundoMulti) {
  MundoMulti.init({
    scene: scene,
    crearAvatarRemoto: crearAvatarRemoto,
    quitarAvatarRemoto: quitarAvatarRemoto,
    onChat: multiChatAgregarMensaje,
    onEstado: (texto) => { const el = document.getElementById("multiEstado"); if (el) el.textContent = texto; },
    onPeers: (n) => { const el = document.getElementById("multiPeerCount"); if (el) el.textContent = "👥 " + n + " conectado" + (n === 1 ? "" : "s"); },
    onListaPeers: multiActualizarSelectorPara,
    actualizarDisfraz: actualizarDisfrazRemoto,
    actualizarPuntero: actualizarPunteroRemoto,
  });
}

function abrirPanelMulti() {
  const panel = document.getElementById("multiPanel");
  if (!panel) return;
  panel.style.display = "block";
  const salaInput = document.getElementById("multiSalaInput");
  const nombreInput = document.getElementById("multiNombreInput");
  const urlSala = new URLSearchParams(location.search).get("sala");
  salaInput.value = urlSala || localStorage.getItem("mundo3d_ultima_sala") || "";
  nombreInput.value = localStorage.getItem("mundo3d_nombre") || "";
  miTexturaAvatar = localStorage.getItem("mundo3d_textura") || null;
  const texPrev = document.getElementById("multiTexturaPreview");
  const texQuitar = document.getElementById("multiTexturaQuitar");
  if (miTexturaAvatar) { texPrev.src = miTexturaAvatar; texPrev.style.display = "inline-block"; texQuitar.style.display = "inline-block"; }
  else { texPrev.style.display = "none"; texQuitar.style.display = "none"; }
  document.getElementById("multiChatLog").innerHTML = "";
  document.getElementById("multiEstado").textContent = "";
  multiActualizarSelectorPara([]);
  if (window.MundoMulti && MundoMulti.estaActivo()) {
    document.getElementById("multiJoinBox").style.display = "none";
    document.getElementById("multiStatusBox").style.display = "block";
  } else {
    document.getElementById("multiJoinBox").style.display = "block";
    document.getElementById("multiStatusBox").style.display = "none";
    // Antes entraba sola en cuanto detectaba "?sala=" en el enlace -- pero eso no dejaba tiempo a
    // elegir foto/nombre antes de unirte (el panel cambiaba al chat casi al instante). Ahora solo
    // rellena el código de sala; entrar sigue siendo un clic en "Entrar", ya con foto si quieres.
    if (urlSala) document.getElementById("multiEstado").textContent = "Sala \"" + urlSala + "\" desde el enlace -- elige foto/nombre si quieres y pulsa Entrar.";
  }
}

function cerrarPanelMulti() {
  if (window.MundoMulti) MundoMulti.salir();
  aplicarTexturaJugadorPropio(null);
  const panel = document.getElementById("multiPanel");
  if (panel) panel.style.display = "none";
  multiPanelInputActive = false;
}

// El "Modo jugar" captura el ratón (pointer lock) para mirar alrededor, así que mientras
// juegas no se puede hacer clic normal en los campos de sala/chat -- y en Chrome, a diferencia
// de Firefox, pulsar Tab suelta el pointer lock por su cuenta de forma inconsistente. En vez de
// depender de eso, controlamos nosotros mismos cuándo se libera el ratón para escribir.
function abrirPanelParaEscribir() {
  if (!isPlayModeActive || multiPanelInputActive) return;
  multiPanelInputActive = true;
  if (document.pointerLockElement === canvas) document.exitPointerLock();
  document.getElementById("playClickToStart").style.display = "none";
  const panel = document.getElementById("multiPanel");
  if (panel) panel.classList.add("editando");
  const toggleBtn = document.getElementById("multiToggleBtn");
  if (toggleBtn) toggleBtn.textContent = "▶ Volver al juego";
  const chatInput = document.getElementById("multiChatInput");
  const salaInput = document.getElementById("multiSalaInput");
  const target = (window.MundoMulti && MundoMulti.estaActivo()) ? chatInput : salaInput;
  if (target) target.focus();
}

function cerrarPanelParaEscribir() {
  if (!multiPanelInputActive) return;
  multiPanelInputActive = false;
  if (document.activeElement && document.activeElement.closest && document.activeElement.closest("#multiPanel")) {
    document.activeElement.blur();
  }
  const panel = document.getElementById("multiPanel");
  if (panel) panel.classList.remove("editando");
  const toggleBtn = document.getElementById("multiToggleBtn");
  if (toggleBtn) toggleBtn.textContent = "👥 Sala";
  if (!isPlayModeActive) return;
  if (isTouchDevice()) return; // en táctil no hay ratón que capturar
  const req = canvas.requestPointerLock();
  if (req && typeof req.catch === "function") {
    req.catch(() => { document.getElementById("playClickToStart").style.display = "flex"; });
  }
}

document.getElementById("multiToggleBtn")?.addEventListener("click", () => {
  if (multiPanelInputActive) cerrarPanelParaEscribir(); else abrirPanelParaEscribir();
});

async function entrarEnSalaMulti() {
  if (!window.MundoMulti) return;
  const salaVal = document.getElementById("multiSalaInput").value.trim();
  const nombreVal = document.getElementById("multiNombreInput").value.trim() || "Visitante";
  if (!salaVal) { document.getElementById("multiEstado").textContent = "Escribe un código de sala."; return; }
  localStorage.setItem("mundo3d_ultima_sala", salaVal);
  localStorage.setItem("mundo3d_nombre", nombreVal);
  const ok = await MundoMulti.entrar(salaVal, nombreVal, miTexturaAvatar);
  if (ok) {
    document.getElementById("multiJoinBox").style.display = "none";
    document.getElementById("multiStatusBox").style.display = "block";
    aplicarTexturaJugadorPropio(miTexturaAvatar);
  }
}

document.getElementById("multiJoinBtn")?.addEventListener("click", entrarEnSalaMulti);
// navigator.clipboard solo existe en contexto seguro (https:// o localhost) -- si la web va por
// http:// sin más (como escenas-3d.infodocencia.net de momento), se queda "undefined" y no avisa de
// nada. Con execCommand("copy") sobre un <textarea> oculto funciona también en http://.
function copiarTextoFallback(texto) {
  try {
    const ta = document.createElement("textarea");
    ta.value = texto;
    ta.style.position = "fixed"; ta.style.opacity = "0"; ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch { return false; }
}
function copiarTexto(texto) {
  if (window.isSecureContext && navigator.clipboard) {
    return navigator.clipboard.writeText(texto).then(() => true).catch(() => copiarTextoFallback(texto));
  }
  return Promise.resolve(copiarTextoFallback(texto));
}
document.getElementById("multiCopyLinkBtn")?.addEventListener("click", () => {
  const salaVal = document.getElementById("multiSalaInput").value.trim();
  if (!salaVal) return;
  const url = location.origin + location.pathname + "?sala=" + encodeURIComponent(salaVal);
  copiarTexto(url).then((ok) => {
    document.getElementById("multiEstado").textContent = ok ? "Enlace copiado." : ("No se pudo copiar solo -- cópialo a mano: " + url);
  });
});
document.getElementById("multiChatInput")?.addEventListener("keydown", (e) => {
  e.stopPropagation();
  if (e.key === "Escape") { e.target.blur(); cerrarPanelParaEscribir(); return; }
  if (e.key === "Enter") {
    const input = e.target;
    const texto = input.value.trim();
    const paraSid = document.getElementById("multiChatPara")?.value || undefined;
    if (texto && window.MundoMulti) MundoMulti.enviarChat(texto, paraSid);
    input.value = "";
  }
});

document.getElementById("multiArchivoBtn")?.addEventListener("click", () => {
  const paraSid = document.getElementById("multiChatPara")?.value || "";
  if (!paraSid) { document.getElementById("multiEstado").textContent = "Elige primero a quién (selector \"Para\") -- los archivos solo se mandan en privado."; return; }
  document.getElementById("multiArchivoInput").click();
});
document.getElementById("multiArchivoInput")?.addEventListener("change", (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f || !window.MundoMulti) return;
  const paraSid = document.getElementById("multiChatPara")?.value || "";
  if (!paraSid) { document.getElementById("multiEstado").textContent = "Elige primero a quién (selector \"Para\")."; return; }
  MundoMulti.enviarArchivo(f, paraSid, (err) => {
    document.getElementById("multiEstado").textContent = err ? ("No se pudo enviar: " + err.message) : "";
  });
});

function bloquearOrientacionActual() {
  if (!screen.orientation || typeof screen.orientation.lock !== "function") return;
  const tipoActual = screen.orientation.type || "";
  const deseado = tipoActual.indexOf("portrait") === 0 ? "portrait" : "landscape";
  screen.orientation.lock(deseado)
    .then(() => { playOrientationLocked = true; })
    .catch(() => { playOrientationLocked = false; /* no soportado o requiere pantalla completa: seguimos sin bloqueo */ });
}
function desbloquearOrientacion() {
  if (!playOrientationLocked) return;
  playOrientationLocked = false;
  if (screen.orientation && typeof screen.orientation.unlock === "function") {
    try { screen.orientation.unlock(); } catch { /* ignorar */ }
  }
}
function enterPlayMode() {
  const player = findCharacterRecord();
  if (!player) { alertBox('Añade un objeto marcado como "Personaje (detector)" en Colisionador (por ejemplo, un Trabajador) para poder jugar.', "info"); return; }
  isPlaying = false; updatePlayButton();
  playerRecordId = player.id;
  prePlayState = {
    camPos: camera.position.clone(), camTarget: orbitControls.target.clone(),
    playerPos: player.object3D.position.clone(), playerQuat: player.object3D.quaternion.clone(),
  };
  playYaw = 0; playPitch = -0.25; firstPersonMode = false;
  playCamDist = CHASE_RADIUS;
  npcClockTime = 0; overlapState = new Map();
  sceneObjects.forEach((r) => { if (r.kind === "light" && r.__gizmoMesh) r.__gizmoMesh.visible = false; }); // la bombilla-gizmo es solo ayuda de edición, no debe verse jugando
  sceneObjects.forEach((r) => { if (r.kind === "camerapath") r.object3D.visible = false; }); // el tubo-guía del recorrido es solo ayuda de edición, no debe verse jugando
  // Igual que la posición/rotación/opacidad (que ya vuelven a su __origin al salir de Jugar), el texto
  // de un rótulo puede mutar en caliente durante la partida (acción "Red" con respuesta -> rótulo) --
  // sin este snapshot, ese cambio se quedaba pegado al volver al editor (discrepancia con el resto de
  // elementos animados, que sí se reinician solos). Se guarda aquí y se restaura en exitPlayMode().
  sceneObjects.forEach((r) => { if (r.kind === "text3d") r.__playOriginText = r.text3d.text; });
  // Igual que el texto de un rótulo: la imagen de un objeto de Imagen puede cambiar en caliente
  // durante la partida (acción "Imagen desde variable" o Red en modo "imagen") -- mismo snapshot y
  // restauración al salir de Jugar.
  sceneObjects.forEach((r) => { if (r.kind === "image") r.__playOriginImageBase64 = r.imageBase64; });
  playKeys = { w: false, a: false, s: false, d: false, shift: false, space: false, arrowUp: false, arrowDown: false, arrowLeft: false, arrowRight: false };
  playVelY = 0; playGrounded = true;
  playScore = 0; interactionPanelOpen = false; nearestInteractiveId = null;
  gameVariables = {}; networkActionsAllowed = false; networkGateAsked = false;
  catDisguiseActive = false; catKeyBuffer = ""; // el huevo de pascua siempre arranca "apagado" al entrar
  touchJoystickId = null; touchJoystickVec = { x: 0, y: 0 }; touchLookId = null;
  const startGY = computeGroundY(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.id);
  if (startGY !== null) player.object3D.position.y = startGY;
  orbitControls.enabled = false;
  transformControls.detach();
  document.getElementById("app").classList.add("playing");
  document.getElementById("playFeed").innerHTML = "";
  document.getElementById("playScore").textContent = "Puntuación: 0";
  document.getElementById("interactPrompt").style.display = "none";
  document.getElementById("shotPrompt").style.display = "none";
  document.getElementById("interactPanel").style.display = "none";
  document.getElementById("interactPanel").innerHTML = "";
  document.getElementById("touchJoystick").style.display = isTouchDevice() ? "block" : "none";
  document.getElementById("touchJumpBtn").style.display = isTouchDevice() ? "flex" : "none";
  document.getElementById("touchViewBtn").style.display = isTouchDevice() ? "flex" : "none";
  document.getElementById("touchInteractBtn").style.display = "none";
  document.getElementById("touchShootBtn").style.display = "none";
  document.getElementById("touchLaserBtn").style.display = isTouchDevice() ? "flex" : "none";
  document.getElementById("touchLaserBtn").classList.remove("activo");
  document.getElementById("touchDroneBtn").style.display = isTouchDevice() ? "flex" : "none";
  document.getElementById("touchDroneBtn").classList.remove("activo");
  document.getElementById("touchDroneDownBtn").style.display = "none";
  nearestShotTargetId = null;
  punteroLaserActivo = false;
  droneModeActive = false;
  cameraPathActive = null;
  document.getElementById("cameraPathCaption").style.display = "none";
  document.getElementById("playDebugInfo").style.display = isTouchDevice() ? "block" : "none"; // temporal: para diagnosticar el bug de camara tras rotar movil
  document.getElementById("playInstructions").style.display = isTouchDevice() ? "none" : "block";
  document.getElementById("playClickToStart").style.display = "flex";
  isPlayModeActive = true;
  abrirPanelMulti();
  // Bloquea la orientación a la que tenga el móvil AHORA MISMO (la que sea): así, mientras se
  // juega, no puede volver a rotar y no hay ningún resize/orientationchange que gestionar durante
  // la partida -- el viewport queda fijo desde este instante hasta salir. Si el navegador no lo
  // permite (Safari/iOS no lo soporta; algunos exigen pantalla completa primero), sencillamente no
  // se bloquea y seguimos con el resize reforzado de abajo como red de seguridad, igual que antes.
  bloquearOrientacionActual();
  resizeRenderer();
  // El grid CSS puede tardar un frame (o más, en algunos móviles) en
  // colapsar de verdad tras añadir la clase "playing". Reforzamos el resize
  // en cuanto el layout se asiente para evitar una cámara con aspect ratio
  // erróneo (pantalla negra / geometría deformada) justo al entrar -- esto
  // es lo que "reinicia" el viewport del juego al tamaño real del visor del
  // editor en el instante de entrar, como si la página se acabara de cargar.
  requestAnimationFrame(resizeRenderer);
  setTimeout(resizeRenderer, 200);
  // Recorrido de cámara automático al iniciar la partida (p.ej. un traveling de apertura que
  // sobrevuela el escenario): si hay alguno marcado, se dispara nada más entrar.
  const autoplayRec = Array.from(sceneObjects.values()).find((r) => r.kind === "camerapath" && r.cameraPathData && r.cameraPathData.autoplay);
  if (autoplayRec) playCameraPath(autoplayRec);
}

function exitPlayMode() {
  if (!isPlayModeActive) return;
  // En modo visitante (sala protegida con PIN, aún sin desbloquear) Escape NO debe devolver al
  // editor completo -- eso es justo lo que el PIN impide. En su lugar, se ofrece introducirlo.
  if (salaModoVisitante) { intentarDesbloquearEdicionSala(); return; }
  isPlayModeActive = false;
  interactionPanelOpen = false;
  cameraPathActive = null;
  desbloquearOrientacion();
  cerrarPanelMulti();
  stopBgMusic();
  // Al salir de Jugar, TODO vuelve a como estaba antes de entrar -- cualquier acción disparada durante
  // la partida (un ascensor que se quedó arriba, algo que desapareció con un fade...) se deshace sola.
  // Sin esto había que resetear cada pieza a mano en el editor después de cada prueba.
  sceneObjects.forEach((r) => {
    if (r.videoEl) r.videoEl.pause();
    if (r.id === playerRecordId) return; // el jugador se restaura aparte, un poco más abajo
    r.__oneShot = null;
    r.__spin = null;
    r.__standObj = null; r.__standPrevY = null;
    const origin = r.object3D.userData.__origin;
    if (origin) { r.object3D.position.copy(origin.pos); r.object3D.quaternion.copy(origin.quat); }
    const baseOpacity = (r.opacity != null ? r.opacity : 1);
    r.colorMaterials.forEach((m) => { m.opacity = baseOpacity; m.visible = baseOpacity > 0.01; m.emissiveIntensity = 0; });
    if (r.kind === "text3d" && r.__playOriginText !== undefined && r.text3d.text !== r.__playOriginText) {
      r.text3d.text = r.__playOriginText;
      rebuildText3D(r);
    }
    r.__playOriginText = undefined;
    if (r.kind === "image" && r.__playOriginImageBase64 !== undefined && r.imageBase64 !== r.__playOriginImageBase64) {
      swapImageTexture(r, r.__playOriginImageBase64, null);
    }
    r.__playOriginImageBase64 = undefined;
    if (r.mixer) { r.mixer.stopAllAction(); r.mixer.update(0); }
    if (r.kind === "light" && r.__gizmoMesh) r.__gizmoMesh.visible = true;
    if (r.kind === "camerapath") r.object3D.visible = true;
  });
  document.getElementById("interactPanel").style.display = "none";
  document.getElementById("interactPrompt").style.display = "none";
  document.getElementById("shotPrompt").style.display = "none";
  if (document.pointerLockElement === canvas) document.exitPointerLock();
  const player = sceneObjects.get(playerRecordId);
  if (player && prePlayState) {
    player.object3D.position.copy(prePlayState.playerPos);
    player.object3D.quaternion.copy(prePlayState.playerQuat);
    player.colorMaterials.forEach((m) => { m.visible = true; });
    player.__standObj = null; player.__standPrevY = null;
    if (player.__playerClipAction) { player.__playerClipAction.stop(); player.__playerClipAction = null; }
    if (player.mixer) player.mixer.update(0);
    // Quita cualquier resto del huevo de pascua al salir: nunca debe quedar visible en el editor normal
    // ni colarse en un guardado de proyecto (el campo __catGroupObj no forma parte del serializador).
    if (player.__catGroupObj) {
      player.object3D.remove(player.__catGroupObj);
      player.__catGroupObj = null;
    }
    player.object3D.children.forEach((c) => { c.visible = true; });
  }
  catDisguiseActive = false; catKeyBuffer = "";
  if (prePlayState) { camera.position.copy(prePlayState.camPos); orbitControls.target.copy(prePlayState.camTarget); }
  orbitControls.enabled = true;
  document.getElementById("app").classList.remove("playing");
  playerRecordId = null;
  resizeRenderer();
  renderHierarchy(); renderProps();
}

function playFeedToast(text) {
  const feed = document.getElementById("playFeed");
  const div = document.createElement("div");
  div.className = "toast";
  div.textContent = text;
  feed.prepend(div);
  while (feed.children.length > 4) feed.removeChild(feed.lastChild);
  setTimeout(() => { if (div.parentNode) div.remove(); }, 5000);
}

function escPlayHtml(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function toggleFirstPerson() {
  if (cameraPathActive) return;
  firstPersonMode = !firstPersonMode;
  // Reseteamos la inclinación vertical al cambiar de vista: si el jugador
  // dejó la cámara mirando muy arriba/abajo en un modo, al pasar al otro
  // puede quedar "mirando a Cuenca" (desorientado). El giro horizontal
  // (hacia dónde miras) se conserva, solo se nivela la vertical.
  playPitch = -0.25;
  // También reseteamos la distancia de cámara suavizada (playCamDist) a su valor de referencia: si
  // por lo que sea se había quedado corta (p. ej. tras un giro de pantalla con las medidas del visor
  // temporalmente mal, o un techo/plataforma cercano que la recortó) se queda así de forma persistente
  // -- solo se corrige poco a poco, frame a frame. Cambiar de vista es un buen momento para partir de
  // cero en vez de arrastrar ese estado.
  playCamDist = CHASE_RADIUS;
  const p = sceneObjects.get(playerRecordId);
  if (p) {
    p.colorMaterials.forEach((m) => { m.visible = !firstPersonMode; });
    if (p.__catGroupObj) p.__catGroupObj.visible = catDisguiseActive && !firstPersonMode;
  }
}

function updateCameraPathCaption() {
  const el = document.getElementById("cameraPathCaption");
  if (!el) return;
  if (cameraPathActive && cameraPathActive.caption) {
    el.textContent = cameraPathActive.caption;
    el.style.display = "block";
  } else {
    el.style.display = "none";
  }
}

function playCameraPath(rec) {
  if (!isPlayModeActive || !rec || rec.kind !== "camerapath") return;
  const cpd = rec.cameraPathData;
  if (!cpd || !cpd.path || !cpd.path.nodes || cpd.path.nodes.length < 2) return;
  rec.object3D.updateMatrixWorld(true);
  const worldPts = cpd.path.nodes.map((n) => rec.object3D.localToWorld(new THREE.Vector3(n.x, n.y, n.z)));
  const curve = new THREE.CatmullRomCurve3(worldPts, !!cpd.path.closed, "catmullrom", 0.5);
  cameraPathActive = {
    curve, duration: Math.max(0.5, cpd.duration || 6), elapsed: 0,
    caption: cpd.caption || "", lookAtTargetId: cpd.lookAtTargetId || null,
    wasFirstPerson: firstPersonMode, wasDrone: droneModeActive,
  };
  droneModeActive = false; // el recorrido de cámara tiene prioridad sobre cualquier otro modo de vista
  nearestInteractiveId = null; updateInteractPrompt();
  nearestShotTargetId = null; updateShotPrompt();
  updateCameraPathCaption();
  playFeedToast("🎥 " + rec.name);
}

function endCameraPath() {
  if (!cameraPathActive) return;
  const cp = cameraPathActive;
  cameraPathActive = null;
  droneModeActive = cp.wasDrone;
  firstPersonMode = cp.wasFirstPerson;
  updateCameraPathCaption();
}

function toggleDroneMode() {
  if (cameraPathActive) return;
  droneModeActive = !droneModeActive;
  const p = sceneObjects.get(playerRecordId);
  if (droneModeActive) {
    droneCamPos.copy(camera.position); // arranca justo donde estaba mirando, sin salto
    nearestInteractiveId = null;
    nearestShotTargetId = null;
  }
  if (p) {
    p.colorMaterials.forEach((m) => { m.visible = !(firstPersonMode || droneModeActive); });
    if (p.__catGroupObj) p.__catGroupObj.visible = catDisguiseActive && !(firstPersonMode || droneModeActive);
  }
  updateInteractPrompt();
  updateShotPrompt();
  const btn = document.getElementById("touchDroneBtn");
  if (btn) btn.classList.toggle("activo", droneModeActive);
  const downBtn = document.getElementById("touchDroneDownBtn");
  if (downBtn) downBtn.style.display = (droneModeActive && isTouchDevice()) ? "flex" : "none";
  playFeedToast(droneModeActive
    ? "🛸 Modo dron: ACTIVADO -- vista libre de inspección, sin suelo ni colisión (sin disparo ni interacción mientras está activo)"
    : "🚶 Modo dron: desactivado -- vuelves a tu personaje");
}

function updateInteractPrompt() {
  const el = document.getElementById("interactPrompt");
  const btn = document.getElementById("touchInteractBtn");
  const showTouchBtn = isTouchDevice() && !interactionPanelOpen && !!nearestInteractiveId;
  if (interactionPanelOpen || !nearestInteractiveId) {
    el.style.display = "none";
    if (btn) btn.style.display = "none";
    return;
  }
  const rec = sceneObjects.get(nearestInteractiveId);
  if (!rec || !rec.interactive || !rec.interactive.enabled) {
    el.style.display = "none";
    if (btn) btn.style.display = "none";
    return;
  }
  el.textContent = "[E] " + (rec.interactive.prompt || "Interactuar");
  el.style.display = isTouchDevice() ? "none" : "block"; // en táctil el botón redondo sustituye al aviso de teclado
  if (btn) btn.style.display = showTouchBtn ? "flex" : "none";
}

function updateShotPrompt() {
  const el = document.getElementById("shotPrompt");
  const btn = document.getElementById("touchShootBtn");
  if (!el) return;
  const rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;
  if (!rec || !rec.interactive || !rec.interactive.onShotAction) {
    el.style.display = "none";
    if (btn) btn.style.display = "none";
    return;
  }
  el.textContent = "🎯 [F] Disparar";
  el.style.display = isTouchDevice() ? "none" : "block";
  if (btn) btn.style.display = isTouchDevice() ? "flex" : "none";
}

function attemptShoot() {
  if (!isPlayModeActive || interactionPanelOpen || droneModeActive || cameraPathActive) return;
  const rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;
  if (!rec || !rec.interactive || !rec.interactive.onShotAction) return;
  triggerOneShotAction(rec, rec.interactive.onShotAction);
  playFeedToast("🎯 " + rec.name);
}

function toggleLaserPuntero() {
  if (!isPlayModeActive) return;
  punteroLaserActivo = !punteroLaserActivo;
  playFeedToast(punteroLaserActivo ? "🔴 Puntero láser: ACTIVADO -- los demás ven dónde apuntas" : "⚪ Puntero láser: desactivado");
  const btn = document.getElementById("touchLaserBtn");
  if (btn) btn.classList.toggle("activo", punteroLaserActivo);
}

function playOneShotSound(base64, volume) {
  if (!base64) return;
  try {
    const audio = new Audio(base64);
    audio.volume = (volume === undefined || volume === null || isNaN(volume)) ? 1 : volume;
    audio.play().catch(() => {});
  } catch (e) { /* ignora fallos de reproducción (formato no soportado, etc.) */ }
}

// Recorre TODAS las acciones del proyecto (por objeto, encadenadas con .next, en paralelo) en
// busca de acciones "Red" (fetchUrl) y devuelve las URLs distintas que usan -- para poder
// mostrárselas a quien abre el proyecto ANTES de que salga ninguna petición real (ver
// gateNetworkActions()).
function collectFetchUrls() {
  const urls = [];
  const seen = new Set();
  function scan(a) {
    if (!a) return;
    if (a.type === "fetchUrl" && a.url && !seen.has(a.url)) { seen.add(a.url); urls.push(a.url); }
    if (a.next) scan(a.next);
    (a.parallel || []).forEach(scan);
  }
  sceneObjects.forEach((rec) => {
    (rec.actions || []).forEach(scan);
    if (rec.interactive) {
      scan(rec.interactive.onInteractAction);
      scan(rec.interactive.onShotAction);
      (rec.interactive.choices || []).forEach((c) => scan(c.action));
    }
  });
  return urls;
}

// Puerta de permiso de red para la acción "Red": apagada de fábrica, como el JS de un lector de
// PDF -- la decide quien ABRE el proyecto (no quien lo creó), la primera vez que una acción de red
// intenta dispararse de verdad en ESTA sesión de juego (no al entrar en Modo jugar sin más: si
// nunca llegas a activar esa acción, nunca se pregunta). Se recuerda solo para esta sesión --
// volver a entrar en Modo jugar, o recargar la página, vuelve a preguntar.
function gateNetworkActions() {
  if (networkGateAsked) return Promise.resolve(networkActionsAllowed);
  networkGateAsked = true;
  const urls = collectFetchUrls();
  if (!urls.length) { networkActionsAllowed = false; return Promise.resolve(false); }
  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:2000; display:flex; align-items:center; justify-content:center;";
    const box = document.createElement("div");
    box.style.cssText = "background:#181b22; border:1px solid #333947; border-radius:8px; padding:18px; width:min(480px,92vw); color:#eee; font-family:inherit;";
    box.innerHTML = '<h3 style="margin-top:0;">🌐 Este escenario quiere conectarse a internet</h3>' +
      '<p style="font-size:13px; opacity:.85;">Alguna acción de este proyecto envía o recibe datos de:</p>' +
      '<ul style="font-size:12.5px; opacity:.9; max-height:140px; overflow:auto; padding-left:18px; margin:8px 0;">' +
      urls.map((u) => '<li style="word-break:break-all; margin-bottom:4px;">' + String(u).replace(/</g, "&lt;") + '</li>').join('') +
      '</ul>' +
      '<p style="font-size:12.5px; opacity:.7;">Si no confías en el origen de este escenario, deniégalo -- el juego sigue funcionando igual, solo sin esas acciones concretas.</p>' +
      '<div style="display:flex; gap:8px; margin-top:12px;">' +
      '<button type="button" id="netGateAllow" style="flex:1; padding:8px; border-radius:6px; border:1px solid #3a6a3a; background:#1c2b1c; color:#eee; cursor:pointer;">Permitir</button>' +
      '<button type="button" id="netGateDeny" style="flex:1; padding:8px; border-radius:6px; border:1px solid #444; background:#22252d; color:#eee; cursor:pointer;">Denegar</button>' +
      '</div>';
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    document.getElementById("netGateAllow").addEventListener("click", () => { networkActionsAllowed = true; overlay.remove(); resolve(true); });
    document.getElementById("netGateDeny").addEventListener("click", () => { networkActionsAllowed = false; overlay.remove(); resolve(false); });
  });
}

function triggerOneShotAction(rec, action, batchStartedAt) {
  if (!action || !action.type || action.type === "none") return;
  // batchStartedAt: cuando esta llamada viene de "en paralelo" de OTRA acción hermana (ver las
  // llamadas "forEach(pa => triggerOneShotAction(rec, pa, startedAt))" más abajo), heredamos el
  // MISMO instante exacto que la hermana, en vez de medir uno nuevo con performance.now(). Antes,
  // cada acción en paralelo media su propio instante por separado -- casi idénticos, pero no
  // exactamente iguales -- y la fusión de __oneShot (ver más abajo) solo los reconocía como "de la
  // misma tanda" dentro de una tolerancia de 50ms. Con 2 acciones paralelas solía bastar, pero con
  // 3 o más (p. ej. girar + correr + desaparecer a la vez sobre CesiumMan) el trabajo extra de las
  // primeras podía hacer que la última se disparase pasados esos 50ms, dejase de reconocerse como
  // "de la misma tanda", y creara un __oneShot NUEVO desde cero -- pisando sin fundir el mover/girar
  // que las hermanas ya habían dejado (volvía a la posición/rotación de partida, sin moverse, con
  // solo la animación de caminar -- que va por un sistema aparte -- dando la sensación de avance).
  // Heredar el mismo instante en vez de medirlo de nuevo hace la fusión exacta y ya no depende del
  // tiempo que tarde en procesarse cada hermana.
  const startedAt = batchStartedAt || performance.now();
  if (action.type === "sound") {
    playOneShotSound(action.soundBase64, action.volume);
    if (action.next) triggerOneShotAction(rec, action.next); // el sonido es instantáneo: encadena ya
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt)); // en paralelo: se disparan ya, sin esperar
    return;
  }
  if (action.type === "toggleVideo") {
    // Instantáneo, como el sonido -- alterna reproducir/pausar el vídeo de destino (mismo efecto
    // que pulsar E encima de un vídeo, pero disparable desde OTRA pieza, en paralelo, o a distancia
    // con el rayo de disparo).
    let videoRecs = [rec];
    if (action.target === "player") videoRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if (action.target === "__group__") {
      const gV = rec.groupId ? objectGroups.get(rec.groupId) : null;
      videoRecs = gV ? gV.memberIds.map((mid) => sceneObjects.get(mid)).filter(Boolean) : [rec];
    } else if (action.target && action.target !== "self") {
      const foundV = sceneObjects.get(action.target);
      if (!foundV) { console.warn('Don Claude 3D: acción "vídeo" con objetivo "' + action.target + '" no encontrado (referencia rota) -- no se ejecuta.'); videoRecs = []; }
      else videoRecs = [foundV];
    }
    videoRecs.forEach((r) => { if (r.kind === "video") toggleVideoPlayback(r); });
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "setVariable") {
    // Instantáneo -- asigna a gameVariables[action.varName] el resultado de evaluar action.expr
    // con evalSafeExpr() (ver arriba): puede referenciar la propia variable ("monedas + 1") u
    // otras ("total = monedasA + monedasB"), siempre dentro de la caja reducida de + - * / ().
    const val = evalSafeExpr(action.expr, gameVariables);
    if (action.varName) gameVariables[action.varName] = val;
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "setImageVar") {
    // Asíncrona (construir la textura nueva tarda un tick, aunque sea un data URL) -- el next/parallel
    // se disparan cuando la imagen queda puesta, no antes. action.target es el id de un objeto de
    // Imagen concreto (elegido en el formulario, no "self"/"player"/"__group__" -- una imagen se pone
    // en un objeto de Imagen específico, no "en el objeto que dispara la acción" por defecto).
    const chainOnImg = () => {
      if (action.next) triggerOneShotAction(rec, action.next);
      (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa));
    };
    const dataUrlImg = action.varName ? gameVariables[action.varName] : null;
    const targetImgRec = action.target ? sceneObjects.get(action.target) : null;
    if (!dataUrlImg || typeof dataUrlImg !== "string" || dataUrlImg.indexOf("data:image") !== 0 || !targetImgRec || targetImgRec.kind !== "image") {
      chainOnImg();
      return;
    }
    swapImageTexture(targetImgRec, dataUrlImg, chainOnImg);
    return;
  }
  if (action.type === "setTextVar") {
    // Igual que "Imagen desde variable" pero para un rótulo de Texto 3D -- SIN red de por medio (a
    // diferencia de la acción Red en modo "rótulo"). Instantánea y síncrona: rebuildText3D no tiene
    // ninguna espera async (a diferencia de construir una textura de imagen desde cero).
    const textVarVal = action.varName ? gameVariables[action.varName] : undefined;
    const targetTxtRec = action.target ? sceneObjects.get(action.target) : null;
    if (textVarVal !== undefined && targetTxtRec && targetTxtRec.kind === "text3d") {
      targetTxtRec.text3d.text = String(textVarVal);
      rebuildText3D(targetTxtRec);
    }
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "fetchUrl") {
    // Asíncrona por naturaleza (petición de red) -- el encadenado (.next/.parallel) se dispara
    // cuando la petición TERMINA (éxito, fallo, o denegada por la puerta de permiso), nunca antes,
    // para que una acción siguiente que dependa de la variable/rótulo resultante no se adelante.
    const chainOn = () => {
      if (action.next) triggerOneShotAction(rec, action.next);
      (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    };
    gateNetworkActions().then((allowed) => {
      if (!allowed || !action.url) { chainOn(); return; }
      const urlFinal = interpolateVars(action.url, gameVariables);
      if (urlFinal.indexOf("mailto:") === 0) {
        // mailto: no es una petición HTTP (fetch la rechazaría) -- se abre el cliente de correo
        // del jugador con asunto/cuerpo ya rellenados. interpolateVars ya pasó cada {{variable}}
        // por encodeURIComponent, así que el texto UTF-8 (acentos, emoji...) llega bien codificado
        // al "?subject=...&body=...".
        window.open(urlFinal, "_blank", "noopener,noreferrer");
        chainOn();
        return;
      }
      const method = action.method === "POST" ? "POST" : "GET";
      const parts = urlFinal.split("?");
      const fetchPromise = method === "POST"
        ? fetch(parts[0], { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: parts[1] || "" })
        : fetch(urlFinal);
      fetchPromise.then((res) => res.text()).then((text) => {
        if (action.responseMode === "label") {
          let targetRecsF = [rec];
          if (action.target === "player") targetRecsF = [sceneObjects.get(playerRecordId)].filter(Boolean);
          else if (action.target && action.target !== "self" && action.target !== "__group__") { const f = sceneObjects.get(action.target); targetRecsF = f ? [f] : []; }
          targetRecsF.forEach((r) => { if (r.kind === "text3d") { r.text3d.text = text; rebuildText3D(r); } });
        } else if (action.responseMode === "imagen") {
          // El endpoint debe devolver el data URL COMPLETO como texto plano (data:image/...;base64,...),
          // igual que "rótulo" espera texto plano -- leer con res.text() en vez de tratar la respuesta
          // como binario evita corromper los bytes de la imagen al pasar por JS.
          let targetRecsImg = [rec];
          if (action.target === "player") targetRecsImg = [sceneObjects.get(playerRecordId)].filter(Boolean);
          else if (action.target && action.target !== "self" && action.target !== "__group__") { const fi = sceneObjects.get(action.target); targetRecsImg = fi ? [fi] : []; }
          targetRecsImg = targetRecsImg.filter((r) => r.kind === "image");
          if (!targetRecsImg.length || text.indexOf("data:image") !== 0) return;
          // Devolvemos una promesa para que el .finally(chainOn) de más abajo espere de verdad a que
          // la textura termine de construirse (asíncrono, como el resto de esta acción).
          return new Promise((resolve) => {
            let pendingImg = targetRecsImg.length;
            targetRecsImg.forEach((r) => { swapImageTexture(r, text, () => { pendingImg--; if (pendingImg === 0) resolve(); }); });
          });
        } else if (action.responseMode === "variables" && action.varMap) {
          let parsed = null;
          try { parsed = JSON.parse(text); } catch (e) { parsed = null; }
          const lines = String(action.varMap).split("\n");
          if (parsed && typeof parsed === "object") {
            lines.forEach((line) => {
              const eq = line.indexOf("=");
              if (eq < 0) return;
              const field = line.slice(0, eq).trim(), varName = line.slice(eq + 1).trim();
              if (!field || !varName) return;
              const v = field.split(".").reduce((o, k) => (o && typeof o === "object") ? o[k] : undefined, parsed);
              if (v !== undefined) gameVariables[varName] = v;
            });
          } else if (lines[0]) {
            const eq0 = lines[0].indexOf("=");
            const firstVar = (eq0 >= 0 ? lines[0].slice(eq0 + 1) : lines[0]).trim();
            if (firstVar) gameVariables[firstVar] = text;
          }
        }
      }).catch(() => { /* fallo de red: no rompe la partida, sencillamente no llega nada */ }).finally(chainOn);
    });
    return;
  }
  if (action.type === "copyToClipboard") {
    // Instantáneo -- copia texto (con {{variables}} interpoladas SIN codificar, a diferencia de
    // fetchUrl/mailto: aquí no es una URL) al portapapeles del jugador.
    copiarTexto(interpolateVarsPlain(action.text, gameVariables));
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "if") {
    // Instantáneo -- evalúa action.expr con evalSafeExpr() (admite comparaciones/&&/||/!, no solo
    // aritmética) y dispara la rama "then" o "else" (cualquiera puede faltar). El "next"/"parallel"
    // de la propia acción "if" se disparan siempre, independientemente de qué rama se tomó -- son
    // el "después de decidir", no parte de la decisión.
    const condVal = evalSafeExpr(action.expr, gameVariables);
    const isTrue = typeof condVal === "string" ? (condVal !== "" && condVal !== "0") : !!condVal;
    const branch = isTrue ? action.then : action.else;
    if (branch) triggerOneShotAction(rec, branch, startedAt);
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "for") {
    // Dispara action.body "count" veces seguidas (tope de seguridad: 1000 -- esto no es un bucle
    // "en el tiempo", se disparan todas ya mismo, así que sin tope una cifra mal escrita podría
    // colgar la pestaña). Si hay varName, esa variable vale 0,1,2... en cada vuelta -- útil dentro
    // del cuerpo repetido (p. ej. un "Variable" que sume varName a un total, o una URL con {{i}}).
    const countRaw = evalSafeExpr(String(action.count != null ? action.count : "0"), gameVariables);
    const count = Math.max(0, Math.min(1000, Math.floor(typeof countRaw === "number" ? countRaw : (parseFloat(countRaw) || 0))));
    const body = action.body;
    // Caso especial "mover/rotar a punto (relativo)": ese "to" es un delta fijo respecto al origen
    // del objeto, calculado UNA vez al crear la acción -- no "avanza X más desde donde esté ahora".
    // Dispararlo N veces seguidas (mismo startedAt) fusiona todas en el MISMO __oneShot con el MISMO
    // destino (origen + delta) una y otra vez -- de ahí que "for" pareciera hacer solo un giro/paso
    // en vez de N. OJO: un solo tween "amplificado" (destino = origen + N*delta) NO sirve para rotar
    // -- un quaternion no distingue 450 grados de 90 (solo existe la orientación final, sin memoria
    // de vueltas), así que ese único giro colapsaría al camino corto de siempre. La única forma
    // correcta es encadenar N tramos reales -- cada uno con destino origen + paso*delta -- uno detrás
    // de otro (cada tramo, al ser un giro/paso corto y sin ambigüedad, avanza de verdad); el total
    // tarda N * duración (no la duración sola), pero SÍ se ve dar la vuelta N veces de verdad.
    if (body && (body.type === "moveTo" || body.type === "rotateTo") && body.relative && body.to && count > 0) {
      if (action.varName) gameVariables[action.varName] = count - 1;
      let headStep = null, prevStep = null;
      for (let step = 1; step <= count; step++) {
        const stepAction = {
          type: body.type, target: body.target, relative: true, ease: body.ease,
          to: { x: body.to.x * step, y: body.to.y * step, z: body.to.z * step },
          duration: body.duration,
        };
        if (!headStep) headStep = stepAction;
        if (prevStep) prevStep.next = stepAction;
        prevStep = stepAction;
      }
      const extras = (action.parallel || []).slice();
      if (action.next) extras.push(action.next);
      prevStep.next = body.next || null;
      prevStep.parallel = extras;
      triggerOneShotAction(rec, headStep, startedAt);
      return;
    }
    for (let __fi = 0; __fi < count; __fi++) {
      if (action.varName) gameVariables[action.varName] = __fi;
      if (body) triggerOneShotAction(rec, body, startedAt);
    }
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "screenMessage") {
    // Aviso narrativo en pantalla (no bloquea WASD) -- el next/parallel se disparan al cerrarse
    // (automático o manual), no al mostrarse, para que encadene bien con lo que venga después.
    showScreenMessage(interpolateVarsPlain(action.text, gameVariables), action.autoDismissSec || 0, () => {
      if (action.next) triggerOneShotAction(rec, action.next);
      (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa));
    });
    return;
  }
  if (action.type === "askInput") {
    // Entrada libre en pantalla (bloquea WASD mientras está abierta) -- igual que arriba, el
    // next/parallel se disparan al cerrarse (al Enviar o Cancelar), con las variables ya escritas.
    showAskInput(interpolateVarsPlain(action.promptText, gameVariables), action.varName, action.allowFile, action.fileVarName, () => {
      if (action.next) triggerOneShotAction(rec, action.next);
      (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa));
    });
    return;
  }
  if (action.type === "cameraPath") {
    // Instantáneo, como el sonido -- arranca el recorrido de cámara del objeto de destino (siempre
    // un objeto "camerapath": no admite "player" ni "__group__", un recorrido vive en un único objeto).
    let cpRec = rec;
    if (action.target && action.target !== "self" && action.target !== "player" && action.target !== "__group__") {
      const foundCp = sceneObjects.get(action.target);
      if (!foundCp) { console.warn('Don Claude 3D: acción "recorrido de cámara" con objetivo "' + action.target + '" no encontrado (referencia rota) -- no se ejecuta.'); cpRec = null; }
      else cpRec = foundCp;
    }
    if (cpRec) playCameraPath(cpRec);
    if (action.next) triggerOneShotAction(rec, action.next);
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "playClip") {
    // Reproduce una animación (clip GLB) UNA VEZ (o en bucle) al dispararse -- a diferencia del
    // "Reproducir animación" de la línea de tiempo propia del objeto (que se evalúa por scrub cada
    // frame según npcClockTime), esto usa el reproductor normal del mixer en tiempo real, así que
    // no pisa ni depende de rec.actions/checkpoints -- puede convivir con ellos siempre que el
    // objeto de destino no tenga SU PROPIA animación de línea de tiempo (lo normal para un
    // personaje/prop pensado para dispararse desde fuera, como un maniquí o un NPC decorativo).
    // OJO: esto solo anima el ESQUELETO (huesos) -- no traslada rec.object3D.position ni un
    // milímetro (la mayoría de los clips de "caminar" de un GLB no llevan movimiento de raíz
    // incluido). Si además quieres que el personaje SE DESPLACE de verdad mientras "camina", hace
    // falta OTRA acción en paralelo de tipo "Mover a punto" -- esta por sí sola solo mueve las
    // piernas en el sitio.
    let clipRecs = [rec];
    if (action.target === "player") clipRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if (action.target === "__group__") {
      const gC = rec.groupId ? objectGroups.get(rec.groupId) : null;
      clipRecs = gC ? gC.memberIds.map((mid) => sceneObjects.get(mid)).filter(Boolean) : [rec];
    } else if (action.target && action.target !== "self") {
      const foundC = sceneObjects.get(action.target);
      if (!foundC) { console.warn('Don Claude 3D: acción "animación" con objetivo "' + action.target + '" no encontrado (referencia rota) -- no se ejecuta.'); clipRecs = []; }
      else clipRecs = [foundC];
    }
    const clipDurationMs = Math.max(50, (action.duration || 1) * 1000);
    clipRecs.forEach((r, idx) => {
      if (!r.mixer || !r.clips || !r.clips.length) return;
      const clip = r.clips.find((c) => c.name === action.clipName) || r.clips[0];
      if (!clip) return;
      if (r.__activeClipAction) r.__activeClipAction.stop();
      const clipAction = r.mixer.clipAction(clip);
      clipAction.reset();
      clipAction.setLoop(action.loop ? THREE.LoopRepeat : THREE.LoopOnce, action.loop ? Infinity : 1);
      clipAction.clampWhenFinished = !action.loop;
      clipAction.play();
      r.__activeClipAction = clipAction;
      r.__oneShotClip = { startedAt, durationMs: action.loop ? null : clipDurationMs, nextAction: idx === 0 ? (action.next || null) : null, chainRec: rec };
    });
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  if (action.type === "spin") {
    // Giro continuo en bucle (p. ej. una rueda) -- no es un "de aquí a allí" como moveTo/rotateTo, es una
    // rotación local que se va acumulando cada frame mientras dure, encima de lo que sea que haga el objeto
    // por otro lado (p. ej. el desplazamiento rígido de su grupo). Ver updateSpins().
    let spinRecs = [rec];
    if (action.target === "player") spinRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if (action.target === "__group__") {
      const g = rec.groupId ? objectGroups.get(rec.groupId) : null;
      // a diferencia de mover/rotar en grupo (cuerpo rígido alrededor del ancla), cada pieza gira sobre SU
      // PROPIO eje local -- así 4 ruedas puestas a girar en paralelo cada una da vueltas en su sitio.
      spinRecs = g ? g.memberIds.map((mid) => sceneObjects.get(mid)).filter(Boolean) : [rec];
    } else if (action.target && action.target !== "self") {
      const foundSpin = sceneObjects.get(action.target);
      if (!foundSpin) { console.warn('Don Claude 3D: acción "girar" con objetivo "' + action.target + '" no encontrado (referencia rota, probablemente de un objeto borrado/reemplazado) -- no se ejecuta.'); spinRecs = []; }
      else spinRecs = [foundSpin];
    }
    if (!spinRecs.length) return;
    const axisVec = action.axis === "x" ? new THREE.Vector3(1, 0, 0) : action.axis === "z" ? new THREE.Vector3(0, 0, 1) : new THREE.Vector3(0, 1, 0);
    const speedRad = deg2rad(action.speed || 0);
    const durationMs = Math.max(50, (action.duration || 1) * 1000);
    spinRecs.forEach((r, idx) => {
      r.__spin = { axisVec, speedRad, startedAt, durationMs, nextAction: idx === 0 ? (action.next || null) : null, chainRec: rec };
    });
    (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt));
    return;
  }
  let targetRecs = [rec];
  // groupRigid: cuando el destino es "todo el grupo" con mover/rotar, cada pieza no salta al MISMO
  // punto/ángulo -- se calcula el desplazamiento/rotación del objeto ancla (rec, el que lleva el disparador)
  // y se aplica ese mismo movimiento relativo a todas las piezas, como un cuerpo rígido (el carro entero,
  // con sus ruedas y tuercas, se desplaza/gira junto -- cada una mantiene su posición relativa al ancla).
  let groupRigid = null;
  if (action.target === "player") targetRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
  else if (action.target === "__group__") {
    const g = rec.groupId ? objectGroups.get(rec.groupId) : null;
    targetRecs = g ? g.memberIds.map((mid) => sceneObjects.get(mid)).filter(Boolean) : [rec];
    if (action.type === "moveTo" && action.to) {
      groupRigid = { tipo: "mover", delta: new THREE.Vector3(action.to.x, action.to.y, action.to.z).sub(rec.object3D.position) };
    } else if (action.type === "rotateTo" && action.to) {
      const toQuat = new THREE.Quaternion().setFromEuler(new THREE.Euler(deg2rad(action.to.x), deg2rad(action.to.y), deg2rad(action.to.z)));
      const deltaQuat = toQuat.clone().multiply(rec.object3D.quaternion.clone().invert());
      groupRigid = { tipo: "rotar", deltaQuat, ancla: rec.object3D.position.clone() };
    }
  }
  else if (action.target && action.target !== "self") {
    const found = sceneObjects.get(action.target);
    if (!found) { console.warn('Don Claude 3D: acción con objetivo "' + action.target + '" no encontrado (referencia rota, probablemente de un objeto borrado/reemplazado) -- no se ejecuta, en vez de aplicarse por error sobre quien la disparó.'); targetRecs = []; }
    else targetRecs = [found];
  }
  if (!targetRecs.length) return;
  const duration = Math.max(50, (action.duration || 1) * 1000);
  targetRecs.forEach((targetRec, idx) => {
    // Fusión con un __oneShot YA en marcha sobre la MISMA pieza: si varias acciones distintas (p. ej.
    // "Rotar a ángulo", "Mover a punto" y "Aparecer/desaparecer") se disparan EN PARALELO sobre el
    // mismo objeto, cada una por su lado solo sabe tocar SU aspecto (posición, rotación u opacidad) --
    // sin esto, cada nueva en llegar pisaba entera la __oneShot que había dejado la anterior (solo hay
    // UNA ranura __oneShot por objeto), así que de 2 o 3 acciones a la vez solo se veía la última. Con
    // el mismo "startedAt" heredado de la hermana (ver arriba), la comparación es EXACTA -- no una
    // tolerancia de tiempo -- así que da igual cuántas acciones paralelas se combinen ni cuánto tarde
    // en procesarse cada una: todas fusionan sobre el mismo __oneShot en vez de pisarse.
    const existingOS = targetRec.__oneShot;
    const mergeable = existingOS && existingOS.startedAt === startedAt;
    const fromPos = mergeable ? existingOS.fromPos.clone() : targetRec.object3D.position.clone();
    const fromQuat = mergeable ? existingOS.fromQuat.clone() : targetRec.object3D.quaternion.clone();
    const fromOpacity = mergeable ? existingOS.fromOpacity : (targetRec.colorMaterials.length ? targetRec.colorMaterials[0].opacity : 1);
    let toPos = mergeable ? existingOS.toPos.clone() : fromPos.clone();
    let toQuat = mergeable ? existingOS.toQuat.clone() : fromQuat.clone();
    let toOpacity = mergeable ? existingOS.toOpacity : fromOpacity;
    let flashDef = mergeable ? existingOS.flashDef : null;
    const mergedDuration = mergeable ? Math.max(existingOS.duration, duration) : duration;
    if (groupRigid && groupRigid.tipo === "mover") {
      toPos = fromPos.clone().add(groupRigid.delta);
    } else if (groupRigid && groupRigid.tipo === "rotar") {
      const rel = fromPos.clone().sub(groupRigid.ancla).applyQuaternion(groupRigid.deltaQuat);
      toPos = groupRigid.ancla.clone().add(rel);
      toQuat = groupRigid.deltaQuat.clone().multiply(fromQuat);
    } else if (action.relative && action.type === "moveTo" && action.to) {
      const originPos = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.pos : targetRec.object3D.position;
      toPos = originPos.clone().add(new THREE.Vector3(action.to.x, action.to.y, action.to.z));
    } else if (action.relative && action.type === "rotateTo" && action.to) {
      const originQuat = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.quat : targetRec.object3D.quaternion;
      const oe = new THREE.Euler().setFromQuaternion(originQuat);
      const ne = new THREE.Euler(oe.x + deg2rad(action.to.x), oe.y + deg2rad(action.to.y), oe.z + deg2rad(action.to.z));
      toQuat = new THREE.Quaternion().setFromEuler(ne);
    } else {
      if (action.type === "moveTo" && action.to) toPos.set(action.to.x, action.to.y, action.to.z);
      if (action.type === "rotateTo" && action.to) toQuat.setFromEuler(new THREE.Euler(deg2rad(action.to.x), deg2rad(action.to.y), deg2rad(action.to.z)));
    }
    if (action.type === "fade") toOpacity = action.to;
    if (action.type === "flash") flashDef = { color: action.color, repeat: action.repeat || 3 };
    targetRec.__oneShot = {
      startedAt, duration: mergedDuration,
      fromPos, toPos, fromQuat, toQuat, fromOpacity, toOpacity,
      ease: "smooth", flashDef,
      // el encadenado ("next") se dispara UNA sola vez por activación, no una vez por miembro del grupo -- si
      // esta pieza ya llevaba un "next" pendiente de la acción hermana con la que se acaba de fusionar, se
      // conserva (no lo pisamos con null solo porque idx!==0 en ESTA llamada).
      nextAction: idx === 0 ? (action.next || null) : (mergeable ? existingOS.nextAction : null), chainRec: rec,
    };
  });
  (action.parallel || []).forEach((pa) => triggerOneShotAction(rec, pa, startedAt)); // en paralelo: mismo instante exacto, sin esperar el duration de arriba
}

function updateSpins(dt) {
  const toChain = [];
  for (const rec of sceneObjects.values()) {
    const sp = rec.__spin;
    if (!sp) continue;
    rec.object3D.rotateOnAxis(sp.axisVec, sp.speedRad * dt);
    if (performance.now() - sp.startedAt >= sp.durationMs) {
      if (sp.nextAction) toChain.push({ chainRec: sp.chainRec, nextAction: sp.nextAction });
      rec.__spin = null;
    }
  }
  toChain.forEach((c) => triggerOneShotAction(c.chainRec, c.nextAction));
}

function updateOneShotClips(dt) {
  const toChain = [];
  for (const rec of sceneObjects.values()) {
    const oc = rec.__oneShotClip;
    if (!oc) continue;
    if (rec.mixer) rec.mixer.update(dt);
    if (oc.durationMs !== null && performance.now() - oc.startedAt >= oc.durationMs) {
      if (oc.nextAction) toChain.push({ chainRec: oc.chainRec, nextAction: oc.nextAction });
      rec.__oneShotClip = null;
    }
  }
  toChain.forEach((c) => triggerOneShotAction(c.chainRec, c.nextAction));
}

function updateOneShotAnimations() {
  const nowMs = performance.now();
  const toChain = []; // { chainRec, nextAction } — se disparan DESPUÉS de recorrer todos, para no reentrar a medio bucle
  for (const rec of sceneObjects.values()) {
    const os = rec.__oneShot;
    if (!os) continue;
    const p = clamp((nowMs - os.startedAt) / os.duration, 0, 1);
    const pe = easeVal(p, os.ease);
    rec.object3D.position.copy(os.fromPos).lerp(os.toPos, pe);
    // Si esta animación no implica ningún cambio de rotación (p. ej. un movimiento de
    // grupo rígido, que solo traslada), NO reasignamos el quaternion cada frame: si lo
    // hiciéramos, borraríamos sin querer cualquier giro en curso (__spin) sobre la misma
    // pieza -- por ejemplo, una rueda que forma parte del grupo que se traslada Y ADEMÁS
    // gira sobre sí misma. Antes de este guard, ese giro se veía "congelado" porque cada
    // frame se le devolvía a la fuerza su orientación de partida justo después de que
    // updateSpins() la hubiera hecho avanzar.
    if (!os.fromQuat.equals(os.toQuat)) {
      rec.object3D.quaternion.copy(os.fromQuat).slerp(os.toQuat, pe);
    }
    if (rec.colorMaterials.length) {
      const op = lerp(os.fromOpacity, os.toOpacity, pe);
      rec.colorMaterials.forEach((m) => { m.opacity = op; m.visible = op > 0.01; });
    }
    if (os.flashDef) {
      const intensity = Math.abs(Math.sin(p * Math.PI * os.flashDef.repeat));
      if (intensity > 0.02 && rec.colorMaterials.length) {
        const c = new THREE.Color(os.flashDef.color || "#ff3b3b");
        rec.colorMaterials.forEach((m) => { m.emissive = c; m.emissiveIntensity = intensity; });
      } else if (rec.colorMaterials.length) {
        rec.colorMaterials.forEach((m) => { if (m.emissiveIntensity) m.emissiveIntensity = 0; });
      }
    }
    if (p >= 1) {
      if (os.nextAction) toChain.push({ chainRec: os.chainRec, nextAction: os.nextAction });
      rec.__oneShot = null;
    }
  }
  toChain.forEach((c) => triggerOneShotAction(c.chainRec, c.nextAction));
}

function openInteractionLink(rec) {
  const url = (rec.interactive.url || "").trim();
  if (!url) { playFeedToast("⚠️ " + rec.name + ": no tiene ninguna URL configurada."); return; }
  window.open(url, "_blank", "noopener,noreferrer");
  playFeedToast("🔗 Abriendo enlace: " + rec.name);
  triggerOneShotAction(rec, rec.interactive.onInteractAction);
}

function openInteractionPanel(id) {
  const rec = sceneObjects.get(id);
  if (!rec || !rec.interactive || !rec.interactive.enabled) return;
  if (rec.kind === "video") { toggleVideoPlayback(rec); return; }
  if (rec.interactive.kind === "link") { openInteractionLink(rec); return; }
  if (rec.interactive.kind === "text") {
    const oia = rec.interactive.onInteractAction;
    const bareText = !(rec.interactive.text && rec.interactive.text.trim());
    // "Preguntar" y "Mensaje en pantalla" ya traen su PROPIA ventanita completa (con su propio
    // bloqueo/desbloqueo de puntero) -- abrir TAMBIÉN el panel de "leer cartel" por encima daba dos
    // overlays a la vez (bug real, visto jugando la partida exportada: el cartel y la pregunta se
    // superponían, y encima el aviso de "clic para jugar" se colaba por debajo de exitPointerLock).
    // Mismo camino que el texto vacío: se dispara al instante, sin panel de cartel.
    const ownsOverlay = oia && (oia.type === "askInput" || oia.type === "screenMessage");
    if (bareText || ownsOverlay) {
      triggerOneShotAction(rec, oia);
      return;
    }
  }
  interactionPanelOpen = true;
  document.getElementById("interactPrompt").style.display = "none";
  if (rec.interactive.kind === "text") triggerOneShotAction(rec, rec.interactive.onInteractAction);
  const panel = document.getElementById("interactPanel");
  let html = '<div class="box"><h4>' + escPlayHtml(rec.name) + "</h4>";
  html += "<p>" + escPlayHtml(rec.interactive.text || "(sin texto)") + "</p>";
  const isChoice = rec.interactive.kind === "choice" && rec.interactive.choices.length;
  if (isChoice) {
    rec.interactive.choices.forEach((c, i) => {
      html += '<div class="opt" data-idx="' + i + '">' + (i + 1) + ". " + escPlayHtml(c.label || "Opción " + (i + 1)) + "</div>";
    });
    html += '<div class="sub">Toca una opción, o pulsa su número (Esc para cerrar sin elegir)</div>';
  } else {
    html += '<button type="button" class="actBtn" id="interactContinueBtn">Continuar</button>';
    html += '<div class="sub">Toca el botón, o pulsa E o Esc para continuar</div>';
  }
  html += "</div>";
  panel.innerHTML = html;
  panel.dataset.forId = id;
  panel.style.display = "flex";
  if (isChoice) {
    panel.querySelectorAll(".opt").forEach((el) => {
      el.addEventListener("click", () => chooseInteractionOption(parseInt(el.dataset.idx, 10)));
    });
  } else {
    const btn = document.getElementById("interactContinueBtn");
    if (btn) btn.addEventListener("click", closeInteractionPanel);
  }
}

function closeInteractionPanel() {
  interactionPanelOpen = false;
  const panel = document.getElementById("interactPanel");
  panel.style.display = "none";
  panel.innerHTML = "";
}

// Mensaje narrativo en pantalla (acción "screenMessage"): un cuadro centrado, igual de estilo que
// el panel de interacción, pero SIN bloquear WASD/puntero -- es un aviso, no un formulario. Si
// autoDismissSec es 0/nulo hace falta cerrarlo a mano (botón, E o Esc); si no, se cierra solo.
let screenMsgDismissFn = null;
function showScreenMessage(text, autoDismissSec, onDone) {
  const panel = document.getElementById("screenMsgOverlay");
  if (!panel) { if (onDone) onDone(); return; }
  let done = false;
  const finish = () => {
    if (done) return;
    done = true;
    screenMsgDismissFn = null;
    panel.style.display = "none";
    panel.innerHTML = "";
    if (onDone) onDone();
  };
  let html = '<div class="box"><p>' + escPlayHtml(text) + "</p>";
  if (!autoDismissSec) {
    html += '<button type="button" class="actBtn" id="screenMsgCloseBtn">Continuar</button>';
    html += '<div class="sub">Toca el botón, o pulsa E o Esc para continuar</div>';
  }
  html += "</div>";
  panel.innerHTML = html;
  panel.style.display = "flex";
  if (autoDismissSec) {
    setTimeout(finish, Math.max(200, autoDismissSec * 1000));
  } else {
    const btn = document.getElementById("screenMsgCloseBtn");
    if (btn) btn.addEventListener("click", finish);
    screenMsgDismissFn = finish;
  }
}

// Entrada libre en pantalla (acción "askInput"): pregunta + campo de texto (y, opcionalmente, un
// adjunto de imagen en base64, con el MISMO tope de tamaño que el chat -- MAX_ASK_ARCHIVO_BYTES).
// A diferencia del mensaje narrativo, ESTA sí bloquea WASD/puntero mientras está abierta (como el
// panel de sala/chat -- mismo patrón de exitPointerLock/requestPointerLock). El texto del jugador
// se escapa siempre con escPlayHtml antes de tocar innerHTML; el archivo se valida por tamaño antes
// de leerlo, y se guarda como texto (data URL) en la variable indicada -- para mandarlo de verdad
// hace falta una acción "Red" en modo POST (nunca GET: un data URL de imagen es demasiado largo
// para cualquier URL).
function showAskInput(promptText, varName, allowFile, fileVarName, onDone) {
  askInputActive = true;
  if (document.pointerLockElement === canvas) document.exitPointerLock();
  const panel = document.getElementById("askInputOverlay");
  let pendingFileDataUrl = null;
  const finish = () => {
    askInputActive = false;
    panel.style.display = "none";
    panel.innerHTML = "";
    if (isPlayModeActive && !isTouchDevice()) {
      const req = canvas.requestPointerLock();
      if (req && typeof req.catch === "function") req.catch(() => { document.getElementById("playClickToStart").style.display = "flex"; });
    }
    if (onDone) onDone();
  };
  let html = '<div class="box"><p>' + escPlayHtml(promptText || "") + "</p>";
  html += '<input type="text" id="askInputText" style="width:100%; box-sizing:border-box; padding:8px; border-radius:6px; border:1px solid var(--border); background:#0f1116; color:var(--text); margin-bottom:8px;" maxlength="500">';
  if (allowFile) {
    html += '<p class="sub" id="askInputFileInfo">Sin archivo adjunto.</p>';
    html += '<input type="file" id="askInputFile" accept="image/*" style="display:none;">';
    html += '<button type="button" class="small" id="askInputFileTrigger" style="margin-bottom:8px;">📎 Adjuntar imagen</button>';
  }
  html += '<div class="flexRow" style="gap:8px;"><button type="button" class="actBtn" id="askInputSend" style="flex:1;">Enviar</button><button type="button" class="small" id="askInputCancel" style="flex:1;">Cancelar</button></div>';
  html += '<div class="sub">Enter para enviar, Esc para cancelar</div></div>';
  panel.innerHTML = html;
  panel.style.display = "flex";
  const textEl = document.getElementById("askInputText");
  textEl.focus();
  if (allowFile) {
    document.getElementById("askInputFileTrigger").addEventListener("click", () => document.getElementById("askInputFile").click());
    document.getElementById("askInputFile").addEventListener("change", (e) => {
      const file = e.target.files[0];
      const info = document.getElementById("askInputFileInfo");
      if (!file) return;
      if (file.size > MAX_ASK_ARCHIVO_BYTES) {
        if (info) info.textContent = "Demasiado grande (máx. " + Math.round(MAX_ASK_ARCHIVO_BYTES / 1024) + "KB) -- no se adjunta.";
        pendingFileDataUrl = null;
        e.target.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onload = () => { pendingFileDataUrl = reader.result; if (info) info.textContent = "Adjunto: " + file.name; };
      reader.onerror = () => { if (info) info.textContent = "No se pudo leer el archivo."; };
      reader.readAsDataURL(file);
    });
  }
  const doSend = () => {
    if (varName) gameVariables[varName] = textEl.value;
    if (allowFile && fileVarName && pendingFileDataUrl) gameVariables[fileVarName] = pendingFileDataUrl;
    finish();
  };
  document.getElementById("askInputSend").addEventListener("click", doSend);
  document.getElementById("askInputCancel").addEventListener("click", finish);
  textEl.addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); doSend(); }
    else if (e.key === "Escape") { e.preventDefault(); finish(); }
  });
}

function chooseInteractionOption(index) {
  const panel = document.getElementById("interactPanel");
  const rec = sceneObjects.get(panel.dataset.forId);
  if (!rec || !rec.interactive || rec.interactive.kind !== "choice") { closeInteractionPanel(); return; }
  const choice = rec.interactive.choices[index];
  if (!choice) return;
  const pts = choice.points || 0;
  playScore += pts;
  document.getElementById("playScore").textContent = "Puntuación: " + playScore;
  playFeedToast((pts >= 0 ? "✅ " : "⚠️ ") + rec.name + ": " + choice.label + " (" + (pts >= 0 ? "+" : "") + pts + " pts)");
  triggerOneShotAction(rec, choice.action);
  closeInteractionPanel();
}

document.getElementById("btnPlayMode").addEventListener("click", enterPlayMode);
document.getElementById("btnExitPlayMode").addEventListener("click", exitPlayMode);
document.getElementById("playClickToStart").addEventListener("click", () => {
  document.getElementById("playClickToStart").style.display = "none";
  if (bgMusicEl) bgMusicEl.play().catch(() => {}); else startBgMusic();
  if (isTouchDevice()) return; // en táctil no hay puntero de ratón que capturar; el joystick/arrastre llevan el control
  const req = canvas.requestPointerLock();
  if (req && typeof req.catch === "function") {
    req.catch(() => {
      alertBox("El navegador no concedió el control del ratón sobre este visor. Puedes seguir moviéndote con WASD; vuelve a pulsar sobre el visor para reintentar mirar alrededor con el ratón.", "info");
      if (isPlayModeActive) document.getElementById("playClickToStart").style.display = "flex";
    });
  }
});
document.addEventListener("pointerlockchange", () => {
  if (isTouchDevice()) return;
  if (isPlayModeActive && document.pointerLockElement !== canvas) {
    // askInput también suelta el puntero a propósito (exitPointerLock, como el panel de sala/chat) --
    // sin este chequeo, el aviso "Clic para empezar a jugar" aparecía POR ENCIMA del cuadro de
    // "Preguntar", tapándolo a medias y obligando a un clic extra que rompía el flujo (bug real,
    // detectado jugando la partida exportada de verdad: la pregunta y el aviso de clic se superponían).
    if (!multiPanelInputActive && !askInputActive) {
      document.getElementById("playClickToStart").style.display = "flex";
    }
    // Pausa la música al perder el ratón (p. ej. al pulsar Esc): algunos navegadores desbloquean el
    // puntero de forma nativa sin llegar a disparar el keydown de "escape" que usamos para salir del todo.
    if (bgMusicEl) bgMusicEl.pause();
  }
});
document.addEventListener("mousemove", (e) => {
  if (!isPlayModeActive || document.pointerLockElement !== canvas || cameraPathActive) return;
  playYaw -= (e.movementX || 0) * 0.0022;
  playPitch -= (e.movementY || 0) * 0.0022;
  playPitch = clamp(playPitch, -1.0, 1.0);
});

// Joystick táctil (movimiento): el dedo que toca dentro de su base queda "pinchado" a él por
// touch.identifier hasta que se levanta, con independencia de otros dedos en pantalla.
const touchJoystickEl = document.getElementById("touchJoystick");
const playDebugInfoEl = document.getElementById("playDebugInfo"); // temporal, ver comentario en tick()
const touchJoystickKnobEl = document.getElementById("touchJoystickKnob");
const TOUCH_JOYSTICK_RADIUS = 46;
touchJoystickEl.addEventListener("touchstart", (e) => {
  if (!isPlayModeActive) return;
  if (multiPanelInputActive) cerrarPanelParaEscribir(); // volver a tocar el juego cierra el teclado si estaba escribiendo
  const t = e.changedTouches[0];
  touchJoystickId = t.identifier;
  e.preventDefault();
}, { passive: false });
function updateTouchJoystickFromTouch(t) {
  const rect = touchJoystickEl.getBoundingClientRect();
  const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
  let dx = t.clientX - cx, dy = t.clientY - cy;
  const dist = Math.hypot(dx, dy);
  if (dist > TOUCH_JOYSTICK_RADIUS) { dx = (dx / dist) * TOUCH_JOYSTICK_RADIUS; dy = (dy / dist) * TOUCH_JOYSTICK_RADIUS; }
  touchJoystickKnobEl.style.transform = "translate(" + dx + "px," + dy + "px)";
  touchJoystickVec = { x: clamp(dx / TOUCH_JOYSTICK_RADIUS, -1, 1), y: clamp(-dy / TOUCH_JOYSTICK_RADIUS, -1, 1) };
}
function resetTouchJoystick() {
  touchJoystickId = null;
  touchJoystickVec = { x: 0, y: 0 };
  touchJoystickKnobEl.style.transform = "translate(0,0)";
}
// Arrastre táctil para mirar: cualquier toque que NO caiga en el joystick ni en el botón de interactuar
// (esos ya capturan/detienen su propio touchstart) se interpreta como "mirar", igual que el ratón.
canvas.addEventListener("touchstart", (e) => {
  if (!isPlayModeActive || touchLookId !== null) return;
  if (multiPanelInputActive) cerrarPanelParaEscribir(); // volver a tocar el juego cierra el teclado si estaba escribiendo
  const t = e.changedTouches[0];
  touchLookId = t.identifier;
  touchLookLast = { x: t.clientX, y: t.clientY };
}, { passive: true });
window.addEventListener("touchmove", (e) => {
  if (!isPlayModeActive) return;
  for (const t of e.changedTouches) {
    if (t.identifier === touchJoystickId) { updateTouchJoystickFromTouch(t); e.preventDefault(); }
    else if (t.identifier === touchLookId) {
      const dx = t.clientX - touchLookLast.x, dy = t.clientY - touchLookLast.y;
      if (!cameraPathActive) {
        playYaw -= dx * 0.0055;
        playPitch -= dy * 0.0055;
        playPitch = clamp(playPitch, -1.0, 1.0);
      }
      touchLookLast = { x: t.clientX, y: t.clientY };
      e.preventDefault();
    }
  }
}, { passive: false });
function releaseTouch(e) {
  for (const t of e.changedTouches) {
    if (t.identifier === touchJoystickId) resetTouchJoystick();
    if (t.identifier === touchLookId) touchLookId = null;
  }
}
window.addEventListener("touchend", releaseTouch);
window.addEventListener("touchcancel", releaseTouch);
document.getElementById("touchInteractBtn").addEventListener("touchstart", (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (multiPanelInputActive) cerrarPanelParaEscribir();
  if (nearestInteractiveId) openInteractionPanel(nearestInteractiveId);
});
document.getElementById("touchShootBtn").addEventListener("touchstart", (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (multiPanelInputActive) cerrarPanelParaEscribir();
  attemptShoot();
});
document.getElementById("touchLaserBtn").addEventListener("touchstart", (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (multiPanelInputActive) cerrarPanelParaEscribir();
  toggleLaserPuntero();
});
document.getElementById("touchDroneBtn").addEventListener("touchstart", (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (multiPanelInputActive) cerrarPanelParaEscribir();
  toggleDroneMode();
});
const touchDroneDownBtnEl = document.getElementById("touchDroneDownBtn");
touchDroneDownBtnEl.addEventListener("touchstart", (e) => { e.preventDefault(); playKeys.shift = true; });
touchDroneDownBtnEl.addEventListener("touchend", (e) => { e.preventDefault(); playKeys.shift = false; });
touchDroneDownBtnEl.addEventListener("touchcancel", () => { playKeys.shift = false; });
const touchJumpBtnEl = document.getElementById("touchJumpBtn");
touchJumpBtnEl.addEventListener("touchstart", (e) => {
  e.preventDefault();
  if (multiPanelInputActive) cerrarPanelParaEscribir(); // si no, el teclado se queda abierto tapando el juego
  playKeys.space = true;
});
touchJumpBtnEl.addEventListener("touchend", (e) => { e.preventDefault(); playKeys.space = false; });
touchJumpBtnEl.addEventListener("touchcancel", () => { playKeys.space = false; });
document.getElementById("touchViewBtn").addEventListener("touchstart", (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (multiPanelInputActive) cerrarPanelParaEscribir();
  toggleFirstPerson();
});

// Gesto secreto táctil para el huevo de pascua del gatito: en móvil no hay teclado para teclear
// "miau", así que tocar 5 veces rápido el marcador de puntuación hace lo mismo. Sigue siendo solo
// del editor — nunca se copia al juego exportado (ver toggleCatEasterEgg).
let catTapTimes = [];
document.getElementById("playScore").addEventListener("click", () => {
  if (!isPlayModeActive) return;
  const now = performance.now();
  catTapTimes.push(now);
  catTapTimes = catTapTimes.filter((t) => now - t < 1500);
  if (catTapTimes.length >= 5) { catTapTimes = []; toggleCatEasterEgg(); }
});

window.addEventListener("keydown", (e) => {
  if (!isPlayModeActive) return;
  const activeId = document.activeElement && document.activeElement.id;
  const enCampoDeTexto = activeId === "multiChatInput" || activeId === "multiSalaInput" || activeId === "multiNombreInput" || activeId === "multiChatPara";
  if (enCampoDeTexto) {
    // Dentro de un campo de texto dejamos que el navegador maneje las teclas con normalidad
    // (incluido Tab, para moverse entre "sala" y "nombre") -- solo interceptamos Escape, para
    // volver al juego sin perder la partida.
    if (e.key === "Escape") { e.target.blur(); cerrarPanelParaEscribir(); }
    return;
  }
  // askInputText tiene su PROPIO listener de keydown (con stopPropagation) para Enter/Esc -- si por
  // lo que sea el evento llegara aquí de todos modos, el chequeo askInputActive de más abajo ya lo
  // absorbe sin hacer nada (no debe cerrarse con la función del panel de sala/chat, que es otra cosa).
  if (e.key === "Tab") {
    // Tab abre/cierra el panel de sala y chat. Lo gestionamos nosotros en vez de confiar en el
    // comportamiento del navegador: Chrome suelta el pointer lock al pulsar Tab (Firefox no),
    // así que dejarlo "a su aire" daba una experiencia distinta (y rota) según el navegador.
    e.preventDefault();
    if (multiPanelInputActive) cerrarPanelParaEscribir(); else abrirPanelParaEscribir();
    return;
  }
  const k = e.key.toLowerCase();
  if (multiPanelInputActive) {
    // Panel abierto pero el foco está en un botón, no en un campo de texto: igualmente no debe
    // colarse ninguna tecla de movimiento hacia el juego.
    if (k === "escape") cerrarPanelParaEscribir();
    return;
  }
  if (askInputActive) {
    // El propio campo de texto ya gestiona Enter/Esc con stopPropagation -- esto es solo red de
    // seguridad para cuando el foco está en otro control del overlay (el botón Adjuntar, etc.).
    return;
  }
  // El mensaje narrativo en pantalla NO bloquea el resto del juego (se puede seguir andando
  // mientras se lee) -- solo intercepta E/Esc para cerrarlo si hace falta cerrarlo a mano; el
  // resto de teclas sigue su curso normal más abajo (WASD, etc.), a diferencia de askInputActive
  // o interactionPanelOpen, que sí bloquean todo lo demás.
  if (screenMsgDismissFn && (k === "e" || k === "escape")) { screenMsgDismissFn(); return; }
  if (interactionPanelOpen) {
    if (k >= "1" && k <= "4") { chooseInteractionOption(parseInt(k, 10) - 1); }
    else if (k === "e" || k === "escape") { closeInteractionPanel(); }
    return;
  }
  if (k.length === 1 && /[a-z]/.test(k)) {
    catKeyBuffer = (catKeyBuffer + k).slice(-4);
    if (catKeyBuffer === "miau") { catKeyBuffer = ""; toggleCatEasterEgg(); }
  }
  if (k === "w") playKeys.w = true;
  if (k === "a") playKeys.a = true;
  if (k === "s") playKeys.s = true;
  if (k === "d") playKeys.d = true;
  if (k === "arrowup") { playKeys.arrowUp = true; e.preventDefault(); }
  if (k === "arrowdown") { playKeys.arrowDown = true; e.preventDefault(); }
  if (k === "arrowleft") { playKeys.arrowLeft = true; e.preventDefault(); }
  if (k === "arrowright") { playKeys.arrowRight = true; e.preventDefault(); }
  if (k === "shift") playKeys.shift = true;
  if (k === " " || k === "spacebar") { playKeys.space = true; e.preventDefault(); }
  if (k === "v") toggleFirstPerson();
  if (k === "c") toggleDroneMode();
  if (k === "e") { if (nearestInteractiveId) openInteractionPanel(nearestInteractiveId); }
  if (k === "f") attemptShoot();
  if (k === "l") toggleLaserPuntero();
  if (k === "escape") exitPlayMode();
});
window.addEventListener("keyup", (e) => {
  if (!isPlayModeActive) return;
  const activeId = document.activeElement && document.activeElement.id;
  const enCampoDeTexto = activeId === "multiChatInput" || activeId === "multiSalaInput" || activeId === "multiNombreInput" || activeId === "multiChatPara" || activeId === "askInputText";
  if (enCampoDeTexto || multiPanelInputActive) return;
  const k = e.key.toLowerCase();
  if (k === "w") playKeys.w = false;
  if (k === "a") playKeys.a = false;
  if (k === "s") playKeys.s = false;
  if (k === "d") playKeys.d = false;
  if (k === "arrowup") playKeys.arrowUp = false;
  if (k === "arrowdown") playKeys.arrowDown = false;
  if (k === "arrowleft") playKeys.arrowLeft = false;
  if (k === "arrowright") playKeys.arrowRight = false;
  if (k === "shift") playKeys.shift = false;
  if (k === " " || k === "spacebar") playKeys.space = false;
});

function collidesSolidAt(x, y, z, half, excludeId) {
  // 'y' es la altura de los PIES del jugador (coincide con el sistema de suelo/rampas: object3D.position.y = altura de apoyo).
  const eps = 0.05;
  const cBox = new THREE.Box3(
    new THREE.Vector3(x - half.x, y, z - half.z),
    new THREE.Vector3(x + half.x, y + half.y * 2, z + half.z)
  );
  for (const rec of sceneObjects.values()) {
    if (rec.id === excludeId) continue;
    if (rec.collider.kind !== "solid") continue;
    // Usa el AABB real de la malla (se adapta a escala/rotación), no un tamaño fijo manual.
    const oBox = new THREE.Box3().setFromObject(rec.object3D);
    // Si los pies del jugador están a la altura de la superficie superior de este sólido (o por encima), está
    // de pie ENCIMA de él (p. ej. un muro que sostiene un piso) — no debe bloquear el paso horizontal ahí arriba.
    if (y >= oBox.max.y - eps) continue;
    if (cBox.intersectsBox(oBox)) return true;
  }
  return false;
}

const groundRaycaster = new THREE.Raycaster();
const cameraRaycaster = new THREE.Raycaster();
const shotRaycaster = new THREE.Raycaster(); // rayo de "disparo a distancia": desde la cámara hacia donde mira la mira (crosshair)
const punteroRaycaster = new THREE.Raycaster(); // rayo del puntero láser multiusuario (contra CUALQUIER objeto, no solo los que tienen acción de disparo)
const SHOT_MAX_DISTANCE = 60;
function computeGroundHit(x, z, fromY, excludeId) {
  // Origen del rayo solo un poco por encima de los pies actuales (no varios metros): así no "ve" ni te sube
  // automáticamente a un suelo/rampa de una planta superior cuando en realidad caminas por debajo de él.
  groundRaycaster.set(new THREE.Vector3(x, fromY + 0.6, z), new THREE.Vector3(0, -1, 0));
  groundRaycaster.far = 60;
  const targets = [ground];
  for (const rec of sceneObjects.values()) {
    if (rec.id === excludeId) continue;
    if (rec.collider.kind === "solid" || rec.collider.kind === "ground") targets.push(rec.object3D);
  }
  const hits = groundRaycaster.intersectObjects(targets, true);
  return hits.length ? { y: hits[0].point.y, object: hits[0].object } : null;
}
function computeGroundY(x, z, fromY, excludeId) {
  const hit = computeGroundHit(x, z, fromY, excludeId);
  return hit ? hit.y : null;
}
// Comprueba la altura actual de UN objeto conocido (p.ej. la plataforma sobre la que ya estábamos
// de pie el frame anterior), con un margen amplio a propósito: aquí no estamos "buscando" suelo
// nuevo (por eso no hay riesgo de detectar el suelo de la planta de arriba), solo confirmando dónde
// ha quedado ESA superficie concreta este frame, se haya movido lo que se haya movido.
function raycastGroundAgainstObject(x, z, fromY, obj) {
  groundRaycaster.set(new THREE.Vector3(x, fromY + 5, z), new THREE.Vector3(0, -1, 0));
  groundRaycaster.far = 20;
  const hits = groundRaycaster.intersectObject(obj, true);
  return hits.length ? hits[0].point.y : null;
}

function computeHeadClearance(x, z, feetY, excludeId) {
  // "Suelo/rampa" (p.ej. una escalera) no bloquea el paso horizontal por diseño (para poder
  // caminar por debajo de una planta superior), pero su cara inclinada SÍ debe golpear la cabeza
  // si te acercas por debajo y el hueco se estrecha (como el techo de una escalera real). Se
  // lanza el rayo un poco por ENCIMA de los pies (no desde los pies mismos) para no "auto-chocar"
  // con la propia rampa cuando ya vas caminando de pie sobre ella.
  const startY = feetY + 0.25;
  groundRaycaster.set(new THREE.Vector3(x, startY, z), new THREE.Vector3(0, 1, 0));
  groundRaycaster.far = 3;
  const targets = [];
  for (const rec of sceneObjects.values()) {
    if (rec.id === excludeId) continue;
    if (rec.collider.kind === "ground") targets.push(rec.object3D);
  }
  if (!targets.length) return Infinity;
  const hits = groundRaycaster.intersectObjects(targets, true);
  return hits.length ? (hits[0].point.y - feetY) : Infinity;
}

function resolveMoveWithCollision(player, dir, dist) {
  const size = player.collider.size || { x: 0.5, y: 1.2, z: 0.5 };
  const half = { x: size.x / 2, y: size.y / 2, z: size.z / 2 };
  const pos = player.object3D.position;
  const y = pos.y;
  const nx = pos.x + dir.x * dist;
  if (!collidesSolidAt(nx, y, pos.z, half, player.id) && computeHeadClearance(nx, pos.z, y, player.id) >= size.y) pos.x = nx;
  const nz = pos.z + dir.z * dist;
  if (!collidesSolidAt(pos.x, y, nz, half, player.id) && computeHeadClearance(pos.x, nz, y, player.id) >= size.y) pos.z = nz;
}

// "Empujón" ligero contra los avatares remotos del multijugador -- no es un motor de físicas real
// (cada visitante resuelve esto solo, con la última posición de red que tiene de los demás, sin
// ninguna autoridad central), pero al acercarte demasiado a alguien te frena/aparta un poco, así
// que si dos se caminan de frente ambos notan que "chocan" en vez de atravesarse.
const RADIO_EMPUJON_PROPIO = 0.3, RADIO_EMPUJON_OTRO = 0.3;
function empujarLejosDeAvataresRemotos(player) {
  if (!window.MundoMulti || !MundoMulti.estaActivo()) return;
  const avatares = MundoMulti.listaAvatares();
  if (!avatares.length) return;
  const pos = player.object3D.position;
  const minDist = RADIO_EMPUJON_PROPIO + RADIO_EMPUJON_OTRO;
  avatares.forEach((avatar) => {
    const dx = pos.x - avatar.position.x, dz = pos.z - avatar.position.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 0.0001 && dist < minDist) {
      const empuje = minDist - dist;
      pos.x += (dx / dist) * empuje;
      pos.z += (dz / dist) * empuje;
    }
  });
  const half = sceneHalfExtent();
  pos.x = clamp(pos.x, -half, half);
  pos.z = clamp(pos.z, -half, half);
}

function updatePlayMode(dt) {
  const player = sceneObjects.get(playerRecordId);
  if (!player) { exitPlayMode(); return; }

  // Resto de objetos: siguen sus acciones en bucle, en tiempo real, ignorando al jugador.
  if (timelineDuration > 0.02) {
    const prevClock = npcClockTime;
    npcClockTime += dt;
    if (npcClockTime > timelineDuration) npcClockTime = npcClockTime % timelineDuration;
    fireDueChainTriggers(prevClock, npcClockTime);
  }
  applyTimeToScene(npcClockTime, { log: false, excludeId: playerRecordId });

  if (cameraPathActive) {
    // Recorrido de cámara en curso: el juego queda "en pausa" -- ni el personaje ni el Modo dron se
    // mueven, solo la cámara viaja por el camino trazado. Posición = punto interpolado del camino;
    // orientación = mira hacia un objeto fijo si se configuró uno, o si no, en la dirección de avance
    // (tangente de la curva) -- así es como se consigue la "rotación de cámara a lo largo del
    // recorrido" sin tener que definir un ángulo a mano en cada nodo.
    const cp = cameraPathActive;
    cp.elapsed += dt;
    const tCp = clamp(cp.elapsed / cp.duration, 0, 1);
    const posCp = cp.curve.getPointAt(tCp);
    camera.position.copy(posCp);
    let lookCp;
    if (cp.lookAtTargetId) {
      const lookRec = sceneObjects.get(cp.lookAtTargetId);
      lookCp = lookRec ? lookRec.object3D.getWorldPosition(new THREE.Vector3()) : posCp.clone().add(cp.curve.getTangentAt(tCp));
    } else {
      lookCp = posCp.clone().add(cp.curve.getTangentAt(tCp));
    }
    camera.lookAt(lookCp);
    if (tCp >= 1) endCameraPath();
  } else if (!interactionPanelOpen && !askInputActive && !multiPanelInputActive && droneModeActive) {
    // Modo dron: la cámara vuela libre, desconectada del personaje -- sin colisión, sin
    // suelo/gravedad. W/S avanzan en la dirección EXACTA a la que miras (incluyendo arriba/abajo,
    // como un dron/pájaro), A/D desplazan en horizontal, Espacio sube y Mayús baja en vertical puro.
    if (playKeys.arrowLeft) playYaw += TURN_SPEED * dt;
    if (playKeys.arrowRight) playYaw -= TURN_SPEED * dt;
    const droneForward = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(playPitch, playYaw, 0, "YXZ"));
    const droneRight = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, playYaw, 0));
    let dMoveZ = 0, dMoveX = 0, dMoveY = 0;
    if (playKeys.w || playKeys.arrowUp) dMoveZ += 1;
    if (playKeys.s || playKeys.arrowDown) dMoveZ -= 1;
    if (playKeys.d) dMoveX += 1;
    if (playKeys.a) dMoveX -= 1;
    if (playKeys.space) dMoveY += 1;
    if (playKeys.shift) dMoveY -= 1;
    dMoveZ += touchJoystickVec.y;
    dMoveX += touchJoystickVec.x;
    const droneDir = new THREE.Vector3()
      .addScaledVector(droneForward, dMoveZ)
      .addScaledVector(droneRight, dMoveX)
      .addScaledVector(new THREE.Vector3(0, 1, 0), dMoveY);
    if (droneDir.lengthSq() > 0.0001) droneCamPos.addScaledVector(droneDir.normalize(), DRONE_SPEED * dt);
    camera.position.copy(droneCamPos);
    camera.rotation.order = "YXZ";
    camera.rotation.set(playPitch, playYaw, 0);
  } else if (!interactionPanelOpen && !askInputActive && !multiPanelInputActive) {
    // Flechas Izq/Der: giran la vista (mismo playYaw que mueve el ratón) — permite recorrer el
    // escenario solo con el teclado, sin depender del pointer lock del ratón.
    if (playKeys.arrowLeft) playYaw += TURN_SPEED * dt;
    if (playKeys.arrowRight) playYaw -= TURN_SPEED * dt;
    // Movimiento del jugador, relativo a la orientación de cámara (playYaw), vía Euler 'YXZ' estándar.
    const forwardVec = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, playYaw, 0));
    const rightVec = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, playYaw, 0));
    let moveZ = 0, moveX = 0;
    if (playKeys.w || playKeys.arrowUp) moveZ += 1;
    if (playKeys.s || playKeys.arrowDown) moveZ -= 1;
    if (playKeys.d) moveX += 1;
    if (playKeys.a) moveX -= 1;
    // Joystick táctil: se suma como un vector continuo (en vez de on/off como las teclas).
    moveZ += touchJoystickVec.y;
    moveX += touchJoystickVec.x;
    const joyMag = Math.hypot(touchJoystickVec.x, touchJoystickVec.y);
    const inputLen = Math.hypot(moveX, moveZ);
    if (inputLen > 0.001) {
      const dir = new THREE.Vector3().addScaledVector(forwardVec, moveZ / inputLen).addScaledVector(rightVec, moveX / inputLen);
      dir.normalize();
      const speed = (playKeys.shift || joyMag > 0.75) ? RUN_SPEED : WALK_SPEED;
      resolveMoveWithCollision(player, dir, speed * dt);
      const half = sceneHalfExtent();
      player.object3D.position.x = clamp(player.object3D.position.x, -half, half);
      player.object3D.position.z = clamp(player.object3D.position.z, -half, half);
      const targetQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, -1), dir);
      if (player.facingOffsetDeg) targetQuat.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), deg2rad(player.facingOffsetDeg)));
      player.object3D.quaternion.slerp(targetQuat, clamp(dt * 10, 0, 1));
    }

    // Animación del personaje (si el modelo importado trae clips): el jugador NO pasa por la
    // línea de tiempo de "acciones" normal (se excluye a propósito en applyTimeToScene, porque
    // esa línea de tiempo es para objetos autónomos, no para algo que tú controlas con WASD), así
    // que sin esto el mixer nunca se actualizaba y una acción "Reproducir animación" puesta sobre
    // el propio personaje no tenía ningún efecto. Aquí se reproduce en tiempo real mientras camina
    // o corre (el primer clip marcado con una acción "playClip", o si no hay ninguna, el primer
    // clip del modelo) y se congela en el último fotograma al pararse, en vez de resetear de golpe.
    if (player.mixer && player.clips && player.clips.length) {
      if (!player.__playerClipAction) {
        const wanted = (player.actions || []).find((a) => a.type === "playClip");
        const clip = (wanted && player.clips.find((c) => c.name === wanted.clipName)) || player.clips[0];
        if (clip) player.__playerClipAction = player.mixer.clipAction(clip).play();
      }
      if (player.__playerClipAction) {
        player.__playerClipAction.paused = !(inputLen > 0.001);
        player.mixer.update(dt);
      }
    }

    // Fuera del "if" de movimiento a propósito: aunque estés quieto, si otro visitante camina
    // hacia ti también debe notarse el empujón, no solo cuando te mueves tú.
    empujarLejosDeAvataresRemotos(player);

    // Suelo/rampas/salto: apoya al personaje sobre la superficie real (raycasting hacia abajo) o aplica gravedad si está en el aire.
    // Si el frame anterior estábamos de pie sobre un objeto concreto (un ascensor, una plataforma
    // en movimiento...), lo comprobamos primero A ÉL con margen amplio y arrastramos al jugador
    // exactamente lo que se haya movido esa superficie. El rayo "general" de detección de suelo
    // usa un margen corto a propósito (para no detectar el suelo de la planta de arriba mientras
    // caminas por debajo), así que en una plataforma que sube deprisa (o tras un pico de dt) podía
    // perder el contacto un instante y dejar al personaje "colarse" a través de ella.
    if (player.__standObj && player.__standObj.parent) {
      const carriedY = raycastGroundAgainstObject(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.__standObj);
      if (carriedY !== null && player.__standPrevY != null) {
        player.object3D.position.y += (carriedY - player.__standPrevY);
      }
    }
    const groundHit = computeGroundHit(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.id);
    const gY = groundHit ? groundHit.y : null;
    const closeToGround = gY !== null && (player.object3D.position.y - gY) < 0.25;
    if (playKeys.space && playGrounded && closeToGround) { playVelY = JUMP_SPEED; playGrounded = false; }
    if (playGrounded && closeToGround) {
      player.object3D.position.y = lerp(player.object3D.position.y, gY, clamp(dt * 15, 0, 1));
      playVelY = 0;
    } else {
      playVelY += GRAVITY * dt;
      player.object3D.position.y += playVelY * dt;
      if (gY !== null && player.object3D.position.y <= gY && playVelY <= 0) {
        player.object3D.position.y = gY; playVelY = 0; playGrounded = true;
      } else {
        playGrounded = false;
      }
    }
    // Recordamos sobre qué objeto y a qué altura quedamos de pie, para poder "arrastrar" al
    // jugador con esa superficie el próximo frame si resulta ser una plataforma en movimiento.
    if (playGrounded && groundHit) {
      player.__standObj = groundHit.object;
      player.__standPrevY = groundHit.y;
    } else {
      player.__standObj = null;
      player.__standPrevY = null;
    }

    // Cámara: primera o tercera persona, orbitando alrededor de playYaw/playPitch (mismo sistema que el movimiento).
    const pivot = player.object3D.position.clone().add(new THREE.Vector3(0, 1.35, 0));
    if (firstPersonMode) {
      camera.position.copy(pivot);
      camera.rotation.order = "YXZ";
      camera.rotation.set(playPitch, playYaw, 0);
    } else {
      // Cámara adaptativa: si el hueco entre el pivote y la posición ideal de la cámara
      // choca con un sólido o un plano de techo/suelo, se acerca hasta justo antes de
      // chocar (como una cámara al hombro) en vez de atravesarlo. También evita que la
      // cámara caiga por debajo del suelo si se mira muy hacia arriba.
      const camDir = new THREE.Vector3().setFromSpherical(new THREE.Spherical(1, Math.PI / 2 - playPitch, playYaw));
      const camTargets = [];
      for (const rec of sceneObjects.values()) {
        if (rec.id === playerRecordId) continue;
        // "ground" incluido a propósito: los techos/pisos superiores suelen ser Planos con
        // colisionador Suelo/rampa (no "Sólido"), y si no se incluyen aquí la cámara los
        // atraviesa igual que le pasaba antes a la cabeza del jugador con las escaleras.
        if (rec.collider.kind === "solid" || rec.collider.kind === "ground") camTargets.push(rec.object3D);
      }
      // Un único rayo por el centro se cuela por rendijas (el hueco de una escalera en el
      // techo, el remate de una esquina...). Lanzamos un pequeño abanico de rayos alrededor
      // de esa dirección central, aproximando el "bulto" de la cámara, y nos quedamos con la
      // distancia más corta de todas: así cualquiera de los bordes cercanos frena la cámara.
      const camUpRef = Math.abs(camDir.y) > 0.98 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
      const camRight = new THREE.Vector3().crossVectors(camDir, camUpRef).normalize();
      const camUp2 = new THREE.Vector3().crossVectors(camRight, camDir).normalize();
      const FAN_SPREAD = 0.4; // metros aprox. de "anchura" de cámara a CHASE_RADIUS de distancia
      // Incluye también las 4 diagonales: en un giro (p.ej. al doblar en lo alto de una
      // escalera en L) la cámara barre un arco, y un abanico solo en cruz puede dejar pasar
      // esquinas/remates que sí pillan las diagonales.
      const sampleOffsets = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [0.7, -0.7], [-0.7, 0.7], [-0.7, -0.7]];
      let rawCamDist = CHASE_RADIUS;
      for (const [rx, ry] of sampleOffsets) {
        const samplePoint = pivot.clone().addScaledVector(camDir, CHASE_RADIUS).addScaledVector(camRight, rx * FAN_SPREAD).addScaledVector(camUp2, ry * FAN_SPREAD);
        const sampleDir = samplePoint.sub(pivot).normalize();
        cameraRaycaster.set(pivot, sampleDir);
        cameraRaycaster.far = CHASE_RADIUS;
        const hits = cameraRaycaster.intersectObjects(camTargets, true);
        if (hits.length) rawCamDist = Math.min(rawCamDist, Math.max(0.5, hits[0].distance - 0.3));
      }
      // Los colisionadores "Suelo/rampa" (rampas, pisos superiores... y ahora también un camino ondulado)
      // cuentan como objetivo de estos rayos a propósito, pero eso significa que sobre un terreno con
      // ondulaciones la distancia "cruda" puede saltar de un frame a otro. Se suaviza aquí (en vez de
      // aplicarla tal cual) para evitar ese temblor -- los topes de suelo/techo de abajo siguen siendo
      // instantáneos, así que nunca se atraviesa nada durante la transición.
      playCamDist = lerp(playCamDist, rawCamDist, clamp(dt * 10, 0, 1));
      let camDist = playCamDist;
      // Los topes de suelo/techo NO deben tocar la Y a pelo: eso deja la cámara en un punto
      // que ya no está sobre la recta pivote→cámara, con la X/Z de una distancia distinta a
      // la Y forzada — resultado: clipping (la cámara "al ras" de un piso, metida en la rampa
      // en ese punto raro). En su lugar, recortamos la MISMA camDist que usa el abanico, así
      // el punto final sigue siendo pivote + camDir*camDist, siempre consistente.
      const tentative = pivot.clone().addScaledVector(camDir, camDist);
      const camFloorY = computeGroundY(tentative.x, tentative.z, pivot.y + 2, playerRecordId);
      if (camFloorY !== null && camDir.y < -0.001) {
        const maxDistFloor = (camFloorY + 0.15 - pivot.y) / camDir.y;
        camDist = Math.max(0.5, Math.min(camDist, maxDistFloor));
      }
      // Alcance del rayo de techo limitado a algo proporcional a la distancia real de la camara
      // (antes 12 unidades, mucho mas que CHASE_RADIUS=4.5: una rampa o plataforma normal bastante
      // alejada del jugador podia detectarse como "techo" sin que hubiera ningun techo bajo de verdad
      // encima). Minimo subido de 0.5 a 1.2: antes, cuanto mas mirabas hacia arriba (mayor camDir.y)
      // mas se cerraba la formula sin mas limite que 0.5, asi que la camara acababa pegada al
      // personaje en vez de simplemente dejar de acercarse mas.
      cameraRaycaster.set(pivot, new THREE.Vector3(0, 1, 0));
      cameraRaycaster.far = CHASE_RADIUS + 1.5;
      const camCeilingHits = cameraRaycaster.intersectObjects(camTargets, true);
      if (camCeilingHits.length && camDir.y > 0.001) {
        const maxDistCeil = (camCeilingHits[0].point.y - 0.2 - pivot.y) / camDir.y;
        camDist = Math.max(1.2, Math.min(camDist, maxDistCeil));
      }
      camera.position.copy(pivot).addScaledVector(camDir, camDist);
      camera.lookAt(pivot);
    }
  }

  // Temporal: lectura en vivo del estado de la cámara en Modo Jugar (solo visible en táctil), para
  // poder diagnosticar el bug de "cámara arriba/dron" al rotar el móvil con datos reales en vez de
  // conjeturas -- una captura de pantalla en el momento en que falla dice en qué variable está el problema.
  if (playDebugInfoEl) {
    playDebugInfoEl.textContent =
      "pitch:" + playPitch.toFixed(3) + " yaw:" + playYaw.toFixed(3) +
      " camDist:" + playCamDist.toFixed(2) +
      " 1a:" + (firstPersonMode ? "si" : "no") +
      " playerY:" + player.object3D.position.y.toFixed(2) +
      " aspect:" + camera.aspect.toFixed(3) +
      " vw:" + viewportWrap.clientWidth + "x" + viewportWrap.clientHeight +
      " win:" + window.innerWidth + "x" + window.innerHeight +
      " orient:" + (screen.orientation ? screen.orientation.type : "?");
  }

  if (window.MundoMulti && MundoMulti.estaActivo()) {
    // Puntero láser: hacia dónde apunta la mira en el mundo, para que otros visitantes lo vean
    // (formación/presentación multiusuario). SOLO se calcula y retransmite mientras el jugador lo
    // tiene activado a propósito (tecla L / botón 🔴 en táctil) -- si estuviera siempre encendido,
    // con varios visitantes a la vez la pantalla se llena de rayos aunque nadie quiera señalar nada
    // en ese momento. Desactivado, se manda "null" (así el resto deja de ver tu rayo enseguida).
    let miPuntero = null;
    if (punteroLaserActivo) {
      const punteroTargets = [];
      for (const rec of sceneObjects.values()) {
        if (rec.id === playerRecordId) continue;
        if (!rec.object3D) continue;
        punteroTargets.push(rec.object3D);
      }
      if (punteroTargets.length) {
        const punteroDir = new THREE.Vector3();
        camera.getWorldDirection(punteroDir);
        punteroRaycaster.set(camera.position, punteroDir);
        punteroRaycaster.far = SHOT_MAX_DISTANCE;
        const punteroHits = punteroRaycaster.intersectObjects(punteroTargets, true);
        if (punteroHits.length) miPuntero = { x: punteroHits[0].point.x, y: punteroHits[0].point.y, z: punteroHits[0].point.z };
      }
    }
    MundoMulti.enviarPosicion(player.object3D.position.x, player.object3D.position.y, player.object3D.position.z, playYaw, catDisguiseActive ? "gato" : null, miPuntero);
  }

  // Objetos interactivos: encuentra el más cercano dentro de su radio de detección. En Modo dron
  // y durante un recorrido de cámara no se juega ni se interactúa, así que ni se calcula.
  if (droneModeActive || cameraPathActive) {
    nearestInteractiveId = null;
    updateInteractPrompt();
    nearestShotTargetId = null;
    updateShotPrompt();
  } else {
  let nearest = null, nearestDist = Infinity;
  for (const rec of sceneObjects.values()) {
    if (rec.id === playerRecordId) continue;
    if (!rec.interactive || !rec.interactive.enabled) continue;
    const d = rec.object3D.position.distanceTo(player.object3D.position);
    if (d <= (rec.interactive.radius || 2) && d < nearestDist) { nearest = rec; nearestDist = d; }
  }
  nearestInteractiveId = nearest ? nearest.id : null;
  updateInteractPrompt();

  // Disparo a distancia: rayo desde la cámara hacia donde apunta la mira (crosshair), contra
  // cualquier objeto con una acción "al disparar" configurada -- funciona a distancia (hasta
  // SHOT_MAX_DISTANCE), a diferencia de la E que exige proximidad. Independiente del sistema
  // de interactivo/E: un objeto puede tener una, otra, o ambas.
  {
    const shotTargets = [];
    for (const rec of sceneObjects.values()) {
      if (rec.id === playerRecordId) continue;
      if (!rec.interactive || !rec.interactive.onShotAction) continue;
      // Si está desvanecido (fade a opacidad 0 -- p.ej. tras huir), colorMaterials queda con
      // visible=false pero el Object3D en sí sigue "presente": sin este filtro, el rayo de disparo
      // lo seguiría alcanzando para siempre en el sitio donde desapareció, invisible pero disparable.
      if (rec.colorMaterials.length && rec.colorMaterials.every((m) => !m.visible)) continue;
      shotTargets.push(rec.object3D);
    }
    nearestShotTargetId = null;
    if (shotTargets.length) {
      const shotDir = new THREE.Vector3();
      camera.getWorldDirection(shotDir);
      shotRaycaster.set(camera.position, shotDir);
      shotRaycaster.far = SHOT_MAX_DISTANCE;
      const shotHits = shotRaycaster.intersectObjects(shotTargets, true);
      if (shotHits.length) nearestShotTargetId = objectForMesh(shotHits[0].object);
    }
    updateShotPrompt();
  }
  }

  if (window.MundoMulti && MundoMulti.estaActivo()) {
    MundoMulti.actualizarAvatares(dt);
  }

  runCollisionChecks(true);
}

function updateTimeLabel() {
  document.getElementById("timeLabel").textContent = formatTime(currentTime) + " / " + formatTime(timelineDuration);
}

function applyTimeToScene(t, opts) {
  opts = opts || {};
  for (const rec of sceneObjects.values()) {
    if (opts.excludeId && rec.id === opts.excludeId) continue;
    if (!rec.checkpoints) recomputeCheckpoints(rec);
    const ev = evaluateRecord(rec, t);
    if (!ev) continue;
    rec.object3D.position.copy(ev.pos);
    rec.object3D.quaternion.copy(ev.quat);
    rec.colorMaterials.forEach((m) => { m.opacity = ev.opacity; m.visible = ev.opacity > 0.01; });
    if (ev.flashIntensity > 0.02 && rec.colorMaterials.length) {
      const c = new THREE.Color(ev.flashColor || "#ff3b3b");
      rec.colorMaterials.forEach((m) => { m.emissive = c; m.emissiveIntensity = ev.flashIntensity; });
    } else if (rec.colorMaterials.length) {
      rec.colorMaterials.forEach((m) => { if (m.emissiveIntensity) m.emissiveIntensity = 0; });
    }
    if (ev.clipInfo && rec.mixer && rec.clips.length) {
      const clip = rec.clips.find((c) => c.name === ev.clipInfo.name);
      if (clip) {
        if (!rec.__activeClipAction || rec.__activeClipAction.getClip() !== clip) {
          if (rec.__activeClipAction) rec.__activeClipAction.stop();
          rec.__activeClipAction = rec.mixer.clipAction(clip);
          rec.__activeClipAction.play();
        }
        let lt = ev.clipInfo.localTime;
        if (ev.clipInfo.loop && clip.duration > 0) lt = lt % clip.duration;
        rec.__activeClipAction.time = clamp(lt, 0, clip.duration);
        rec.mixer.update(0);
      }
    }
  }
  runCollisionChecks(opts.log === true);
}

function runCollisionChecks(shouldLog) {
  const chars = [], zones = [];
  for (const rec of sceneObjects.values()) {
    if (rec.collider.kind === "character") chars.push(rec);
    if (rec.collider.kind === "zone") zones.push(rec);
  }
  const liveOverlaps = [];
  for (const c of chars) {
    const cPos = new THREE.Vector3(); c.object3D.getWorldPosition(cPos);
    const cSize = c.collider.size;
    const cBox = new THREE.Box3().setFromCenterAndSize(cPos, new THREE.Vector3(cSize.x, cSize.y, cSize.z));
    for (const z of zones) {
      const zPos = new THREE.Vector3(); z.object3D.getWorldPosition(zPos);
      const zSize = z.collider.size;
      const zBox = new THREE.Box3().setFromCenterAndSize(zPos, new THREE.Vector3(zSize.x, zSize.y, zSize.z));
      const overlapping = cBox.intersectsBox(zBox);
      const key = c.id + "|" + z.id;
      const wasOverlapping = overlapState.get(key) || false;
      if (overlapping) liveOverlaps.push(c.name + " × " + z.name);
      if (shouldLog && overlapping && !wasOverlapping) {
        pushEvent("⚠️ " + (z.collider.riskLabel || "Riesgo") + " — " + c.name + " entra en \"" + z.name + "\" (t=" + formatTime(currentTime) + ")");
      }
      overlapState.set(key, overlapping);
    }
  }
}

function pushEvent(text) {
  eventLogList.unshift({ text, time: currentTime });
  if (eventLogList.length > 200) eventLogList.pop();
  renderEventLog();
  if (isPlayModeActive) playFeedToast(text);
}
function renderEventLog() {
  const box = document.getElementById("eventLog");
  if (!eventLogList.length) { box.innerHTML = '<p class="sub">Sin eventos todavía. Reproduce la línea de tiempo para detectar solapes entre el personaje y las zonas de riesgo.</p>'; return; }
  box.innerHTML = eventLogList.map((e) => '<div class="logItem"><b>' + e.text + "</b></div>").join("");
}
document.getElementById("btnClearLog").addEventListener("click", () => { eventLogList = []; renderEventLog(); });

function setCurrentTime(t, opts) {
  currentTime = clamp(t, 0, timelineDuration);
  document.getElementById("scrubber").value = String(currentTime);
  updateTimeLabel();
  applyTimeToScene(currentTime, opts);
}

document.getElementById("scrubber").addEventListener("input", (e) => {
  isPlaying = false; updatePlayButton();
  setCurrentTime(parseFloat(e.target.value), { log: false });
});

let recordingActive = false;
let mediaRecorderRef = null;

function updatePlayButton() {
  document.getElementById("btnPlay").textContent = isPlaying ? "⏸ Pausar" : "▶ Reproducir";
}
document.getElementById("btnPlay").addEventListener("click", () => {
  if (isPlaying) { isPlaying = false; updatePlayButton(); return; }
  if (currentTime >= timelineDuration - 0.001) currentTime = 0;
  isPlaying = true;
  playStartClock = performance.now();
  playStartTimeline = currentTime;
  updatePlayButton();
});
document.getElementById("btnStop").addEventListener("click", () => {
  isPlaying = false; updatePlayButton();
  overlapState = new Map();
  setCurrentTime(0, { log: false });
});
document.getElementById("loopToggle").addEventListener("change", () => {});

function speedValue() { return parseFloat(document.getElementById("speedSelect").value) || 1; }

let lastFrameTime = performance.now();
function tick() {
  const nowFrame = performance.now();
  const dt = clamp((nowFrame - lastFrameTime) / 1000, 0, 0.05);
  lastFrameTime = nowFrame;

  updateSunCycle(dt); // independiente de isPlayModeActive: el ciclo/hora real se ve en vivo también editando
  updateNightSky(dt); // idem: la boveda celeste nocturna tambien se ve en vivo mientras editas
  updateWeatherSystems(dt); // ídem: la lluvia/nieve se ve caer también mientras editas, no solo jugando
  updateCricketSounds(dt);

  if (isPlayModeActive) {
    // Actualizamos primero las animaciones en curso (p.ej. un ascensor sólido subiendo) y SOLO DESPUÉS
    // al jugador: su raycast de suelo debe ver ya la posición de la plataforma EN ESTE MISMO frame, no
    // la del frame anterior. Con el orden inverso (como estaba antes) el jugador siempre iba "un frame
    // por detrás" de cualquier plataforma en movimiento -- con una plataforma rápida o bajo más carga de
    // procesado (frames más pesados, dt mayor) ese desfase acumulado supera el margen del rayo, deja de
    // detectar la plataforma y el personaje se desliza/cae a través de ella.
    updateOneShotAnimations();
    updateSpins(dt);
    updateOneShotClips(dt);
    updatePlayMode(dt);
    updateSkyPointer(dt, punteroLaserActivo);
  } else {
    if (isPlaying) {
      const now = performance.now();
      let t = playStartTimeline + ((now - playStartClock) / 1000) * speedValue();
      const loop = document.getElementById("loopToggle").checked;
      const prevT = currentTime;
      if (t >= timelineDuration) {
        if (loop) { t = 0; playStartTimeline = 0; playStartClock = now; overlapState = new Map(); }
        else { t = timelineDuration; isPlaying = false; updatePlayButton(); if (recordingActive) stopRecording(); }
      }
      fireDueChainTriggers(prevT, t);
      setCurrentTime(t, { log: true });
    }
    if (transformControls.object && transformControls.dragging) {
      selectedRecs().forEach((rec) => {
        rec.object3D.userData.__origin = { pos: rec.object3D.position.clone(), quat: rec.object3D.quaternion.clone() };
        recomputeCheckpoints(rec);
      });
    }
    orbitControls.update();
    updateOneShotAnimations();
    updateSpins(dt);
    updateOneShotClips(dt);
  }
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}

/* =========================================================================
   GRABACIÓN DE VÍDEO
   ========================================================================= */
function pickMimeType() {
  const options = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
  for (const o of options) if (window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(o)) return o;
  return "video/webm";
}
function startRecording() {
  if (!window.MediaRecorder) { alertBox("Este navegador no soporta MediaRecorder; prueba con Chrome, Edge o Firefox.", "warn"); return; }
  const stream = canvas.captureStream(30);
  const chunks = [];
  let recorder;
  try { recorder = new MediaRecorder(stream, { mimeType: pickMimeType() }); }
  catch (err) { alertBox("No se pudo iniciar la grabación: " + err.message, "warn"); return; }
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  recorder.onstop = () => {
    const blob = new Blob(chunks, { type: "video/webm" });
    downloadBlob(blob, "don-claude-3d-escenario-" + Date.now() + ".webm");
    logInfo("Vídeo descargado (" + (blob.size / 1024).toFixed(0) + " KB).");
  };
  mediaRecorderRef = recorder;
  recordingActive = true;
  recorder.start();
  document.getElementById("btnRecord").textContent = "⏹ Detener grabación";
  overlapState = new Map();
  setCurrentTime(0, { log: false });
  isPlaying = true; playStartClock = performance.now(); playStartTimeline = 0;
  updatePlayButton();
}
function stopRecording() {
  recordingActive = false;
  document.getElementById("btnRecord").textContent = "⏺ Grabar película";
  if (mediaRecorderRef && mediaRecorderRef.state !== "inactive") mediaRecorderRef.stop();
}
document.getElementById("btnRecord").addEventListener("click", () => {
  if (recordingActive) stopRecording();
  else {
    if (!sceneOrder.some((id) => sceneObjects.get(id).actions.length)) {
      alertBox("Ningún objeto tiene acciones: la grabación mostrará la escena estática.", "info");
    }
    startRecording();
  }
});

/* =========================================================================
   ASISTENTE DE PLANTILLAS DE RIESGO LABORAL
   ========================================================================= */
const RISK_TEMPLATES = [
  { id: "caida", label: "Caída a distinto nivel", desc: "Uso de escaleras o superficies elevadas sin protección adecuada.",
    build(pos) { const r = addPrefabToScene("escalera", pos); r.collider.kind = "zone"; r.collider.riskLabel = "Caída a distinto nivel: escalera sin protección"; r.collider.size = { x: 0.9, y: 2.2, z: 0.6 }; return r; } },
  { id: "atrapamiento", label: "Atrapamiento", desc: "Zonas de almacenamiento o maquinaria con riesgo de atrapamiento entre cargas.",
    build(pos) { const r = addPrefabToScene("palet", pos); r.collider.kind = "zone"; r.collider.riskLabel = "Atrapamiento entre cargas apiladas"; r.collider.size = { x: 1.4, y: 1, z: 1.6 }; return r; } },
  { id: "electrico", label: "Contacto eléctrico", desc: "Cables sueltos o instalaciones eléctricas expuestas.",
    build(pos) { const r = addPrefabToScene("cable_suelto", pos); return r; } },
  { id: "incendio", label: "Incendio / falta de extintor", desc: "Zona sin extintor visible o accesible en caso de conato de incendio.",
    build(pos) {
      const r = addPrefabToScene("extintor", pos);
      r.collider.kind = "zone"; r.collider.riskLabel = "Comprobar accesibilidad del extintor"; r.collider.size = { x: 0.9, y: 1, z: 0.9 };
      return r;
    } },
  { id: "cargas", label: "Manejo manual de cargas", desc: "Levantamiento o transporte de cargas pesadas sin ayuda mecánica.",
    build(pos) { const r = addPrefabToScene("palet", pos); r.collider.kind = "zone"; r.collider.riskLabel = "Manejo manual de cargas pesadas"; r.collider.size = { x: 1.2, y: 1, z: 1.4 }; return r; } },
  { id: "resbalon", label: "Resbalón", desc: "Suelos mojados o con derrames sin señalizar.",
    build(pos) { const r = addPrefabToScene("charco", pos); return r; } },
];

function renderTemplateList() {
  const box = document.getElementById("tplList");
  box.innerHTML = RISK_TEMPLATES.map((t) => '<button class="tplBtn" data-tpl="' + t.id + '"><b>' + t.label + "</b><span>" + t.desc + "</span></button>").join("");
  box.querySelectorAll(".tplBtn").forEach((btn) => btn.addEventListener("click", () => applyTemplate(btn.dataset.tpl)));
}
let tplPlacementIndex = 0;
function applyTemplate(id) {
  const tpl = RISK_TEMPLATES.find((t) => t.id === id);
  if (!tpl) return;
  pushUndo();
  const pos = { x: -4 + tplPlacementIndex * 2.3, y: 0, z: -2.4 };
  tplPlacementIndex++;
  const rec = tpl.build(pos);
  const guide = document.getElementById("assistGuideChar").checked;
  if (guide) {
    const character = sceneOrder.map((id2) => sceneObjects.get(id2)).find((r) => r.collider.kind === "character");
    if (character) {
      const zonePos = rec.object3D.position;
      character.actions.push({ type: "moveTo", to: { x: zonePos.x, y: 0, z: zonePos.z + 0.9 }, duration: 2, ease: "smooth" });
      character.actions.push({ type: "wait", duration: 0.6 });
      recomputeCheckpoints(character);
    } else {
      alertBox('Añade un "Trabajador" a la escena para que el asistente pueda guiarlo automáticamente hasta el riesgo.', "info");
    }
  }
  recomputeTimelineDuration();
  renderHierarchy();
  if (selectedId === rec.id) renderProps();
  logInfo('Plantilla "' + tpl.label + '" añadida a la escena.');
}

/* =========================================================================
   GUARDAR / CARGAR PROYECTO
   ========================================================================= */
function serializeProjectData() {
  const objects = sceneOrder.map((id) => {
    const rec = sceneObjects.get(id);
    return {
      id: rec.id, name: rec.name, kind: rec.kind,
      primitiveType: rec.primitiveType, prefabType: rec.prefabType,
      gltfBase64: rec.gltfBase64, gltfFileName: rec.gltfFileName,
      text3d: rec.text3d, imageBase64: rec.imageBase64, imageFileName: rec.imageFileName,
      videoBase64: rec.videoBase64, videoFileName: rec.videoFileName,
      extrudeData: rec.extrudeData,
      lightData: rec.lightData || null,
      cameraPathData: rec.cameraPathData || null,
      weatherData: rec.weatherData || null,
      colorHex: (rec.colorMaterials.length && rec.kind !== "text3d" && rec.kind !== "image" && rec.kind !== "video") ? "#" + rec.colorMaterials[0].color.getHexString() : null,
      opacity: (rec.opacity != null ? rec.opacity : 1),
      textureBase64: rec.textureBase64 || null,
      textureRepeatX: rec.textureRepeatX || 1,
      textureRepeatY: rec.textureRepeatY || 1,
      transform: {
        position: rec.object3D.position.toArray(),
        quaternion: rec.object3D.quaternion.toArray(),
        scale: rec.object3D.scale.toArray(),
      },
      collider: rec.collider,
      facingOffsetDeg: rec.facingOffsetDeg || 0,
      actions: rec.actions,
      interactive: rec.interactive,
      groupId: rec.groupId || null,
    };
  });
  return {
    don_claude_3d_project: true, version: 1, exported_at: new Date().toISOString(),
    objects,
    camera: { position: camera.position.toArray(), target: orbitControls.target.toArray() },
    audio: projectAudio,
    environment: sceneEnvironment,
    groups: Array.from(objectGroups.values()),
  };
}

function exportProject() {
  const project = serializeProjectData();
  const blob = new Blob([JSON.stringify(project)], { type: "application/json" });
  downloadBlob(blob, "don-claude-3d-proyecto-" + Date.now() + ".json");
}
document.getElementById("btnExportProject").addEventListener("click", exportProject);

/* =========================================================================
   COMPARTIR PROYECTO POR ENLACE (multi/proyecto.php)
   ========================================================================= */
// Sube el proyecto actual a multi/proyecto.php bajo un código de sala y copia el enlace
// (mismo código que el panel de sala del multijugador -- un enlace, un mundo, una sala).
async function compartirProyectoActual() {
  if (!window.MundoMulti) { alertBox("Falta multi/mundo-multi.js -- no se puede compartir por enlace.", "warn"); return; }
  const sugerido = document.getElementById("multiSalaInput")?.value.trim() || localStorage.getItem("mundo3d_ultima_sala") || "";
  const sala = prompt("Código para este proyecto (letras/números/guiones, 3-40 caracteres). Quien abra el enlace con este código verá el mismo escenario:", sugerido);
  if (!sala) return;
  const salaLimpia = sala.trim();
  if (!/^[a-zA-Z0-9_-]{3,40}$/.test(salaLimpia)) { alertBox("Código inválido: usa letras, números o guiones, 3 a 40 caracteres.", "warn"); return; }
  const proyecto = serializeProjectData();
  if (!proyecto.objects.length && !confirm("La escena está vacía (0 objetos) -- ¿aun así quieres compartirla así? Si querías compartir un escenario ya construido, cancela y comprueba que estás en la pestaña/proyecto correcto (Jerarquía a la derecha).")) return;

  // Averiguamos si esta sala ya está protegida con PIN antes de pedirlo, para no pedir un PIN
  // "para nada" la primera vez ni dejar sin avisar a quien sí necesita escribirlo.
  let protegida = false;
  try {
    const chk = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaLimpia) + "&comprobarPin=1");
    const chkData = await chk.json().catch(() => null);
    protegida = !!(chkData && chkData.protegida);
  } catch { /* si falla la comprobación, seguimos como si no estuviera protegida -- el servidor es quien manda de verdad */ }

  let pin = "";
  if (protegida) {
    const intento = prompt("Esta sala ya está protegida con PIN. Escríbelo para poder guardar encima del proyecto existente:");
    if (intento === null) return; // cancelado
    pin = intento.trim();
    if (!pin) { alertBox("Hace falta el PIN para actualizar esta sala.", "warn"); return; }
  } else {
    const intento = prompt("Esta sala aún no tiene PIN. Puedes fijar uno ahora (4-16 letras/números) para que solo quien lo conozca pueda volver a guardar encima -- o dejarlo en blanco para seguir sin proteger:", "");
    if (intento === null) return; // cancelado
    pin = intento.trim();
    if (pin && !/^[A-Za-z0-9]{4,16}$/.test(pin)) { alertBox("PIN inválido: usa 4 a 16 letras o números (o déjalo en blanco).", "warn"); return; }
  }

  // Se manda también la "base" (sin campos pesados) de la que partía esta sesión, para que el
  // servidor pueda fusionar en vez de sobrescribir si alguien más guardó cambios mientras tanto --
  // ver docblock de multi/proyecto.php. Si esta pestaña nunca cargó/sincronizó nada de esta sala
  // (p.ej. primera vez que se comparte), no hay base conocida: se manda null.
  const baseLigera = (salaActualCodigo === salaLimpia && salaProyectoBase) ? aligerarProyectoParaBase(salaProyectoBase) : null;
  const cuerpo = JSON.stringify({ sala: salaLimpia, proyecto, pin, proyectoBaseLigero: baseLigera });
  const pesoMB = (cuerpo.length / 1024 / 1024).toFixed(1);
  logInfo("Subiendo proyecto (" + pesoMB + " MB)…");
  try {
    const res = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaLimpia), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: cuerpo,
    });
    const data = await res.json().catch(() => null);
    if (res.status === 403) {
      alertBox("PIN incorrecto -- no se ha actualizado el proyecto guardado.", "warn");
      return;
    }
    if (!res.ok || !data || !data.ok) {
      alertBox("No se pudo subir el proyecto" + (data && data.error ? (": " + data.error) : " (" + res.status + ")") + ".", "warn");
      return;
    }
    localStorage.setItem("mundo3d_ultima_sala", salaLimpia);
    // El servidor devuelve el proyecto YA fusionado con lo que hubiera de otras personas (altas,
    // ediciones ajenas que no tocamos...) -- se aplica aquí mismo para que esta pestaña también vea
    // ese trabajo, no solo el suyo. Este guardado propio no debe auto-notificarse como "cambio de
    // otra persona" en el sondeo, así que la versión y la base locales se ponen al día aquí mismo.
    if (data.proyecto) { importProject(data.proyecto); salaProyectoBase = data.proyecto; }
    if (data.version != null) salaVersionAplicada = data.version;
    salaVersionIgnorada = null;
    document.getElementById("avisoSalaActualizada").style.display = "none";
    iniciarSondeoSala(salaLimpia);
    const url = location.origin + location.pathname + "?sala=" + encodeURIComponent(salaLimpia);
    const copiado = await copiarTexto(url);
    let msg = copiado ? ("Enlace copiado: " + url) : ("Proyecto compartido -- copia el enlace a mano: " + url);
    if (pin && !protegida) msg += " — PIN fijado, apúntalo: hará falta para volver a guardar encima de esta sala.";
    if (data.conflictos && data.conflictos.length) {
      msg += " ⚠️ " + data.conflictos.length + " elemento(s) fueron editados por otra persona al mismo tiempo que tú -- se ha mantenido su versión ya guardada, revisa: " + data.conflictos.join(", ") + ".";
    }
    alertBox(msg, data.conflictos && data.conflictos.length ? "warn" : "ok");
  } catch (err) {
    alertBox("Fallo de red subiendo el proyecto: " + err.message, "warn");
  }
}
document.getElementById("btnCompartirProyecto").addEventListener("click", compartirProyectoActual);

// Al abrir un enlace con "?sala=" se intenta cargar el proyecto guardado bajo ese código --
// si no hay ninguno (p.ej. la sala solo se usa para el multijugador, sin proyecto compartido),
// no pasa nada: sigues con la escena que tuvieras.
async function cargarProyectoDesdeEnlaceSiHay() {
  const sala = new URLSearchParams(location.search).get("sala");
  if (!sala || !/^[a-zA-Z0-9_-]{3,40}$/.test(sala)) return;
  try {
    const res = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(sala));
    if (!res.ok) return; // 404: esa sala no tiene proyecto compartido, o multi/ no está desplegado
    const data = await res.json();
    if (!data || !data.don_claude_3d_project) return;
    pushUndo();
    // OJO: hay que ESPERAR a que importProject() termine de verdad (incluidos los .glb, que se
    // decodifican de forma asíncrona) antes de seguir -- si no, la comprobación de PIN de abajo
    // (y el findCharacterRecord() que decide si hay Modo jugar) podía ejecutarse mientras un
    // personaje importado como .glb (p.ej. CesiumMan) todavía se estaba decodificando: no
    // aparecía todavía en sceneObjects, así que "no se encontraba ningún Personaje" aunque sí
    // lo hubiera, y la sala se quedaba en modo "solo mirar" (o, en el bug anterior, en un estado
    // roto donde encima se podía seguir editando) sin que hubiera ningún problema real de fondo.
    await importProject(data);
    salaProyectoBase = data;
    logInfo('Escenario cargado desde el enlace compartido (sala "' + sala + '").');
  } catch { /* sin conexión con multi/proyecto.php: se queda con la escena local */ }

  // "Pulsar para editar": si la sala tiene PIN fijado, quien entra por el enlace arranca en modo
  // visitante (solo ver/jugar, editor oculto) hasta que introduce ese PIN -- así un enlace compartido
  // en clase, por ejemplo, no deja que cualquiera reordene o borre lo que ya se construyó.
  try {
    const chk = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(sala) + "&comprobarPin=1");
    const chkData = await chk.json().catch(() => null);
    if (chkData && chkData.protegida) activarModoVisitante(sala);
    if (chkData && chkData.version != null) salaVersionAplicada = chkData.version;
  } catch { /* si falla la comprobación, se queda en modo editor normal, igual que antes de este cambio */ }

  // A partir de aquí esta pestaña "vive" en la sala: si alguien más guarda cambios encima (mismo
  // código, con o sin PIN), un sondeo periódico los detecta sin necesidad de F5 -- ver más abajo.
  iniciarSondeoSala(sala);
}

let salaModoVisitante = false;
let salaVisitanteCodigo = null;
let salaActualCodigo = null;
let salaVersionAplicada = null;   // versión (filemtime) de lo que hay cargado ahora mismo en la escena
let salaVersionIgnorada = null;   // versión que el usuario descartó a propósito con "Ignorar"
let salaVersionPendiente = null;  // versión detectada en el servidor, aún no aplicada
let salaPollTimer = null;
// Último proyecto cargado/sincronizado de la sala -- es la "base" para la fusión de guardados: al
// guardar, el servidor compara esto con lo local y con lo que él ya tenga para saber qué es una
// alta nueva, qué es una edición y qué no se ha tocado (ver docblock de multi/proyecto.php). Sin
// esto, guardar sería "quien guarda el último pisa lo del otro" -- con esto, ambos trabajos se suman.
let salaProyectoBase = null;

// Copia de los objetos de un proyecto sin sus campos pesados (modelos/imágenes/vídeo en base64) --
// es lo único que hace falta mandar como "base" al guardar: la fusión solo necesita compararlos, y
// mandar los campos pesados otra vez doblaría el peso de cada guardado sin necesidad.
function aligerarProyectoParaBase(proyecto) {
  if (!proyecto || !Array.isArray(proyecto.objects)) return proyecto;
  return {
    ...proyecto,
    objects: proyecto.objects.map((o) => {
      const { gltfBase64, imageBase64, videoBase64, textureBase64, ...ligero } = o;
      return ligero;
    }),
  };
}

// Huella ligera de un objeto de escena para comparar "¿ha cambiado de verdad?" sin arrastrar sus
// campos pesados. Réplica EXACTA (misma lógica, mismo criterio) de huellaObjeto() en
// multi/proyecto.php -- las dos deben dar siempre el mismo resultado ante los mismos datos, o la
// fusión al cargar (aquí, en el navegador) y la fusión al guardar (en el servidor) discreparían.
// test/js-fusion-carga-functional.mjs comprueba justo esa paridad extrayendo esta función tal cual.
function huellaObjetoJS(o) {
  if (!o || typeof o !== "object") return JSON.stringify(o);
  const { gltfBase64, imageBase64, videoBase64, textureBase64, ...ligero } = o;
  return JSON.stringify(ligero);
}
function indexarObjetosPorIdJS(objetos) {
  const out = new Map();
  (objetos || []).forEach((o) => { if (o && o.id != null) out.set(o.id, o); });
  return out;
}

// Fusión de 3 vías (base / local / servidor) -- misma lógica que fusionarProyectos() en
// multi/proyecto.php (ver su docblock para la explicación completa de cada caso), pero SIN escribir
// nada: esto es lo que usa "Cargar cambios" para no perder ediciones locales sin guardar todavía al
// traer lo último del servidor. El guardado de verdad (con la fusión que persiste) sigue ocurriendo
// en el servidor, dentro del mismo bloqueo de fichero -- esto es solo para que la vista local, entre
// guardado y guardado, no "olvide" lo que estabas construyendo.
function fusionarProyectosJS(base, local, servidor) {
  if (!servidor || !Array.isArray(servidor.objects)) return { proyecto: local, conflictos: [] };
  if (!local || !Array.isArray(local.objects)) return { proyecto: servidor, conflictos: [] };

  const hayBase = !!(base && Array.isArray(base.objects));
  const baseObjs = hayBase ? indexarObjetosPorIdJS(base.objects) : new Map();
  const localObjs = indexarObjetosPorIdJS(local.objects);
  const servObjs = indexarObjetosPorIdJS(servidor.objects);

  const todosLosIds = new Set([...localObjs.keys(), ...servObjs.keys()]);
  const merged = [];
  const conflictos = [];

  for (const id of todosLosIds) {
    const enLocal = localObjs.has(id);
    const enServ = servObjs.has(id);
    const enBase = hayBase && baseObjs.has(id);
    const localCambio = enBase && enLocal && huellaObjetoJS(baseObjs.get(id)) !== huellaObjetoJS(localObjs.get(id));
    const servCambio = enBase && enServ && huellaObjetoJS(baseObjs.get(id)) !== huellaObjetoJS(servObjs.get(id));

    if (enLocal && enServ) {
      if (localCambio && servCambio) { merged.push(servObjs.get(id)); conflictos.push(id); }
      else if (localCambio) merged.push(localObjs.get(id));
      else merged.push(servObjs.get(id));
    } else if (enLocal && !enServ) {
      if (!enBase) merged.push(localObjs.get(id));
      else if (localCambio) { merged.push(localObjs.get(id)); conflictos.push(id); }
      // si no cambió localmente y ya no está en el servidor: lo borró otra persona -- se respeta, se omite
    } else if (!enLocal && enServ) {
      if (!enBase) merged.push(servObjs.get(id));
      else if (servCambio) { merged.push(servObjs.get(id)); conflictos.push(id); }
      // si no cambió en el servidor y yo lo borré localmente: se respeta el borrado, se omite
    }
  }

  const resultado = { ...local, objects: merged };
  for (const campo of ["environment", "audio", "camera"]) {
    const baseVal = hayBase ? base[campo] : null;
    const localVal = local[campo];
    const servVal = servidor[campo];
    const localCambioCampo = hayBase && JSON.stringify(baseVal) !== JSON.stringify(localVal);
    const servCambioCampo = hayBase && JSON.stringify(baseVal) !== JSON.stringify(servVal);
    resultado[campo] = (servCambioCampo && !localCambioCampo) ? servVal : localVal;
    if (localCambioCampo && servCambioCampo && JSON.stringify(localVal) !== JSON.stringify(servVal)) conflictos.push(campo);
  }

  return { proyecto: resultado, conflictos };
}
const SALA_POLL_MS = 10000; // 10s: lo bastante rápido para notarse, sin saturar el servidor a base de sondeos

function iniciarSondeoSala(sala) {
  salaActualCodigo = sala;
  if (salaPollTimer) clearInterval(salaPollTimer);
  salaPollTimer = setInterval(comprobarVersionSala, SALA_POLL_MS);
}

async function comprobarVersionSala() {
  if (!salaActualCodigo) return;
  try {
    const res = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaActualCodigo) + "&comprobarPin=1");
    const data = await res.json().catch(() => null);
    if (!data || data.version == null) return;
    if (data.version === salaVersionAplicada) return; // sin cambios desde la última vez
    if (salaModoVisitante) {
      // Visitante: no hay ediciones propias que perder, así que se aplica sin preguntar.
      await aplicarActualizacionSala();
    } else if (data.version !== salaVersionIgnorada) {
      // Editor: podría tener cambios sin guardar -- se avisa en vez de sobrescribir en caliente.
      salaVersionPendiente = data.version;
      document.getElementById("avisoSalaActualizada").style.display = "block";
    }
  } catch { /* red caída: se reintenta solo, en el siguiente ciclo, sin avisar cada vez */ }
}

async function aplicarActualizacionSala() {
  if (!salaActualCodigo) return;
  try {
    const res = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaActualCodigo));
    if (!res.ok) return;
    const servidorData = await res.json();
    if (!servidorData || !servidorData.don_claude_3d_project) return;

    let resultado, conflictos = [];
    if (salaModoVisitante) {
      // Visitante: no hay ediciones propias que fusionar (el editor está bloqueado) -- se aplica el
      // proyecto del servidor tal cual.
      resultado = servidorData;
    } else {
      // Editor: si esta pestaña tiene cambios sin guardar (objetos añadidos/editados desde la última
      // vez que se sincronizó), "Cargar cambios" NO debe tirarlos por sobrescribir sin más -- se
      // fusionan aquí en local con lo último del servidor (misma lógica que el guardado, ver
      // fusionarProyectosJS). Esto es solo para que la vista no "olvide" tu trabajo en curso; el
      // guardado que persiste de verdad sigue pasando por el servidor la próxima vez que compartas.
      const local = serializeProjectData();
      const fusion = fusionarProyectosJS(salaProyectoBase, local, servidorData);
      resultado = fusion.proyecto;
      conflictos = fusion.conflictos;
    }

    await importProject(resultado); // esperar a que terminen de decodificarse los .glb (ver comentario en cargarProyectoDesdeEnlaceSiHay) antes de mirar si hay Personaje
    salaProyectoBase = servidorData; // la base pasa a ser lo que hay confirmado en el servidor
    const chk = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaActualCodigo) + "&comprobarPin=1");
    const chkData = await chk.json().catch(() => null);
    if (chkData && chkData.version != null) salaVersionAplicada = chkData.version;
    salaVersionIgnorada = null;
    salaVersionPendiente = null;
    document.getElementById("avisoSalaActualizada").style.display = "none";
    if (salaModoVisitante && findCharacterRecord()) enterPlayMode();
    if (conflictos.length) {
      alertBox("Sala actualizada. ⚠️ " + conflictos.length + " elemento(s) se editaron a la vez en los dos sitios -- se mantuvo la versión ya guardada, revisa: " + conflictos.join(", ") + ".", "warn");
    } else {
      logInfo("Sala actualizada con los últimos cambios guardados" + (salaModoVisitante ? "" : " (se han conservado tus ediciones sin guardar)") + ".");
    }
  } catch (err) {
    logInfo("No se pudo aplicar la actualización de la sala: " + err.message);
  }
}
document.getElementById("btnCargarCambiosSala").addEventListener("click", aplicarActualizacionSala);
document.getElementById("btnDescartarAvisoSala").addEventListener("click", () => {
  salaVersionIgnorada = salaVersionPendiente;
  document.getElementById("avisoSalaActualizada").style.display = "none";
});

function activarModoVisitante(sala) {
  salaModoVisitante = true;
  salaVisitanteCodigo = sala;
  document.getElementById("app").classList.add("visitante");
  transformControls.detach();
  document.getElementById("btnEditarSala").style.display = "inline-block";
  if (findCharacterRecord()) {
    orbitControls.enabled = false;
    enterPlayMode();
    logInfo('Sala protegida con PIN -- entras como visitante (solo ver/jugar). Pulsa "✏️ Editar sala" arriba a la derecha si tienes el PIN de edición.');
  } else {
    // Sin ningún objeto "Personaje" en la escena no hay Modo jugar posible (enterPlayMode() lo exige) --
    // antes esto dejaba al visitante en un estado roto: sin los paneles del editor (ocultos por la clase
    // "visitante") pero SIN el HUD de "clic para jugar" tampoco, con la cámara bloqueada (orbitControls
    // deshabilitado) y, peor aún, los objetos seguían siendo seleccionables/editables con el ratón porque
    // solo isPlayModeActive bloqueaba esos listeners, no salaModoVisitante. Ahora, si no hay personaje, se
    // deja mirar el escenario orbitando la cámara con normalidad -- la edición sigue bloqueada (ver los
    // guardas "|| salaModoVisitante" añadidos a la selección por clic y a los atajos de teclado).
    orbitControls.enabled = true;
    logInfo('Sala protegida con PIN -- entras como visitante. Este escenario no tiene ningún objeto "Personaje", así que no hay Modo jugar disponible: puedes mirarlo orbitando la cámara. Pulsa "✏️ Editar sala" arriba a la derecha si tienes el PIN de edición.');
  }
}

function desactivarModoVisitante() {
  salaModoVisitante = false;
  document.getElementById("app").classList.remove("visitante");
  orbitControls.enabled = true;
  document.getElementById("btnEditarSala").style.display = "none";
  if (isPlayModeActive) exitPlayMode();
  alertBox("Edición desbloqueada para esta sala.", "ok");
}

async function intentarDesbloquearEdicionSala() {
  if (!salaVisitanteCodigo) return;
  const pin = prompt("PIN de edición de esta sala:");
  if (pin === null) return; // cancelado
  try {
    const res = await fetch("multi/proyecto.php?sala=" + encodeURIComponent(salaVisitanteCodigo) + "&validarPin=1", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pin: pin.trim() }),
    });
    const data = await res.json().catch(() => null);
    if (res.status === 403 || !data || !data.ok) { alertBox("PIN incorrecto.", "warn"); return; }
    desactivarModoVisitante();
  } catch (err) {
    alertBox("Fallo de red comprobando el PIN: " + err.message, "warn");
  }
}
document.getElementById("btnEditarSala").addEventListener("click", intentarDesbloquearEdicionSala);

/* =========================================================================
   DESHACER / REHACER (historial por snapshots del proyecto)
   ========================================================================= */
let undoStack = [];
let redoStack = [];
const UNDO_LIMIT = 60;
let liveEditSnapshotTaken = false;
let restoringHistory = false; // evita que importProject() durante un deshacer/rehacer genere su propio snapshot

function snapshotState() {
  return JSON.parse(JSON.stringify(serializeProjectData()));
}

function pushUndo() {
  if (restoringHistory) return;
  undoStack.push(snapshotState());
  if (undoStack.length > UNDO_LIMIT) undoStack.shift();
  redoStack = [];
}

function beginLiveEdit() {
  if (restoringHistory || liveEditSnapshotTaken) return;
  pushUndo();
  liveEditSnapshotTaken = true;
}
function endLiveEdit() { liveEditSnapshotTaken = false; }

function performUndo() {
  if (!undoStack.length) return;
  const current = snapshotState();
  const prev = undoStack.pop();
  redoStack.push(current);
  if (redoStack.length > UNDO_LIMIT) redoStack.shift();
  restoringHistory = true;
  importProject(prev);
  restoringHistory = false;
  logInfo("Deshecho.");
}
function performRedo() {
  if (!redoStack.length) return;
  const current = snapshotState();
  const next = redoStack.pop();
  undoStack.push(current);
  restoringHistory = true;
  importProject(next);
  restoringHistory = false;
  logInfo("Rehecho.");
}

// Cualquier edición dentro del panel de Propiedades (nombre, transformación, colisionador,
// color, acciones, interacción, texto/imagen/vídeo...) toma una única instantánea al entrar
// en el campo (focusin), no una por cada tecla — así una sesión de edición es un solo paso de deshacer.
const propsPanelForUndo = document.getElementById("propsPanel");
propsPanelForUndo.addEventListener("focusin", (e) => { if (e.target.matches("input, textarea, select")) beginLiveEdit(); });
propsPanelForUndo.addEventListener("focusout", (e) => { if (e.target.matches("input, textarea, select")) endLiveEdit(); });
document.getElementById("btnUndo").addEventListener("click", performUndo);
document.getElementById("btnRedo").addEventListener("click", performRedo);

/* =========================================================================
   EXPORTAR VIDEOJUEGO STANDALONE (.html, jugable, sin editor)
   ========================================================================= */
function buildStandaloneGameRuntimeSrc(projectJson) {
  const L = [];
  L.push('import * as THREE from "three";\nimport { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";\n');
  L.push('var PROJECT = ' + projectJson + ';\n');
  L.push([
    'var canvas = document.getElementById("gcanvas");',
    'var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });',
    'renderer.shadowMap.enabled = true;',
    'renderer.shadowMap.type = THREE.PCFSoftShadowMap;',
    'renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));',
    'var scene = new THREE.Scene();',
    'scene.background = new THREE.Color(0x0a0b0f);',
    'scene.fog = new THREE.Fog(0x0a0b0f, 20, 60);',
    'var BASE_FOV = 60;',
    'function computeFov(aspect, baseFov){',
    '  if (aspect >= 1) return baseFov;',
    '  var baseFovRad = THREE.MathUtils.degToRad(baseFov);',
    '  var vFovRad = 2 * Math.atan(Math.tan(baseFovRad/2) / aspect);',
    '  return Math.min(THREE.MathUtils.radToDeg(vFovRad), 100);',
    '}',
    'var camera = new THREE.PerspectiveCamera(BASE_FOV, window.innerWidth/window.innerHeight, 0.1, 500);',
    'camera.fov = computeFov(camera.aspect, BASE_FOV); camera.updateProjectionMatrix();',
    'var hemi = new THREE.HemisphereLight(0xdfe8ff, 0x2a2416, 0.9); scene.add(hemi);',
    'var dirLight = new THREE.DirectionalLight(0xffffff, 1.4);',
    'dirLight.position.set(6,10,4); dirLight.castShadow = true;',
    'dirLight.shadow.mapSize.set(2048,2048);',
    'dirLight.shadow.camera.left=-15; dirLight.shadow.camera.right=15; dirLight.shadow.camera.top=15; dirLight.shadow.camera.bottom=-15;',
    'scene.add(dirLight);',
    'var GROUND_SIZE = Math.max(10, (PROJECT.environment && PROJECT.environment.groundSize) || 40);',
    'var SCENE_HALF_EXTENT = Math.max(5, (GROUND_SIZE/2) - 1);',
    'var groundMat = new THREE.MeshStandardMaterial({color:0x1c2029, roughness:1});',
    'var ground = new THREE.Mesh(new THREE.PlaneGeometry(GROUND_SIZE,GROUND_SIZE), groundMat);',
    'ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);',
    'scene.add(new THREE.GridHelper(GROUND_SIZE,GROUND_SIZE,0x333947,0x21242e));',
    'function resize(){ var w=window.innerWidth||1, h=window.innerHeight||1; renderer.setSize(w, h, false); camera.aspect = w/h; camera.fov = computeFov(camera.aspect, BASE_FOV); camera.updateProjectionMatrix(); }',
    // Al rotar el movil con un dedo activo sobre el visor, ese touch.identifier sigue "vivo" pero
    // sus coordenadas pasan a referirse a la nueva orientacion de golpe -- el siguiente touchmove ve
    // un salto enorme y lo interpreta como "mirar muy arriba de golpe" (modo dron/spiderman en 3a
    // persona). Soltamos el seguimiento tactil antes de que llegue ese touchmove corrupto.
    'function soltarTactilPorCambioDeOrientacion(){ touchLookId=null; resetTouchJoystick(); }',
    'window.addEventListener("resize", resize);',
    'window.addEventListener("orientationchange", function(){ soltarTactilPorCambioDeOrientacion(); setTimeout(resize,50); setTimeout(resize,300); });',
    'if(window.visualViewport){ window.visualViewport.addEventListener("resize", function(){ soltarTactilPorCambioDeOrientacion(); resize(); }); }',
    'resize();',
    'function sunPositionFromAngles(elevationDeg, azimuthDeg, radius){',
    '  var elev = deg2rad(elevationDeg), azim = deg2rad(azimuthDeg);',
    '  var r = radius || 12;',
    '  return { x: r*Math.cos(elev)*Math.sin(azim), y: r*Math.sin(elev), z: r*Math.cos(elev)*Math.cos(azim) };',
    '}',
    'function sunAnglesFromHour(hour){',
    '  var angle = 2*Math.PI*(hour-6)/24;',
    '  var elevationDeg = 80*Math.sin(angle);',
    '  var azimuthDeg = (hour/24*360) % 360;',
    '  var intensityFactor = clamp((elevationDeg+10)/20, 0.08, 1);',
    '  return { elevationDeg: elevationDeg, azimuthDeg: azimuthDeg, intensityFactor: intensityFactor };',
    '}',
    'function sunAnglesFromRealDateTime(date, latitudeDeg){',
    '  var lat = deg2rad(latitudeDeg != null ? latitudeDeg : 40);',
    '  var startOfYear = new Date(date.getFullYear(), 0, 0);',
    '  var dayOfYear = Math.floor((date - startOfYear) / 86400000);',
    '  var decl = deg2rad(23.44 * Math.sin(deg2rad((360/365) * (dayOfYear - 81))));',
    '  var hour = date.getHours() + date.getMinutes()/60 + date.getSeconds()/3600;',
    '  var hourAngle = deg2rad(15 * (hour - 12));',
    '  var elevRad = Math.asin(Math.sin(lat)*Math.sin(decl) + Math.cos(lat)*Math.cos(decl)*Math.cos(hourAngle));',
    '  var elevationDeg = elevRad * 180 / Math.PI;',
    '  var azimuthDeg = (hour/24*360) % 360;',
    '  var intensityFactor = clamp((elevationDeg+10)/20, 0.08, 1);',
    '  return { elevationDeg: elevationDeg, azimuthDeg: azimuthDeg, intensityFactor: intensityFactor };',
    '}',
    'var dayCycleClock = 0;',
    'var dayCycleTotalSec = 0;',
    'function computeSunHourOfDay(dt){',
    '  if(PROJECT.environment && PROJECT.environment.sunMode === "realtime"){',
    '    var now = new Date();',
    '    return now.getHours() + now.getMinutes()/60 + now.getSeconds()/3600;',
    '  }',
    '  if(PROJECT.environment && PROJECT.environment.sunMode === "cycle"){',
    '    dayCycleClock += dt;',
    '    dayCycleTotalSec += dt;',
    '    var dayLenSec = Math.max(10, (PROJECT.environment.dayDurationMin || 10) * 60);',
    '    dayCycleClock = dayCycleClock % dayLenSec;',
    '    return (dayCycleClock/dayLenSec) * 24;',
    '  }',
    '  return null;',
    '}',
    'function updateSunCycle(dt){',
    '  var env = PROJECT.environment;',
    '  if(!env || !env.sunMode || env.sunMode === "manual") return;',
    '  var a;',
    '  if(env.sunMode === "realtime"){',
    '    a = sunAnglesFromRealDateTime(new Date(), env.latitudeDeg);',
    '  } else {',
    '    var hour = computeSunHourOfDay(dt);',
    '    if(hour == null) return;',
    '    a = sunAnglesFromHour(hour);',
    '  }',
    '  var azimuthDeg = (a.azimuthDeg + (env.sunOrientationOffsetDeg || 0)) % 360;',
    '  dirLight.color.set(env.sunColor || "#ffffff");',
    '  dirLight.intensity = (env.sunIntensity != null ? env.sunIntensity : 1.4) * a.intensityFactor;',
    '  var sunPos = sunPositionFromAngles(a.elevationDeg, azimuthDeg);',
    '  dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);',
    '  applyNightTint(a.elevationDeg);',
    '}',
    'function nightTintFactorFromElevation(elevationDeg){ return clamp((10-elevationDeg)/30, 0, 1); }',
    'function lerpColorHex(hexA, hexB, t){',
    '  var a = parseInt((hexA || "#000000").replace("#",""), 16), b = parseInt((hexB || "#000000").replace("#",""), 16);',
    '  var ar=(a>>16)&255, ag=(a>>8)&255, ab=a&255;',
    '  var br=(b>>16)&255, bg=(b>>8)&255, bb=b&255;',
    '  var r=Math.round(ar+(br-ar)*t), g=Math.round(ag+(bg-ag)*t), bl=Math.round(ab+(bb-ab)*t);',
    '  return "#" + ((1<<24)+(r<<16)+(g<<8)+bl).toString(16).slice(1);',
    '}',
    'function applyNightTint(elevationDeg){',
    '  var factor = nightTintFactorFromElevation(elevationDeg);',
    '  var el = document.getElementById("nightTintOverlay");',
    '  if(el) el.style.opacity = String(factor * 0.55);',
    '  if(!PROJECT.environment.horizonBase64){',
    '    var blended = lerpColorHex(PROJECT.environment.bgColor || "#0a0b0f", PROJECT.environment.nightBgColor || "#050912", factor);',
    '    scene.background = new THREE.Color(blended);',
    '    scene.fog.color.set(blended);',
    '  }',
    '}',
    'function applyEnvironment(env){',
    '  if(!env) return;',
    '  if(env.horizonBase64){',
    '    var img = new Image();',
    '    img.onload = function(){ var tex = new THREE.Texture(img); tex.needsUpdate = true; scene.background = tex; };',
    '    img.src = env.horizonBase64;',
    '  } else {',
    '    scene.background = new THREE.Color(env.bgColor || "#0a0b0f");',
    '  }',
    '  scene.fog.color.set(env.bgColor || "#0a0b0f");',
    '  scene.fog.far = Math.max(10, env.fogFar || 60);',
    '  scene.fog.near = scene.fog.far / 3;',
    '  groundMat.color.set(env.groundColor || "#1c2029");',
    '  dirLight.color.set(env.sunColor || "#ffffff");',
    '  if(!env.sunMode || env.sunMode === "manual"){',
    '    dirLight.intensity = env.sunIntensity != null ? env.sunIntensity : 1.4;',
    '    var elevationDeg = env.sunElevationDeg != null ? env.sunElevationDeg : 54;',
    '    var sunPos = sunPositionFromAngles(elevationDeg, env.sunAzimuthDeg != null ? env.sunAzimuthDeg : 56);',
    '    dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);',
    '    applyNightTint(elevationDeg);',
    '  }',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }',
    'function deg2rad(d){ return d*Math.PI/180; }',
    'function easeVal(p,kind){ if(kind==="smooth") return p*p*(3-2*p); return p; }',
    'function lerp(a,b,p){ return a+(b-a)*p; }',
    'function base64ToArrayBuffer(b64){ var binary=atob(b64); var bytes=new Uint8Array(binary.length); for(var i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i); return bytes.buffer; }',
    'function evalSafeExpr(expr, vars){',
    '  var s = String(expr==null ? "" : expr); var i = 0;',
    '  function peek(){ return s[i]; }',
    '  function skipWs(){ while(i<s.length && /\\s/.test(s[i])) i++; }',
    '  function toNum(v){ var n = typeof v==="number" ? v : parseFloat(v); return isNaN(n) ? 0 : n; }',
    '  function truthy(v){ return typeof v==="string" ? (v!=="" && v!=="0") : !!v; }',
    '  function addVals(a,b){ if(typeof a==="string" || typeof b==="string") return String(a==null?"":a)+String(b==null?"":b); return toNum(a)+toNum(b); }',
    '  function compareVals(a,b,op){',
    '    var r;',
    '    if(typeof a==="string" || typeof b==="string"){',
    '      var as=String(a==null?"":a), bs=String(b==null?"":b);',
    '      if(op==="==") r=(as===bs); else if(op==="!=") r=(as!==bs); else if(op===">") r=(as>bs); else if(op==="<") r=(as<bs); else if(op===">=") r=(as>=bs); else r=(as<=bs);',
    '    } else {',
    '      var an=toNum(a), bn=toNum(b);',
    '      if(op==="==") r=(an===bn); else if(op==="!=") r=(an!==bn); else if(op===">") r=(an>bn); else if(op==="<") r=(an<bn); else if(op===">=") r=(an>=bn); else r=(an<=bn);',
    '    }',
    '    return r?1:0;',
    '  }',
    '  function parseAtom(){',
    '    skipWs(); var c = peek();',
    '    if(c==="("){ i++; var v=parseExpr(); skipWs(); if(peek()===")") i++; return v; }',
    '    if(c===\'"\' || c==="\'"){',
    '      var quote=c; i++; var start=i;',
    '      while(i<s.length && s[i]!==quote) i++;',
    '      var str=s.slice(start,i); if(peek()===quote) i++;',
    '      return str;',
    '    }',
    '    if((c>="0" && c<="9") || c==="."){ var start2=i; while(i<s.length && ((s[i]>="0"&&s[i]<="9")||s[i]===".")) i++; return parseFloat(s.slice(start2,i)); }',
    '    if(/[A-Za-z_]/.test(c||"")){ var start3=i; while(i<s.length && /[A-Za-z0-9_]/.test(s[i])) i++; var name=s.slice(start3,i); var val=vars?vars[name]:undefined; return val===undefined?0:val; }',
    '    i++; return 0;',
    '  }',
    '  function parseUnary(){ skipWs(); if(peek()==="-"){ i++; return -toNum(parseUnary()); } if(peek()==="+"){ i++; return parseUnary(); } if(peek()==="!"){ i++; return truthy(parseUnary())?0:1; } return parseAtom(); }',
    '  function parseTerm(){',
    '    var v=parseUnary();',
    '    for(;;){ skipWs(); var op=peek(); if(op==="*"||op==="/"||op==="%"){ i++; var rhs=parseUnary(); v=(op==="*")?(toNum(v)*toNum(rhs)):(op==="/")?(toNum(v)/(toNum(rhs)||1e-9)):(toNum(v)%(toNum(rhs)||1e-9)); } else break; }',
    '    return v;',
    '  }',
    '  function parseAdditive(){',
    '    var v=parseTerm();',
    '    for(;;){ skipWs(); var op=peek(); if(op==="+"||op==="-"){ i++; var rhs=parseTerm(); v=(op==="+")?addVals(v,rhs):(toNum(v)-toNum(rhs)); } else break; }',
    '    return v;',
    '  }',
    '  function parseCompare(){',
    '    var v=parseAdditive(); skipWs();',
    '    var two=s.substr(i,2), op=null;',
    '    if(two===">="||two==="<="||two==="=="||two==="!="){ op=two; i+=2; }',
    '    else if(peek()===">"||peek()==="<"){ op=peek(); i+=1; }',
    '    if(op){ skipWs(); var rhs=parseAdditive(); v=compareVals(v,rhs,op); }',
    '    return v;',
    '  }',
    '  function parseAnd(){',
    '    var v=parseCompare();',
    '    for(;;){ skipWs(); if(s.substr(i,2)==="&&"){ i+=2; var rhs=parseCompare(); v=(truthy(v)&&truthy(rhs))?1:0; } else break; }',
    '    return v;',
    '  }',
    '  function parseOr(){',
    '    var v=parseAnd();',
    '    for(;;){ skipWs(); if(s.substr(i,2)==="||"){ i+=2; var rhs=parseAnd(); v=(truthy(v)||truthy(rhs))?1:0; } else break; }',
    '    return v;',
    '  }',
    '  function parseExpr(){ return parseOr(); }',
    '  try{ skipWs(); return s?parseExpr():0; } catch(e){ return 0; }',
    '}',
    'function interpolateVars(template, vars){',
    '  return String(template==null?"":template).replace(/\\{\\{\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\}\\}/g, function(m,name){',
    '    var v = vars?vars[name]:undefined; return encodeURIComponent(v==null?"":v);',
    '  });',
    '}',
    'function interpolateVarsPlain(template, vars){',
    '  return String(template==null?"":template).replace(/\\{\\{\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*\\}\\}/g, function(m,name){',
    '    var v = vars?vars[name]:undefined; return v==null?"":String(v);',
    '  });',
    '}',
    'function copiarTextoFallback(texto){',
    '  try{',
    '    var ta = document.createElement("textarea");',
    '    ta.value = texto; ta.style.position="fixed"; ta.style.opacity="0"; ta.style.left="-9999px";',
    '    document.body.appendChild(ta); ta.focus(); ta.select();',
    '    var ok = document.execCommand("copy");',
    '    document.body.removeChild(ta);',
    '    return ok;',
    '  } catch(e){ return false; }',
    '}',
    'function copiarTexto(texto){',
    '  if(window.isSecureContext && navigator.clipboard){',
    '    return navigator.clipboard.writeText(texto).then(function(){ return true; }).catch(function(){ return copiarTextoFallback(texto); });',
    '  }',
    '  return Promise.resolve(copiarTextoFallback(texto));',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function rad2deg(r){ return r*180/Math.PI; }',
    '',
    '/* =========================================================================',
    '   BOVEDA CELESTE NOCTURNA (estrellas y Luna reales, opcional por proyecto)',
    '   =========================================================================',
    '   Catalogo de ~757 estrellas reales (posiciones J2000 en grados, RA/Dec) que',
    '   forman las lineas clasicas de las 88 constelaciones IAU, mas los propios',
    '   segmentos de esas lineas -- adaptado de d3-celestial (c) Olaf Frohn, licencia',
    '   MIT, a su vez sobre datos del catalogo Hipparcos. NIGHT_SKY_STARS es un',
    '   array plano [ra,dec,mag, ra,dec,mag, ...]; "mag" aqui es una magnitud',
    '   aproximada por rango de brillo de la CONSTELACION (1/2/3), no una fotometria',
    '   exacta estrella a estrella -- ver README para como ampliarlo. Reservado',
    '   tambien NIGHT_SKY_CONSTELLATIONS (nombre en espanol + segmentos por indice)',
    '   para una futura identificacion de constelaciones con el puntero.',
    '*/',
    'var NIGHT_SKY_STARS = [30.975,42.33,2.0,17.433,35.621,2.0,9.832,30.861,2.0,2.097,29.09,2.0,14.302,23.418,2.0,11.835,24.267,2.0,9.639,29.312,2.0,9.22,33.719,2.0,354.534,43.268,2.0,345.48,42.326,2.0,355.102,44.334,2.0,354.391,46.458,2.0,14.188,38.499,2.0,12.454,41.079,2.0,17.375,47.242,2.0,24.498,48.628,2.0,356.509,46.42,2.0,142.311,-35.951,3.6,156.788,-31.068,3.6,164.179,-37.138,3.6,221.965,-79.045,3.6,245.087,-78.696,3.6,250.769,-77.517,3.6,248.363,-78.897,3.6,311.919,-9.496,2.8,313.163,-8.983,2.8,322.89,-5.571,2.8,331.446,-0.32,2.8,335.414,-1.387,2.8,337.208,-0.02,2.8,338.839,-0.117,2.8,343.154,-7.58,2.8,349.476,-9.182,2.8,347.362,-21.172,2.8,331.609,-13.87,2.8,334.209,-7.783,2.8,336.319,1.377,2.8,350.743,-20.101,2.8,355.441,-17.817,2.8,296.565,10.613,2.0,297.696,8.868,2.0,298.828,6.407,2.0,302.826,-0.822,2.0,298.118,1.006,2.0,291.375,3.115,2.0,286.353,13.864,2.0,286.562,-4.883,2.0,261.349,-56.378,3.6,262.775,-60.684,3.6,252.447,-59.041,3.6,254.655,-55.99,3.6,254.896,-53.16,3.6,262.96,-49.876,3.6,261.325,-55.53,3.6,42.496,27.261,2.0,31.793,23.462,2.0,28.66,20.808,2.0,28.383,19.294,2.0,89.882,44.947,2.0,79.172,45.998,2.0,76.629,41.234,2.0,74.248,33.166,2.0,81.573,28.608,2.0,89.93,37.213,2.0,89.882,54.285,2.0,75.492,43.823,2.0,75.62,41.076,2.0,206.816,17.457,2.0,208.671,18.398,2.0,213.915,19.182,2.0,217.958,30.371,2.0,218.019,38.308,2.0,225.487,40.391,2.0,228.876,33.315,2.0,221.247,27.074,2.0,220.287,13.728,2.0,214.096,46.088,2.0,213.366,51.788,2.0,216.299,51.851,2.0,67.709,-44.954,3.6,70.141,-41.864,3.6,70.514,-37.144,3.6,76.102,-35.483,3.6,74.322,53.752,2.8,75.855,60.442,2.8,73.513,66.343,2.8,57.59,71.332,2.8,57.38,65.526,2.8,52.267,59.94,2.8,94.712,69.32,2.8,105.017,76.977,2.8,134.622,11.858,2.8,131.171,18.154,2.8,130.821,21.468,2.8,131.667,28.765,2.8,124.129,9.185,2.8,194.002,38.315,2.8,188.436,41.358,2.8,95.675,-17.956,2.0,101.287,-16.716,2.0,105.756,-23.833,2.0,107.098,-26.393,2.0,105.43,-27.935,2.0,104.656,-28.972,2.0,95.078,-30.063,2.0,111.024,-29.303,2.0,104.034,-17.054,2.0,105.94,-15.633,2.0,103.547,-12.039,2.0,114.826,5.225,2.8,111.788,8.289,2.8,304.412,-12.508,2.8,305.253,-14.781,2.8,307.215,-17.814,2.8,311.524,-25.271,2.8,312.955,-26.919,2.8,321.667,-22.411,2.8,326.76,-16.127,2.8,325.023,-16.662,2.8,320.562,-16.834,2.8,316.487,-17.233,2.8,99.44,-43.196,2.0,95.988,-52.696,2.0,138.3,-69.717,2.0,153.434,-70.038,2.0,160.739,-64.394,2.0,158.006,-61.685,2.0,154.271,-61.332,2.0,139.273,-59.275,2.0,125.629,-59.51,2.0,119.195,-52.982,2.0,122.383,-47.337,2.0,131.176,-54.709,2.0,166.635,-62.424,2.0,167.142,-61.947,2.0,168.15,-60.318,2.0,167.148,-58.975,2.0,163.374,-58.853,2.0,28.599,63.67,2.0,21.454,60.235,2.0,14.177,60.717,2.0,10.127,56.537,2.0,2.295,59.15,2.0,170.252,-54.491,2.0,182.09,-50.722,2.0,187.01,-50.231,2.0,190.379,-48.96,2.0,204.972,-53.466,2.0,208.885,-47.288,2.0,207.404,-42.474,2.0,207.376,-41.688,2.0,211.671,-36.37,2.0,218.877,-42.158,2.0,224.79,-42.104,2.0,200.149,-36.712,2.0,219.896,-60.837,2.0,210.956,-60.373,2.0,182.913,-52.368,2.0,172.942,-59.442,2.0,307.395,62.994,2.8,311.322,61.839,2.8,319.645,62.586,2.8,325.877,58.78,2.8,333.759,57.044,2.8,332.714,58.201,2.8,337.293,58.415,2.8,342.42,66.2,2.8,354.837,77.632,2.8,322.165,70.561,2.8,40.825,3.236,2.0,38.969,5.593,2.0,37.04,8.46,2.0,41.236,10.114,2.0,44.929,8.907,2.0,45.57,4.09,2.0,39.871,0.329,2.0,34.837,-2.978,2.0,27.865,-10.335,2.0,26.017,-15.938,2.0,10.897,-17.987,2.0,4.857,-8.824,2.0,17.148,-10.182,2.0,21.006,-8.183,2.0,124.632,-76.92,3.6,158.867,-78.608,3.6,161.318,-80.47,3.6,184.587,-79.312,3.6,179.907,-78.222,3.6,229.379,-58.801,3.6,220.627,-64.975,3.6,230.844,-59.321,3.6,95.528,-33.436,3.6,87.74,-35.768,3.6,84.912,-34.074,3.6,82.803,-35.471,3.6,89.787,-42.815,3.6,197.497,17.529,3.6,197.968,27.878,3.6,186.734,28.268,3.6,284.681,-37.107,3.6,286.605,-37.063,3.6,287.368,-37.904,3.6,287.507,-39.341,3.6,287.087,-40.497,3.6,285.779,-42.095,3.6,282.396,-43.434,3.6,278.376,-42.312,3.6,233.232,31.359,2.8,231.957,29.106,2.8,233.672,26.715,2.8,235.686,26.296,2.8,237.399,26.068,2.8,239.397,26.878,2.8,240.361,29.851,2.8,182.103,-24.729,3.6,182.531,-22.62,3.6,183.952,-17.542,3.6,187.466,-16.515,3.6,188.597,-23.397,3.6,174.171,-9.802,3.6,171.153,-10.859,3.6,169.835,-14.778,3.6,164.944,-18.299,3.6,167.915,-22.826,3.6,170.841,-18.78,3.6,171.22,-17.684,3.6,176.191,-18.351,3.6,179.004,-17.151,3.6,191.93,-59.689,2.8,183.786,-58.749,2.8,186.65,-63.099,2.8,187.792,-57.113,2.8,318.234,30.227,2.0,311.553,33.97,2.0,305.557,40.257,2.0,296.244,45.131,2.0,292.427,51.73,2.0,289.276,53.368,2.0,310.358,45.28,2.0,299.077,35.083,2.0,292.68,27.96,2.0,308.303,11.303,3.6,309.387,14.595,3.6,309.909,15.912,3.6,311.662,16.124,3.6,310.865,15.075,3.6,64.007,-51.487,3.6,68.499,-55.045,3.6,83.406,-62.49,3.6,86.193,-65.736,3.6,88.525,-63.09,3.6,76.378,-57.473,3.6,268.382,56.873,2.8,269.151,51.489,2.8,262.608,52.301,2.8,263.067,55.173,2.8,288.139,67.662,2.8,275.189,71.338,2.8,257.197,65.715,2.8,245.998,61.514,2.8,240.472,58.565,2.8,231.232,58.966,2.8,211.097,64.376,2.8,188.371,69.788,2.8,172.851,69.331,2.8,275.264,72.733,2.8,297.043,70.268,2.8,318.956,5.248,3.6,318.62,10.007,3.6,317.585,10.132,3.6,76.962,-5.086,2.0,71.376,-3.255,2.0,69.08,-3.353,2.0,62.966,-6.838,2.0,59.507,-13.508,2.0,56.536,-12.102,2.0,55.812,-9.763,2.0,53.233,-9.458,2.0,44.107,-8.898,2.0,41.031,-13.859,2.0,41.276,-18.573,2.0,45.598,-23.625,2.0,49.879,-21.758,2.0,53.447,-21.633,2.0,56.712,-23.25,2.0,68.888,-30.562,2.0,66.009,-34.017,2.0,64.474,-33.798,2.0,57.364,-36.2,2.0,54.274,-40.275,2.0,49.982,-43.07,2.0,44.565,-40.305,2.0,40.167,-39.855,2.0,36.746,-47.704,2.0,34.127,-51.512,2.0,28.989,-51.609,2.0,24.428,-57.237,2.0,48.019,-28.988,3.6,42.273,-32.406,3.6,31.123,-29.297,3.6,93.719,22.507,2.0,95.74,22.514,2.0,100.983,25.131,2.0,107.785,30.245,2.0,113.649,31.888,2.0,116.329,28.026,2.0,113.981,26.896,2.0,110.031,21.982,2.0,106.027,20.57,2.0,99.428,16.399,2.0,101.322,12.896,2.0,109.523,16.54,2.0,345.22,-52.754,3.6,342.139,-51.317,3.6,340.667,-46.885,3.6,337.439,-43.749,3.6,332.058,-46.961,3.6,337.317,-43.496,3.6,333.904,-41.347,3.6,331.529,-39.543,3.6,328.482,-37.365,3.6,245.48,19.153,2.8,247.555,21.49,2.8,250.322,31.603,2.8,250.724,38.922,2.8,248.526,42.437,2.8,244.935,46.313,2.8,242.192,44.935,2.8,238.169,42.452,2.8,255.072,30.926,2.8,258.762,36.809,2.8,269.063,37.251,2.8,260.921,37.146,2.8,258.758,24.839,2.8,266.615,27.721,2.8,269.441,29.248,2.8,271.886,28.762,2.8,258.662,14.39,2.8,63.501,-42.294,3.6,40.639,-50.8,3.6,39.352,-52.543,3.6,40.165,-54.55,3.6,45.903,-59.738,3.6,44.699,-64.071,3.6,131.694,6.419,2.8,132.108,5.838,2.8,130.806,3.399,2.8,129.689,3.341,2.8,129.414,5.704,2.8,133.848,5.946,2.8,138.591,2.314,2.8,144.964,-1.143,2.8,141.897,-8.659,2.8,147.87,-14.847,2.8,152.647,-12.354,2.8,156.523,-16.836,2.8,162.406,-16.194,2.8,173.25,-31.858,2.8,178.227,-33.908,2.8,199.73,-23.172,2.8,211.593,-26.682,2.8,222.572,-27.96,2.8,6.438,-77.254,3.6,56.81,-74.239,3.6,39.897,-68.267,3.6,35.437,-68.659,3.6,28.734,-67.647,3.6,29.692,-61.57,3.6,309.392,-47.291,3.6,311.01,-51.921,3.6,313.702,-58.454,3.6,329.48,-54.993,3.6,319.967,-53.449,3.6,335.89,52.229,3.6,337.823,50.282,3.6,337.383,47.707,3.6,335.256,46.537,3.6,337.622,43.123,3.6,340.129,44.276,3.6,336.129,49.476,3.6,333.47,39.715,3.6,333.992,37.749,3.6,152.093,11.967,2.0,151.833,16.763,2.0,154.993,19.841,2.0,168.527,20.524,2.0,177.265,14.572,2.0,168.56,15.43,2.0,154.173,23.417,2.0,148.191,26.007,2.0,146.463,23.774,2.0,151.857,35.245,3.6,156.478,33.796,3.6,163.328,34.215,3.6,156.971,36.707,3.6,143.556,36.398,3.6,91.539,-14.935,3.6,89.101,-14.168,3.6,86.739,-14.822,3.6,83.183,-17.822,3.6,78.233,-16.206,3.6,76.365,-22.371,3.6,82.061,-20.759,3.6,86.116,-22.448,3.6,87.83,-20.879,3.6,78.308,-12.941,3.6,79.894,-13.177,3.6,226.018,-25.282,2.8,222.72,-16.042,2.8,229.252,-9.383,2.8,233.882,-14.79,2.8,234.256,-28.135,2.8,234.664,-29.778,2.8,237.74,-33.627,3.6,234.942,-34.412,3.6,230.452,-36.261,3.6,230.343,-40.648,3.6,224.633,-43.134,3.6,220.482,-47.388,3.6,228.071,-52.099,3.6,229.633,-47.875,3.6,230.67,-44.69,3.6,233.785,-41.167,3.6,240.031,-38.397,3.6,241.648,-36.802,3.6,94.906,59.011,3.6,104.319,58.423,3.6,111.678,49.212,3.6,125.709,43.188,3.6,135.16,41.783,3.6,139.711,36.803,3.6,140.264,34.393,3.6,281.193,37.605,2.8,281.095,39.613,2.8,279.235,38.784,2.8,283.626,36.899,2.8,284.736,32.69,2.8,282.52,33.363,2.8,92.56,-74.753,3.6,82.971,-76.341,3.6,73.797,-74.937,3.6,75.679,-71.314,3.6,312.492,-33.78,3.6,312.121,-43.989,3.6,320.19,-40.809,3.6,319.485,-32.172,3.6,315.323,-32.258,3.6,115.312,-9.551,2.8,122.148,-2.984,2.8,107.966,-0.493,2.8,97.204,-7.033,2.8,93.714,-6.275,2.8,101.965,2.412,2.8,95.942,4.593,2.8,98.226,7.333,2.8,100.244,9.896,2.8,176.402,-66.729,3.6,184.393,-67.961,3.6,189.296,-69.136,3.6,191.57,-68.108,3.6,195.568,-71.549,3.6,188.117,-72.133,3.6,241.623,-45.173,3.6,246.796,-47.555,3.6,244.96,-50.156,3.6,240.804,-49.23,3.6,216.73,-83.668,3.6,341.515,-81.382,3.6,325.369,-77.39,3.6,269.757,-9.774,2.8,266.973,2.707,2.8,265.868,4.567,2.8,263.734,12.56,2.8,254.417,9.375,2.8,247.728,1.984,2.8,243.586,-3.694,2.8,244.58,-4.692,2.8,249.29,-10.567,2.8,257.594,-15.725,2.8,247.785,-16.613,2.8,246.756,-18.456,2.8,246.026,-20.037,2.8,246.396,-23.447,2.8,260.502,-25.0,2.8,261.839,-29.867,2.8,91.893,14.768,2.0,88.596,20.276,2.0,90.98,20.139,2.0,92.985,14.209,2.0,90.596,9.647,2.0,88.793,7.407,2.0,81.283,6.35,2.0,73.724,10.151,2.0,74.637,1.714,2.0,73.563,2.441,2.0,72.802,5.605,2.0,72.46,6.961,2.0,72.653,8.9,2.0,74.093,13.514,2.0,76.142,15.404,2.0,77.425,15.597,2.0,78.635,-8.202,2.0,81.119,-2.397,2.0,83.002,-0.299,2.0,83.784,9.934,2.0,85.19,-1.943,2.0,86.939,-9.67,2.0,84.053,-1.202,2.0,306.412,-56.735,2.8,311.24,-66.203,2.8,302.182,-66.182,2.8,283.054,-62.188,2.8,275.807,-61.494,2.8,272.145,-63.669,2.8,266.433,-64.724,2.8,280.759,-71.428,2.8,300.148,-72.91,2.8,321.611,-65.366,2.8,332.497,33.178,2.0,340.751,30.221,2.0,345.944,28.083,2.0,3.309,15.184,2.0,346.19,15.205,2.0,341.673,12.173,2.0,340.365,10.831,2.0,332.55,6.198,2.0,326.046,9.875,2.0,342.501,24.602,2.0,341.633,23.566,2.0,331.753,25.345,2.0,326.161,25.645,2.0,56.08,32.288,2.0,58.533,31.884,2.0,59.741,35.791,2.0,59.464,40.01,2.0,56.298,42.578,2.0,55.731,47.788,2.0,54.122,48.193,2.0,51.081,49.861,2.0,46.199,53.506,2.0,42.674,55.895,2.0,43.564,52.763,2.0,47.267,49.613,2.0,47.374,44.858,2.0,47.042,40.956,2.0,47.822,39.612,2.0,46.294,38.84,2.0,44.69,39.663,2.0,44.916,41.033,2.0,61.646,50.351,2.0,63.724,48.409,2.0,62.165,47.712,2.0,41.05,49.228,2.0,25.915,50.689,2.0,6.571,-42.306,2.8,16.521,-46.718,2.8,22.091,-43.318,2.8,22.813,-49.073,2.8,17.096,-55.246,2.8,2.353,-45.747,2.8,102.048,-61.941,3.6,87.457,-56.167,3.6,86.821,-51.066,3.6,18.437,24.584,2.8,17.915,30.09,2.8,19.867,27.264,2.8,17.863,21.035,2.8,22.871,15.346,2.8,26.349,9.158,2.8,30.512,2.764,2.8,28.389,3.188,2.8,25.358,5.488,2.8,22.546,6.144,2.8,18.433,7.575,2.8,15.736,7.89,2.8,12.171,7.585,2.8,359.828,6.863,2.8,354.988,5.626,2.8,351.992,6.379,2.8,350.086,5.381,2.8,349.291,3.282,2.8,351.733,1.256,2.8,355.512,1.78,2.8,356.598,3.487,2.8,345.969,3.82,2.8,340.164,-27.044,2.8,344.413,-29.622,2.8,343.987,-32.54,2.8,343.131,-32.876,2.8,337.876,-32.346,2.8,332.096,-32.989,2.8,326.237,-33.026,2.8,326.934,-30.898,2.8,109.286,-37.097,2.8,113.845,-28.369,2.8,114.708,-26.804,2.8,117.324,-24.86,2.8,119.215,-22.88,2.8,121.886,-24.304,2.8,120.896,-40.003,2.8,117.022,-25.937,2.8,115.952,-28.955,2.8,130.026,-35.308,3.6,130.898,-33.186,3.6,132.633,-27.71,3.6,63.606,-62.474,3.6,64.121,-59.302,3.6,59.687,-61.4,3.6,56.05,-64.807,3.6,295.024,18.014,3.6,296.847,18.534,3.6,299.689,19.492,3.6,295.262,17.476,3.6,274.407,-36.762,2.0,276.043,-34.385,2.0,275.249,-29.828,2.0,276.993,-25.422,2.0,273.441,-21.059,2.0,290.66,-44.459,2.0,290.972,-40.616,2.0,285.653,-29.88,2.0,281.414,-26.991,2.0,298.815,-41.868,2.0,299.934,-35.276,2.0,298.96,-26.299,2.0,294.177,-24.884,2.0,291.319,-24.509,2.0,288.885,-25.257,2.0,283.816,-26.297,2.0,271.452,-30.424,2.0,286.735,-27.67,2.0,286.171,-21.741,2.0,287.441,-21.024,2.0,289.409,-18.953,2.0,290.418,-17.847,2.0,290.432,-15.955,2.0,284.433,-21.107,2.0,283.542,-22.745,2.0,239.713,-26.114,2.0,240.083,-22.622,2.0,241.359,-19.805,2.0,245.297,-25.593,2.0,247.352,-26.432,2.0,248.971,-28.216,2.0,252.541,-34.293,2.0,252.968,-38.047,2.0,253.646,-42.361,2.0,258.038,-43.239,2.0,264.33,-42.998,2.0,266.896,-40.127,2.0,265.622,-39.03,2.0,263.402,-37.104,2.0,14.652,-29.357,3.6,357.231,-28.13,3.6,349.706,-32.532,3.6,353.243,-37.818,3.6,278.802,-8.244,3.6,281.794,-4.748,3.6,280.568,-9.053,3.6,277.299,-14.566,3.6,236.547,15.422,3.6,235.388,19.67,3.6,237.185,18.142,3.6,239.113,15.662,3.6,233.701,10.539,3.6,236.067,6.426,3.6,237.704,4.478,3.6,264.397,-15.399,3.6,270.77,-8.18,3.6,275.327,-2.899,3.6,284.055,4.204,3.6,151.984,-0.372,3.6,148.127,-8.105,3.6,157.37,-2.739,3.6,157.573,-0.637,3.6,84.411,21.142,2.0,68.98,16.509,2.0,67.166,15.871,2.0,64.948,15.628,2.0,65.734,17.543,2.0,67.154,19.18,2.0,60.17,12.49,2.0,51.792,9.733,2.0,60.789,5.989,2.0,51.203,9.029,2.0,54.218,0.402,2.0,272.807,-45.954,3.6,276.743,-45.968,3.6,277.208,-49.071,3.6,28.27,29.579,3.6,32.386,34.987,3.6,34.329,33.847,3.6,252.166,-69.028,2.8,238.786,-63.431,2.8,229.727,-68.68,2.8,334.625,-60.26,3.6,349.357,-58.236,3.6,7.886,-62.958,3.6,5.018,-64.875,3.6,359.979,-65.577,3.6,336.833,-64.966,3.6,183.857,57.033,2.0,165.932,61.751,2.0,165.46,56.382,2.0,178.458,53.695,2.0,193.507,55.96,2.0,200.981,54.925,2.0,206.885,49.313,2.0,176.513,47.779,2.0,169.62,33.094,2.0,169.547,31.531,2.0,167.416,44.498,2.0,155.582,41.499,2.0,154.274,42.914,2.0,142.882,63.062,2.0,127.566,60.718,2.0,147.747,59.039,2.0,148.026,54.064,2.0,143.214,51.677,2.0,134.802,48.042,2.0,135.906,47.157,2.0,236.015,77.794,2.8,244.376,75.755,2.8,230.182,71.834,2.8,222.676,74.156,2.8,251.493,82.037,2.8,263.054,86.587,2.8,37.955,89.264,2.8,140.528,-55.011,2.8,149.216,-54.568,2.8,161.692,-49.42,2.8,153.684,-42.122,2.8,142.675,-40.467,2.8,136.999,-43.433,2.8,176.465,6.529,2.0,177.674,1.765,2.0,184.976,-0.667,2.0,190.415,-1.449,2.0,197.488,-5.539,2.0,201.298,-11.161,2.0,214.004,-6.0,2.0,220.765,-5.658,2.0,195.544,10.959,2.0,193.901,3.397,2.0,203.673,-0.596,2.0,210.412,1.544,2.0,221.562,1.893,2.0,135.612,-66.396,3.6,126.434,-66.137,3.6,121.983,-68.617,3.6,109.208,-67.957,3.6,107.187,-70.499,3.6,289.054,21.39,3.6,292.176,24.665,3.6,298.365,24.08,3.6,300.275,27.754,3.6,303.942,27.814,3.6];',
    'var NIGHT_SKY_CONSTELLATIONS = [{"id":"And","es":"Andr\\u00f3meda","rank":"1","seg":[[0,1],[1,2],[2,3],[4,5],[5,6],[6,2],[2,7],[7,8],[8,9],[8,10],[10,11],[1,12],[12,13],[13,14],[14,15],[10,16]]},{"id":"Ant","es":"M\\u00e1quina Neum\\u00e1tica","rank":"3","seg":[[17,18],[18,19]]},{"id":"Aps","es":"Ave del Para\\u00edso","rank":"3","seg":[[20,21],[21,22],[22,23]]},{"id":"Aqr","es":"Acuario","rank":"2","seg":[[24,25],[25,26],[26,27],[27,28],[28,29],[29,30],[30,31],[31,32],[32,33],[26,34],[27,35],[29,36],[37,32],[32,38]]},{"id":"Aql","es":"\\u00c1guila","rank":"1","seg":[[39,40],[40,41],[41,42],[42,43],[43,44],[44,45],[45,40],[40,44],[44,46]]},{"id":"Ara","es":"Altar","rank":"3","seg":[[47,48],[48,49],[49,50],[50,51],[51,52],[52,53]]},{"id":"Ari","es":"Carnero","rank":"1","seg":[[54,55],[55,56],[56,57]]},{"id":"Aur","es":"Cochero","rank":"1","seg":[[58,59],[59,60],[60,61],[61,62],[62,63],[63,58],[58,64],[64,59],[59,65],[65,66]]},{"id":"Boo","es":"Boyero","rank":"1","seg":[[67,68],[68,69],[69,70],[70,71],[71,72],[72,73],[73,74],[74,69],[69,75],[71,76],[76,77],[77,78],[78,76]]},{"id":"Cae","es":"Cincel","rank":"3","seg":[[79,80],[80,81],[81,82]]},{"id":"Cam","es":"Jirafa","rank":"2","seg":[[83,84],[84,85],[85,86],[86,87],[87,88],[85,89],[89,90]]},{"id":"Cnc","es":"Cangrejo","rank":"2","seg":[[91,92],[92,93],[93,94],[92,95]]},{"id":"CVn","es":"Lebreles","rank":"2","seg":[[96,97]]},{"id":"CMa","es":"Perro Mayor","rank":"1","seg":[[98,99],[99,100],[100,101],[101,102],[102,103],[103,104],[105,101],[99,106],[106,107],[107,108],[108,106]]},{"id":"CMi","es":"Perro Menor","rank":"2","seg":[[109,110]]},{"id":"Cap","es":"Capricornio","rank":"2","seg":[[111,112],[112,113],[113,114],[114,115],[115,116],[116,117],[117,118],[118,119],[119,120],[120,111]]},{"id":"Car","es":"Carina","rank":"1","seg":[[121,122],[122,123],[123,124],[124,125],[125,126],[126,127],[127,128],[128,129],[129,130],[130,131],[131,132],[132,128],[125,133],[133,134],[134,135],[135,136],[136,137],[137,126]]},{"id":"Cas","es":"Casiopea","rank":"1","seg":[[138,139],[139,140],[140,141],[141,142]]},{"id":"Cen","es":"Centauro","rank":"1","seg":[[143,144],[144,145],[145,146],[146,147],[147,148],[148,149],[149,150],[150,151],[151,152],[152,153],[150,154],[155,147],[147,156],[145,157],[157,158]]},{"id":"Cep","es":"Cefeo","rank":"2","seg":[[159,160],[160,161],[161,162],[162,163],[163,164],[164,165],[165,166],[166,167],[167,168],[168,161],[168,166]]},{"id":"Cet","es":"Ballena","rank":"1","seg":[[169,170],[170,171],[171,172],[172,173],[173,174],[174,169],[169,175],[175,176],[176,177],[177,178],[178,179],[179,180],[180,181],[181,182],[182,177]]},{"id":"Cha","es":"Camale\\u00f3n","rank":"3","seg":[[183,184],[184,185],[185,186],[186,187],[187,184]]},{"id":"Cir","es":"Comp\\u00e1s","rank":"3","seg":[[188,189],[189,190]]},{"id":"Col","es":"Paloma","rank":"3","seg":[[191,192],[192,193],[193,194],[192,195]]},{"id":"Com","es":"Pelo de Berenice","rank":"3","seg":[[196,197],[197,198]]},{"id":"CrA","es":"Corona Austral","rank":"3","seg":[[199,200],[200,201],[201,202],[202,203],[203,204],[204,205],[205,206]]},{"id":"CrB","es":"Corona Boreal","rank":"2","seg":[[207,208],[208,209],[209,210],[210,211],[211,212],[212,213]]},{"id":"Crv","es":"Cuervo","rank":"3","seg":[[214,215],[215,216],[216,217],[217,218],[218,215]]},{"id":"Crt","es":"Copa","rank":"3","seg":[[219,220],[220,221],[221,222],[222,223],[223,224],[224,225],[225,226],[226,227],[221,225]]},{"id":"Cru","es":"Cruz del Sur","rank":"2","seg":[[228,229],[230,231]]},{"id":"Cyg","es":"Cisne","rank":"1","seg":[[232,233],[233,234],[234,235],[235,236],[236,237],[238,234],[234,239],[239,240]]},{"id":"Del","es":"Delf\\u00edn","rank":"3","seg":[[241,242],[242,243],[243,244],[244,245],[245,242]]},{"id":"Dor","es":"Pez dorado","rank":"3","seg":[[246,247],[247,248],[248,249],[249,250],[250,248],[248,251],[251,247]]},{"id":"Dra","es":"Drag\\u00f3n","rank":"2","seg":[[252,253],[253,254],[254,255],[255,252],[252,256],[256,257],[257,258],[258,259],[259,260],[260,261],[261,262],[262,263],[263,264],[257,265],[256,266]]},{"id":"Equ","es":"Caballito","rank":"3","seg":[[267,268],[268,269]]},{"id":"Eri","es":"Er\\u00eddano","rank":"1","seg":[[270,271],[271,272],[272,273],[273,274],[274,275],[275,276],[276,277],[277,278],[278,279],[279,280],[280,281],[281,282],[282,283],[283,284],[284,285],[285,286],[286,287],[287,288],[288,289],[289,290],[290,291],[291,292],[292,293],[293,294],[294,295],[295,296]]},{"id":"For","es":"Horno","rank":"3","seg":[[297,298],[298,299]]},{"id":"Gem","es":"Gemelos","rank":"1","seg":[[300,301],[301,302],[302,303],[303,304],[304,305],[305,306],[306,307],[307,308],[308,309],[309,310],[307,311]]},{"id":"Gru","es":"Grulla","rank":"3","seg":[[312,313],[313,314],[314,315],[315,316],[316,314],[317,318],[318,319],[319,320]]},{"id":"Her","es":"H\\u00e9rcules","rank":"2","seg":[[321,322],[322,323],[323,324],[324,325],[325,326],[326,327],[327,328],[323,329],[324,330],[331,332],[332,330],[330,329],[329,333],[333,334],[334,335],[335,336],[337,322]]},{"id":"Hor","es":"Reloj","rank":"3","seg":[[338,339],[339,340],[340,341],[341,342],[342,343]]},{"id":"Hya","es":"Hidra","rank":"2","seg":[[344,345],[345,346],[346,347],[347,348],[348,344],[344,349],[349,350],[350,351],[351,352],[352,353],[353,354],[354,355],[355,356],[356,357],[357,358],[358,359],[359,360],[360,361]]},{"id":"Hyi","es":"Hidra Macho","rank":"3","seg":[[362,363],[363,364],[364,365],[365,366],[366,367]]},{"id":"Ind","es":"Indio","rank":"3","seg":[[368,369],[369,370],[370,371],[371,372],[372,368]]},{"id":"Lac","es":"Lagarto","rank":"3","seg":[[373,374],[374,375],[375,376],[376,377],[377,378],[378,375],[375,379],[379,373],[377,380],[380,381]]},{"id":"Leo","es":"Le\\u00f3n","rank":"1","seg":[[382,383],[383,384],[384,385],[385,386],[386,387],[387,382],[384,388],[388,389],[389,390]]},{"id":"LMi","es":"Le\\u00f3n Menor","rank":"3","seg":[[391,392],[392,393],[393,394],[394,391],[391,395]]},{"id":"Lep","es":"Conejo","rank":"3","seg":[[396,397],[397,398],[398,399],[399,400],[400,401],[401,402],[402,403],[403,404],[405,400],[400,406]]},{"id":"Lib","es":"Balanza","rank":"2","seg":[[407,408],[408,409],[409,410],[410,411],[411,412],[408,410]]},{"id":"Lup","es":"Lobo","rank":"3","seg":[[413,414],[414,415],[415,416],[416,417],[417,418],[418,419],[419,420],[420,421],[421,422],[422,423],[423,424],[416,422]]},{"id":"Lyn","es":"Lince","rank":"3","seg":[[425,426],[426,427],[427,428],[428,429],[429,430],[430,431]]},{"id":"Lyr","es":"Lira","rank":"2","seg":[[432,433],[433,434],[434,432],[432,435],[435,436],[436,437],[437,432]]},{"id":"Men","es":"Mesa","rank":"3","seg":[[438,439],[439,440],[440,441]]},{"id":"Mic","es":"Microscopio","rank":"3","seg":[[442,443],[443,444],[444,445],[445,446],[446,442]]},{"id":"Mon","es":"Unicornio","rank":"2","seg":[[447,448],[448,449],[449,450],[450,451],[449,452],[452,453],[453,454],[454,455]]},{"id":"Mus","es":"Mosca","rank":"3","seg":[[456,457],[457,458],[458,459],[459,460],[460,461],[461,458]]},{"id":"Nor","es":"Escuadra","rank":"3","seg":[[462,463],[463,464],[464,465],[465,462]]},{"id":"Oct","es":"Bast\\u00f3n","rank":"3","seg":[[466,467],[467,468],[468,466]]},{"id":"Oph","es":"Ofiuco","rank":"2","seg":[[469,470],[470,471],[471,472],[472,473],[473,474],[474,475],[475,476],[476,477],[477,478],[473,477],[477,479],[479,480],[480,481],[481,482],[471,478],[478,483],[483,484]]},{"id":"Ori","es":"Ori\\u00f3n","rank":"1","seg":[[485,486],[486,487],[487,488],[488,489],[489,490],[490,491],[491,492],[493,494],[494,495],[495,496],[496,497],[497,492],[492,498],[498,499],[499,500],[501,502],[502,503],[503,491],[491,504],[504,490],[490,505],[505,506],[505,507],[507,503]]},{"id":"Pav","es":"Pavo","rank":"2","seg":[[508,509],[509,510],[510,511],[511,512],[512,513],[513,514],[514,515],[515,516],[516,509],[509,517]]},{"id":"Peg","es":"Pegaso","rank":"1","seg":[[518,519],[519,520],[520,3],[3,521],[521,522],[522,523],[523,524],[524,525],[525,526],[522,520],[520,527],[527,528],[528,529],[529,530]]},{"id":"Per","es":"Perseo","rank":"1","seg":[[531,532],[532,533],[533,534],[534,535],[535,536],[536,537],[537,538],[538,539],[539,540],[540,541],[541,542],[542,543],[543,544],[544,545],[545,546],[546,547],[547,548],[548,544],[549,550],[550,551],[551,536],[542,552],[552,553]]},{"id":"Phe","es":"F\\u00e9nix","rank":"2","seg":[[554,555],[555,556],[556,557],[557,558],[558,555],[555,559],[559,554]]},{"id":"Pic","es":"Caballete del Pintor","rank":"3","seg":[[560,561],[561,562]]},{"id":"Psc","es":"Peces","rank":"2","seg":[[563,564],[564,565],[565,563],[563,566],[566,567],[567,568],[568,569],[569,570],[570,571],[571,572],[572,573],[573,574],[574,575],[575,576],[576,577],[577,578],[578,579],[579,580],[580,581],[581,582],[582,583],[583,577],[580,584]]},{"id":"PsA","es":"Pez Austral","rank":"2","seg":[[585,586],[586,587],[587,588],[588,589],[589,590],[590,591],[591,592],[592,590],[590,585]]},{"id":"Pup","es":"Popa","rank":"2","seg":[[121,593],[593,594],[594,595],[595,596],[596,597],[597,598],[598,599],[599,131],[596,600],[600,601],[601,594]]},{"id":"Pyx","es":"Br\\u00fajula","rank":"3","seg":[[599,602],[602,603],[603,604]]},{"id":"Ret","es":"Ret\\u00edculo","rank":"3","seg":[[605,606],[606,607],[607,608],[608,605]]},{"id":"Sge","es":"Flecha","rank":"3","seg":[[609,610],[610,611],[612,610]]},{"id":"Sgr","es":"Sagitario","rank":"1","seg":[[613,614],[614,615],[615,616],[616,617],[618,619],[619,620],[620,621],[621,616],[622,623],[623,624],[624,625],[625,626],[626,627],[627,628],[628,621],[621,615],[615,629],[629,614],[614,620],[620,630],[630,628],[628,631],[631,632],[632,633],[633,634],[634,635],[631,636],[636,637],[637,628]]},{"id":"Sco","es":"Escorpi\\u00f3n","rank":"1","seg":[[638,639],[639,640],[639,641],[641,642],[642,643],[643,644],[644,645],[645,646],[646,647],[647,648],[648,649],[649,650],[650,651]]},{"id":"Scl","es":"Escultor","rank":"3","seg":[[652,653],[653,654],[654,655]]},{"id":"Sct","es":"Escudo","rank":"3","seg":[[656,657],[657,658],[658,659],[659,656]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[660,661],[661,662],[662,663],[663,660],[660,664],[664,665],[665,666],[666,475]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[478,667],[667,469],[469,668],[668,669],[669,670]]},{"id":"Sex","es":"Sextante","rank":"3","seg":[[671,672],[672,673],[673,674]]},{"id":"Tau","es":"Toro","rank":"1","seg":[[675,676],[676,677],[677,678],[678,679],[679,680],[680,62],[678,681],[681,682],[682,683],[682,684],[684,685]]},{"id":"Tel","es":"Telescopio","rank":"3","seg":[[686,687],[687,688]]},{"id":"Tri","es":"Tri\\u00e1ngulo","rank":"3","seg":[[689,690],[690,691],[691,689]]},{"id":"TrA","es":"Tri\\u00e1ngulo Austral","rank":"2","seg":[[692,693],[693,694],[694,692]]},{"id":"Tuc","es":"Tuc\\u00e1n","rank":"3","seg":[[695,696],[696,697],[697,698],[698,699],[699,700],[700,695]]},{"id":"UMa","es":"Osa Mayor","rank":"1","seg":[[701,702],[702,703],[703,704],[704,701],[701,705],[705,706],[706,707],[704,708],[708,709],[709,710],[708,711],[711,712],[711,713],[702,714],[714,715],[715,716],[716,703],[703,717],[717,718],[718,719],[720,718]]},{"id":"UMi","es":"Osa Menor","rank":"2","seg":[[721,722],[722,723],[723,724],[724,721],[721,725],[725,726],[726,727]]},{"id":"Vel","es":"Vela","rank":"2","seg":[[132,728],[728,729],[729,730],[730,731],[731,732],[732,733],[733,131]]},{"id":"Vir","es":"Virgen","rank":"1","seg":[[734,735],[735,736],[736,737],[737,738],[738,739],[739,740],[740,741],[742,743],[743,737],[738,744],[744,745],[745,746]]},{"id":"Vol","es":"Pez Volador","rank":"3","seg":[[747,748],[748,749],[749,750],[750,751],[751,749],[749,747]]},{"id":"Vul","es":"Zorra","rank":"3","seg":[[752,753],[753,754],[754,755],[755,756]]}];',
    'var NIGHT_SKY_DOME_R = 300; // radio del domo, dentro del far=500 de la camara',
    'var NIGHT_SKY_LIGHT_LAYER = 2; // capa dedicada: solo la ilumina la luz de fase lunar',
    '// Polo norte de la ecliptica en coordenadas ecuatoriales J2000 (RA=18h=270 grados,',
    '// Dec=90-23.439291=66.560709 grados). El eje de rotacion real de la Luna esta inclinado',
    '// solo ~1.54 grados respecto a este polo (frente a los ~5.14 grados del polo orbital), asi',
    '// que se usa como aproximacion del "norte selenografico" para orientar la textura -- el',
    '// error que esto introduce (libracion fisica/optica real, +-~8 grados de tambaleo) se ignora',
    '// a proposito: es un efecto menor e imperceptible para un adorno de fondo en el cielo.',
    'var ECLIPTIC_POLE_RA_DEG = 270.0, ECLIPTIC_POLE_DEC_DEG = 66.560709;',
    '',
    'function julianDateUTC(date) { return date.getTime() / 86400000 + 2440587.5; }',
    '',
    'function gmstDeg(jd) {',
    '  var d = jd - 2451545.0;',
    '  var g = 280.46061837 + 360.98564736629 * d;',
    '  return ((g % 360) + 360) % 360;',
    '}',
    '',
    '// Convierte ascension recta/declinacion (grados, J2000) a altura/acimut (grados) para un',
    '// instante (fecha juliana UT), latitud y longitud dadas -- formulas estandar de posicion',
    '// horizontal. El acimut usa el mismo convenio que sunPositionFromAngles() de este proyecto',
    '// (0 dispara hacia +Z, 90 hacia +X): no se corresponde con el norte geografico real de',
    '// ningun escenario en concreto, ya que estos escenarios no tienen una orientacion geografica',
    '// definida -- solo importa que el cielo gire de forma consistente y realista con el tiempo.',
    'function equatorialToAltAz(raDeg, decDeg, jd, latDeg, lonDeg) {',
    '  var lst = (gmstDeg(jd) + (lonDeg || 0)) % 360;',
    '  var haDeg = ((lst - raDeg + 540) % 360) - 180;',
    '  var ha = deg2rad(haDeg), dec = deg2rad(decDeg), lat = deg2rad(latDeg);',
    '  var sinAlt = Math.sin(dec) * Math.sin(lat) + Math.cos(dec) * Math.cos(lat) * Math.cos(ha);',
    '  var alt = Math.asin(clamp(sinAlt, -1, 1));',
    '  var cosAlt = Math.cos(alt) || 1e-9;',
    '  var cosAz = (Math.sin(dec) - Math.sin(alt) * Math.sin(lat)) / (cosAlt * Math.cos(lat) || 1e-9);',
    '  var sinAz = (-Math.sin(ha) * Math.cos(dec)) / cosAlt;',
    '  var az = Math.atan2(sinAz, clamp(cosAz, -1, 1));',
    '  return { altDeg: rad2deg(alt), azDeg: (rad2deg(az) + 360) % 360 };',
    '}',
    '',
    '// Posicion geocentrica aparente del Sol, baja precision (~0.01 grados, Meeus cap.25 abreviado).',
    '// Se usa SOLO para iluminar la Luna con su fase real -- es independiente del "sol artistico"',
    '// (sunAnglesFromRealDateTime / modo manual-ciclo-realtime), que ambienta el escenario pero no',
    '// pretende precision astronomica.',
    'function sunEquatorialPosition(jd) {',
    '  var d = jd - 2451545.0;',
    '  var L = ((280.460 + 0.9856474 * d) % 360 + 360) % 360;',
    '  var g = deg2rad(((357.528 + 0.9856003 * d) % 360 + 360) % 360);',
    '  var lambda = deg2rad(L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g));',
    '  var eps = deg2rad(23.439 - 0.0000004 * d);',
    '  var raRad = Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda));',
    '  var decRad = Math.asin(Math.sin(eps) * Math.sin(lambda));',
    '  return { raDeg: (rad2deg(raRad) + 360) % 360, decDeg: rad2deg(decRad) };',
    '}',
    '',
    '// Posicion geocentrica de la Luna (serie truncada Meeus/Chapront, terminos principales,',
    '// precision visual ~0.3 grados) + fraccion iluminada real a partir de la elongacion Luna-Sol.',
    'function moonEquatorialPosition(jd) {',
    '  var d = jd - 2451545.0;',
    '  var Lp = ((218.3164477 + 13.17639648 * d) % 360 + 360) % 360;',
    '  var D  = ((297.8501921 + 12.19074912 * d) % 360 + 360) % 360;',
    '  var M  = ((357.5291092 + 0.98560028  * d) % 360 + 360) % 360;',
    '  var Mp = ((134.9633964 + 13.06499295 * d) % 360 + 360) % 360;',
    '  var F  = ((93.2720950  + 13.22935024 * d) % 360 + 360) % 360;',
    '  var rD = deg2rad(D), rM = deg2rad(M), rMp = deg2rad(Mp), rF = deg2rad(F);',
    '  var dL = 6.289 * Math.sin(rMp) - 1.274 * Math.sin(2*rD - rMp) + 0.658 * Math.sin(2*rD)',
    '    - 0.186 * Math.sin(rM) - 0.059 * Math.sin(2*rD - 2*rMp) - 0.057 * Math.sin(2*rD - rM - rMp)',
    '    + 0.053 * Math.sin(2*rD + rMp) + 0.046 * Math.sin(2*rD - rM) - 0.041 * Math.sin(rM - rMp)',
    '    - 0.035 * Math.sin(rD) - 0.031 * Math.sin(rM + rMp) - 0.015 * Math.sin(2*rF - 2*rD)',
    '    + 0.011 * Math.sin(rMp - 4*rD);',
    '  var dB = 5.128 * Math.sin(rF) + 0.281 * Math.sin(rMp + rF) + 0.278 * Math.sin(rMp - rF)',
    '    + 0.173 * Math.sin(2*rD - rF) + 0.055 * Math.sin(2*rD - rMp + rF) + 0.046 * Math.sin(2*rD - rMp - rF)',
    '    + 0.033 * Math.sin(2*rD + rF) + 0.017 * Math.sin(2*rD + rMp + rF);',
    '  var lambda = deg2rad(Lp + dL);',
    '  var beta = deg2rad(dB);',
    '  var eps = deg2rad(23.439 - 0.0000004 * d);',
    '  var decRad = Math.asin(Math.sin(beta) * Math.cos(eps) + Math.cos(beta) * Math.sin(eps) * Math.sin(lambda));',
    '  var y = Math.sin(lambda) * Math.cos(eps) - Math.tan(beta) * Math.sin(eps);',
    '  var x = Math.cos(lambda);',
    '  var raRad = Math.atan2(y, x);',
    '  var elongDeg = ((D % 360) + 360) % 360;',
    '  var illumFrac = (1 - Math.cos(deg2rad(elongDeg))) / 2;',
    '  return {',
    '    raDeg: (rad2deg(raRad) + 360) % 360,',
    '    decDeg: rad2deg(decRad),',
    '    illumFrac: illumFrac,',
    '    waxing: elongDeg < 180,',
    '    elongDeg: elongDeg,',
    '  };',
    '}',
    '',
    'function moonPhaseName(elongDeg, illumFrac) {',
    '  if (illumFrac < 0.02) return "Luna nueva";',
    '  if (illumFrac > 0.98) return "Luna llena";',
    '  var waxing = elongDeg < 180;',
    '  if (illumFrac < 0.48) return waxing ? "Luna creciente" : "Luna menguante";',
    '  if (illumFrac > 0.52) return waxing ? "Luna gibosa (creciente)" : "Luna gibosa (menguante)";',
    '  return waxing ? "Cuarto creciente" : "Cuarto menguante";',
    '}',
    '',
    '// Fecha/hora simulada para sincronizar Luna y estrellas con el ciclo dia/noche rapido (Sol en',
    '// modo "cycle"): usa el dia de calendario real de hoy pero la hora avanza al ritmo del reloj',
    '// interno del ciclo (dayCycleClock/dayCycleTotalSec) en vez del reloj real.',
    'function simulatedSkyDate() {',
    '  var dayLenSec = Math.max(10, (PROJECT.environment.dayDurationMin || 10) * 60);',
    '  var daysElapsed = Math.floor(dayCycleTotalSec / dayLenSec);',
    '  var fracDay = dayCycleClock / dayLenSec;',
    '  var base = new Date();',
    '  base.setHours(0, 0, 0, 0);',
    '  return new Date(base.getTime() + daysElapsed * 86400000 + fracDay * 86400000);',
    '}',
    '// Devuelve la fecha/hora que debe usarse para calcular el cielo: manual fija, simulada del',
    '// ciclo rapido (Sol en modo "cycle"), o la del sistema en cualquier otro caso.',
    'function nightSkyDateForNow() {',
    '  if (PROJECT.environment.skyDateMode === "manual" && PROJECT.environment.skyManualDate) {',
    '    var dp = PROJECT.environment.skyManualDate.split("-").map(Number);',
    '    var tp = (PROJECT.environment.skyManualTime || "22:00").split(":").map(Number);',
    '    var utcMs = Date.UTC(dp[0] || 2000, (dp[1] || 1) - 1, dp[2] || 1, tp[0] || 0, tp[1] || 0, 0);',
    '    var offset = PROJECT.environment.skyUtcOffsetHours != null ? PROJECT.environment.skyUtcOffsetHours : 1;',
    '    return new Date(utcMs - offset * 3600000);',
    '  }',
    '  if (PROJECT.environment.sunMode === "cycle") return simulatedSkyDate();',
    '  return new Date();',
    '}',
    '',
    'var nightSkyGroup = null, nightSkyStarLayers = [], nightSkyMoonMesh = null, nightSkyMoonLight = null;',
    'var nightSkyStarDirCache = null;',
    'var nightSkyMoonTexture = null, nightSkyMoonFallbackTexture = null;',
    'var nightSkyClockAccum = 0, nightSkyLastCalcAt = -999;',
    'var nightSkyLastPhaseName = "";',
    'var nightSkyRotGroup = null;',
    'var nightSkyRotDeltaQuat = new THREE.Quaternion();',
    'var nightSkyRotJdAtRecalc = 0;',
    'var NIGHT_SKY_ROT_EPS_JD = 1 / 86400;',
    'var _nightSkyRotTmpQuat = new THREE.Quaternion();',
    '',
    'function buildFallbackMoonTexture() {',
    '  var c = document.createElement("canvas"); c.width = 256; c.height = 256;',
    '  var ctx = c.getContext("2d");',
    '  ctx.fillStyle = "#dcd7cc"; ctx.fillRect(0, 0, 256, 256);',
    '  var blobs = [[80,70,40],[152,58,28],[192,140,32],[68,162,36],[128,192,24],[40,118,20],[210,90,18]];',
    '  blobs.forEach(function (b) {',
    '    var g = ctx.createRadialGradient(b[0], b[1], 0, b[0], b[1], b[2]);',
    '    g.addColorStop(0, "rgba(88,86,90,.5)"); g.addColorStop(1, "rgba(88,86,90,0)");',
    '    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b[0], b[1], b[2], 0, Math.PI * 2); ctx.fill();',
    '  });',
    '  for (var i = 0; i < 160; i++) {',
    '    var x = Math.random() * 256, y = Math.random() * 256, r = 1 + Math.random() * 3;',
    '    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);',
    '    ctx.fillStyle = "rgba(55,55,60," + (0.12 + Math.random() * 0.25) + ")"; ctx.fill();',
    '  }',
    '  var tex = new THREE.CanvasTexture(c);',
    '  tex.colorSpace = THREE.SRGBColorSpace || tex.colorSpace;',
    '  return tex;',
    '}',
    '',
    'function makeNightStarLayer(count, sizePx, color, opacity) {',
    '  var geo = new THREE.BufferGeometry();',
    '  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(count * 3), 3));',
    '  var mat = new THREE.PointsMaterial({ color: color, size: sizePx, sizeAttenuation: false, transparent: true, opacity: opacity, depthWrite: false, fog: false });',
    '  var pts = new THREE.Points(geo, mat);',
    '  pts.frustumCulled = false;',
    '  pts.userData.baseOpacity = opacity;',
    '  return pts;',
    '}',
    '',
    'function buildNightSky() {',
    '  nightSkyGroup = new THREE.Group();',
    '  nightSkyGroup.renderOrder = -1000;',
    '  nightSkyGroup.visible = false;',
    '',
    '  nightSkyRotGroup = new THREE.Group();',
    '  nightSkyGroup.add(nightSkyRotGroup);',
    '',
    '  var realIdx = { bright: [], mid: [], dim: [] };',
    '  for (var i = 0; i < NIGHT_SKY_STARS.length; i += 3) {',
    '    var mag = NIGHT_SKY_STARS[i + 2];',
    '    (mag <= 2.2 ? realIdx.bright : (mag <= 3.0 ? realIdx.mid : realIdx.dim)).push(i);',
    '  }',
    '  var fillerRaDec = [];',
    '  var FILLER_COUNT = 2200;',
    '  for (var f = 0; f < FILLER_COUNT; f++) {',
    '    var ra = Math.random() * 360;',
    '    var dec = rad2deg(Math.asin(Math.random() * 2 - 1));',
    '    fillerRaDec.push(ra, dec);',
    '  }',
    '',
    '  var layerBright = makeNightStarLayer(realIdx.bright.length, 3.2, 0xfff3d8, 0.95);',
    '  var layerMid    = makeNightStarLayer(realIdx.mid.length,    2.3, 0xeef2ff, 0.85);',
    '  var layerDim    = makeNightStarLayer(realIdx.dim.length,    1.7, 0xd7dcf5, 0.7);',
    '  var layerFiller = makeNightStarLayer(FILLER_COUNT,          1.1, 0xaab0cf, 0.45);',
    '  layerBright.userData.starIdx = realIdx.bright;',
    '  layerMid.userData.starIdx = realIdx.mid;',
    '  layerDim.userData.starIdx = realIdx.dim;',
    '  layerFiller.userData.fillerRaDec = fillerRaDec;',
    '  nightSkyStarLayers = [layerBright, layerMid, layerDim, layerFiller];',
    '  nightSkyStarLayers.forEach(function (l) { nightSkyRotGroup.add(l); });',
    '',
    '  var moonGeo = new THREE.SphereGeometry(NIGHT_SKY_DOME_R * 0.045, 32, 32);',
    '  nightSkyMoonFallbackTexture = buildFallbackMoonTexture();',
    '  var moonMat = new THREE.ShaderMaterial({',
    '    uniforms: {',
    '      map: { value: nightSkyMoonFallbackTexture },',
    '      uLightDir: { value: new THREE.Vector3(1, 0, 0) },',
    '      uAmbient: { value: 0.15 },',
    '      uOpacity: { value: 1 },',
    '    },',
    '    vertexShader: [',
    '      "varying vec3 vNormalObj;",',
    '      "varying vec2 vUv;",',
    '      "void main() {",',
    '      "  vNormalObj = normal;",',
    '      "  vUv = uv;",',
    '      "  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);",',
    '      "}",',
    '    ].join("\\n"),',
    '    fragmentShader: [',
    '      "uniform sampler2D map;",',
    '      "uniform vec3 uLightDir;",',
    '      "uniform float uAmbient;",',
    '      "uniform float uOpacity;",',
    '      "varying vec3 vNormalObj;",',
    '      "varying vec2 vUv;",',
    '      "void main() {",',
    '      "  vec3 n = normalize(vNormalObj);",',
    '      "  float ndotl = max(dot(n, normalize(uLightDir)), 0.0);",',
    '      "  float shade = uAmbient + (1.0 - uAmbient) * ndotl;",',
    '      "  vec4 tex = texture2D(map, vUv);",',
    '      "  gl_FragColor = vec4(tex.rgb * shade, tex.a * uOpacity);",',
    '      "}",',
    '    ].join("\\n"),',
    '    transparent: true,',
    '    fog: false,',
    '  });',
    '  nightSkyMoonMesh = new THREE.Mesh(moonGeo, moonMat);',
    '  if (PROJECT.environment.moonTextureBase64) {',
    '    (function () {',
    '      var img = new Image();',
    '      img.onload = function () {',
    '        var tex = new THREE.Texture(img);',
    '        tex.needsUpdate = true;',
    '        nightSkyMoonTexture = tex;',
    '        moonMat.uniforms.map.value = tex;',
    '      };',
    '      img.src = PROJECT.environment.moonTextureBase64;',
    '    })();',
    '  }',
    '  nightSkyRotGroup.add(nightSkyMoonMesh);',
    '',
    '  scene.add(nightSkyGroup);',
    '}',
    '',
    'function setNightSkyOpacity(factor) {',
    '  nightSkyStarLayers.forEach(function (l) { l.material.opacity = l.userData.baseOpacity * factor; });',
    '  if (nightSkyMoonMesh) nightSkyMoonMesh.material.uniforms.uOpacity.value = clamp(factor * 1.4, 0, 1);',
    '}',
    '',
    'function placeStarLayerByIndices(layer, jd, lat, lon) {',
    '  var idxs = layer.userData.starIdx;',
    '  var arr = layer.geometry.attributes.position.array;',
    '  var visible = 0;',
    '  for (var k = 0; k < idxs.length; k++) {',
    '    var i = idxs[k];',
    '    var hz = equatorialToAltAz(NIGHT_SKY_STARS[i], NIGHT_SKY_STARS[i + 1], jd, lat, lon);',
    '    if (hz.altDeg < -1) continue;',
    '    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);',
    '    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;',
    '    visible++;',
    '  }',
    '  layer.geometry.setDrawRange(0, visible);',
    '  layer.geometry.attributes.position.needsUpdate = true;',
    '}',
    '',
    'function placeFillerLayer(layer, jd, lat, lon) {',
    '  var raDec = layer.userData.fillerRaDec;',
    '  var arr = layer.geometry.attributes.position.array;',
    '  var visible = 0;',
    '  for (var k = 0; k < raDec.length; k += 2) {',
    '    var hz = equatorialToAltAz(raDec[k], raDec[k + 1], jd, lat, lon);',
    '    if (hz.altDeg < -1) continue;',
    '    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);',
    '    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;',
    '    visible++;',
    '  }',
    '  layer.geometry.setDrawRange(0, visible);',
    '  layer.geometry.attributes.position.needsUpdate = true;',
    '}',
    '',
    'function refreshNightSkyStarDirCache(jd, lat, lon) {',
    '  if (!nightSkyStarDirCache || nightSkyStarDirCache.length !== NIGHT_SKY_STARS.length) nightSkyStarDirCache = new Float32Array(NIGHT_SKY_STARS.length);',
    '  for (var si = 0; si < NIGHT_SKY_STARS.length; si += 3) {',
    '    var shz = equatorialToAltAz(NIGHT_SKY_STARS[si], NIGHT_SKY_STARS[si + 1], jd, lat, lon);',
    '    if (shz.altDeg < 0) { nightSkyStarDirCache[si] = NaN; nightSkyStarDirCache[si + 1] = NaN; nightSkyStarDirCache[si + 2] = NaN; continue; }',
    '    var sp = sunPositionFromAngles(shz.altDeg, shz.azDeg, 1);',
    '    nightSkyStarDirCache[si] = sp.x; nightSkyStarDirCache[si + 1] = sp.y; nightSkyStarDirCache[si + 2] = sp.z;',
    '  }',
    '}',
    '',
    'function updateNightSkyRotationSample(jd, lat, lon) {',
    '  var hz1 = equatorialToAltAz(0, 0, jd, lat, lon);',
    '  var hz2 = equatorialToAltAz(0, 0, jd + NIGHT_SKY_ROT_EPS_JD, lat, lon);',
    '  var p1 = sunPositionFromAngles(hz1.altDeg, hz1.azDeg, 1);',
    '  var p2 = sunPositionFromAngles(hz2.altDeg, hz2.azDeg, 1);',
    '  var v1 = new THREE.Vector3(p1.x, p1.y, p1.z).normalize();',
    '  var v2 = new THREE.Vector3(p2.x, p2.y, p2.z).normalize();',
    '  nightSkyRotDeltaQuat.setFromUnitVectors(v1, v2);',
    '  nightSkyRotJdAtRecalc = jd;',
    '  if (nightSkyRotGroup) nightSkyRotGroup.quaternion.identity();',
    '}',
    '',
    'function recomputeNightSkyPositions() {',
    '  var when = nightSkyDateForNow();',
    '  var jd = julianDateUTC(when);',
    '  var lat = PROJECT.environment.latitudeDeg != null ? PROJECT.environment.latitudeDeg : 40;',
    '  var lon = PROJECT.environment.skyLongitudeDeg != null ? PROJECT.environment.skyLongitudeDeg : 0;',
    '',
    '  placeStarLayerByIndices(nightSkyStarLayers[0], jd, lat, lon);',
    '  placeStarLayerByIndices(nightSkyStarLayers[1], jd, lat, lon);',
    '  placeStarLayerByIndices(nightSkyStarLayers[2], jd, lat, lon);',
    '  placeFillerLayer(nightSkyStarLayers[3], jd, lat, lon);',
    '',
    '  refreshNightSkyStarDirCache(jd, lat, lon);',
    '  updateNightSkyRotationSample(jd, lat, lon);',
    '',
    '  var moonEq = moonEquatorialPosition(jd);',
    '  var moonHz = equatorialToAltAz(moonEq.raDeg, moonEq.decDeg, jd, lat, lon);',
    '  var moonPos = sunPositionFromAngles(moonHz.altDeg, moonHz.azDeg, NIGHT_SKY_DOME_R * 0.9);',
    '  nightSkyMoonMesh.position.set(moonPos.x, moonPos.y, moonPos.z);',
    '  nightSkyMoonMesh.visible = moonHz.altDeg > -2;',
    '',
    '  // Orientacion real del disco: antes el mesh se quedaba siempre con la rotacion por defecto de',
    '  // la esfera (un trozo arbitrario y fijo de la textura, sin relacion con la Luna real). Aqui se',
    '  // gira para que el eje local +X (centro de la textura equirectangular, u=0.5 -- el punto',
    '  // subterrestre medio, sin libracion) apunte hacia el observador, y el eje local +Y (borde',
    '  // superior de la textura, v=0 -- el polo norte de la Luna) apunte hacia la proyeccion del polo',
    '  // norte de la ecliptica sobre el disco visible. Con eso queda fijada tanto la cara que se ve',
    '  // como la inclinacion/roll del disco respecto al horizonte (angulo paralactico), que antes no',
    '  // se calculaba en absoluto. NOTA: no se invierte la U de la textura -- u=0 queda a la izquierda',
    '  // tal cual viene la imagen equirectangular.',
    '  var moonPoleHz = equatorialToAltAz(ECLIPTIC_POLE_RA_DEG, ECLIPTIC_POLE_DEC_DEG, jd, lat, lon);',
    '  var moonPolePt = sunPositionFromAngles(moonPoleHz.altDeg, moonPoleHz.azDeg, 1);',
    '  var moonLen = Math.sqrt(moonPos.x * moonPos.x + moonPos.y * moonPos.y + moonPos.z * moonPos.z) || 1;',
    '  var moonToObsX = -moonPos.x / moonLen, moonToObsY = -moonPos.y / moonLen, moonToObsZ = -moonPos.z / moonLen;',
    '  var moonPoleDot = moonPolePt.x * moonToObsX + moonPolePt.y * moonToObsY + moonPolePt.z * moonToObsZ;',
    '  var moonUpX = moonPolePt.x - moonToObsX * moonPoleDot, moonUpY = moonPolePt.y - moonToObsY * moonPoleDot, moonUpZ = moonPolePt.z - moonToObsZ * moonPoleDot;',
    '  var moonUpLen = Math.sqrt(moonUpX * moonUpX + moonUpY * moonUpY + moonUpZ * moonUpZ);',
    '  if (moonUpLen > 1e-6) {',
    '    moonUpX /= moonUpLen; moonUpY /= moonUpLen; moonUpZ /= moonUpLen;',
    '    var moonRgX = moonToObsY * moonUpZ - moonToObsZ * moonUpY,',
    '        moonRgY = moonToObsZ * moonUpX - moonToObsX * moonUpZ,',
    '        moonRgZ = moonToObsX * moonUpY - moonToObsY * moonUpX;',
    '    var moonBasis = new THREE.Matrix4().makeBasis(',
    '      new THREE.Vector3(moonToObsX, moonToObsY, moonToObsZ),',
    '      new THREE.Vector3(moonUpX, moonUpY, moonUpZ),',
    '      new THREE.Vector3(moonRgX, moonRgY, moonRgZ)',
    '    );',
    '    nightSkyMoonMesh.quaternion.setFromRotationMatrix(moonBasis);',
    '  }',
    '',
    '  var sunEq = sunEquatorialPosition(jd);',
    '  var sunHz = equatorialToAltAz(sunEq.raDeg, sunEq.decDeg, jd, lat, lon);',
    '  var lightPos = sunPositionFromAngles(sunHz.altDeg, sunHz.azDeg, NIGHT_SKY_DOME_R * 0.9 + 40);',
    '  var mdx = lightPos.x - moonPos.x, mdy = lightPos.y - moonPos.y, mdz = lightPos.z - moonPos.z;',
    '  var mdLen = Math.sqrt(mdx * mdx + mdy * mdy + mdz * mdz) || 1;',
    '  nightSkyMoonMesh.material.uniforms.uLightDir.value.set(mdx / mdLen, mdy / mdLen, mdz / mdLen);',
    '',
    '  nightSkyLastPhaseName = moonPhaseName(moonEq.elongDeg, moonEq.illumFrac);',
    '',
    '  meteorCurrentInfo = activeMeteorShowerNow(when);',
    '}',
    '',
    '// Se llama cada frame (editor y Modo jugar), igual que updateSunCycle(). Recoloca el domo sobre',
    '// la camara (como un skybox) todos los frames, pero solo recalcula posiciones astronomicas una',
    '// vez por segundo real -- el cielo tarda minutos en moverse de forma perceptible, así que no',
    '// hace falta mas resolucion y se ahorra trigonometria de ~3000 puntos cada frame.',
    'function updateNightSky(dt) {',
    '  if (!nightSkyGroup) buildNightSky();',
    '  nightSkyClockAccum += dt;',
    '  var dirLen = dirLight.position.length() || 1;',
    '  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));',
    '  var nightFactor = nightTintFactorFromElevation(elevDeg);',
    '  var enabled = !!PROJECT.environment.nightSkyEnabled;',
    '  nightSkyGroup.visible = enabled && nightFactor > 0.015;',
    '  if (!nightSkyGroup.visible) return;',
    '  nightSkyGroup.position.copy(camera.position);',
    '  setNightSkyOpacity(nightFactor);',
    '  updateMeteorShowers(dt);',
    '  if (nightSkyLastCalcAt < 0 || nightSkyClockAccum - nightSkyLastCalcAt >= 1) {',
    '    nightSkyLastCalcAt = nightSkyClockAccum;',
    '    recomputeNightSkyPositions();',
    '  }',
    '  if (nightSkyRotGroup && nightSkyLastCalcAt >= 0) {',
    '    var jdNow = julianDateUTC(nightSkyDateForNow());',
    '    var frac = (jdNow - nightSkyRotJdAtRecalc) / NIGHT_SKY_ROT_EPS_JD;',
    '    if (frac < 0) frac = 0;',
    '    _nightSkyRotTmpQuat.set(0, 0, 0, 1).slerp(nightSkyRotDeltaQuat, frac);',
    '    nightSkyRotGroup.quaternion.copy(_nightSkyRotTmpQuat);',
    '  }',
    '}',
    '',
    '',
    '/* =========================================================================',
    '   IDENTIFICACION DE CONSTELACIONES CON EL PUNTERO (bóveda celeste, fase 2)',
    '   ========================================================================= */',
    'var skyPointerRaycaster = new THREE.Raycaster();',
    'var SKY_POINTER_MAX_BLOCK_DIST = 80; // si hay algo mas cerca que esto en la mira, no se considera "cielo despejado"',
    'var SKY_POINTER_TOLERANCE_DEG = 9; // cono de tolerancia alrededor de la mira para "enganchar" una constelacion',
    'var skyPointerGroup = null;',
    'var skyPointerClockAccum = 0, skyPointerLastCalcAt = -999;',
    'var skyPointerCurrentConst = null;',
    '',
    'function ensureSkyPointerGroup() {',
    '  if (skyPointerGroup) return;',
    '  skyPointerGroup = new THREE.Group();',
    '  var mat = new THREE.LineBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, fog: false, depthWrite: false });',
    '  var geo = new THREE.BufferGeometry();',
    '  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(0), 3));',
    '  var line = new THREE.LineSegments(geo, mat);',
    '  line.frustumCulled = false;',
    '  line.renderOrder = -998;',
    '  skyPointerGroup.add(line);',
    '  skyPointerGroup.userData.lineMesh = line;',
    '  skyPointerGroup.visible = false;',
    '  nightSkyGroup.add(skyPointerGroup);',
    '}',
    '',
    '// Busca, entre TODAS las lineas de las 88 constelaciones, la mas cercana angularmente a la',
    '// direccion de mira (aimDir, vector unitario). Usa nightSkyStarDirCache (vectores unitarios ya',
    '// calculados en el ultimo recalculo del cielo -- ver recomputeNightSkyPositions) para que esto',
    '// sea barato (solo productos escalares, sin trigonometria) y pueda llamarse a cada rato mientras',
    '// el jugador mueve la mira.',
    'function findConstellationUnderAim(aimDir) {',
    '  if (!nightSkyStarDirCache) return null;',
    '  var thresholdDot = Math.cos(deg2rad(SKY_POINTER_TOLERANCE_DEG));',
    '  var bestConst = null, bestDot = thresholdDot;',
    '  for (var c = 0; c < NIGHT_SKY_CONSTELLATIONS.length; c++) {',
    '    var con = NIGHT_SKY_CONSTELLATIONS[c];',
    '    for (var s = 0; s < con.seg.length; s++) {',
    '      var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;',
    '      var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];',
    '      if (da === da) {',
    '        var dot1 = da * aimDir.x + db * aimDir.y + dc * aimDir.z;',
    '        if (dot1 > bestDot) { bestDot = dot1; bestConst = con; }',
    '      }',
    '      var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];',
    '      if (ea === ea) {',
    '        var dot2 = ea * aimDir.x + eb * aimDir.y + ec * aimDir.z;',
    '        if (dot2 > bestDot) { bestDot = dot2; bestConst = con; }',
    '      }',
    '    }',
    '  }',
    '  return bestConst;',
    '}',
    '',
    'function hideSkyPointerLabel() {',
    '  var el = document.getElementById("constellationPrompt");',
    '  if (el) el.style.display = "none";',
    '}',
    'function showSkyPointerLabel(text) {',
    '  var el = document.getElementById("constellationPrompt");',
    '  if (!el) return;',
    '  el.textContent = "✨ " + text;',
    '  el.style.display = "block";',
    '}',
    '',
    'function showSkyPointerConstellation(con) {',
    '  ensureSkyPointerGroup();',
    '  if (!con) {',
    '    skyPointerGroup.visible = false;',
    '    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }',
    '    return;',
    '  }',
    '  if (skyPointerCurrentConst === con) { skyPointerGroup.visible = true; return; }',
    '  skyPointerCurrentConst = con;',
    '  var positions = [];',
    '  for (var s = 0; s < con.seg.length; s++) {',
    '    var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;',
    '    var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];',
    '    var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];',
    '    if (da !== da || ea !== ea) continue;',
    '    positions.push(da * NIGHT_SKY_DOME_R, db * NIGHT_SKY_DOME_R, dc * NIGHT_SKY_DOME_R);',
    '    positions.push(ea * NIGHT_SKY_DOME_R, eb * NIGHT_SKY_DOME_R, ec * NIGHT_SKY_DOME_R);',
    '  }',
    '  var mesh = skyPointerGroup.userData.lineMesh;',
    '  mesh.geometry.dispose();',
    '  mesh.geometry = new THREE.BufferGeometry();',
    '  mesh.geometry.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(positions), 3));',
    '  skyPointerGroup.visible = true;',
    '  showSkyPointerLabel(con.es);',
    '}',
    '',
    '// Se llama cada frame en Modo jugar. "active" es el estado del interruptor del puntero (la misma',
    '// tecla L que ya existe: en el editor, el puntero láser multijugador; en el juego exportado, uno',
    '// nuevo dedicado solo a esto, ya que el exportado no tiene multijugador). Con la mira despejada',
    '// (nada de la escena más cerca que SKY_POINTER_MAX_BLOCK_DIST) y apuntando cerca de una figura de',
    '// constelacion, la resalta y muestra su nombre -- como un puntero de clase de astronomia.',
    'function updateSkyPointer(dt, active) {',
    '  if (!nightSkyGroup) return;',
    '  skyPointerClockAccum += dt;',
    '  if (!active || !nightSkyGroup.visible) {',
    '    if (skyPointerGroup && skyPointerGroup.visible) skyPointerGroup.visible = false;',
    '    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }',
    '    return;',
    '  }',
    '  if (skyPointerLastCalcAt >= 0 && skyPointerClockAccum - skyPointerLastCalcAt < 0.15) return;',
    '  skyPointerLastCalcAt = skyPointerClockAccum;',
    '',
    '  var whenPtr = nightSkyDateForNow();',
    '  var latPtr = PROJECT.environment.latitudeDeg != null ? PROJECT.environment.latitudeDeg : 40;',
    '  var lonPtr = PROJECT.environment.skyLongitudeDeg != null ? PROJECT.environment.skyLongitudeDeg : 0;',
    '  refreshNightSkyStarDirCache(julianDateUTC(whenPtr), latPtr, lonPtr);',
    '',
    '  var aimDir = new THREE.Vector3();',
    '  camera.getWorldDirection(aimDir);',
    '',
    '  var blockTargets = [];',
    '  sceneObjects.forEach(function (rec) {',
    '    if (playerRecordId && rec.id === playerRecordId) return;',
    '    if (rec.object3D) blockTargets.push(rec.object3D);',
    '  });',
    '  var blocked = false;',
    '  if (blockTargets.length) {',
    '    skyPointerRaycaster.set(camera.position, aimDir);',
    '    skyPointerRaycaster.far = SKY_POINTER_MAX_BLOCK_DIST;',
    '    blocked = skyPointerRaycaster.intersectObjects(blockTargets, true).length > 0;',
    '  }',
    '  if (blocked) { showSkyPointerConstellation(null); return; }',
    '  showSkyPointerConstellation(findConstellationUnderAim(aimDir));',
    '}',
    '',
    '',
    '/* =========================================================================',
    '   LLUVIAS DE METEOROS (bóveda celeste, fase 2)',
    '   =========================================================================',
    '   Tabla de las lluvias anuales principales (radiante RA/Dec aproximado y',
    '   rango de fechas activo, valores estándar redondeados -- no cambian de un',
    '   año a otro más que en un par de días). El ZHR (tasa horaria cenital) es',
    '   orientativo, se usa solo para pesar unas lluvias frente a otras, no como',
    '   dato de observación real.',
    '*/',
    'var METEOR_SHOWERS = [',
    '  { name: "Cuadrántidas",   raDeg: 230, decDeg: 49, startMonth: 12, startDay: 28, endMonth: 1,  endDay: 12, peakMonth: 1,  peakDay: 3,  zhr: 110 },',
    '  { name: "Líridas",        raDeg: 271, decDeg: 34, startMonth: 4,  startDay: 16, endMonth: 4,  endDay: 25, peakMonth: 4,  peakDay: 22, zhr: 18 },',
    '  { name: "Eta Acuáridas",  raDeg: 338, decDeg: -1, startMonth: 4,  startDay: 19, endMonth: 5,  endDay: 28, peakMonth: 5,  peakDay: 5,  zhr: 50 },',
    '  { name: "Perseidas",      raDeg: 46,  decDeg: 58, startMonth: 7,  startDay: 17, endMonth: 8,  endDay: 24, peakMonth: 8,  peakDay: 12, zhr: 100 },',
    '  { name: "Oriónidas",      raDeg: 95,  decDeg: 16, startMonth: 10, startDay: 2,  endMonth: 11, endDay: 7,  peakMonth: 10, peakDay: 21, zhr: 20 },',
    '  { name: "Leónidas",       raDeg: 152, decDeg: 22, startMonth: 11, startDay: 6,  endMonth: 11, endDay: 30, peakMonth: 11, peakDay: 18, zhr: 15 },',
    '  { name: "Gemínidas",      raDeg: 112, decDeg: 33, startMonth: 12, startDay: 4,  endMonth: 12, endDay: 17, peakMonth: 12, peakDay: 14, zhr: 150 },',
    '  { name: "Úrsidas",        raDeg: 217, decDeg: 75, startMonth: 12, startDay: 17, endMonth: 12, endDay: 26, peakMonth: 12, peakDay: 22, zhr: 10 },',
    '];',
    'var METEOR_RATE_SCALE = 4; // ajuste de juego: sube/baja lo seguido que se ven fugaces respecto al ZHR real',
    'var METEOR_MAX_ACTIVE = 6;',
    'var METEOR_DOME_R = NIGHT_SKY_DOME_R * 0.95;',
    '',
    'function dayOfYearApprox(month, day) {',
    '  var cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];',
    '  return cum[(month | 0) - 1] + (day | 0);',
    '}',
    '',
    '// Devuelve la lluvia activa "ganadora" ahora mismo (la de mayor actividad ponderada por ZHR, si',
    '// hay varias solapadas) y su tasa de aparicion por segundo para el juego, o null si no hay ninguna',
    '// activa en la fecha actual del cielo.',
    'function activeMeteorShowerNow(date) {',
    '  var doy = dayOfYearApprox(date.getMonth() + 1, date.getDate());',
    '  var best = null, bestWeighted = 0, bestActivity = 0;',
    '  for (var i = 0; i < METEOR_SHOWERS.length; i++) {',
    '    var sh = METEOR_SHOWERS[i];',
    '    var s = dayOfYearApprox(sh.startMonth, sh.startDay);',
    '    var e = dayOfYearApprox(sh.endMonth, sh.endDay);',
    '    var p = dayOfYearApprox(sh.peakMonth, sh.peakDay);',
    '    var inRange = s <= e ? (doy >= s && doy <= e) : (doy >= s || doy <= e);',
    '    if (!inRange) continue;',
    '    var span = s <= e ? (e - s) : (366 - s + e);',
    '    var distToPeak = Math.min(Math.abs(doy - p), 366 - Math.abs(doy - p));',
    '    var halfSpan = Math.max(1, span / 2);',
    '    var activity = clamp(1 - distToPeak / halfSpan, 0, 1);',
    '    var weighted = activity * sh.zhr;',
    '    if (weighted > bestWeighted) { bestWeighted = weighted; best = sh; bestActivity = activity; }',
    '  }',
    '  if (!best) return null;',
    '  var ratePerSecond = clamp((bestWeighted / 3600) * METEOR_RATE_SCALE, 0, 0.25);',
    '  return { shower: best, activity: bestActivity, ratePerSecond: ratePerSecond };',
    '}',
    '',
    'var meteorPool = [];',
    'var meteorCurrentInfo = null; // { shower, activity, ratePerSecond } o null, refrescado junto al resto del cielo',
    '',
    'function meteorMaterial() {',
    '  return new THREE.LineBasicMaterial({ color: 0xfff2cf, transparent: true, opacity: 0, fog: false, depthWrite: false });',
    '}',
    '',
    'function ensureMeteorPool() {',
    '  if (meteorPool.length) return;',
    '  for (var i = 0; i < METEOR_MAX_ACTIVE; i++) {',
    '    var geo = new THREE.BufferGeometry();',
    '    geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(6), 3));',
    '    var mesh = new THREE.LineSegments(geo, meteorMaterial());',
    '    mesh.frustumCulled = false;',
    '    mesh.visible = false;',
    '    nightSkyGroup.add(mesh);',
    '    meteorPool.push({ mesh: mesh, age: 0, duration: 0.4, active: false });',
    '  }',
    '}',
    '',
    'function spawnMeteor(radiantRaDeg, radiantDecDeg, jd, lat, lon) {',
    '  var hz = equatorialToAltAz(radiantRaDeg, radiantDecDeg, jd, lat, lon);',
    '  var radiantDir = new THREE.Vector3();',
    '  if (hz.altDeg > -20) {',
    '    var rp = sunPositionFromAngles(hz.altDeg, hz.azDeg, 1);',
    '    radiantDir.set(rp.x, rp.y, rp.z);',
    '  } else {',
    '    return; // radiante muy por debajo del horizonte, no merece la pena (rara vez visible igualmente)',
    '  }',
    '  var free = null;',
    '  for (var i = 0; i < meteorPool.length; i++) { if (!meteorPool[i].active) { free = meteorPool[i]; break; } }',
    '  if (!free) return;',
    '',
    '  var arbitrary = Math.abs(radiantDir.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);',
    '  var axis = new THREE.Vector3().crossVectors(radiantDir, arbitrary).normalize();',
    '  axis.applyAxisAngle(radiantDir, Math.random() * Math.PI * 2);',
    '  var startAngle = deg2rad(15 + Math.random() * 45);',
    '  var streakAngle = deg2rad(5 + Math.random() * 8);',
    '  var startDir = radiantDir.clone().applyAxisAngle(axis, startAngle);',
    '  var endDir = radiantDir.clone().applyAxisAngle(axis, startAngle + streakAngle);',
    '  if (startDir.y < -0.05 && endDir.y < -0.05) return; // por debajo del horizonte, no se ve',
    '',
    '  var arr = free.mesh.geometry.attributes.position.array;',
    '  arr[0] = startDir.x * METEOR_DOME_R; arr[1] = startDir.y * METEOR_DOME_R; arr[2] = startDir.z * METEOR_DOME_R;',
    '  arr[3] = endDir.x * METEOR_DOME_R;   arr[4] = endDir.y * METEOR_DOME_R;   arr[5] = endDir.z * METEOR_DOME_R;',
    '  free.mesh.geometry.attributes.position.needsUpdate = true;',
    '  free.mesh.visible = true;',
    '  free.age = 0;',
    '  free.duration = 0.35 + Math.random() * 0.25;',
    '  free.active = true;',
    '}',
    '',
    '// Se llama cada frame desde updateNightSky(). La tasa de aparicion (meteorCurrentInfo) solo se',
    '// recalcula una vez por segundo junto al resto del cielo (ver recomputeNightSkyPositions); aqui',
    '// solo se tira "el dado" de aparicion (proceso de Poisson: probabilidad = tasa * dt) y se anima',
    '// el desvanecido de las fugaces ya lanzadas.',
    'function updateMeteorShowers(dt) {',
    '  ensureMeteorPool();',
    '  if (meteorCurrentInfo && meteorCurrentInfo.ratePerSecond > 0 && Math.random() < meteorCurrentInfo.ratePerSecond * dt) {',
    '    var when = nightSkyDateForNow();',
    '    var jd = julianDateUTC(when);',
    '    var lat = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;',
    '    var lon = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;',
    '    spawnMeteor(meteorCurrentInfo.shower.raDeg, meteorCurrentInfo.shower.decDeg, jd, lat, lon);',
    '  }',
    '  for (var i = 0; i < meteorPool.length; i++) {',
    '    var m = meteorPool[i];',
    '    if (!m.active) continue;',
    '    m.age += dt;',
    '    var p = m.age / m.duration;',
    '    if (p >= 1) { m.active = false; m.mesh.visible = false; continue; }',
    '    var op = p < 0.15 ? (p / 0.15) : (1 - (p - 0.15) / 0.85);',
    '    m.mesh.material.opacity = clamp(op, 0, 1);',
    '  }',
    '}',
    '',
    '',
    '/* =========================================================================',
    '   GRILLO NOCTURNO -- canto sintetizado por código (bóveda celeste, fase 2)',
    '   ========================================================================= */',
    'var cricketAudioCtx = null;',
    'var cricketNextChirpMap = new Map(); // id de objeto -> proximo instante (AudioContext.currentTime) de canto',
    'var CRICKET_MAX_SOUNDING = 8;',
    'var CRICKET_HEAR_DIST = 14;',
    '',
    'function ensureCricketAudioCtx() {',
    '  if (cricketAudioCtx) return cricketAudioCtx;',
    '  try {',
    '    var Ctx = window.AudioContext || window.webkitAudioContext;',
    '    if (!Ctx) return null;',
    '    cricketAudioCtx = new Ctx();',
    '  } catch (e) { cricketAudioCtx = null; }',
    '  return cricketAudioCtx;',
    '}',
    '',
    '// Un "canto" de grillo real es un tren de 2-4 pulsos muy cortos y agudos (estridulación). Se',
    '// sintetiza con osciladores cuadrados de vida brevísima -- nada de archivos de audio.',
    'function playCricketChirp(ctx, vol) {',
    '  var now = ctx.currentTime;',
    '  var pulses = 2 + (Math.random() < 0.5 ? 0 : 1);',
    '  for (var p = 0; p < pulses; p++) {',
    '    var t0 = now + p * 0.03;',
    '    var osc = ctx.createOscillator();',
    '    var gain = ctx.createGain();',
    '    osc.type = "square";',
    '    osc.frequency.value = 4200 + (Math.random() * 300 - 150);',
    '    gain.gain.setValueAtTime(0.0001, t0);',
    '    gain.gain.linearRampToValueAtTime(vol, t0 + 0.004);',
    '    gain.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.022);',
    '    osc.connect(gain); gain.connect(ctx.destination);',
    '    osc.start(t0); osc.stop(t0 + 0.03);',
    '  }',
    '}',
    '',
    '// Se llama cada frame (editor y Modo jugar), igual que updateWeatherSystems(). Recorre los objetos',
    '// de la escena buscando prefabs "grillo" visibles; a los que les toque cantar (según su propio',
    '// reloj individual, con algo de aleatoriedad para que no canten todos a la vez) les hace sonar un',
    '// canto con el volumen segun distancia a la camara -- silencioso de dia.',
    'function updateCricketSounds(dt) {',
    '  var dirLen = dirLight.position.length() || 1;',
    '  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));',
    '  var nightFactor = nightTintFactorFromElevation(elevDeg);',
    '  if (nightFactor < 0.2) return;',
    '  var ctx = ensureCricketAudioCtx();',
    '  if (!ctx) return;',
    '  if (ctx.state === "suspended") { ctx.resume().catch(function () {}); }',
    '  var listenerPos = camera.position;',
    '  var sounded = 0;',
    '  var worldPos = new THREE.Vector3();',
    '  sceneObjects.forEach(function (rec) {',
    '    if (sounded >= CRICKET_MAX_SOUNDING) return;',
    '    if (rec.prefabType !== "grillo" || !rec.object3D || !rec.object3D.visible) return;',
    '    var id = rec.id;',
    '    var next = cricketNextChirpMap.get(id);',
    '    if (next == null) { next = ctx.currentTime + Math.random() * 1.5; cricketNextChirpMap.set(id, next); }',
    '    if (ctx.currentTime < next) return;',
    '    rec.object3D.getWorldPosition(worldPos);',
    '    var dist = listenerPos.distanceTo(worldPos);',
    '    cricketNextChirpMap.set(id, ctx.currentTime + 0.6 + Math.random() * 0.9);',
    '    if (dist > CRICKET_HEAR_DIST) return;',
    '    var vol = clamp(1 - dist / CRICKET_HEAR_DIST, 0, 1) * 0.14 * nightFactor;',
    '    if (vol < 0.003) return;',
    '    playCricketChirp(ctx, vol);',
    '    sounded++;',
    '  });',
    '}',
    '',
    'function makeStdMat(colorHex){ return new THREE.MeshStandardMaterial({ color: colorHex, roughness:0.85, metalness:0.05, transparent:true, opacity:1, side:THREE.DoubleSide }); }',
    'function addPart(group, mats, geo, color, x,y,z, rx,ry,rz){',
    '  var mat = makeStdMat(color); mats.push(mat);',
    '  var mesh = new THREE.Mesh(geo, mat); mesh.position.set(x,y,z);',
    '  if(rx) mesh.rotation.x=rx; if(ry) mesh.rotation.y=ry; if(rz) mesh.rotation.z=rz;',
    '  mesh.castShadow=true; mesh.receiveShadow=true; group.add(mesh); return mesh;',
    '}',
    'function createPrimitive(kind){',
    '  var geo; var liftY=0.5;',
    '  if(kind==="box") geo=new THREE.BoxGeometry(1,1,1);',
    '  else if(kind==="sphere"){ geo=new THREE.SphereGeometry(0.6,24,16); liftY=0.6; }',
    '  else if(kind==="cylinder") geo=new THREE.CylinderGeometry(0.5,0.5,1,24);',
    '  else if(kind==="cone") geo=new THREE.ConeGeometry(0.5,1,24);',
    '  else if(kind==="plane"){ geo=new THREE.PlaneGeometry(1.2,1.2); liftY=0; }',
    '  else geo=new THREE.BoxGeometry(1,1,1);',
    '  var mat=makeStdMat(0x8f97a8);',
    '  var mesh=new THREE.Mesh(geo,mat); mesh.castShadow=true; mesh.receiveShadow=true;',
    '  if(kind==="plane") mesh.rotation.x=-Math.PI/2;',
    '  var group=new THREE.Group(); group.add(mesh); group.position.y=liftY;',
    '  return { object3D:group, colorMaterials:[mat] };',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function createPrefab(kind){',
    '  var group=new THREE.Group(); var mats=[];',
    '  var box=function(w,h,d){ return new THREE.BoxGeometry(w,h,d); };',
    '  var cyl=function(rt,rb,h,seg){ return new THREE.CylinderGeometry(rt,rb,h,seg||16); };',
    '  switch(kind){',
    '    case "mesa":',
    '      addPart(group,mats,box(1.2,0.06,0.7),0xb98a56,0,0.75,0);',
    '      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,-0.55,0.375,-0.3);',
    '      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,0.55,0.375,-0.3);',
    '      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,-0.55,0.375,0.3);',
    '      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,0.55,0.375,0.3);',
    '      break;',
    '    case "silla":',
    '      addPart(group,mats,box(0.45,0.06,0.45),0x6b7280,0,0.45,0);',
    '      addPart(group,mats,box(0.45,0.5,0.06),0x6b7280,0,0.7,-0.2);',
    '      addPart(group,mats,box(0.04,0.45,0.04),0x374151,-0.18,0.22,-0.18);',
    '      addPart(group,mats,box(0.04,0.45,0.04),0x374151,0.18,0.22,-0.18);',
    '      addPart(group,mats,box(0.04,0.45,0.04),0x374151,-0.18,0.22,0.18);',
    '      addPart(group,mats,box(0.04,0.45,0.04),0x374151,0.18,0.22,0.18);',
    '      break;',
    '    case "escalera":',
    '      addPart(group,mats,box(0.06,2,0.06),0xd9a441,-0.3,1,0);',
    '      addPart(group,mats,box(0.06,2,0.06),0xd9a441,0.3,1,0);',
    '      for(var i=0;i<6;i++) addPart(group,mats,box(0.66,0.05,0.06),0xd9a441,0,0.25+i*0.32,0);',
    '      break;',
    '    case "palet":',
    '      addPart(group,mats,box(1,0.12,1.2),0x9c7b4f,0,0.06,0);',
    '      for(var j=-1;j<=1;j++) addPart(group,mats,box(0.9,0.03,0.12),0x8a6a41,0,0.14,j*0.5);',
    '      break;',
    '    case "valla":',
    '      addPart(group,mats,box(0.08,1,0.08),0xd9a441,-0.9,0.5,0);',
    '      addPart(group,mats,box(0.08,1,0.08),0xd9a441,0.9,0.5,0);',
    '      addPart(group,mats,box(1.9,0.08,0.08),0xe2434b,0,0.85,0);',
    '      addPart(group,mats,box(1.9,0.08,0.08),0xffffff,0,0.55,0);',
    '      break;',
    '    case "extintor":',
    '      addPart(group,mats,cyl(0.12,0.12,0.55,16),0xd21f2b,0,0.4,0);',
    '      addPart(group,mats,cyl(0.03,0.05,0.15,12),0x2b2b2b,0,0.72,0);',
    '      addPart(group,mats,box(0.16,0.04,0.06),0x2b2b2b,0,0.66,0.09);',
    '      break;',
    '    case "cable_suelto": {',
    '      var segColor=0xff6b35;',
    '      var pts=[[-0.6,-0.05],[-0.2,0.08],[0.15,-0.06],[0.5,0.04]];',
    '      for(var k=0;k<pts.length-1;k++){',
    '        var x1=pts[k][0], z1=pts[k][1], x2=pts[k+1][0], z2=pts[k+1][1];',
    '        var dx=x2-x1, dz=z2-z1, len=Math.sqrt(dx*dx+dz*dz), ang=Math.atan2(dz,dx);',
    '        addPart(group,mats,box(len,0.03,0.03),segColor,(x1+x2)/2,0.02,(z1+z2)/2,0,-ang,0);',
    '      }',
    '      break;',
    '    }',
    '    case "grillo": {',
    '      var body = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), makeStdMat(0x2b2016));',
    '      body.scale.set(1, 0.75, 1.6); body.position.set(0, 0.035, 0);',
    '      body.castShadow = true; body.receiveShadow = true;',
    '      mats.push(body.material); group.add(body);',
    '      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, 0.015, 0.06, -0.05, 1.1, 0, 0.4);',
    '      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, -0.015, 0.06, -0.05, 1.1, 0, -0.4);',
    '      colliderSize = { x: 0.12, y: 0.08, z: 0.18 };',
    '      break;',
    '    }',
    '    case "charco": {',
    '      var matC=makeStdMat(0x3aa0ff); matC.opacity=0.55; mats.push(matC);',
    '      var meshC=new THREE.Mesh(new THREE.CircleGeometry(0.55,24), matC);',
    '      meshC.rotation.x=-Math.PI/2; meshC.position.y=0.011; meshC.receiveShadow=true;',
    '      group.add(meshC);',
    '      break;',
    '    }',
    '    case "personaje": {',
    '      addPart(group,mats,new THREE.CapsuleGeometry(0.22,0.65,6,12),0x4fd1c5,0,0.55,0);',
    '      addPart(group,mats,new THREE.SphereGeometry(0.15,16,12),0xf2c9a0,0,1.02,0);',
    '      addPart(group,mats,box(0.3,0.22,0.05),0xff9f1c,0,0.62,0.19);',
    '      break;',
    '    }',
    '    case "tablon": {',
    '      addPart(group,mats,box(0.06,1.4,0.06),0x6b4a2b,-0.55,0.7,0);',
    '      addPart(group,mats,box(0.06,1.4,0.06),0x6b4a2b,0.55,0.7,0);',
    '      addPart(group,mats,box(1.3,0.9,0.05),0x8a6a41,0,1.1,0);',
    '      addPart(group,mats,box(0.5,0.32,0.01),0xf0e6d2,-0.32,1.3,0.03);',
    '      addPart(group,mats,box(0.5,0.32,0.01),0xf0e6d2,0.32,1.05,0.03);',
    '      break;',
    '    }',
    '    case "papel": {',
    '      addPart(group,mats,box(0.28,0.01,0.38),0xf5f0e4,0,0.02,0);',
    '      break;',
    '    }',
    '    case "cajon": {',
    '      addPart(group,mats,box(0.6,0.5,0.5),0x6b7280,0,0.25,0);',
    '      addPart(group,mats,box(0.56,0.16,0.03),0x4b5563,0,0.35,0.26);',
    '      addPart(group,mats,cyl(0.015,0.015,0.1,8),0x2b2b2b,0,0.35,0.3,Math.PI/2);',
    '      break;',
    '    }',
    '    default:',
    '      addPart(group,mats,box(1,1,1),0x8f97a8,0,0.5,0);',
    '  }',
    '  return { object3D:group, colorMaterials:mats };',
    '}',
  ].join('\n') + '\n');
  L.push([
    'var gltfLoader = new GLTFLoader();',
    'function collectGltfColorMaterials(inner){',
    '  var mats = [];',
    '  inner.traverse(function(o){',
    '    if(o.isMesh && o.material){',
    '      var ms = Array.isArray(o.material) ? o.material : [o.material];',
    '      ms.forEach(function(m){',
    '        m.transparent = true;',
    '        if(mats.indexOf(m)===-1) mats.push(m);',
    '      });',
    '    }',
    '  });',
    '  return mats;',
    '}',
    'function computeModelBounds(inner, mixer, clips){',
    '  var hasSkinned = false;',
    '  inner.traverse(function(o){ if(o.isSkinnedMesh) hasSkinned = true; });',
    '  if(!hasSkinned || !mixer || !clips || !clips.length){',
    '    return new THREE.Box3().setFromObject(inner);',
    '  }',
    '  var box = new THREE.Box3();',
    '  inner.updateMatrixWorld(true);',
    '  var action = mixer.clipAction(clips[0]);',
    '  action.play();',
    '  var steps = 12;',
    '  var dur = clips[0].duration || 0;',
    '  for(var i=0; i<=steps; i++){',
    '    mixer.setTime(dur*i/steps);',
    '    inner.updateMatrixWorld(true);',
    '    inner.traverse(function(o){',
    '      if(o.isSkinnedMesh && o.skeleton){',
    '        o.skeleton.bones.forEach(function(b){ box.expandByPoint(b.getWorldPosition(new THREE.Vector3())); });',
    '      }',
    '    });',
    '  }',
    '  mixer.setTime(0);',
    '  action.stop();',
    '  mixer.update(0);',
    '  if(box.isEmpty()) return new THREE.Box3().setFromObject(inner);',
    '  box.expandByScalar(0.15);',
    '  return box;',
    '}',
    'var sceneObjects = new Map();',
    'var sceneOrder = [];',
    'var objectGroups = new Map();',
    'var playerRecordId = null;',
    '',
    'function recomputeCheckpoints(rec){',
    '  var originPos = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.pos.clone() : rec.object3D.position.clone();',
    '  var originQuat = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.quat.clone() : rec.object3D.quaternion.clone();',
    '  if(!rec.object3D.userData.__origin) rec.object3D.userData.__origin = { pos: originPos.clone(), quat: originQuat.clone() };',
    '  var cps = [{ t:0, pos:originPos.clone(), quat:originQuat.clone(), opacity:(rec.opacity!=null?rec.opacity:1), ease:"linear", flashDef:null }];',
    '  for(var i=0;i<rec.actions.length;i++){',
    '    var a = rec.actions[i];',
    '    var prev = cps[cps.length-1];',
    '    var dur = a.duration || 0;',
    '    var next = { t:prev.t+dur, pos:prev.pos.clone(), quat:prev.quat.clone(), opacity:prev.opacity, ease:a.ease||"linear", flashDef:null };',
    '    if(a.type==="moveTo"){',
    '      if(a.relative) next.pos.copy(originPos).add(new THREE.Vector3(a.to.x,a.to.y,a.to.z));',
    '      else next.pos.set(a.to.x,a.to.y,a.to.z);',
    '    }',
    '    if(a.type==="rotateTo"){',
    '      if(a.relative){',
    '        var oe = new THREE.Euler().setFromQuaternion(originQuat);',
    '        next.quat.setFromEuler(new THREE.Euler(oe.x+deg2rad(a.to.x), oe.y+deg2rad(a.to.y), oe.z+deg2rad(a.to.z)));',
    '      } else {',
    '        next.quat.setFromEuler(new THREE.Euler(deg2rad(a.to.x),deg2rad(a.to.y),deg2rad(a.to.z)));',
    '      }',
    '    }',
    '    if(a.type==="fade") next.opacity = a.to;',
    '    if(a.type==="flash") next.flashDef = { color:a.color, repeat:a.repeat||3 };',
    '    cps.push(next);',
    '  }',
    '  rec.checkpoints = cps;',
    '  rec.totalDuration = cps[cps.length-1].t;',
    '}',
    '',
    'function evaluateRecord(rec, t){',
    '  var cps = rec.checkpoints;',
    '  if(!cps || cps.length<2) return null;',
    '  var last = cps[cps.length-1].t;',
    '  var tt = clamp(t,0,last||0);',
    '  var i=0;',
    '  while(i<cps.length-2 && cps[i+1].t < tt) i++;',
    '  var segStart=cps[i], segEnd=cps[i+1];',
    '  var segDur=(segEnd.t-segStart.t)||1e-6;',
    '  var p = clamp((tt-segStart.t)/segDur,0,1);',
    '  var pe = easeVal(p, segEnd.ease);',
    '  var pos = segStart.pos.clone().lerp(segEnd.pos, pe);',
    '  var quat = segStart.quat.clone().slerp(segEnd.quat, pe);',
    '  var opacity = lerp(segStart.opacity, segEnd.opacity, pe);',
    '  var flashIntensity=0, flashColor=null;',
    '  if(segEnd.flashDef){ flashIntensity=Math.abs(Math.sin(p*Math.PI*segEnd.flashDef.repeat)); flashColor=segEnd.flashDef.color; }',
    '  return { pos:pos, quat:quat, opacity:opacity, flashIntensity:flashIntensity, flashColor:flashColor };',
    '}',
    '',
    'var timelineDuration = 0.01;',
    'function recomputeTimelineDuration(){',
    '  var max=0;',
    '  sceneObjects.forEach(function(rec){ max = Math.max(max, rec.totalDuration||0); });',
    '  timelineDuration = Math.max(max, 0.01);',
    '  recomputeChainTriggers();',
    '}',
    'var chainTriggers = [];',
    'function recomputeChainTriggers(){',
    '  var triggers = [];',
    '  sceneObjects.forEach(function(rec){',
    '    if(!rec.checkpoints) return;',
    '    rec.actions.forEach(function(a, i){',
    '      if(!a || !rec.checkpoints[i+1]) return;',
    '      if(a.type === "setVariable" || a.type === "fetchUrl" || a.type === "copyToClipboard" || a.type === "if" || a.type === "for" || a.type === "screenMessage" || a.type === "askInput" || a.type === "setImageVar" || a.type === "setTextVar") triggers.push({ time: rec.checkpoints[i+1].t, chainRec: rec, action: a });',
    '      if(a.next) triggers.push({ time: rec.checkpoints[i+1].t, chainRec: rec, action: a.next });',
    '    });',
    '  });',
    '  triggers.sort(function(a,b){ return a.time - b.time; });',
    '  chainTriggers = triggers;',
    '}',
    'function fireDueChainTriggers(fromT, toT){',
    '  if(!chainTriggers.length) return;',
    '  if(toT >= fromT){',
    '    chainTriggers.forEach(function(tr){ if(tr.time > fromT && tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });',
    '  } else {',
    '    chainTriggers.forEach(function(tr){ if(tr.time > fromT || tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });',
    '  }',
    '}',
  ].join('\n') + '\n');
  L.push([
    'var overlapState = new Map();',
    'var eventCallback = null;',
    'function runCollisionChecks(){',
    '  var chars=[], zones=[];',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.collider.kind==="character") chars.push(rec);',
    '    if(rec.collider.kind==="zone") zones.push(rec);',
    '  });',
    '  chars.forEach(function(c){',
    '    var cPos = new THREE.Vector3(); c.object3D.getWorldPosition(cPos);',
    '    var cBox = new THREE.Box3().setFromCenterAndSize(cPos, new THREE.Vector3(c.collider.size.x,c.collider.size.y,c.collider.size.z));',
    '    zones.forEach(function(z){',
    '      var zPos = new THREE.Vector3(); z.object3D.getWorldPosition(zPos);',
    '      var zBox = new THREE.Box3().setFromCenterAndSize(zPos, new THREE.Vector3(z.collider.size.x,z.collider.size.y,z.collider.size.z));',
    '      var overlapping = cBox.intersectsBox(zBox);',
    '      var key = c.id+"|"+z.id;',
    '      var was = overlapState.get(key) || false;',
    '      if(overlapping && !was && eventCallback) eventCallback((z.collider.riskLabel||"Riesgo") + " - " + c.name + " entra en " + z.name);',
    '      overlapState.set(key, overlapping);',
    '    });',
    '  });',
    '}',
    '',
    'function applyTimeToScene(t, excludeId){',
    '  sceneObjects.forEach(function(rec){',
    '    if(excludeId && rec.id===excludeId) return;',
    '    var ev = evaluateRecord(rec, t);',
    '    if(!ev) return;',
    '    rec.object3D.position.copy(ev.pos);',
    '    rec.object3D.quaternion.copy(ev.quat);',
    '    rec.colorMaterials.forEach(function(m){ m.opacity=ev.opacity; m.visible = ev.opacity>0.01; });',
    '    if(ev.flashIntensity>0.02 && rec.colorMaterials.length){',
    '      var c=new THREE.Color(ev.flashColor||"#ff3b3b");',
    '      rec.colorMaterials.forEach(function(m){ m.emissive=c; m.emissiveIntensity=ev.flashIntensity; });',
    '    } else if(rec.colorMaterials.length){',
    '      rec.colorMaterials.forEach(function(m){ if(m.emissiveIntensity) m.emissiveIntensity=0; });',
    '    }',
    '  });',
    '  runCollisionChecks();',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function medirLineasTexto(ctx, text, maxWidth){',
    '  var parrafos = (text||"").split("\\n");',
    '  var lines = [];',
    '  for(var p=0;p<parrafos.length;p++){',
    '    var words = parrafos[p].split(/\\s+/).filter(Boolean);',
    '    if(!words.length){ lines.push(""); continue; }',
    '    var line = "";',
    '    for(var i=0;i<words.length;i++){',
    '      var w = words[i];',
    '      var test = line ? line+" "+w : w;',
    '      if(ctx.measureText(test).width > maxWidth && line){ lines.push(line); line=w; } else line=test;',
    '    }',
    '    if(line) lines.push(line);',
    '  }',
    '  if(!lines.length) lines.push("");',
    '  return lines;',
    '}',
    'function buildText3DTexture(text, color, boxWidth){',
    '  var FONT_PX=56, LINE_HEIGHT=64, PADDING=20;',
    '  var anchoLinea = Math.max(60, boxWidth || 472);',
    '  var medir = document.createElement("canvas").getContext("2d");',
    '  medir.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";',
    '  var lines = medirLineasTexto(medir, text||"Texto", anchoLinea);',
    '  var canvas = document.createElement("canvas");',
    '  canvas.width = Math.ceil(anchoLinea + PADDING*2);',
    '  canvas.height = Math.ceil(lines.length*LINE_HEIGHT + PADDING*2);',
    '  var ctx = canvas.getContext("2d");',
    '  ctx.clearRect(0,0,canvas.width,canvas.height);',
    '  ctx.fillStyle = color || "#ffffff";',
    '  ctx.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";',
    '  ctx.textAlign = "center"; ctx.textBaseline = "middle";',
    '  var startY = canvas.height/2 - ((lines.length-1)*LINE_HEIGHT)/2;',
    '  for(var j=0;j<lines.length;j++) ctx.fillText(lines[j], canvas.width/2, startY + j*LINE_HEIGHT);',
    '  var texture = new THREE.CanvasTexture(canvas);',
    '  texture.needsUpdate = true;',
    '  var REF_LINE_CANVAS_PX = LINE_HEIGHT + PADDING*2;',
    '  return { texture: texture, aspect: canvas.width/REF_LINE_CANVAS_PX, heightFactor: canvas.height/REF_LINE_CANVAS_PX };',
    '}',
    'function buildLightObject(lightData){',
    '  var ld = Object.assign({ color:"#fff2cc", intensity:1.2, distance:8, castShadow:false }, lightData||{});',
    '  var light = new THREE.PointLight(new THREE.Color(ld.color), ld.intensity, ld.distance, 2);',
    '  light.castShadow = !!ld.castShadow;',
    '  if(light.castShadow) light.shadow.mapSize.set(512,512);',
    '  return { object3D:light, colorMaterials:[] };',
    '}',
    'var WEATHER_TYPES = {',
    '  rain_light: { count:220, fallSpeed:9,  color:"#9fc6ff", size:0.045, opacity:0.5,  driftX:0.4, driftZ:0.1, kind:"rain" },',
    '  rain_heavy: { count:600, fallSpeed:14, color:"#bcdcff", size:0.05,  opacity:0.62, driftX:0.9, driftZ:0.2, kind:"rain" },',
    '  storm:      { count:650, fallSpeed:15, color:"#cfe3ff", size:0.05,  opacity:0.65, driftX:1.7, driftZ:0.4, kind:"rain", lightning:true },',
    '  hail:       { count:200, fallSpeed:16, color:"#eef3fb", size:0.11,  opacity:0.85, driftX:0.6, driftZ:0.2, kind:"rain" },',
    '  snow_light: { count:170, fallSpeed:1.6,color:"#ffffff", size:0.09,  opacity:0.85, driftX:0.5, driftZ:0.5, kind:"snow" },',
    '  snow_heavy: { count:480, fallSpeed:3.2,color:"#ffffff", size:0.1,   opacity:0.9,  driftX:2.2, driftZ:1.4, kind:"snow" },',
    '};',
    'var WEATHER_AREA_RADIUS = 10, WEATHER_AREA_HEIGHT = 16;',
    'function buildWeatherObject(weatherData){',
    '  var wd = Object.assign({ type:"rain_light" }, weatherData||{});',
    '  var cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;',
    '  var count = cfg.count;',
    '  var positions = new Float32Array(count*3);',
    '  var speeds = new Float32Array(count);',
    '  var phases = new Float32Array(count);',
    '  for(var i=0;i<count;i++){',
    '    positions[i*3+0] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;',
    '    positions[i*3+1] = Math.random() * WEATHER_AREA_HEIGHT;',
    '    positions[i*3+2] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;',
    '    speeds[i] = 0.75 + Math.random()*0.5;',
    '    phases[i] = Math.random() * Math.PI * 2;',
    '  }',
    '  var geo = new THREE.BufferGeometry();',
    '  geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));',
    '  var mat = new THREE.PointsMaterial({ color:new THREE.Color(cfg.color), size:cfg.size, transparent:true, opacity:cfg.opacity, depthWrite:false, sizeAttenuation:true });',
    '  var points = new THREE.Points(geo, mat);',
    '  points.frustumCulled = false;',
    '  var group = new THREE.Group();',
    '  group.add(points);',
    '  group.userData.__weatherPoints = points;',
    '  group.userData.__weatherSpeeds = speeds;',
    '  group.userData.__weatherPhases = phases;',
    '  group.userData.__weatherFlashTimer = 0;',
    '  group.userData.__weatherNextFlash = 2 + Math.random()*4;',
    '  group.userData.__weatherFlashActive = 0;',
    '  return { object3D:group, colorMaterials:[mat], weatherData: wd };',
    '}',
    'var lightningLight = null;',
    'function ensureLightningLight(){',
    '  if(!lightningLight){',
    '    lightningLight = new THREE.PointLight(0xdfe8ff, 0, 80, 1.5);',
    '    lightningLight.position.set(0, 25, 0);',
    '    scene.add(lightningLight);',
    '  }',
    '  return lightningLight;',
    '}',
    'var sharedWeatherAudioCtx = null;',
    'function playThunderSound(){',
    '  try {',
    '    var AC = window.AudioContext || window.webkitAudioContext;',
    '    if(!AC) return;',
    '    if(!sharedWeatherAudioCtx) sharedWeatherAudioCtx = new AC();',
    '    var ctx = sharedWeatherAudioCtx;',
    '    var dur = 1.4;',
    '    var buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate*dur), ctx.sampleRate);',
    '    var data = buffer.getChannelData(0);',
    '    for(var i=0;i<data.length;i++) data[i] = (Math.random()*2-1) * Math.pow(1 - i/data.length, 1.6);',
    '    var src = ctx.createBufferSource();',
    '    src.buffer = buffer;',
    '    var filter = ctx.createBiquadFilter();',
    '    filter.type = "lowpass";',
    '    filter.frequency.setValueAtTime(1200, ctx.currentTime);',
    '    filter.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + dur);',
    '    var gain = ctx.createGain();',
    '    gain.gain.setValueAtTime(0.0001, ctx.currentTime);',
    '    gain.gain.exponentialRampToValueAtTime(0.7, ctx.currentTime + 0.08);',
    '    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);',
    '    src.connect(filter); filter.connect(gain); gain.connect(ctx.destination);',
    '    var delay = 0.25 + Math.random()*1.2;',
    '    src.start(ctx.currentTime + delay);',
    '  } catch(e) { /* WebAudio no disponible/bloqueado: sin sonido, sin romper nada */ }',
    '}',
    'function updateStormLightning(rec, dt){',
    '  var ud = rec.object3D.userData;',
    '  var light = ensureLightningLight();',
    '  if(ud.__weatherFlashActive > 0){',
    '    ud.__weatherFlashActive -= dt;',
    '    light.intensity = Math.max(0, ud.__weatherFlashActive) * 14;',
    '    if(ud.__weatherFlashActive <= 0){ ud.__weatherFlashActive = 0; light.intensity = 0; }',
    '    return;',
    '  }',
    '  ud.__weatherFlashTimer += dt;',
    '  if(ud.__weatherFlashTimer >= ud.__weatherNextFlash){',
    '    ud.__weatherFlashTimer = 0;',
    '    ud.__weatherNextFlash = 4 + Math.random()*9;',
    '    ud.__weatherFlashActive = 0.12 + Math.random()*0.08;',
    '    light.intensity = 14;',
    '    playThunderSound();',
    '  }',
    '}',
    'function updateWeatherSystems(dt){',
    '  var t = performance.now() / 1000;',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.kind !== "weather" || !rec.object3D.visible) return;',
    '    var points = rec.object3D.userData.__weatherPoints;',
    '    if(!points) return;',
    '    var wd = rec.weatherData || { type:"rain_light" };',
    '    var cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;',
    '    var pos = points.geometry.attributes.position.array;',
    '    var speeds = rec.object3D.userData.__weatherSpeeds;',
    '    var phases = rec.object3D.userData.__weatherPhases;',
    '    var count = pos.length/3;',
    '    var isSnow = cfg.kind === "snow";',
    '    for(var i=0;i<count;i++){',
    '      var idx = i*3;',
    '      pos[idx+1] -= cfg.fallSpeed * speeds[i] * dt;',
    '      pos[idx+0] += cfg.driftX * dt * (isSnow ? Math.sin(t+phases[i]) : 1);',
    '      pos[idx+2] += cfg.driftZ * dt * (isSnow ? Math.cos(t*0.7+phases[i]) : 1);',
    '      if(pos[idx+1] < 0){',
    '        pos[idx+1] = WEATHER_AREA_HEIGHT;',
    '        pos[idx+0] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;',
    '        pos[idx+2] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;',
    '      }',
    '      var lim = WEATHER_AREA_RADIUS * 1.3;',
    '      if(pos[idx+0] > lim) pos[idx+0] = -lim; else if(pos[idx+0] < -lim) pos[idx+0] = lim;',
    '      if(pos[idx+2] > lim) pos[idx+2] = -lim; else if(pos[idx+2] < -lim) pos[idx+2] = lim;',
    '    }',
    '    points.geometry.attributes.position.needsUpdate = true;',
    '    if(cfg.lightning) updateStormLightning(rec, dt);',
    '  });',
    '}',
    'function buildText3DObject(text, color, size, boxWidth){',
    '  var built = buildText3DTexture(text, color, boxWidth);',
    '  var mat = new THREE.MeshBasicMaterial({ map:built.texture, transparent:true, side:THREE.DoubleSide, opacity:1, polygonOffset:true, polygonOffsetFactor:-4, polygonOffsetUnits:-4 });',
    '  mat.alphaTest = 0.5;',
    '  var s = size || 1;',
    '  var mesh = new THREE.Mesh(new THREE.PlaneGeometry(built.aspect*s, built.heightFactor*s), mat);',
    '  var group = new THREE.Group(); group.add(mesh); group.position.y = 1.2;',
    '  return { object3D:group, colorMaterials:[mat], mesh:mesh };',
    '}',
    'function buildImagePlaneObject(dataUrl, height, onReady){',
    '  var img = new Image();',
    '  img.onload = function(){',
    '    var texture = new THREE.Texture(img); texture.needsUpdate = true;',
    '    var aspect = (img.width/img.height) || 1;',
    '    var h = height || 1.5;',
    '    var w = h*aspect;',
    '    var mat = new THREE.MeshBasicMaterial({ map:texture, transparent:true, side:THREE.DoubleSide });',
    '    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;',
    '    mat.alphaTest = 0.5;',
    '    var mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,h), mat);',
    '    var group = new THREE.Group(); group.add(mesh); group.position.y = h/2;',
    '    onReady({ object3D:group, colorMaterials:[mat], mesh:mesh, aspect:aspect });',
    '  };',
    '  img.onerror = function(){ onReady(null); };',
    '  img.src = dataUrl;',
    '}',
    'function swapImageTexture(rec, dataUrl, onDone){',
    '  buildImagePlaneObject(dataUrl, null, function(built){',
    '    if(!built){ if(onDone) onDone(false); return; }',
    '    var mesh = rec.object3D.children[0];',
    '    mesh.geometry.dispose();',
    '    if(mesh.material.map) mesh.material.map.dispose();',
    '    mesh.material.dispose();',
    '    mesh.geometry = built.mesh.geometry;',
    '    mesh.material = built.mesh.material;',
    '    rec.colorMaterials = [mesh.material];',
    '    rec.imageBase64 = dataUrl;',
    '    if(onDone) onDone(true);',
    '  });',
    '}',
    'function buildVideoPlaneObject(dataUrl, height, onReady){',
    '  var videoEl = document.createElement("video");',
    '  videoEl.src = dataUrl; videoEl.loop = true; videoEl.muted = false; videoEl.playsInline = true; videoEl.crossOrigin = "anonymous";',
    '  videoEl.pause();',
    '  function finishV(){',
    '    var texture = new THREE.VideoTexture(videoEl);',
    '    texture.minFilter = THREE.LinearFilter; texture.magFilter = THREE.LinearFilter;',
    '    var aspect = (videoEl.videoWidth/videoEl.videoHeight) || (16/9);',
    '    var h = height || 1.5;',
    '    var w = h*aspect;',
    '    var mat = new THREE.MeshBasicMaterial({ map:texture, side:THREE.DoubleSide, transparent:true });',
    '    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;',
    '    mat.alphaTest = 0.5;',
    '    var mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,h), mat);',
    '    var group = new THREE.Group(); group.add(mesh); group.position.y = h/2;',
    '    onReady({ object3D:group, colorMaterials:[mat], mesh:mesh, aspect:aspect, videoEl:videoEl });',
    '  }',
    '  videoEl.addEventListener("loadedmetadata", finishV, { once:true });',
    '  videoEl.addEventListener("error", function(){ onReady(null); }, { once:true });',
    '}',
    'function toggleVideoPlayback(rec){',
    '  if(!rec.videoEl) return;',
    '  if(rec.videoEl.paused){ rec.videoEl.play().catch(function(){}); if(typeof feedToast==="function") feedToast("Video: " + rec.name); }',
    '  else { rec.videoEl.pause(); if(typeof feedToast==="function") feedToast("Video: " + rec.name); }',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function buildExtrudeShape(nodes){',
    '  var shape = new THREE.Shape();',
    '  if(!nodes || nodes.length < 2){ shape.moveTo(-0.5,-0.5); shape.lineTo(0.5,-0.5); shape.lineTo(0.5,0.5); shape.lineTo(-0.5,0.5); shape.closePath(); return shape; }',
    '  shape.moveTo(nodes[0].x, nodes[0].y);',
    '  for(var i=1; i<=nodes.length; i++){',
    '    var prev = nodes[i-1];',
    '    var curr = nodes[i % nodes.length];',
    '    if(prev.handleOut || curr.handleIn){',
    '      var c1x = prev.x + (prev.handleOut ? prev.handleOut.x : 0);',
    '      var c1y = prev.y + (prev.handleOut ? prev.handleOut.y : 0);',
    '      var c2x = curr.x + (curr.handleIn ? curr.handleIn.x : 0);',
    '      var c2y = curr.y + (curr.handleIn ? curr.handleIn.y : 0);',
    '      shape.bezierCurveTo(c1x,c1y,c2x,c2y,curr.x,curr.y);',
    '    } else {',
    '      shape.lineTo(curr.x, curr.y);',
    '    }',
    '  }',
    '  return shape;',
    '}',
    'function buildPathCurve(pathNodes, closed){',
    '  var pts = pathNodes.map(function(n){ return new THREE.Vector3(n.x,n.y,n.z); });',
    '  return new THREE.CatmullRomCurve3(pts, !!closed, "catmullrom", 0.5);',
    '}',
    'function buildSweepFrames(curve, steps){',
    '  var frames = [];',
    '  var worldUp = new THREE.Vector3(0,1,0);',
    '  for(var i=0; i<=steps; i++){',
    '    var t = i/steps;',
    '    var point = curve.getPointAt(t);',
    '    var tangent = curve.getTangentAt(t).clone().normalize();',
    '    var right = new THREE.Vector3().crossVectors(worldUp, tangent);',
    '    if(right.lengthSq() < 1e-6){',
    '      right = new THREE.Vector3().crossVectors(new THREE.Vector3(1,0,0), tangent);',
    '      if(right.lengthSq() < 1e-6) right = new THREE.Vector3().crossVectors(new THREE.Vector3(0,0,1), tangent);',
    '    }',
    '    right.normalize();',
    '    var up = new THREE.Vector3().crossVectors(tangent, right).normalize();',
    '    frames.push({ point:point, right:right, up:up });',
    '  }',
    '  return frames;',
    '}',
    'function buildExtrudeAlongPathGeometry(nodes, pathData){',
    '  var profilePts = buildExtrudeShape(nodes).getPoints(Math.max(12, nodes.length*8));',
    '  var closed = !!pathData.closed;',
    '  var curve = buildPathCurve(pathData.nodes, closed);',
    '  var steps = Math.max(16, pathData.nodes.length*12);',
    '  var frames = buildSweepFrames(curve, steps);',
    '  var positions = [];',
    '  var uvs = [];',
    '  var indices = [];',
    '  var profCount = profilePts.length;',
    '  var ringCount = frames.length;',
    '  var profileCum = [0];',
    '  for(var pk=1; pk<=profCount; pk++){',
    '    var pa = profilePts[pk-1], pb = profilePts[pk % profCount];',
    '    profileCum.push(profileCum[pk-1] + Math.hypot(pb.x-pa.x, pb.y-pa.y));',
    '  }',
    '  var profileLen = Math.max(profileCum[profCount], 0.5) || 1;',
    '  var frameCum = [0];',
    '  for(var fk=1; fk<frames.length; fk++){ frameCum.push(frameCum[fk-1] + frames[fk].point.distanceTo(frames[fk-1].point)); }',
    '  frames.forEach(function(f, i){',
    '    var v = frameCum[i] / profileLen;',
    '    profilePts.forEach(function(p, j){',
    '      var wp = new THREE.Vector3().addVectors(f.point, f.right.clone().multiplyScalar(p.x)).add(f.up.clone().multiplyScalar(p.y));',
    '      positions.push(wp.x, wp.y, wp.z);',
    '      uvs.push(profileCum[j] / profileLen, v);',
    '    });',
    '  });',
    '  for(var i=0; i<ringCount-1; i++){',
    '    for(var j=0; j<profCount; j++){',
    '      var jNext = (j+1) % profCount;',
    '      var a = i*profCount+j, b = i*profCount+jNext, c = (i+1)*profCount+jNext, d = (i+1)*profCount+j;',
    '      indices.push(a,b,c, a,c,d);',
    '    }',
    '  }',
    '  var positionCountBeforeCaps = positions.length/3;',
    '  if(!closed){',
    '    var minX=Infinity, maxX=-Infinity, minY=Infinity, maxY=-Infinity;',
    '    profilePts.forEach(function(p){ minX=Math.min(minX,p.x); maxX=Math.max(maxX,p.x); minY=Math.min(minY,p.y); maxY=Math.max(maxY,p.y); });',
    '    function capUV(p){ return [ (p.x-minX)/Math.max(maxX-minX,0.001), (p.y-minY)/Math.max(maxY-minY,0.001) ]; }',
    '    var startBase = positionCountBeforeCaps;',
    '    profilePts.forEach(function(p){',
    '      var wp = new THREE.Vector3().addVectors(frames[0].point, frames[0].right.clone().multiplyScalar(p.x)).add(frames[0].up.clone().multiplyScalar(p.y));',
    '      positions.push(wp.x, wp.y, wp.z);',
    '      var uv = capUV(p); uvs.push(uv[0], uv[1]);',
    '    });',
    '    var endBase = startBase + profCount;',
    '    var lastFrame = frames[frames.length-1];',
    '    profilePts.forEach(function(p){',
    '      var wp = new THREE.Vector3().addVectors(lastFrame.point, lastFrame.right.clone().multiplyScalar(p.x)).add(lastFrame.up.clone().multiplyScalar(p.y));',
    '      positions.push(wp.x, wp.y, wp.z);',
    '      var uv = capUV(p); uvs.push(uv[0], uv[1]);',
    '    });',
    '    var capTris = THREE.ShapeUtils.triangulateShape(profilePts, []);',
    '    capTris.forEach(function(tri){ indices.push(startBase+tri[0], startBase+tri[2], startBase+tri[1]); });',
    '    capTris.forEach(function(tri){ indices.push(endBase+tri[0], endBase+tri[1], endBase+tri[2]); });',
    '  }',
    '  var geo = new THREE.BufferGeometry();',
    '  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));',
    '  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));',
    '  geo.setIndex(indices);',
    '  geo.computeVertexNormals();',
    '  return geo;',
    '}',
    'function buildExtrudeGeometry(extrudeData){',
    '  if(extrudeData.path && extrudeData.path.nodes && extrudeData.path.nodes.length >= 2){',
    '    return buildExtrudeAlongPathGeometry(extrudeData.nodes, extrudeData.path);',
    '  }',
    '  var shape = buildExtrudeShape(extrudeData.nodes);',
    '  var depth = Math.max(0.02, extrudeData.depth || 0.3);',
    '  var bevelEnabled = !!extrudeData.bevelEnabled;',
    '  var bevelSize = Math.max(0.005, Math.min(extrudeData.bevelSize || 0.05, depth/2 - 0.005));',
    '  return new THREE.ExtrudeGeometry(shape, { depth:depth, bevelEnabled:bevelEnabled, bevelThickness:bevelSize, bevelSize:bevelSize, bevelSegments: bevelEnabled?3:1, curveSegments:16 });',
    '}',
    'function buildExtrudeObject(extrudeData){',
    '  var geo = buildExtrudeGeometry(extrudeData);',
    '  var mat = makeStdMat(0x8f97a8);',
    '  var mesh = new THREE.Mesh(geo, mat);',
    '  mesh.castShadow = true; mesh.receiveShadow = true;',
    '  var group = new THREE.Group(); group.add(mesh);',
    '  return { object3D:group, colorMaterials:[mat] };',
    '}',
  ].join('\n') + '\n');
  L.push([
    'function applyTextureToRecord(rec, dataUrl){',
    '  if(!dataUrl) return;',
    '  var tex = new THREE.TextureLoader().load(dataUrl);',
    '  if(THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;',
    '  tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;',
    '  tex.repeat.set(rec.textureRepeatX||1, rec.textureRepeatY||1);',
    '  rec.colorMaterials.forEach(function(m){ m.map = tex; m.needsUpdate = true; });',
    '}',
    'function addReconstructed(o, object3D, colorMaterials, videoEl, mixer, clips){',
    '  object3D.position.fromArray(o.transform.position);',
    '  object3D.quaternion.fromArray(o.transform.quaternion);',
    '  object3D.scale.fromArray(o.transform.scale);',
    '  if(o.colorHex && colorMaterials.length) colorMaterials.forEach(function(m){ m.color.set(o.colorHex); });',
    '  var opacidad = (o.opacity!=null ? o.opacity : 1);',
    '  if(colorMaterials.length) colorMaterials.forEach(function(m){ m.opacity = opacidad; m.visible = opacidad > 0.01; });',
    '  scene.add(object3D);',
    '  var rec = { id:o.id, name:o.name, kind:o.kind, object3D:object3D, colorMaterials:colorMaterials, opacity:opacidad, collider:o.collider, facingOffsetDeg:o.facingOffsetDeg||0, actions:o.actions||[], checkpoints:null, totalDuration:0, mixer:mixer||null, clips:clips||[], videoEl:videoEl||null, groupId:o.groupId||null, textureRepeatX:o.textureRepeatX||1, textureRepeatY:o.textureRepeatY||1, cameraPathData:o.cameraPathData||null, weatherData:o.weatherData||null, text3d:o.text3d||null, imageBase64:o.imageBase64||null, videoBase64:o.videoBase64||null, interactive:o.interactive||{enabled:false,kind:"text",radius:2,prompt:"Interactuar",text:"",url:"",choices:[],onInteractAction:null} };',
    '  if(o.textureBase64) applyTextureToRecord(rec, o.textureBase64);',
    '  sceneObjects.set(rec.id, rec);',
    '  sceneOrder.push(rec.id);',
    '  recomputeCheckpoints(rec);',
    '  if(rec.collider.kind==="character" && !playerRecordId) playerRecordId = rec.id;',
    '}',
    '',
    'function buildScene(project, onReady){',
    '  var pending=0, done=0;',
    '  function finish(){',
    '    sceneObjects.forEach(function(r){ recomputeCheckpoints(r); });',
    '    (project.groups||[]).forEach(function(g){ objectGroups.set(g.id, { id:g.id, name:g.name, memberIds:g.memberIds.slice() }); });',
    '    recomputeTimelineDuration();',
    '    onReady();',
    '  }',
    '  project.objects.forEach(function(o){',
    '    if(o.kind==="gltf" && o.gltfBase64){',
    '      pending++;',
    '      gltfLoader.parse(base64ToArrayBuffer(o.gltfBase64), "", function(gltf){',
    '        var inner = gltf.scene || gltf.scenes[0];',
    '        inner.traverse(function(m){ if(m.isMesh){ m.castShadow=true; m.receiveShadow=true; } });',
    '        var colorMats = collectGltfColorMaterials(inner);',
    '        var clips = gltf.animations || [];',
    '        var mixer = clips.length ? new THREE.AnimationMixer(inner) : null;',
    '        var mbox = computeModelBounds(inner, mixer, clips);',
    '        var msize = new THREE.Vector3(); mbox.getSize(msize);',
    '        var maxDim = Math.max(msize.x, msize.y, msize.z) || 1;',
    '        var scaleFactor = maxDim > 0 ? 1.6/maxDim : 1;',
    '        inner.scale.setScalar(scaleFactor);',
    '        var mbox2 = computeModelBounds(inner, mixer, clips);',
    '        inner.position.y -= mbox2.min.y;',
    '        if(mixer) mixer.update(0);',
    '        var group=new THREE.Group(); group.add(inner);',
    '        addReconstructed(o, group, colorMats, null, mixer, clips);',
    '        done++; if(done===pending) finish();',
    '      }, function(){ done++; if(done===pending) finish(); });',
    '    } else if(o.kind==="image" && o.imageBase64){',
    '      pending++;',
    '      buildImagePlaneObject(o.imageBase64, null, function(built){',
    '        if(built) addReconstructed(o, built.object3D, built.colorMaterials);',
    '        done++; if(done===pending) finish();',
    '      });',
    '    } else if(o.kind==="video" && o.videoBase64){',
    '      pending++;',
    '      buildVideoPlaneObject(o.videoBase64, null, function(built){',
    '        if(built) addReconstructed(o, built.object3D, built.colorMaterials, built.videoEl);',
    '        done++; if(done===pending) finish();',
    '      });',
    '    } else if(o.kind==="text3d"){',
    '      var t3 = o.text3d || { text:"Texto", color:"#ffffff", size:1 };',
    '      var builtT = buildText3DObject(t3.text, t3.color, t3.size, t3.boxWidth);',
    '      addReconstructed(o, builtT.object3D, builtT.colorMaterials);',
    '    } else if(o.kind==="extrude" && o.extrudeData){',
    '      var builtE = buildExtrudeObject(o.extrudeData);',
    '      addReconstructed(o, builtE.object3D, builtE.colorMaterials);',
    '    } else if(o.kind==="primitive"){',
    '      var built=createPrimitive(o.primitiveType);',
    '      addReconstructed(o, built.object3D, built.colorMaterials);',
    '    } else if(o.kind==="prefab"){',
    '      var built2=createPrefab(o.prefabType);',
    '      addReconstructed(o, built2.object3D, built2.colorMaterials);',
    '    } else if(o.kind==="light"){',
    '      var builtL=buildLightObject(o.lightData);',
    '      addReconstructed(o, builtL.object3D, builtL.colorMaterials);',
    '    } else if(o.kind==="camerapath"){',
    '      addReconstructed(o, new THREE.Group(), []);',
    '    } else if(o.kind==="weather"){',
    '      var builtW=buildWeatherObject(o.weatherData);',
    '      addReconstructed(o, builtW.object3D, builtW.colorMaterials);',
    '    }',
    '  });',
    '  if(pending===0) finish();',
    '}',
  ].join('\n') + '\n');
  L.push([
    'var playYaw=0, playPitch=-0.25;',
    'var playKeys={w:false,a:false,s:false,d:false,shift:false,space:false,arrowUp:false,arrowDown:false,arrowLeft:false,arrowRight:false};',
    'var firstPersonMode=false;',
    'var npcClockTime=0;',
    'var WALK_SPEED=3.2, RUN_SPEED=6.2, CHASE_RADIUS=4.5, GRAVITY=-18, JUMP_SPEED=6.5, TURN_SPEED=2.4;',
    'var playCamDist = CHASE_RADIUS;',
    'var started=false;',
    'var playScore=0;',
    'var gameVariables={};',
    'var networkActionsAllowed=false;',
    'var networkGateAsked=false;',
    'var interactionPanelOpen=false;',
    'var askInputActive=false;',
    'var MAX_ASK_ARCHIVO_BYTES=350*1024;',
    'var screenMsgDismissFn=null;',
    'var nearestInteractiveId=null;',
    'var playVelY=0, playGrounded=true;',
    'function isTouchDevice(){ return (window.matchMedia && window.matchMedia("(pointer: coarse)").matches) || ("ontouchstart" in window) || (navigator.maxTouchPoints||0)>0; }',
    'var touchJoystickId=null, touchJoystickVec={x:0,y:0}, touchLookId=null, touchLookLast={x:0,y:0};',
    '',
    'function feedToast(text){',
    '  var feed=document.getElementById("feed");',
    '  var div=document.createElement("div"); div.className="toast"; div.textContent=text;',
    '  feed.prepend(div);',
    '  while(feed.children.length>4) feed.removeChild(feed.lastChild);',
    '  setTimeout(function(){ if(div.parentNode) div.remove(); }, 5000);',
    '}',
    'eventCallback = feedToast;',
    '',
    'function escGameHtml(s){',
    '  return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");',
    '}',
    'function updateScoreDisplay(){',
    '  var el=document.getElementById("score");',
    '  if(el) el.textContent = "Puntuacion: " + playScore;',
    '}',
    'function updateInteractPrompt(){',
    '  var el=document.getElementById("interactPrompt");',
    '  var btn=document.getElementById("touchInteractBtn");',
    '  var showTouchBtn = isTouchDevice() && !interactionPanelOpen && !!nearestInteractiveId;',
    '  if(interactionPanelOpen || !nearestInteractiveId){ el.style.display="none"; if(btn) btn.style.display="none"; return; }',
    '  var rec=sceneObjects.get(nearestInteractiveId);',
    '  if(!rec || !rec.interactive || !rec.interactive.enabled){ el.style.display="none"; if(btn) btn.style.display="none"; return; }',
    '  el.textContent = "[E] " + (rec.interactive.prompt || "Interactuar");',
    '  el.style.display = isTouchDevice() ? "none" : "block";',
    '  if(btn) btn.style.display = showTouchBtn ? "flex" : "none";',
    '}',
    'function updateShotPrompt(){',
    '  var el=document.getElementById("shotPrompt");',
    '  var btn=document.getElementById("touchShootBtn");',
    '  if(!el) return;',
    '  var rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;',
    '  if(!rec || !rec.interactive || !rec.interactive.onShotAction){ el.style.display="none"; if(btn) btn.style.display="none"; return; }',
    '  el.textContent = "\ud83c\udfaf [F] Disparar";',
    '  el.style.display = isTouchDevice() ? "none" : "block";',
    '  if(btn) btn.style.display = isTouchDevice() ? "flex" : "none";',
    '}',
    'function attemptShoot(){',
    '  if(interactionPanelOpen || droneModeActive || cameraPathActive) return;',
    '  var rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;',
    '  if(!rec || !rec.interactive || !rec.interactive.onShotAction) return;',
    '  triggerOneShotAction(rec, rec.interactive.onShotAction);',
    '  feedToast("\ud83c\udfaf " + rec.name);',
    '}',
    'function playOneShotSound(base64, volume){',
    '  if(!base64) return;',
    '  try{',
    '    var audio = new Audio(base64);',
    '    audio.volume = (volume===undefined || volume===null || isNaN(volume)) ? 1 : volume;',
    '    audio.play().catch(function(){});',
    '  } catch(e){}',
    '}',
    'function collectFetchUrls(){',
    '  var urls = []; var seen = {};',
    '  function scan(a){',
    '    if(!a) return;',
    '    if(a.type==="fetchUrl" && a.url && !seen[a.url]){ seen[a.url]=true; urls.push(a.url); }',
    '    if(a.next) scan(a.next);',
    '    (a.parallel||[]).forEach(scan);',
    '  }',
    '  sceneObjects.forEach(function(rec){',
    '    (rec.actions||[]).forEach(scan);',
    '    if(rec.interactive){',
    '      scan(rec.interactive.onInteractAction);',
    '      scan(rec.interactive.onShotAction);',
    '      (rec.interactive.choices||[]).forEach(function(c){ scan(c.action); });',
    '    }',
    '  });',
    '  return urls;',
    '}',
    'function gateNetworkActions(){',
    '  if(networkGateAsked) return Promise.resolve(networkActionsAllowed);',
    '  networkGateAsked = true;',
    '  var urls = collectFetchUrls();',
    '  if(!urls.length){ networkActionsAllowed = false; return Promise.resolve(false); }',
    '  return new Promise(function(resolve){',
    '    var overlay = document.createElement("div");',
    '    overlay.style.cssText = "position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:2000; display:flex; align-items:center; justify-content:center;";',
    '    var box = document.createElement("div");',
    '    box.style.cssText = "background:#181b22; border:1px solid #333947; border-radius:8px; padding:18px; width:min(480px,92vw); color:#eee; font-family:inherit;";',
    '    box.innerHTML = \'<h3 style="margin-top:0;">🌐 Este escenario quiere conectarse a internet</h3>\' +',
    '      \'<p style="font-size:13px; opacity:.85;">Alguna accion de este proyecto envia o recibe datos de:</p>\' +',
    '      \'<ul style="font-size:12.5px; opacity:.9; max-height:140px; overflow:auto; padding-left:18px; margin:8px 0;">\' +',
    '      urls.map(function(u){ return \'<li style="word-break:break-all; margin-bottom:4px;">\' + String(u).replace(/</g,"&lt;") + \'</li>\'; }).join("") +',
    '      \'</ul>\' +',
    '      \'<p style="font-size:12.5px; opacity:.7;">Si no confias en el origen de este escenario, deniegalo -- el juego sigue funcionando igual, solo sin esas acciones concretas.</p>\' +',
    '      \'<div style="display:flex; gap:8px; margin-top:12px;">\' +',
    '      \'<button type="button" id="netGateAllow" style="flex:1; padding:8px; border-radius:6px; border:1px solid #3a6a3a; background:#1c2b1c; color:#eee; cursor:pointer;">Permitir</button>\' +',
    '      \'<button type="button" id="netGateDeny" style="flex:1; padding:8px; border-radius:6px; border:1px solid #444; background:#22252d; color:#eee; cursor:pointer;">Denegar</button>\' +',
    '      \'</div>\';',
    '    overlay.appendChild(box);',
    '    document.body.appendChild(overlay);',
    '    document.getElementById("netGateAllow").addEventListener("click", function(){ networkActionsAllowed = true; overlay.remove(); resolve(true); });',
    '    document.getElementById("netGateDeny").addEventListener("click", function(){ networkActionsAllowed = false; overlay.remove(); resolve(false); });',
    '  });',
    '}',
    'function triggerOneShotAction(rec, action, batchStartedAt){',
    '  if(!action || !action.type || action.type==="none") return;',
    '  var startedAt = batchStartedAt || performance.now();',
    '  if(action.type==="sound"){',
    '    playOneShotSound(action.soundBase64, action.volume);',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="toggleVideo"){',
    '    var videoRecs = [rec];',
    '    if(action.target==="player") videoRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '    else if(action.target==="__group__"){',
    '      var gV = rec.groupId ? objectGroups.get(rec.groupId) : null;',
    '      videoRecs = gV ? gV.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];',
    '    } else if(action.target && action.target!=="self") {',
    '      var foundV = sceneObjects.get(action.target);',
    '      if(!foundV){ console.warn("Don Claude 3D: accion video con objetivo no encontrado -- no se ejecuta."); videoRecs = []; }',
    '      else videoRecs = [foundV];',
    '    }',
    '    videoRecs.forEach(function(r){ if(r.kind==="video") toggleVideoPlayback(r); });',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="setVariable"){',
    '    var val = evalSafeExpr(action.expr, gameVariables);',
    '    if(action.varName) gameVariables[action.varName] = val;',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="setImageVar"){',
    '    var chainOnImg = function(){',
    '      if(action.next) triggerOneShotAction(rec, action.next);',
    '      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });',
    '    };',
    '    var dataUrlImg = action.varName ? gameVariables[action.varName] : null;',
    '    var targetImgRec = action.target ? sceneObjects.get(action.target) : null;',
    '    if(!dataUrlImg || typeof dataUrlImg!=="string" || dataUrlImg.indexOf("data:image")!==0 || !targetImgRec || targetImgRec.kind!=="image"){',
    '      chainOnImg();',
    '      return;',
    '    }',
    '    swapImageTexture(targetImgRec, dataUrlImg, chainOnImg);',
    '    return;',
    '  }',
    '  if(action.type==="setTextVar"){',
    '    var textVarVal = action.varName ? gameVariables[action.varName] : undefined;',
    '    var targetTxtRec = action.target ? sceneObjects.get(action.target) : null;',
    '    if(textVarVal!==undefined && targetTxtRec && targetTxtRec.kind==="text3d" && targetTxtRec.object3D && targetTxtRec.object3D.children[0]){',
    '      var textVarStr = String(textVarVal);',
    '      targetTxtRec.text3d.text = textVarStr;',
    '      var meshTV = targetTxtRec.object3D.children[0];',
    '      var builtTV = buildText3DTexture(textVarStr, targetTxtRec.text3d.color, targetTxtRec.text3d.boxWidth);',
    '      var oldTexTV = meshTV.material.map;',
    '      meshTV.material.map = builtTV.texture;',
    '      meshTV.material.needsUpdate = true;',
    '      if(oldTexTV) oldTexTV.dispose();',
    '      var sTV = targetTxtRec.text3d.size || 1;',
    '      meshTV.geometry.dispose();',
    '      meshTV.geometry = new THREE.PlaneGeometry(builtTV.aspect*sTV, builtTV.heightFactor*sTV);',
    '    }',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="fetchUrl"){',
    '    var chainOn = function(){',
    '      if(action.next) triggerOneShotAction(rec, action.next);',
    '      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    };',
    '    gateNetworkActions().then(function(allowed){',
    '      if(!allowed || !action.url){ chainOn(); return; }',
    '      var urlFinal = interpolateVars(action.url, gameVariables);',
    '      if(urlFinal.indexOf("mailto:")===0){',
    '        window.open(urlFinal, "_blank", "noopener,noreferrer");',
    '        chainOn();',
    '        return;',
    '      }',
    '      var method = action.method==="POST" ? "POST" : "GET";',
    '      var parts = urlFinal.split("?");',
    '      var fetchPromise = method==="POST"',
    '        ? fetch(parts[0], { method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded"}, body: parts[1]||"" })',
    '        : fetch(urlFinal);',
    '      fetchPromise.then(function(res){ return res.text(); }).then(function(text){',
    '        if(action.responseMode==="label"){',
    '          var targetRecsF = [rec];',
    '          if(action.target==="player") targetRecsF = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '          else if(action.target && action.target!=="self" && action.target!=="__group__"){ var f = sceneObjects.get(action.target); targetRecsF = f ? [f] : []; }',
    '          targetRecsF.forEach(function(r){',
    '            if(r.kind!=="text3d" || !r.object3D || !r.object3D.children[0]) return;',
    '            r.text3d.text = text;',
    '            var meshT = r.object3D.children[0];',
    '            var builtT = buildText3DTexture(text, r.text3d.color, r.text3d.boxWidth);',
    '            var oldTexT = meshT.material.map;',
    '            meshT.material.map = builtT.texture;',
    '            meshT.material.needsUpdate = true;',
    '            if(oldTexT) oldTexT.dispose();',
    '            var sT = r.text3d.size || 1;',
    '            meshT.geometry.dispose();',
    '            meshT.geometry = new THREE.PlaneGeometry(builtT.aspect*sT, builtT.heightFactor*sT);',
    '          });',
    '        } else if(action.responseMode==="imagen"){',
    '          var targetRecsImg = [rec];',
    '          if(action.target==="player") targetRecsImg = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '          else if(action.target && action.target!=="self" && action.target!=="__group__"){ var fi = sceneObjects.get(action.target); targetRecsImg = fi ? [fi] : []; }',
    '          targetRecsImg = targetRecsImg.filter(function(r){ return r.kind==="image"; });',
    '          if(!targetRecsImg.length || text.indexOf("data:image")!==0) return;',
    '          return new Promise(function(resolve){',
    '            var pendingImg = targetRecsImg.length;',
    '            targetRecsImg.forEach(function(r){ swapImageTexture(r, text, function(){ pendingImg--; if(pendingImg===0) resolve(); }); });',
    '          });',
    '        } else if(action.responseMode==="variables" && action.varMap){',
    '          var parsed = null;',
    '          try{ parsed = JSON.parse(text); } catch(e){ parsed = null; }',
    '          var lines = String(action.varMap).split("\\n");',
    '          if(parsed && typeof parsed==="object"){',
    '            lines.forEach(function(line){',
    '              var eq = line.indexOf("=");',
    '              if(eq<0) return;',
    '              var field = line.slice(0,eq).trim(), varName = line.slice(eq+1).trim();',
    '              if(!field || !varName) return;',
    '              var v = field.split(".").reduce(function(o,k){ return (o && typeof o==="object") ? o[k] : undefined; }, parsed);',
    '              if(v!==undefined) gameVariables[varName] = v;',
    '            });',
    '          } else if(lines[0]){',
    '            var eq0 = lines[0].indexOf("=");',
    '            var firstVar = (eq0>=0 ? lines[0].slice(eq0+1) : lines[0]).trim();',
    '            if(firstVar) gameVariables[firstVar] = text;',
    '          }',
    '        }',
    '      }).catch(function(){}).finally(chainOn);',
    '    });',
    '    return;',
    '  }',
    '  if(action.type==="copyToClipboard"){',
    '    copiarTexto(interpolateVarsPlain(action.text, gameVariables));',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="if"){',
    '    var condVal = evalSafeExpr(action.expr, gameVariables);',
    '    var isTrue = typeof condVal==="string" ? (condVal!=="" && condVal!=="0") : !!condVal;',
    '    var branch = isTrue ? action.then : action.else;',
    '    if(branch) triggerOneShotAction(rec, branch, startedAt);',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="for"){',
    '    var countRaw = evalSafeExpr(String(action.count!=null ? action.count : "0"), gameVariables);',
    '    var count = Math.max(0, Math.min(1000, Math.floor(typeof countRaw==="number" ? countRaw : (parseFloat(countRaw)||0))));',
    '    var body = action.body;',
    '    if(body && (body.type==="moveTo" || body.type==="rotateTo") && body.relative && body.to && count>0){',
    '      if(action.varName) gameVariables[action.varName] = count-1;',
    '      var headStep = null, prevStep = null;',
    '      for(var step=1; step<=count; step++){',
    '        var stepAction = {',
    '          type: body.type, target: body.target, relative: true, ease: body.ease,',
    '          to: { x: body.to.x*step, y: body.to.y*step, z: body.to.z*step },',
    '          duration: body.duration',
    '        };',
    '        if(!headStep) headStep = stepAction;',
    '        if(prevStep) prevStep.next = stepAction;',
    '        prevStep = stepAction;',
    '      }',
    '      var extras = (action.parallel||[]).slice();',
    '      if(action.next) extras.push(action.next);',
    '      prevStep.next = body.next || null;',
    '      prevStep.parallel = extras;',
    '      triggerOneShotAction(rec, headStep, startedAt);',
    '      return;',
    '    }',
    '    for(var __fi=0; __fi<count; __fi++){',
    '      if(action.varName) gameVariables[action.varName] = __fi;',
    '      if(body) triggerOneShotAction(rec, body, startedAt);',
    '    }',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="screenMessage"){',
    '    showScreenMessage(interpolateVarsPlain(action.text, gameVariables), action.autoDismissSec||0, function(){',
    '      if(action.next) triggerOneShotAction(rec, action.next);',
    '      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });',
    '    });',
    '    return;',
    '  }',
    '  if(action.type==="askInput"){',
    '    showAskInput(interpolateVarsPlain(action.promptText, gameVariables), action.varName, action.allowFile, action.fileVarName, function(){',
    '      if(action.next) triggerOneShotAction(rec, action.next);',
    '      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });',
    '    });',
    '    return;',
    '  }',
    '  if(action.type==="cameraPath"){',
    '    var cpRec = rec;',
    '    if(action.target && action.target!=="self" && action.target!=="player" && action.target!=="__group__"){',
    '      var foundCp = sceneObjects.get(action.target);',
    '      if(!foundCp){ console.warn("Don Claude 3D: accion recorrido de camara con objetivo no encontrado -- no se ejecuta."); cpRec = null; }',
    '      else cpRec = foundCp;',
    '    }',
    '    if(cpRec) playCameraPath(cpRec);',
    '    if(action.next) triggerOneShotAction(rec, action.next);',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="playClip"){',
    '    var clipRecs = [rec];',
    '    if(action.target==="player") clipRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '    else if(action.target==="__group__"){',
    '      var gC = rec.groupId ? objectGroups.get(rec.groupId) : null;',
    '      clipRecs = gC ? gC.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];',
    '    } else if(action.target && action.target!=="self") {',
    '      var foundC = sceneObjects.get(action.target);',
    '      if(!foundC){ console.warn("Don Claude 3D: accion animacion con objetivo no encontrado -- no se ejecuta."); clipRecs = []; }',
    '      else clipRecs = [foundC];',
    '    }',
    '    var clipDurationMs = Math.max(50, (action.duration||1)*1000);',
    '    clipRecs.forEach(function(r, idx){',
    '      if(!r.mixer || !r.clips || !r.clips.length) return;',
    '      var clip = r.clips.find(function(c){ return c.name===action.clipName; }) || r.clips[0];',
    '      if(!clip) return;',
    '      if(r.__activeClipAction) r.__activeClipAction.stop();',
    '      var clipAction = r.mixer.clipAction(clip);',
    '      clipAction.reset();',
    '      clipAction.setLoop(action.loop ? THREE.LoopRepeat : THREE.LoopOnce, action.loop ? Infinity : 1);',
    '      clipAction.clampWhenFinished = !action.loop;',
    '      clipAction.play();',
    '      r.__activeClipAction = clipAction;',
    '      r.__oneShotClip = { startedAt: startedAt, durationMs: action.loop ? null : clipDurationMs, nextAction: idx===0 ? (action.next||null) : null, chainRec: rec };',
    '    });',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  if(action.type==="spin"){',
    '    var spinRecs = [rec];',
    '    if(action.target==="player") spinRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '    else if(action.target==="__group__"){',
    '      var gS = rec.groupId ? objectGroups.get(rec.groupId) : null;',
    '      spinRecs = gS ? gS.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];',
    '    } else if(action.target && action.target!=="self") {',
    '      var foundSpin = sceneObjects.get(action.target);',
    '      if(!foundSpin){ console.warn("Don Claude 3D: accion girar con objetivo no encontrado (referencia rota) -- no se ejecuta."); spinRecs = []; }',
    '      else spinRecs = [foundSpin];',
    '    }',
    '    if(!spinRecs.length) return;',
    '    var axisVec = action.axis==="x" ? new THREE.Vector3(1,0,0) : action.axis==="z" ? new THREE.Vector3(0,0,1) : new THREE.Vector3(0,1,0);',
    '    var speedRad = deg2rad(action.speed||0);',
    '    var durationMsSpin = Math.max(50, (action.duration||1)*1000);',
    '    spinRecs.forEach(function(r, idx){',
    '      r.__spin = { axisVec:axisVec, speedRad:speedRad, startedAt:startedAt, durationMs:durationMsSpin, nextAction: idx===0 ? (action.next||null) : null, chainRec: rec };',
    '    });',
    '    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '    return;',
    '  }',
    '  var targetRecs = [rec];',
    '  var groupRigid = null;',
    '  if(action.target==="player") targetRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);',
    '  else if(action.target==="__group__"){',
    '    var g = rec.groupId ? objectGroups.get(rec.groupId) : null;',
    '    targetRecs = g ? g.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];',
    '    if(action.type==="moveTo" && action.to){',
    '      groupRigid = { tipo:"mover", delta: new THREE.Vector3(action.to.x,action.to.y,action.to.z).sub(rec.object3D.position) };',
    '    } else if(action.type==="rotateTo" && action.to){',
    '      var toQuatG = new THREE.Quaternion().setFromEuler(new THREE.Euler(deg2rad(action.to.x),deg2rad(action.to.y),deg2rad(action.to.z)));',
    '      var deltaQuatG = toQuatG.clone().multiply(rec.object3D.quaternion.clone().invert());',
    '      groupRigid = { tipo:"rotar", deltaQuat:deltaQuatG, ancla: rec.object3D.position.clone() };',
    '    }',
    '  }',
    '  else if(action.target && action.target!=="self") {',
    '    var found = sceneObjects.get(action.target);',
    '    if(!found){ console.warn("Don Claude 3D: accion con objetivo no encontrado (referencia rota) -- no se ejecuta."); targetRecs = []; }',
    '    else targetRecs = [found];',
    '  }',
    '  if(!targetRecs.length) return;',
    '  var duration = Math.max(50, (action.duration||1)*1000);',
    '  targetRecs.forEach(function(targetRec, idx){',
    '    var existingOS = targetRec.__oneShot;',
    '    var mergeable = existingOS && existingOS.startedAt === startedAt;',
    '    var fromPos = mergeable ? existingOS.fromPos.clone() : targetRec.object3D.position.clone();',
    '    var fromQuat = mergeable ? existingOS.fromQuat.clone() : targetRec.object3D.quaternion.clone();',
    '    var fromOpacity = mergeable ? existingOS.fromOpacity : (targetRec.colorMaterials.length ? targetRec.colorMaterials[0].opacity : 1);',
    '    var toPos = mergeable ? existingOS.toPos.clone() : fromPos.clone();',
    '    var toQuat = mergeable ? existingOS.toQuat.clone() : fromQuat.clone();',
    '    var toOpacity = mergeable ? existingOS.toOpacity : fromOpacity;',
    '    var flashDef = mergeable ? existingOS.flashDef : null;',
    '    var mergedDuration = mergeable ? Math.max(existingOS.duration, duration) : duration;',
    '    if(groupRigid && groupRigid.tipo==="mover"){',
    '      toPos = fromPos.clone().add(groupRigid.delta);',
    '    } else if(groupRigid && groupRigid.tipo==="rotar"){',
    '      var rel = fromPos.clone().sub(groupRigid.ancla).applyQuaternion(groupRigid.deltaQuat);',
    '      toPos = groupRigid.ancla.clone().add(rel);',
    '      toQuat = groupRigid.deltaQuat.clone().multiply(fromQuat);',
    '    } else if(action.relative && action.type==="moveTo" && action.to){',
    '      var originPos = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.pos : targetRec.object3D.position;',
    '      toPos = originPos.clone().add(new THREE.Vector3(action.to.x, action.to.y, action.to.z));',
    '    } else if(action.relative && action.type==="rotateTo" && action.to){',
    '      var originQuat = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.quat : targetRec.object3D.quaternion;',
    '      var oe = new THREE.Euler().setFromQuaternion(originQuat);',
    '      var ne = new THREE.Euler(oe.x+deg2rad(action.to.x), oe.y+deg2rad(action.to.y), oe.z+deg2rad(action.to.z));',
    '      toQuat = new THREE.Quaternion().setFromEuler(ne);',
    '    } else {',
    '      if(action.type==="moveTo" && action.to) toPos.set(action.to.x, action.to.y, action.to.z);',
    '      if(action.type==="rotateTo" && action.to) toQuat.setFromEuler(new THREE.Euler(deg2rad(action.to.x), deg2rad(action.to.y), deg2rad(action.to.z)));',
    '    }',
    '    if(action.type==="fade") toOpacity = action.to;',
    '    if(action.type==="flash") flashDef = { color: action.color, repeat: action.repeat||3 };',
    '    targetRec.__oneShot = { startedAt: startedAt, duration: mergedDuration, fromPos:fromPos, toPos:toPos, fromQuat:fromQuat, toQuat:toQuat, fromOpacity:fromOpacity, toOpacity:toOpacity, ease:"smooth", flashDef:flashDef, nextAction: idx===0 ? (action.next||null) : (mergeable ? existingOS.nextAction : null), chainRec: rec };',
    '  });',
    '  (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });',
    '}',
    'function updateSpins(dt){',
    '  var toChainSpin = [];',
    '  sceneObjects.forEach(function(rec){',
    '    var sp = rec.__spin;',
    '    if(!sp) return;',
    '    rec.object3D.rotateOnAxis(sp.axisVec, sp.speedRad*dt);',
    '    if(performance.now()-sp.startedAt >= sp.durationMs){',
    '      if(sp.nextAction) toChainSpin.push({ chainRec: sp.chainRec, nextAction: sp.nextAction });',
    '      rec.__spin = null;',
    '    }',
    '  });',
    '  toChainSpin.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });',
    '}',
    'function updateOneShotClips(dt){',
    '  var toChainClip = [];',
    '  sceneObjects.forEach(function(rec){',
    '    var oc = rec.__oneShotClip;',
    '    if(!oc) return;',
    '    if(rec.mixer) rec.mixer.update(dt);',
    '    if(oc.durationMs!==null && performance.now()-oc.startedAt >= oc.durationMs){',
    '      if(oc.nextAction) toChainClip.push({ chainRec: oc.chainRec, nextAction: oc.nextAction });',
    '      rec.__oneShotClip = null;',
    '    }',
    '  });',
    '  toChainClip.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });',
    '}',
    'function updateOneShotAnimations(){',
    '  var nowMs = performance.now();',
    '  var toChain = [];',
    '  sceneObjects.forEach(function(rec){',
    '    var os = rec.__oneShot;',
    '    if(!os) return;',
    '    var p = clamp((nowMs-os.startedAt)/os.duration, 0, 1);',
    '    var pe = easeVal(p, os.ease);',
    '    rec.object3D.position.copy(os.fromPos).lerp(os.toPos, pe);',
    '    if(!os.fromQuat.equals(os.toQuat)){',
    '      rec.object3D.quaternion.copy(os.fromQuat).slerp(os.toQuat, pe);',
    '    }',
    '    if(rec.colorMaterials.length){',
    '      var op = lerp(os.fromOpacity, os.toOpacity, pe);',
    '      rec.colorMaterials.forEach(function(m){ m.opacity=op; m.visible = op>0.01; });',
    '    }',
    '    if(os.flashDef){',
    '      var intensity = Math.abs(Math.sin(p*Math.PI*os.flashDef.repeat));',
    '      if(intensity>0.02 && rec.colorMaterials.length){',
    '        var c=new THREE.Color(os.flashDef.color||"#ff3b3b");',
    '        rec.colorMaterials.forEach(function(m){ m.emissive=c; m.emissiveIntensity=intensity; });',
    '      } else if(rec.colorMaterials.length){',
    '        rec.colorMaterials.forEach(function(m){ if(m.emissiveIntensity) m.emissiveIntensity=0; });',
    '      }',
    '    }',
    '    if(p>=1){',
    '      if(os.nextAction) toChain.push({ chainRec: os.chainRec, nextAction: os.nextAction });',
    '      rec.__oneShot = null;',
    '    }',
    '  });',
    '  toChain.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });',
    '}',
    'function openInteractionLink(rec){',
    '  var url=(rec.interactive.url||"").trim();',
    '  if(!url){ feedToast("AVISO " + rec.name + ": no tiene ninguna URL configurada."); return; }',
    '  window.open(url, "_blank", "noopener,noreferrer");',
    '  feedToast("Abriendo enlace: " + rec.name);',
    '  triggerOneShotAction(rec, rec.interactive.onInteractAction);',
    '}',
    'function openInteractionPanel(id){',
    '  var rec=sceneObjects.get(id);',
    '  if(!rec || !rec.interactive || !rec.interactive.enabled) return;',
    '  if(rec.kind==="video"){ toggleVideoPlayback(rec); return; }',
    '  if(rec.interactive.kind==="link"){ openInteractionLink(rec); return; }',
    '  if(rec.interactive.kind==="text"){',
    '    var oia=rec.interactive.onInteractAction;',
    '    var bareText=!(rec.interactive.text && rec.interactive.text.trim());',
    '    var ownsOverlay = oia && (oia.type==="askInput" || oia.type==="screenMessage");',
    '    if(bareText || ownsOverlay){',
    '      triggerOneShotAction(rec, oia);',
    '      return;',
    '    }',
    '  }',
    '  interactionPanelOpen=true;',
    '  document.getElementById("interactPrompt").style.display="none";',
    '  if(rec.interactive.kind==="text") triggerOneShotAction(rec, rec.interactive.onInteractAction);',
    '  var panel=document.getElementById("interactPanel");',
    '  var html = \'<div class="box"><h4>\' + escGameHtml(rec.name) + "</h4>";',
    '  html += "<p>" + escGameHtml(rec.interactive.text || "(sin texto)") + "</p>";',
    '  var isChoice = rec.interactive.kind==="choice" && rec.interactive.choices.length;',
    '  if(isChoice){',
    '    rec.interactive.choices.forEach(function(c,i){',
    '      html += \'<div class="opt" data-idx="\' + i + \'">\' + (i+1) + ". " + escGameHtml(c.label || "Opcion " + (i+1)) + "</div>";',
    '    });',
    '    html += \'<div class="optSub">Toca una opcion, o pulsa su numero (Esc para cerrar sin elegir)</div>\';',
    '  } else {',
    '    html += \'<button type="button" class="actBtn" id="interactContinueBtn">Continuar</button>\';',
    '    html += \'<div class="optSub">Toca el boton, o pulsa E o Esc para continuar</div>\';',
    '  }',
    '  html += "</div>";',
    '  panel.innerHTML = html;',
    '  panel.dataset.forId = id;',
    '  panel.style.display = "flex";',
    '  if(isChoice){',
    '    Array.prototype.forEach.call(panel.querySelectorAll(".opt"), function(el){',
    '      el.addEventListener("click", function(){ chooseInteractionOption(parseInt(el.dataset.idx,10)); });',
    '    });',
    '  } else {',
    '    var contBtn = document.getElementById("interactContinueBtn");',
    '    if(contBtn) contBtn.addEventListener("click", closeInteractionPanel);',
    '  }',
    '}',
    'function closeInteractionPanel(){',
    '  interactionPanelOpen=false;',
    '  var panel=document.getElementById("interactPanel");',
    '  panel.style.display="none";',
    '  panel.innerHTML="";',
    '}',
    'function chooseInteractionOption(index){',
    '  var panel=document.getElementById("interactPanel");',
    '  var rec=sceneObjects.get(panel.dataset.forId);',
    '  if(!rec || !rec.interactive || rec.interactive.kind!=="choice"){ closeInteractionPanel(); return; }',
    '  var choice=rec.interactive.choices[index];',
    '  if(!choice) return;',
    '  var pts=choice.points||0;',
    '  playScore += pts;',
    '  updateScoreDisplay();',
    '  feedToast((pts>=0?"OK ":"AVISO ") + rec.name + ": " + choice.label + " (" + (pts>=0?"+":"") + pts + " pts)");',
    '  triggerOneShotAction(rec, choice.action);',
    '  closeInteractionPanel();',
    '}',
    'function showScreenMessage(text, autoDismissSec, onDone){',
    '  var panel=document.getElementById("screenMsgOverlay");',
    '  if(!panel){ if(onDone) onDone(); return; }',
    '  var done=false;',
    '  var finish=function(){',
    '    if(done) return;',
    '    done=true;',
    '    screenMsgDismissFn=null;',
    '    panel.style.display="none";',
    '    panel.innerHTML="";',
    '    if(onDone) onDone();',
    '  };',
    '  var html=\'<div class="box"><p>\' + escGameHtml(text) + "</p>";',
    '  if(!autoDismissSec){',
    '    html += \'<button type="button" class="actBtn" id="screenMsgCloseBtn">Continuar</button>\';',
    '    html += \'<div class="sub">Toca el boton, o pulsa E o Esc para continuar</div>\';',
    '  }',
    '  html += "</div>";',
    '  panel.innerHTML = html;',
    '  panel.style.display = "flex";',
    '  if(autoDismissSec){',
    '    setTimeout(finish, Math.max(200, autoDismissSec*1000));',
    '  } else {',
    '    var btn=document.getElementById("screenMsgCloseBtn");',
    '    if(btn) btn.addEventListener("click", finish);',
    '    screenMsgDismissFn = finish;',
    '  }',
    '}',
    'function showAskInput(promptText, varName, allowFile, fileVarName, onDone){',
    '  askInputActive = true;',
    '  if(document.pointerLockElement===canvas) document.exitPointerLock();',
    '  var panel=document.getElementById("askInputOverlay");',
    '  var pendingFileDataUrl=null;',
    '  var finish=function(){',
    '    askInputActive=false;',
    '    panel.style.display="none";',
    '    panel.innerHTML="";',
    '    if(started && !isTouchDevice()){',
    '      var req=canvas.requestPointerLock();',
    '      if(req && typeof req.catch==="function") req.catch(function(){ document.getElementById("clickToStart").style.display="flex"; });',
    '    }',
    '    if(onDone) onDone();',
    '  };',
    '  var html=\'<div class="box"><p>\' + escGameHtml(promptText||"") + "</p>";',
    '  html += \'<input type="text" id="askInputText" style="width:100%;box-sizing:border-box;padding:8px;border-radius:6px;border:1px solid #2a2f3d;background:#0f1116;color:#e8e8ee;margin-bottom:8px;" maxlength="500">\';',
    '  if(allowFile){',
    '    html += \'<p class="sub" id="askInputFileInfo">Sin archivo adjunto.</p>\';',
    '    html += \'<input type="file" id="askInputFile" accept="image/*" style="display:none;">\';',
    '    html += \'<button type="button" class="small" id="askInputFileTrigger" style="margin-bottom:8px;">Adjuntar imagen</button>\';',
    '  }',
    '  html += \'<div class="flexRow"><button type="button" class="actBtn" id="askInputSend" style="flex:1;">Enviar</button><button type="button" class="small" id="askInputCancel" style="flex:1;">Cancelar</button></div>\';',
    '  html += \'<div class="sub">Enter para enviar, Esc para cancelar</div></div>\';',
    '  panel.innerHTML = html;',
    '  panel.style.display = "flex";',
    '  var textEl=document.getElementById("askInputText");',
    '  textEl.focus();',
    '  if(allowFile){',
    '    document.getElementById("askInputFileTrigger").addEventListener("click", function(){ document.getElementById("askInputFile").click(); });',
    '    document.getElementById("askInputFile").addEventListener("change", function(e){',
    '      var file=e.target.files[0];',
    '      var info=document.getElementById("askInputFileInfo");',
    '      if(!file) return;',
    '      if(file.size > MAX_ASK_ARCHIVO_BYTES){',
    '        if(info) info.textContent = "Demasiado grande (max. " + Math.round(MAX_ASK_ARCHIVO_BYTES/1024) + "KB) -- no se adjunta.";',
    '        pendingFileDataUrl=null;',
    '        e.target.value="";',
    '        return;',
    '      }',
    '      var reader=new FileReader();',
    '      reader.onload=function(){ pendingFileDataUrl=reader.result; if(info) info.textContent="Adjunto: " + file.name; };',
    '      reader.onerror=function(){ if(info) info.textContent="No se pudo leer el archivo."; };',
    '      reader.readAsDataURL(file);',
    '    });',
    '  }',
    '  var doSend=function(){',
    '    if(varName) gameVariables[varName]=textEl.value;',
    '    if(allowFile && fileVarName && pendingFileDataUrl) gameVariables[fileVarName]=pendingFileDataUrl;',
    '    finish();',
    '  };',
    '  document.getElementById("askInputSend").addEventListener("click", doSend);',
    '  document.getElementById("askInputCancel").addEventListener("click", finish);',
    '  textEl.addEventListener("keydown", function(e){',
    '    e.stopPropagation();',
    '    if(e.key==="Enter"){ e.preventDefault(); doSend(); }',
    '    else if(e.key==="Escape"){ e.preventDefault(); finish(); }',
    '  });',
    '}',
    '',
    'var bgMusicEl = null;',
    'function startBgMusic(){',
    '  if(!PROJECT.audio || !PROJECT.audio.musicBase64) return;',
    '  bgMusicEl = new Audio(PROJECT.audio.musicBase64);',
    '  bgMusicEl.loop = true;',
    '  bgMusicEl.volume = PROJECT.audio.volume!==undefined ? PROJECT.audio.volume : 0.5;',
    '  bgMusicEl.play().catch(function(){});',
    '}',
    'document.getElementById("touchJoystick").style.display = isTouchDevice() ? "block" : "none";',
    'document.getElementById("touchJumpBtn").style.display = isTouchDevice() ? "flex" : "none";',
    'document.getElementById("touchViewBtn").style.display = isTouchDevice() ? "flex" : "none";',
    'document.getElementById("touchDroneBtn").style.display = isTouchDevice() ? "flex" : "none";',
    'document.getElementById("playInstructions").style.display = isTouchDevice() ? "none" : "block";',
    'var autoplayCameraPathDone = false;',
    'document.getElementById("clickToStart").addEventListener("click", function(){',
    '  document.getElementById("clickToStart").style.display="none";',
    '  if(bgMusicEl) bgMusicEl.play().catch(function(){}); else startBgMusic();',
    '  started=true;',
    '  if(!autoplayCameraPathDone){',
    '    autoplayCameraPathDone = true;',
    '    var acp = null;',
    '    sceneObjects.forEach(function(r){ if(!acp && r.kind==="camerapath" && r.cameraPathData && r.cameraPathData.autoplay) acp = r; });',
    '    if(acp) playCameraPath(acp);',
    '  }',
    '  if(isTouchDevice()) return;',
    '  var reqInit=canvas.requestPointerLock();',
    '  if(reqInit && typeof reqInit.catch==="function") reqInit.catch(function(){ document.getElementById("clickToStart").style.display="flex"; });',
    '});',
    'document.addEventListener("pointerlockchange", function(){',
    '  if(isTouchDevice()) return;',
    '  if(started && document.pointerLockElement!==canvas){ if(!askInputActive) document.getElementById("clickToStart").style.display="flex"; if(bgMusicEl) bgMusicEl.pause(); sceneObjects.forEach(function(r){ if(r.videoEl) r.videoEl.pause(); }); }',
    '});',
    'document.addEventListener("mousemove", function(e){',
    '  if(!started || document.pointerLockElement!==canvas || cameraPathActive) return;',
    '  playYaw -= (e.movementX||0)*0.0022;',
    '  playPitch -= (e.movementY||0)*0.0022;',
    '  playPitch = clamp(playPitch,-1.0,1.0);',
    '});',
    'var touchJoystickEl = document.getElementById("touchJoystick");',
    'var touchJoystickKnobEl = document.getElementById("touchJoystickKnob");',
    'var TOUCH_JOYSTICK_RADIUS = 46;',
    'touchJoystickEl.addEventListener("touchstart", function(e){',
    '  var t=e.changedTouches[0]; touchJoystickId=t.identifier; e.preventDefault();',
    '}, { passive:false });',
    'function updateTouchJoystickFromTouch(t){',
    '  var rect=touchJoystickEl.getBoundingClientRect();',
    '  var cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;',
    '  var dx=t.clientX-cx, dy=t.clientY-cy;',
    '  var dist=Math.hypot(dx,dy);',
    '  if(dist>TOUCH_JOYSTICK_RADIUS){ dx=(dx/dist)*TOUCH_JOYSTICK_RADIUS; dy=(dy/dist)*TOUCH_JOYSTICK_RADIUS; }',
    '  touchJoystickKnobEl.style.transform = "translate(" + dx + "px," + dy + "px)";',
    '  touchJoystickVec = { x: clamp(dx/TOUCH_JOYSTICK_RADIUS,-1,1), y: clamp(-dy/TOUCH_JOYSTICK_RADIUS,-1,1) };',
    '}',
    'function resetTouchJoystick(){ touchJoystickId=null; touchJoystickVec={x:0,y:0}; touchJoystickKnobEl.style.transform="translate(0,0)"; }',
    'canvas.addEventListener("touchstart", function(e){',
    '  if(!started || touchLookId!==null) return;',
    '  var t=e.changedTouches[0]; touchLookId=t.identifier; touchLookLast={x:t.clientX,y:t.clientY};',
    '}, { passive:true });',
    'window.addEventListener("touchmove", function(e){',
    '  if(!started) return;',
    '  for(var i=0;i<e.changedTouches.length;i++){',
    '    var t=e.changedTouches[i];',
    '    if(t.identifier===touchJoystickId){ updateTouchJoystickFromTouch(t); e.preventDefault(); }',
    '    else if(t.identifier===touchLookId){',
    '      var dx=t.clientX-touchLookLast.x, dy=t.clientY-touchLookLast.y;',
    '      if(!cameraPathActive){ playYaw -= dx*0.0055; playPitch -= dy*0.0055; playPitch = clamp(playPitch,-1.0,1.0); }',
    '      touchLookLast={x:t.clientX,y:t.clientY}; e.preventDefault();',
    '    }',
    '  }',
    '}, { passive:false });',
    'function releaseTouch(e){',
    '  for(var i=0;i<e.changedTouches.length;i++){',
    '    var t=e.changedTouches[i];',
    '    if(t.identifier===touchJoystickId) resetTouchJoystick();',
    '    if(t.identifier===touchLookId) touchLookId=null;',
    '  }',
    '}',
    'window.addEventListener("touchend", releaseTouch);',
    'window.addEventListener("touchcancel", releaseTouch);',
    'document.getElementById("touchInteractBtn").addEventListener("touchstart", function(e){',
    '  e.preventDefault(); e.stopPropagation();',
    '  if(nearestInteractiveId) openInteractionPanel(nearestInteractiveId);',
    '});',
    'document.getElementById("touchShootBtn").addEventListener("touchstart", function(e){',
    '  e.preventDefault(); e.stopPropagation();',
    '  attemptShoot();',
    '});',
    'var touchJumpBtnEl = document.getElementById("touchJumpBtn");',
    'touchJumpBtnEl.addEventListener("touchstart", function(e){ e.preventDefault(); playKeys.space=true; });',
    'touchJumpBtnEl.addEventListener("touchend", function(e){ e.preventDefault(); playKeys.space=false; });',
    'touchJumpBtnEl.addEventListener("touchcancel", function(){ playKeys.space=false; });',
    'function updateCameraPathCaption(){',
    '  var el = document.getElementById("cameraPathCaption");',
    '  if(!el) return;',
    '  if(cameraPathActive && cameraPathActive.caption){ el.textContent = cameraPathActive.caption; el.style.display="block"; }',
    '  else { el.style.display="none"; }',
    '}',
    'function playCameraPath(rec){',
    '  if(!rec || rec.kind!=="camerapath") return;',
    '  var cpd = rec.cameraPathData;',
    '  if(!cpd || !cpd.path || !cpd.path.nodes || cpd.path.nodes.length<2) return;',
    '  rec.object3D.updateMatrixWorld(true);',
    '  var worldPts = cpd.path.nodes.map(function(n){ return rec.object3D.localToWorld(new THREE.Vector3(n.x,n.y,n.z)); });',
    '  var curve = new THREE.CatmullRomCurve3(worldPts, !!cpd.path.closed, "catmullrom", 0.5);',
    '  cameraPathActive = { curve:curve, duration:Math.max(0.5, cpd.duration||6), elapsed:0, caption:cpd.caption||"", lookAtTargetId:cpd.lookAtTargetId||null, wasFirstPerson:firstPersonMode, wasDrone:droneModeActive };',
    '  droneModeActive = false;',
    '  nearestInteractiveId = null; updateInteractPrompt();',
    '  nearestShotTargetId = null; updateShotPrompt();',
    '  updateCameraPathCaption();',
    '  feedToast("🎥 " + rec.name);',
    '}',
    'function endCameraPath(){',
    '  if(!cameraPathActive) return;',
    '  var cp = cameraPathActive;',
    '  cameraPathActive = null;',
    '  droneModeActive = cp.wasDrone;',
    '  firstPersonMode = cp.wasFirstPerson;',
    '  updateCameraPathCaption();',
    '}',
    'function toggleFirstPerson(){',
    '  if(cameraPathActive) return;',
    '  firstPersonMode=!firstPersonMode;',
    '  playPitch=-0.25;',
    '  playCamDist = CHASE_RADIUS;',
    '  var p=sceneObjects.get(playerRecordId);',
    '  if(p) p.colorMaterials.forEach(function(m){ m.visible=!(firstPersonMode||droneModeActive); });',
    '}',
    'function toggleDroneMode(){',
    '  if(cameraPathActive) return;',
    '  droneModeActive=!droneModeActive;',
    '  var p=sceneObjects.get(playerRecordId);',
    '  if(droneModeActive){ droneCamPos.copy(camera.position); nearestInteractiveId=null; nearestShotTargetId=null; }',
    '  if(p) p.colorMaterials.forEach(function(m){ m.visible=!(firstPersonMode||droneModeActive); });',
    '  updateInteractPrompt(); updateShotPrompt();',
    '  var btn=document.getElementById("touchDroneBtn");',
    '  if(btn) btn.classList.toggle("activo", droneModeActive);',
    '  var downBtn=document.getElementById("touchDroneDownBtn");',
    '  if(downBtn) downBtn.style.display = (droneModeActive && isTouchDevice()) ? "flex" : "none";',
    '  feedToast(droneModeActive ? "\uD83D\uDEF8 Modo dron: ACTIVADO" : "\uD83D\uDEB6 Modo dron: desactivado");',
    '}',
    'document.getElementById("touchViewBtn").addEventListener("touchstart", function(e){',
    '  e.preventDefault(); e.stopPropagation(); toggleFirstPerson();',
    '});',
    'document.getElementById("touchDroneBtn").addEventListener("touchstart", function(e){',
    '  e.preventDefault(); e.stopPropagation(); toggleDroneMode();',
    '});',
    'var touchDroneDownBtnEl = document.getElementById("touchDroneDownBtn");',
    'touchDroneDownBtnEl.addEventListener("touchstart", function(e){ e.preventDefault(); playKeys.shift=true; });',
    'touchDroneDownBtnEl.addEventListener("touchend", function(e){ e.preventDefault(); playKeys.shift=false; });',
    'touchDroneDownBtnEl.addEventListener("touchcancel", function(){ playKeys.shift=false; });',
    'window.addEventListener("keydown", function(e){',
    '  var k=e.key.toLowerCase();',
    '  if(askInputActive){',
    '    // askInputText tiene su propio listener de keydown (con stopPropagation) para Enter/Esc --',
    '    // esto es solo red de seguridad para cuando el foco esta en otro control del overlay.',
    '    return;',
    '  }',
    '  if(screenMsgDismissFn && (k==="e" || k==="escape")){ screenMsgDismissFn(); return; }',
    '  if(interactionPanelOpen){',
    '    if(k>="1" && k<="4"){ chooseInteractionOption(parseInt(k,10)-1); }',
    '    else if(k==="e" || k==="escape"){ closeInteractionPanel(); }',
    '    return;',
    '  }',
    '  if(k==="w") playKeys.w=true; if(k==="a") playKeys.a=true; if(k==="s") playKeys.s=true; if(k==="d") playKeys.d=true;',
    '  if(k==="arrowup"){ playKeys.arrowUp=true; e.preventDefault(); }',
    '  if(k==="arrowdown"){ playKeys.arrowDown=true; e.preventDefault(); }',
    '  if(k==="arrowleft"){ playKeys.arrowLeft=true; e.preventDefault(); }',
    '  if(k==="arrowright"){ playKeys.arrowRight=true; e.preventDefault(); }',
    '  if(k==="shift") playKeys.shift=true;',
    '  if(k===" " || k==="spacebar"){ playKeys.space=true; e.preventDefault(); }',
    '  if(k==="v") toggleFirstPerson();',
    '  if(k==="c") toggleDroneMode();',
    '  if(k==="e"){ if(nearestInteractiveId) openInteractionPanel(nearestInteractiveId); }',
    '  if(k==="f") attemptShoot();',
    '  if(k==="r") location.reload();',
    '  if(k==="l"){ skyPointerActivo = !skyPointerActivo; }',
    '});',
    'window.addEventListener("keyup", function(e){',
    '  var k=e.key.toLowerCase();',
    '  if(k==="w") playKeys.w=false; if(k==="a") playKeys.a=false; if(k==="s") playKeys.s=false; if(k==="d") playKeys.d=false;',
    '  if(k==="arrowup") playKeys.arrowUp=false;',
    '  if(k==="arrowdown") playKeys.arrowDown=false;',
    '  if(k==="arrowleft") playKeys.arrowLeft=false;',
    '  if(k==="arrowright") playKeys.arrowRight=false;',
    '  if(k==="shift") playKeys.shift=false;',
    '  if(k===" " || k==="spacebar") playKeys.space=false;',
    '});',
  ].join('\n') + '\n');
  L.push([
    'function collidesSolidAt(x, y, z, half, excludeId){',
    '  var eps = 0.05;',
    '  var cBox = new THREE.Box3(new THREE.Vector3(x-half.x, y, z-half.z), new THREE.Vector3(x+half.x, y+half.y*2, z+half.z));',
    '  var hit = false;',
    '  sceneObjects.forEach(function(rec){',
    '    if(hit || rec.id===excludeId || rec.collider.kind!=="solid") return;',
    '    var oBox = new THREE.Box3().setFromObject(rec.object3D);',
    '    if(y >= oBox.max.y - eps) return;',
    '    if(cBox.intersectsBox(oBox)) hit = true;',
    '  });',
    '  return hit;',
    '}',
    'function resolveMoveWithCollision(player, dir, dist){',
    '  var size = player.collider.size || { x:0.5, y:1.2, z:0.5 };',
    '  var half = { x:size.x/2, y:size.y/2, z:size.z/2 };',
    '  var pos = player.object3D.position;',
    '  var y = pos.y;',
    '  var nx = pos.x + dir.x*dist;',
    '  if(!collidesSolidAt(nx, y, pos.z, half, player.id) && computeHeadClearance(nx, pos.z, y, player.id) >= size.y) pos.x = nx;',
    '  var nz = pos.z + dir.z*dist;',
    '  if(!collidesSolidAt(pos.x, y, nz, half, player.id) && computeHeadClearance(pos.x, nz, y, player.id) >= size.y) pos.z = nz;',
    '}',
    'var groundRaycaster = new THREE.Raycaster();',
    'var cameraRaycaster = new THREE.Raycaster();',
    'var shotRaycaster = new THREE.Raycaster();',
    'var SHOT_MAX_DISTANCE = 60;',
    'var nearestShotTargetId = null;',
    'var droneModeActive = false;',
    'var skyPointerActivo = false;',
    'var droneCamPos = new THREE.Vector3();',
    'var DRONE_SPEED = 5;',
    'var cameraPathActive = null;',
    'function objectForMeshRuntime(mesh){',
    '  var o = mesh, found = null;',
    '  while(o && !found){',
    '    sceneObjects.forEach(function(rec, id){ if(rec.object3D === o) found = id; });',
    '    o = o.parent;',
    '  }',
    '  return found;',
    '}',
    'function computeGroundHit(x, z, fromY, excludeId){',
    '  groundRaycaster.set(new THREE.Vector3(x, fromY+0.6, z), new THREE.Vector3(0,-1,0));',
    '  groundRaycaster.far = 60;',
    '  var targets = [ground];',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.id===excludeId) return;',
    '    if(rec.collider.kind==="solid" || rec.collider.kind==="ground") targets.push(rec.object3D);',
    '  });',
    '  var hits = groundRaycaster.intersectObjects(targets, true);',
    '  return hits.length ? { y:hits[0].point.y, object:hits[0].object } : null;',
    '}',
    'function computeGroundY(x, z, fromY, excludeId){',
    '  var hit = computeGroundHit(x, z, fromY, excludeId);',
    '  return hit ? hit.y : null;',
    '}',
    'function raycastGroundAgainstObject(x, z, fromY, obj){',
    '  groundRaycaster.set(new THREE.Vector3(x, fromY+5, z), new THREE.Vector3(0,-1,0));',
    '  groundRaycaster.far = 20;',
    '  var hits = groundRaycaster.intersectObject(obj, true);',
    '  return hits.length ? hits[0].point.y : null;',
    '}',
    'function computeHeadClearance(x, z, feetY, excludeId){',
    '  var startY = feetY + 0.25;',
    '  groundRaycaster.set(new THREE.Vector3(x, startY, z), new THREE.Vector3(0,1,0));',
    '  groundRaycaster.far = 3;',
    '  var targets = [];',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.id===excludeId) return;',
    '    if(rec.collider.kind==="ground") targets.push(rec.object3D);',
    '  });',
    '  if(!targets.length) return Infinity;',
    '  var hits = groundRaycaster.intersectObjects(targets, true);',
    '  return hits.length ? (hits[0].point.y - feetY) : Infinity;',
    '}',
    'function updatePlayer(dt){',
    '  if(!playerRecordId) return;',
    '  var player = sceneObjects.get(playerRecordId);',
    '  if(!player) return;',
    '  var prevClockTime = npcClockTime;',
    '  npcClockTime += dt;',
    '  if(timelineDuration>0.02 && npcClockTime>timelineDuration) npcClockTime = npcClockTime % timelineDuration;',
    '  fireDueChainTriggers(prevClockTime, npcClockTime);',
    '  applyTimeToScene(npcClockTime, playerRecordId);',
    '  if(cameraPathActive){',
    '    var cp = cameraPathActive;',
    '    cp.elapsed += dt;',
    '    var tCp = clamp(cp.elapsed/cp.duration, 0, 1);',
    '    var posCp = cp.curve.getPointAt(tCp);',
    '    camera.position.copy(posCp);',
    '    var lookCp;',
    '    if(cp.lookAtTargetId){',
    '      var lookRec = sceneObjects.get(cp.lookAtTargetId);',
    '      lookCp = lookRec ? lookRec.object3D.getWorldPosition(new THREE.Vector3()) : posCp.clone().add(cp.curve.getTangentAt(tCp));',
    '    } else { lookCp = posCp.clone().add(cp.curve.getTangentAt(tCp)); }',
    '    camera.lookAt(lookCp);',
    '    if(tCp>=1) endCameraPath();',
    '  } else if(!interactionPanelOpen && !askInputActive && droneModeActive){',
    '    if(playKeys.arrowLeft) playYaw += TURN_SPEED*dt;',
    '    if(playKeys.arrowRight) playYaw -= TURN_SPEED*dt;',
    '    var droneForward = new THREE.Vector3(0,0,-1).applyEuler(new THREE.Euler(playPitch,playYaw,0,"YXZ"));',
    '    var droneRight = new THREE.Vector3(1,0,0).applyEuler(new THREE.Euler(0,playYaw,0));',
    '    var dMoveZ=0, dMoveX=0, dMoveY=0;',
    '    if(playKeys.w || playKeys.arrowUp) dMoveZ+=1; if(playKeys.s || playKeys.arrowDown) dMoveZ-=1; if(playKeys.d) dMoveX+=1; if(playKeys.a) dMoveX-=1;',
    '    if(playKeys.space) dMoveY+=1; if(playKeys.shift) dMoveY-=1;',
    '    dMoveZ += touchJoystickVec.y; dMoveX += touchJoystickVec.x;',
    '    var droneDir = new THREE.Vector3().addScaledVector(droneForward, dMoveZ).addScaledVector(droneRight, dMoveX).addScaledVector(new THREE.Vector3(0,1,0), dMoveY);',
    '    if(droneDir.lengthSq()>0.0001) droneCamPos.addScaledVector(droneDir.normalize(), DRONE_SPEED*dt);',
    '    camera.position.copy(droneCamPos);',
    '    camera.rotation.order="YXZ";',
    '    camera.rotation.set(playPitch, playYaw, 0);',
    '  } else if(!interactionPanelOpen && !askInputActive){',
    '    if(playKeys.arrowLeft) playYaw += TURN_SPEED*dt;',
    '    if(playKeys.arrowRight) playYaw -= TURN_SPEED*dt;',
    '    var forwardVec = new THREE.Vector3(0,0,-1).applyEuler(new THREE.Euler(0,playYaw,0));',
    '    var rightVec = new THREE.Vector3(1,0,0).applyEuler(new THREE.Euler(0,playYaw,0));',
    '    var moveZ=0, moveX=0;',
    '    if(playKeys.w || playKeys.arrowUp) moveZ+=1; if(playKeys.s || playKeys.arrowDown) moveZ-=1; if(playKeys.d) moveX+=1; if(playKeys.a) moveX-=1;',
    '    moveZ += touchJoystickVec.y; moveX += touchJoystickVec.x;',
    '    var joyMag = Math.hypot(touchJoystickVec.x, touchJoystickVec.y);',
    '    var inputLen = Math.hypot(moveX,moveZ);',
    '    if(inputLen>0.001){',
    '      var dir = new THREE.Vector3().addScaledVector(forwardVec, moveZ/inputLen).addScaledVector(rightVec, moveX/inputLen);',
    '      dir.normalize();',
    '      var speed = (playKeys.shift || joyMag>0.75) ? RUN_SPEED : WALK_SPEED;',
    '      resolveMoveWithCollision(player, dir, speed*dt);',
    '      player.object3D.position.x = clamp(player.object3D.position.x,-SCENE_HALF_EXTENT,SCENE_HALF_EXTENT);',
    '      player.object3D.position.z = clamp(player.object3D.position.z,-SCENE_HALF_EXTENT,SCENE_HALF_EXTENT);',
    '      var targetQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,-1), dir);',
    '      if(player.facingOffsetDeg) targetQuat.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), deg2rad(player.facingOffsetDeg)));',
    '      player.object3D.quaternion.slerp(targetQuat, clamp(dt*10,0,1));',
    '    }',
    '    if(player.mixer && player.clips && player.clips.length){',
    '      if(!player.__playerClipAction){',
    '        var wanted=(player.actions||[]).find(function(a){ return a.type==="playClip"; });',
    '        var clip=(wanted && player.clips.find(function(c){ return c.name===wanted.clipName; })) || player.clips[0];',
    '        if(clip) player.__playerClipAction = player.mixer.clipAction(clip).play();',
    '      }',
    '      if(player.__playerClipAction){',
    '        player.__playerClipAction.paused = !(inputLen>0.001);',
    '        player.mixer.update(dt);',
    '      }',
    '    }',
    '    if(player.__standObj && player.__standObj.parent){',
    '      var carriedY = raycastGroundAgainstObject(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.__standObj);',
    '      if(carriedY!==null && player.__standPrevY!=null){ player.object3D.position.y += (carriedY - player.__standPrevY); }',
    '    }',
    '    var groundHit = computeGroundHit(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.id);',
    '    var gY = groundHit ? groundHit.y : null;',
    '    var closeToGround = gY!==null && (player.object3D.position.y - gY) < 0.25;',
    '    if(playKeys.space && playGrounded && closeToGround){ playVelY = JUMP_SPEED; playGrounded=false; }',
    '    if(playGrounded && closeToGround){',
    '      player.object3D.position.y = lerp(player.object3D.position.y, gY, clamp(dt*15,0,1));',
    '      playVelY = 0;',
    '    } else {',
    '      playVelY += GRAVITY*dt;',
    '      player.object3D.position.y += playVelY*dt;',
    '      if(gY!==null && player.object3D.position.y<=gY && playVelY<=0){ player.object3D.position.y=gY; playVelY=0; playGrounded=true; }',
    '      else { playGrounded=false; }',
    '    }',
    '    if(playGrounded && groundHit){ player.__standObj = groundHit.object; player.__standPrevY = groundHit.y; }',
    '    else { player.__standObj = null; player.__standPrevY = null; }',
    '    var pivot = player.object3D.position.clone().add(new THREE.Vector3(0,1.35,0));',
    '    if(firstPersonMode){',
    '      camera.position.copy(pivot);',
    '      camera.rotation.order="YXZ";',
    '      camera.rotation.set(playPitch, playYaw, 0);',
    '    } else {',
    '      var camDir = new THREE.Vector3().setFromSpherical(new THREE.Spherical(1, Math.PI/2-playPitch, playYaw));',
    '      var camTargets = [];',
    '      sceneObjects.forEach(function(rec){',
    '        if(rec.id===playerRecordId) return;',
    '        if(rec.collider.kind==="solid" || rec.collider.kind==="ground") camTargets.push(rec.object3D);',
    '      });',
    '      var camUpRef = Math.abs(camDir.y) > 0.98 ? new THREE.Vector3(1,0,0) : new THREE.Vector3(0,1,0);',
    '      var camRight = new THREE.Vector3().crossVectors(camDir, camUpRef).normalize();',
    '      var camUp2 = new THREE.Vector3().crossVectors(camRight, camDir).normalize();',
    '      var FAN_SPREAD = 0.4;',
    '      var sampleOffsets = [[0,0],[1,0],[-1,0],[0,1],[0,-1],[0.7,0.7],[0.7,-0.7],[-0.7,0.7],[-0.7,-0.7]];',
    '      var rawCamDist = CHASE_RADIUS;',
    '      for (var si=0; si<sampleOffsets.length; si++){',
    '        var rx=sampleOffsets[si][0], ry=sampleOffsets[si][1];',
    '        var samplePoint = pivot.clone().addScaledVector(camDir, CHASE_RADIUS).addScaledVector(camRight, rx*FAN_SPREAD).addScaledVector(camUp2, ry*FAN_SPREAD);',
    '        var sampleDir = samplePoint.sub(pivot).normalize();',
    '        cameraRaycaster.set(pivot, sampleDir);',
    '        cameraRaycaster.far = CHASE_RADIUS;',
    '        var hits = cameraRaycaster.intersectObjects(camTargets, true);',
    '        if(hits.length) rawCamDist = Math.min(rawCamDist, Math.max(0.5, hits[0].distance-0.3));',
    '      }',
    '      playCamDist = lerp(playCamDist, rawCamDist, clamp(dt*10,0,1));',
    '      var camDist = playCamDist;',
    '      var tentative = pivot.clone().addScaledVector(camDir, camDist);',
    '      var camFloorY = computeGroundY(tentative.x, tentative.z, pivot.y+2, playerRecordId);',
    '      if(camFloorY!==null && camDir.y < -0.001){',
    '        var maxDistFloor = (camFloorY+0.15-pivot.y)/camDir.y;',
    '        camDist = Math.max(0.5, Math.min(camDist, maxDistFloor));',
    '      }',
    '      cameraRaycaster.set(pivot, new THREE.Vector3(0,1,0));',
    '      cameraRaycaster.far = CHASE_RADIUS + 1.5;',
    '      var camCeilingHits = cameraRaycaster.intersectObjects(camTargets, true);',
    '      if(camCeilingHits.length && camDir.y > 0.001){',
    '        var maxDistCeil = (camCeilingHits[0].point.y-0.2-pivot.y)/camDir.y;',
    '        camDist = Math.max(1.2, Math.min(camDist, maxDistCeil));',
    '      }',
    '      camera.position.copy(pivot).addScaledVector(camDir, camDist);',
    '      camera.lookAt(pivot);',
    '    }',
    '  }',
    '  if(droneModeActive || cameraPathActive){',
    '    nearestInteractiveId = null; updateInteractPrompt();',
    '    nearestShotTargetId = null; updateShotPrompt();',
    '  } else {',
    '  var nearest=null, nearestDist=Infinity;',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.id===playerRecordId) return;',
    '    if(!rec.interactive || !rec.interactive.enabled) return;',
    '    var d = rec.object3D.position.distanceTo(player.object3D.position);',
    '    if(d <= (rec.interactive.radius||2) && d < nearestDist){ nearest=rec; nearestDist=d; }',
    '  });',
    '  nearestInteractiveId = nearest ? nearest.id : null;',
    '  updateInteractPrompt();',
    '  var shotTargets=[];',
    '  sceneObjects.forEach(function(rec){',
    '    if(rec.id===playerRecordId) return;',
    '    if(!rec.interactive || !rec.interactive.onShotAction) return;',
    '    if(rec.colorMaterials.length && rec.colorMaterials.every(function(m){ return !m.visible; })) return;',
    '    shotTargets.push(rec.object3D);',
    '  });',
    '  nearestShotTargetId = null;',
    '  if(shotTargets.length){',
    '    var shotDir = new THREE.Vector3();',
    '    camera.getWorldDirection(shotDir);',
    '    shotRaycaster.set(camera.position, shotDir);',
    '    shotRaycaster.far = SHOT_MAX_DISTANCE;',
    '    var shotHits = shotRaycaster.intersectObjects(shotTargets, true);',
    '    if(shotHits.length) nearestShotTargetId = objectForMeshRuntime(shotHits[0].object);',
    '  }',
    '  updateShotPrompt();',
    '  }',
    '}',
    '',
    'var lastT = performance.now();',
    'function tick(){',
    '  var now = performance.now();',
    '  var dt = clamp((now-lastT)/1000, 0, 0.05);',
    '  lastT = now;',
    '  updateSunCycle(dt);',
    '  updateNightSky(dt);',
    '  updateWeatherSystems(dt);',
    '  updateCricketSounds(dt);',
    '  updateOneShotAnimations();', // se actualizan las plataformas/animaciones en curso ANTES que el jugador, para que su raycast de suelo vea la posición de este mismo frame (evita que se caiga de un ascensor en movimiento)
    '  updateSpins(dt);',
    '  updateOneShotClips(dt);',
    '  if(playerRecordId) updatePlayer(dt);',
    '  else { var prevClockTime2 = npcClockTime; npcClockTime += dt; if(timelineDuration>0.02 && npcClockTime>timelineDuration) npcClockTime = npcClockTime % timelineDuration; fireDueChainTriggers(prevClockTime2, npcClockTime); applyTimeToScene(npcClockTime, null); }',
    '  updateSkyPointer(dt, skyPointerActivo);',
    '  renderer.render(scene, camera);',
    '  requestAnimationFrame(tick);',
    '}',
    '',
    'applyEnvironment(PROJECT.environment);',
    'buildScene(PROJECT, function(){',
    '  if(!playerRecordId){ camera.position.set(7,6,10); camera.lookAt(new THREE.Vector3(0,1,0)); }',
    '  else {',
    '    var startPlayer = sceneObjects.get(playerRecordId);',
    '    var startGY = computeGroundY(startPlayer.object3D.position.x, startPlayer.object3D.position.z, startPlayer.object3D.position.y, startPlayer.id);',
    '    if(startGY!==null) startPlayer.object3D.position.y = startGY;',
    '    playVelY = 0; playGrounded = true;',
    '  }',
    '  document.getElementById("loadingMsg").style.display="none";',
    '  requestAnimationFrame(tick);',
    '});',
  ].join('\n') + '\n');
  return L.join('\n');
}

function buildStandaloneGameHtml(project) {
  const safeJson = JSON.stringify(project).replace(/<\/script/gi, "<\\/script");
  const runtimeSrc = buildStandaloneGameRuntimeSrc(safeJson);
  const parts = [];
  parts.push('<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">');
  parts.push('<meta name="viewport" content="width=device-width, initial-scale=1.0">');
  parts.push('<title>Videojuego 3D — Don Claude</title><style>');
  parts.push('html,body{height:100%;height:100dvh;margin:0;background:#0a0b0f;overflow:hidden;font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;}');
  parts.push('#gcanvas{width:100%;height:100%;display:block;}');
  parts.push('#hud{position:fixed;inset:0;pointer-events:none;color:#e8e8ee;}');
  parts.push('.crosshair{position:absolute;top:50%;left:50%;width:6px;height:6px;margin:-3px 0 0 -3px;border-radius:50%;background:rgba(255,255,255,.8);}');
  parts.push('.instructions{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);background:rgba(10,11,15,.7);color:#9aa0ae;padding:6px 14px;border-radius:20px;font-size:11px;white-space:nowrap;}');
  parts.push('#feed{position:absolute;top:56px;left:14px;max-width:320px;max-height:calc(100vh - 232px);overflow:hidden;display:flex;flex-direction:column;gap:4px;}');
  parts.push('#feed .toast{background:rgba(58,20,24,.85);border:1px solid #6b2b32;color:#ffc7cb;padding:6px 10px;border-radius:6px;font-size:12px;}');
  parts.push('#clickToStart{position:absolute;inset:0;pointer-events:auto;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:rgba(10,11,15,.75);color:#e8e8ee;font-size:16px;cursor:pointer;text-align:center;}');
  parts.push('#loadingMsg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#9aa0ae;font-size:13px;}');
  parts.push('#score{position:absolute;top:14px;left:50%;transform:translateX(-50%);background:rgba(10,11,15,.7);color:#e8e8ee;padding:6px 16px;border-radius:20px;font-size:13px;font-weight:600;}');
  parts.push('#interactPrompt{position:absolute;bottom:64px;left:50%;transform:translateX(-50%);background:rgba(10,11,15,.8);color:#fff;padding:7px 16px;border-radius:8px;font-size:13px;font-weight:600;display:none;}');
  parts.push('#shotPrompt{position:absolute;bottom:100px;left:50%;transform:translateX(-50%);background:rgba(120,20,20,.82);color:#fff;padding:6px 14px;border-radius:8px;font-size:12px;font-weight:600;display:none;}');
  parts.push('#constellationPrompt{position:absolute;top:70px;left:50%;transform:translateX(-50%);background:rgba(20,22,45,.8);color:#ffe9b8;padding:6px 16px;border-radius:8px;font-size:13px;font-weight:600;letter-spacing:.02em;display:none;}');
  parts.push('#cameraPathCaption{position:absolute;bottom:15%;left:50%;transform:translateX(-50%);background:rgba(10,11,15,.75);color:#fff;padding:10px 22px;border-radius:8px;font-size:16px;font-weight:600;text-align:center;max-width:70%;letter-spacing:.01em;display:none;}');
  parts.push('#interactPanel{position:absolute;inset:0;pointer-events:auto;display:none;align-items:center;justify-content:center;background:rgba(5,6,9,.72);}');
  parts.push('#interactPanel .box{background:#161922;border:1px solid #2a2f3d;border-radius:10px;padding:20px 26px;max-width:460px;color:#e8e8ee;}');
  parts.push('#interactPanel .box h4{margin:0 0 10px;font-size:15px;}');
  parts.push('#interactPanel .box p{margin:0 0 10px;font-size:13px;line-height:1.5;}');
  parts.push('#interactPanel .box .opt{font-size:13px;padding:8px 10px;margin:2px -10px;color:#9aa0ae;border-radius:6px;cursor:pointer;}');
  parts.push('#interactPanel .box .opt:hover,#interactPanel .box .opt:active{background:rgba(79,140,255,.18);color:#e8e8ee;}');
  parts.push('#interactPanel .box .optSub{margin-top:12px;font-size:11px;color:#9aa0ae;}');
  parts.push('#interactPanel .box .actBtn{margin-top:12px;padding:9px 18px;border-radius:6px;border:1px solid rgba(255,255,255,.3);background:rgba(79,140,255,.88);color:#fff;font-size:13px;font-weight:600;cursor:pointer;}');
  parts.push('#screenMsgOverlay,#askInputOverlay{position:absolute;inset:0;pointer-events:auto;display:none;align-items:center;justify-content:center;background:rgba(5,6,9,.72);}');
  parts.push('#screenMsgOverlay .box,#askInputOverlay .box{background:#161922;border:1px solid #2a2f3d;border-radius:10px;padding:20px 26px;max-width:460px;width:90%;color:#e8e8ee;}');
  parts.push('#screenMsgOverlay .box p,#askInputOverlay .box p{margin:0 0 10px;font-size:13px;line-height:1.5;}');
  parts.push('#screenMsgOverlay .box .sub,#askInputOverlay .box .sub{margin-top:12px;font-size:11px;color:#9aa0ae;}');
  parts.push('#screenMsgOverlay .box .actBtn,#askInputOverlay .box .actBtn{margin-top:0;padding:9px 18px;border-radius:6px;border:1px solid rgba(255,255,255,.3);background:rgba(79,140,255,.88);color:#fff;font-size:13px;font-weight:600;cursor:pointer;}');
  parts.push('#askInputOverlay .box .small{padding:9px 10px;font-size:12px;border-radius:6px;border:1px solid rgba(255,255,255,.3);background:rgba(255,255,255,.08);color:#e8e8ee;cursor:pointer;}');
  parts.push('#askInputOverlay .box .flexRow{display:flex;gap:8px;align-items:center;}');
  parts.push('#touchJoystick{position:absolute;left:26px;bottom:26px;width:112px;height:112px;border-radius:50%;background:rgba(255,255,255,.08);border:2px solid rgba(255,255,255,.28);pointer-events:auto;touch-action:none;display:none;}');
  parts.push('#touchJoystickKnob{position:absolute;left:50%;top:50%;width:46px;height:46px;margin:-23px 0 0 -23px;border-radius:50%;background:rgba(255,255,255,.38);border:2px solid rgba(255,255,255,.65);}');
  parts.push('#touchInteractBtn{position:absolute;right:30px;bottom:36px;width:66px;height:66px;border-radius:50%;background:rgba(79,140,255,.88);color:#fff;border:2px solid rgba(255,255,255,.65);font-size:14px;font-weight:700;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;display:none;}');
  parts.push('#touchJumpBtn{position:absolute;right:26px;bottom:118px;width:58px;height:58px;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;border:2px solid rgba(255,255,255,.5);font-size:10px;font-weight:700;letter-spacing:.03em;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;display:none;}');
  parts.push('#touchShootBtn{position:absolute;right:28px;bottom:188px;width:54px;height:54px;border-radius:50%;background:rgba(200,60,50,.85);color:#fff;border:2px solid rgba(255,255,255,.6);font-size:18px;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;display:none;}');
  parts.push('#touchViewBtn{position:absolute;top:14px;right:14px;width:38px;height:38px;border-radius:50%;background:rgba(10,11,15,.7);color:#fff;border:1px solid rgba(255,255,255,.35);font-size:16px;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;display:none;}');
  parts.push('#touchDroneBtn{position:absolute;left:26px;top:14px;width:42px;height:42px;border-radius:50%;background:rgba(10,11,15,.7);color:#fff;border:1px solid rgba(255,255,255,.35);font-size:16px;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;opacity:.55;display:none;}');
  parts.push('#touchDroneBtn.activo{background:rgba(60,140,220,.85);border-color:rgba(255,255,255,.75);opacity:1;}');
  parts.push('#touchDroneDownBtn{position:absolute;right:26px;bottom:190px;width:42px;height:42px;border-radius:50%;background:rgba(10,11,15,.7);color:#fff;border:1px solid rgba(255,255,255,.35);font-size:16px;pointer-events:auto;touch-action:none;align-items:center;justify-content:center;display:none;}');
  parts.push('#nightTintOverlay{position:absolute;inset:0;background:#0a1030;opacity:0;pointer-events:none;mix-blend-mode:multiply;transition:opacity .3s linear;}');
  parts.push('</style></head><body>');
  parts.push('<canvas id="gcanvas"></canvas>');
  parts.push('<div id="nightTintOverlay"></div>');
  parts.push('<div id="hud">');
  parts.push('<div class="crosshair"></div>');
  parts.push('<div id="feed"></div>');
  parts.push('<div id="score">Puntuacion: 0</div>');
  parts.push('<div id="interactPrompt"></div>');
  parts.push('<div id="shotPrompt"></div>');
  parts.push('<div id="constellationPrompt"></div>');
  parts.push('<div id="cameraPathCaption"></div>');
  parts.push('<div id="interactPanel"></div>');
  parts.push('<div id="screenMsgOverlay"></div>');
  parts.push('<div id="askInputOverlay"></div>');
  parts.push('<div class="instructions" id="playInstructions">WASD / flechas: moverse (las flechas tambien giran) - raton: mirar - Mayus: correr - Espacio: saltar - E: interactuar - F: disparar - V: 1a/3a persona - C: modo dron (vista libre) - R: reiniciar</div>');
  parts.push('<div id="touchJoystick"><div id="touchJoystickKnob"></div></div>');
  parts.push('<button type="button" id="touchJumpBtn">SALTAR</button>');
  parts.push('<button type="button" id="touchInteractBtn">E</button>');
  parts.push('<button type="button" id="touchShootBtn">&#127919;</button>');
  parts.push('<button type="button" id="touchViewBtn" title="Cambiar 1a/3a persona">&#128065;</button>');
  parts.push('<button type="button" id="touchDroneBtn" title="Modo dron (vista libre, sin jugar)">&#128760;</button>');
  parts.push('<button type="button" id="touchDroneDownBtn" title="Bajar">&#11015;</button>');
  parts.push('<div id="clickToStart"><div>Clic para empezar a jugar</div><div style="font-size:11px;color:#9aa0ae;">simulacion generada con Don Claude 3D - no sustituye una evaluacion de riesgos real</div></div>');
  parts.push('<div id="loadingMsg">Cargando escenario...</div>');
  parts.push('</div>');
  parts.push('<script type="importmap">');
  parts.push('{"imports":{"three":"https://unpkg.com/three@0.160.0/build/three.module.js","three/addons/":"https://unpkg.com/three@0.160.0/examples/jsm/"}}');
  parts.push('</' + 'script>');
  parts.push('<script type="module">');
  parts.push(runtimeSrc);
  parts.push('</' + 'script>');
  parts.push('</body></html>');
  return parts.join('\n');
}

function exportStandaloneGame() {
  if (!findCharacterRecord()) { alertBox('Añade un objeto marcado como "Personaje (detector)" en Colisionador para poder exportar un videojuego jugable.', "info"); return; }
  const project = serializeProjectData();
  const html = buildStandaloneGameHtml(project);
  const blob = new Blob([html], { type: "text/html" });
  downloadBlob(blob, "videojuego-don-claude-" + Date.now() + ".html");
  logInfo("Videojuego exportado: un .html independiente y jugable, sin este editor. Ábrelo con doble clic.");
}
document.getElementById("btnExportGame").addEventListener("click", exportStandaloneGame);

// Recorre TODAS las acciones de todos los objetos (las de la lista normal, la de interactuar y las
// de cada opción de una decisión), incluyendo cadenas ("next") y paralelas, buscando "target" que
// apunten a un id que ya no existe -- rastro típico de haber borrado y vuelto a crear un objeto sin
// que las acciones de OTROS objetos que lo señalaban se actualizaran (se quedan "colgadas": en vez
// de mover al objetivo correcto acaban aplicándose sobre quien disparó la acción, en silencio).
function findBrokenActionReferences() {
  const problemas = [];
  function revisar(nombreDueno, a) {
    if (!a) return;
    if (a.target && a.target !== "self" && a.target !== "player" && a.target !== "__group__" && !sceneObjects.has(a.target)) {
      problemas.push(nombreDueno);
    }
    if (a.next) revisar(nombreDueno, a.next);
    (a.parallel || []).forEach((pa) => revisar(nombreDueno, pa));
  }
  sceneObjects.forEach((rec) => {
    (rec.actions || []).forEach((a) => revisar(rec.name, a));
    if (rec.interactive) {
      revisar(rec.name, rec.interactive.onInteractAction);
      (rec.interactive.choices || []).forEach((c) => revisar(rec.name, c.action));
    }
  });
  return Array.from(new Set(problemas));
}
function importProject(project) {
  clearAllObjects();
  let pending = 0, done = 0;
  // Devuelve un Promise que se resuelve cuando TODOS los objetos (incluidos los .glb, que se
  // decodifican de forma asíncrona vía gltfLoader.parse) ya están en sceneObjects -- antes,
  // quien llamaba a importProject() no tenía forma de saber cuándo había terminado de verdad,
  // así que un código como "cargar el proyecto de la sala y luego comprobar si hay un Personaje
  // para entrar en Modo jugar" podía ejecutarse ANTES de que un personaje importado como .glb
  // (p.ej. CesiumMan) hubiera terminado de decodificarse -- findCharacterRecord() no lo
  // encontraba (aún no estaba en sceneObjects) y se entraba en modo "solo mirar" por error,
  // aunque el personaje sí existiera en el proyecto. Quien no necesite esperar puede seguir
  // llamando a importProject() sin más, como siempre; el valor de retorno es opcional.
  let resolverListo;
  const listo = new Promise((resolve) => { resolverListo = resolve; });
  const finish = () => {
    recomputeTimelineDuration(); renderHierarchy(); selectObject(null);
    logInfo("Proyecto cargado: " + project.objects.length + " objeto(s).");
    const rotas = findBrokenActionReferences();
    if (rotas.length) {
      alertBox('⚠️ ' + rotas.length + ' objeto(s) tienen una acción que apunta a otro objeto que ya no existe (probablemente borrado y vuelto a crear): ' + rotas.join(", ") + '. Esas acciones concretas no harán nada hasta que las revises (botón 🔗/🎬 en sus propiedades).', "warn");
    }
    resolverListo();
  };
  project.objects.forEach((o) => {
    if (o.kind === "gltf" && o.gltfBase64) {
      pending++;
      gltfLoader.parse(base64ToArrayBuffer(o.gltfBase64), "", (gltf) => {
        const inner = gltf.scene || gltf.scenes[0];
        inner.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
        const group = new THREE.Group(); group.add(inner);
        const clips = gltf.animations || [];
        const mixer = clips.length ? new THREE.AnimationMixer(inner) : null;
        applyImportedObject(o, group, collectGltfColorMaterials(inner), mixer, clips, o.gltfBase64, o.gltfFileName);
        done++; if (done === pending) finish();
      }, () => { done++; if (done === pending) finish(); });
    } else if (o.kind === "image" && o.imageBase64) {
      pending++;
      buildImagePlaneObject(o.imageBase64, null, (built) => {
        if (built) applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
        done++; if (done === pending) finish();
      });
    } else if (o.kind === "video" && o.videoBase64) {
      pending++;
      buildVideoPlaneObject(o.videoBase64, null, (built) => {
        if (built) applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null, built.videoEl);
        done++; if (done === pending) finish();
      });
    } else if (o.kind === "text3d") {
      const t3 = o.text3d || { text: "Texto", color: "#ffffff", size: 1 };
      const built = buildText3DObject(t3.text, t3.color, t3.size, t3.boxWidth);
      applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
    } else if (o.kind === "extrude" && o.extrudeData) {
      const built = buildExtrudeObject(o.extrudeData);
      applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
    } else if (o.kind === "primitive") {
      const built = createPrimitive(o.primitiveType);
      applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
    } else if (o.kind === "prefab") {
      const built = createPrefab(o.prefabType);
      applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
    } else if (o.kind === "light") {
      const built = buildLightObject(o.lightData);
      applyImportedObject(o, built.object3D, [], null, [], null, null);
    } else if (o.kind === "camerapath") {
      applyImportedObject(o, new THREE.Group(), [], null, [], null, null);
    } else if (o.kind === "weather") {
      const built = buildWeatherObject(o.weatherData);
      applyImportedObject(o, built.object3D, built.colorMaterials, null, [], null, null);
    }
  });
  if (pending === 0) finish();
  if (project.camera) {
    camera.position.fromArray(project.camera.position);
    orbitControls.target.fromArray(project.camera.target);
  }
  // OJO: clonar aquí, NO asignar la referencia tal cual. "project" puede ser (o compartir campos
  // con) salaProyectoBase -- la "base" que se guarda para comparar en la fusión de guardados de
  // sala (ver docblock de multi/proyecto.php). Si sceneEnvironment/projectAudio fueran el MISMO
  // objeto que project.environment/project.audio, cada cambio del usuario en el panel (que muta
  // sceneEnvironment.bgColor, .nightBgColor, .skyManualDate... en sitio) se filtraba también a la
  // "base" antes de guardar -- así, al comparar base vs local para decidir qué fusionar, ambos
  // salían idénticos (porque eran literalmente el mismo objeto) y el guardado creía que el usuario
  // "no había tocado" el entorno, perdiendo silenciosamente sus cambios de color día/noche o de
  // fecha de la bóveda celeste al sobrescribir una sala ya compartida. Clonar rompe ese alias.
  projectAudio = structuredClone(project.audio) || { musicBase64: null, musicFileName: null, volume: 0.5 };
  document.getElementById("musicVolume").value = projectAudio.volume !== undefined ? projectAudio.volume : 0.5;
  updateMusicUI();
  sceneEnvironment = structuredClone(project.environment) || { bgColor: "#0a0b0f", groundColor: "#1c2029", horizonBase64: null, horizonFileName: null, groundSize: 40, fogFar: 60 };
  if (!sceneEnvironment.groundSize) sceneEnvironment.groundSize = 40; // compatibilidad con proyectos guardados antes de este campo
  if (!sceneEnvironment.fogFar) sceneEnvironment.fogFar = 60; // ídem, para proyectos guardados antes de la niebla configurable
  if (!sceneEnvironment.sunColor) sceneEnvironment.sunColor = "#ffffff"; // ídem, para proyectos guardados antes del Sol configurable
  if (sceneEnvironment.sunIntensity == null) sceneEnvironment.sunIntensity = 1.4;
  if (sceneEnvironment.sunElevationDeg == null) sceneEnvironment.sunElevationDeg = 54;
  if (sceneEnvironment.sunAzimuthDeg == null) sceneEnvironment.sunAzimuthDeg = 56;
  if (!sceneEnvironment.sunMode) sceneEnvironment.sunMode = "manual"; // ídem, para proyectos guardados antes del ciclo día/noche
  if (!sceneEnvironment.dayDurationMin) sceneEnvironment.dayDurationMin = 10;
  if (sceneEnvironment.latitudeDeg == null) sceneEnvironment.latitudeDeg = 40;
  if (sceneEnvironment.sunOrientationOffsetDeg == null) sceneEnvironment.sunOrientationOffsetDeg = 0; // ídem, para proyectos guardados antes de este control
  if (sceneEnvironment.nightSkyEnabled == null) sceneEnvironment.nightSkyEnabled = false; // idem, para proyectos guardados antes de la boveda celeste
  if (!sceneEnvironment.skyDateMode) sceneEnvironment.skyDateMode = "auto";
  if (sceneEnvironment.skyLongitudeDeg == null) sceneEnvironment.skyLongitudeDeg = -3.7;
  if (sceneEnvironment.skyUtcOffsetHours == null) sceneEnvironment.skyUtcOffsetHours = 1;
  if (!sceneEnvironment.nightBgColor) sceneEnvironment.nightBgColor = "#050912";
  dayCycleClock = 0; dayCycleTotalSec = 0;
  resizeGroundAndBounds();
  if (horizonTexture) { horizonTexture.dispose(); horizonTexture = null; }
  if (nightSkyMoonTexture) { nightSkyMoonTexture.dispose(); nightSkyMoonTexture = null; }
  if (nightSkyMoonMesh) { nightSkyMoonMesh.material.map = nightSkyMoonFallbackTexture; nightSkyMoonMesh.material.needsUpdate = true; }
  if (sceneEnvironment.moonTextureBase64) {
    const moonImg = new Image();
    moonImg.onload = () => { const tex = new THREE.Texture(moonImg); tex.needsUpdate = true; nightSkyMoonTexture = tex; if (nightSkyMoonMesh) { nightSkyMoonMesh.material.map = tex; nightSkyMoonMesh.material.needsUpdate = true; } };
    moonImg.src = sceneEnvironment.moonTextureBase64;
  }
  nightSkyLastCalcAt = -999;
  if (sceneEnvironment.horizonBase64) {
    const img = new Image();
    img.onload = () => { horizonTexture = new THREE.Texture(img); horizonTexture.needsUpdate = true; applyEnvironment(); };
    img.src = sceneEnvironment.horizonBase64;
  }
  applyEnvironment();
  updateEnvironmentUI();
  objectGroups = new Map();
  (project.groups || []).forEach((g) => { objectGroups.set(g.id, { id: g.id, name: g.name, memberIds: g.memberIds.slice() }); });
  return listo;
}

function applyImportedObject(o, object3D, colorMaterials, mixer, clips, gltfBase64, gltfFileName, videoEl) {
  object3D.position.fromArray(o.transform.position);
  object3D.quaternion.fromArray(o.transform.quaternion);
  object3D.scale.fromArray(o.transform.scale);
  if (o.colorHex && colorMaterials.length) colorMaterials.forEach((m) => m.color.set(o.colorHex));
  const opacidadImportada = (o.opacity != null ? o.opacity : 1);
  if (colorMaterials.length) colorMaterials.forEach((m) => { m.opacity = opacidadImportada; m.visible = opacidadImportada > 0.01; });
  scene.add(object3D);
  const rec = newRecord({
    id: o.id, name: o.name, kind: o.kind, primitiveType: o.primitiveType, prefabType: o.prefabType,
    object3D, colorMaterials, opacity: opacidadImportada, collider: o.collider, facingOffsetDeg: o.facingOffsetDeg || 0, actions: o.actions || [],
    interactive: o.interactive || { enabled: false, kind: "text", radius: 2, prompt: "Interactuar", text: "", url: "", choices: [], onInteractAction: null, onShotAction: null },
    mixer, clips, gltfBase64, gltfFileName,
    text3d: o.text3d || null, imageBase64: o.imageBase64 || null, imageFileName: o.imageFileName || null,
    videoBase64: o.videoBase64 || null, videoFileName: o.videoFileName || null, videoEl: videoEl || null,
    extrudeData: o.extrudeData || null,
    lightData: o.lightData || null,
    cameraPathData: o.cameraPathData || null,
    weatherData: o.weatherData || null,
    groupId: o.groupId || null,
    textureRepeatX: o.textureRepeatX || 1,
    textureRepeatY: o.textureRepeatY || 1,
  });
  sceneObjects.set(rec.id, rec); // aseguramos id original
  // Objetos de luz: recuperamos las referencias directas al THREE.PointLight y a la esfera-gizmo
  // que buildLightObject() dejó guardadas en object3D.userData, para poder editarlos en vivo desde
  // el panel de propiedades sin tener que volver a recorrer el grupo cada vez.
  if (object3D.userData.__lightObj) {
    rec.__lightObj = object3D.userData.__lightObj;
    rec.__gizmoMesh = object3D.userData.__gizmoMesh;
    rec.__gizmoMat = object3D.userData.__gizmoMat;
  }
  if (rec.kind === "camerapath") rebuildCameraPathVisual(rec);
  if (o.textureBase64) aplicarTexturaAPieza(rec, o.textureBase64);
  recomputeCheckpoints(rec);
}

document.getElementById("btnImportProjectTrigger").addEventListener("click", () => document.getElementById("importProjectInput").click());
document.getElementById("importProjectInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!data.don_claude_3d_project) { alertBox("Ese archivo no es un proyecto de Don Claude 3D.", "warn"); return; }
      pushUndo();
      importProject(data);
    } catch (err) { alertBox("No se pudo leer el proyecto: " + err.message, "warn"); }
  };
  reader.readAsText(file);
  e.target.value = "";
});

document.getElementById("btnHelp").addEventListener("click", () => { document.getElementById("helpModal").style.display = "flex"; });
document.getElementById("btnCloseHelp").addEventListener("click", () => { document.getElementById("helpModal").style.display = "none"; });

document.getElementById("btnResetScene").addEventListener("click", () => {
  if (!sceneOrder.length) return;
  if (!confirm("¿Vaciar toda la escena?")) return;
  pushUndo();
  clearAllObjects();
  recomputeTimelineDuration();
});

/* =========================================================================
   ESCENARIO DE EJEMPLO: UN DÍA DE TRABAJO
   ========================================================================= */
function loadExampleScenario() {
  if (sceneOrder.length && !confirm("Esto reemplaza la escena actual por el escenario de ejemplo. ¿Continuar?")) return;
  pushUndo();
  clearAllObjects();

  addPrefabToScene("mesa", { x: -3, y: 0, z: 2 });
  addPrefabToScene("silla", { x: -3, y: 0, z: 2.6 });
  addPrefabToScene("valla", { x: 5, y: 0, z: -3 });
  addPrefabToScene("extintor", { x: -5, y: 0, z: -3 });

  const worker = addPrefabToScene("personaje", { x: -3, y: 0, z: 4.5 });
  worker.name = "Trabajador";

  tplPlacementIndex = 0;
  document.getElementById("assistGuideChar").checked = true;
  applyTemplate("resbalon");
  applyTemplate("electrico");
  applyTemplate("caida");

  // Vuelta al punto de partida al final de la jornada simulada
  worker.actions.push({ type: "moveTo", to: { x: -3, y: 0, z: 4.5 }, duration: 2.5, ease: "smooth" });
  recomputeCheckpoints(worker);

  recomputeTimelineDuration();
  renderHierarchy();
  selectObject(worker.id);
  logInfo('Escenario de ejemplo cargado. Pulsa "▶ Reproducir" para ver al trabajador recorrer los tres riesgos, o "⏺ Grabar película" para guardarlo como vídeo.');
}
document.getElementById("btnExampleScene").addEventListener("click", loadExampleScenario);

/* =========================================================================
   TABS Y AVISOS
   ========================================================================= */
document.getElementById("tabBtnLib").addEventListener("click", () => setTab("lib"));
document.getElementById("tabBtnAsst").addEventListener("click", () => setTab("asst"));
function setTab(name) {
  document.getElementById("tabBtnLib").classList.toggle("active", name === "lib");
  document.getElementById("tabBtnAsst").classList.toggle("active", name === "asst");
  document.getElementById("tabLib").classList.toggle("active", name === "lib");
  document.getElementById("tabAsst").classList.toggle("active", name === "asst");
}

document.querySelectorAll("[data-prim]").forEach((btn) => btn.addEventListener("click", () => { pushUndo(); addPrimitiveToScene(btn.dataset.prim); }));
document.getElementById("btnAddLight").addEventListener("click", () => { pushUndo(); addLightToScene(); });
document.querySelectorAll("[data-weather]").forEach((btn) => btn.addEventListener("click", () => { pushUndo(); addWeatherToScene(btn.dataset.weather); }));
document.getElementById("btnAddCameraPath").addEventListener("click", () => { pushUndo(); addCameraPathToScene(); });
document.querySelectorAll("[data-prefab]").forEach((btn) => btn.addEventListener("click", () => { pushUndo(); addPrefabToScene(btn.dataset.prefab); }));

let alertTimer = null;
function alertBox(msg, kind) {
  const existing = document.getElementById("floatingAlert");
  if (existing) existing.remove();
  const div = document.createElement("div");
  div.id = "floatingAlert";
  div.className = "alert " + (kind || "info");
  div.style.position = "fixed"; div.style.top = "54px"; div.style.right = "16px"; div.style.zIndex = "999"; div.style.maxWidth = "360px";
  div.textContent = msg;
  document.body.appendChild(div);
  clearTimeout(alertTimer);
  alertTimer = setTimeout(() => div.remove(), 6000);
}
function logInfo(msg) { alertBox(msg, "ok"); }

/* =========================================================================
   INICIALIZACIÓN
   ========================================================================= */
renderTemplateList();
renderHierarchy();
renderProps();
resizeRenderer();
recomputeTimelineDuration();
cargarProyectoDesdeEnlaceSiHay();
requestAnimationFrame(tick);
