import * as THREE from 'three';

function deg2rad(d){ return d*Math.PI/180; }
function rad2deg(r){ return r*180/Math.PI; }

function makeRec(rotDeg) {
  const obj = new THREE.Object3D();
  obj.quaternion.setFromEuler(new THREE.Euler(0, deg2rad(rotDeg), 0));
  obj.userData.__origin = { pos: obj.position.clone(), quat: obj.quaternion.clone() };
  return { object3D: obj, __oneShot: null };
}

let now = 1000; // reloj simulado

function triggerOneShotAction(rec, action, batchStartedAt) {
  if (!action || !action.type) return;
  const startedAt = batchStartedAt || now;
  if (action.type === "for") {
    const count = action.count;
    const body = action.body;
    if (body && (body.type === "moveTo" || body.type === "rotateTo") && body.relative && body.to && count > 0) {
      let headStep = null, prevStep = null;
      for (let step = 1; step <= count; step++) {
        const stepAction = { type: body.type, target: body.target, relative: true, ease: body.ease,
          to: { x: body.to.x*step, y: body.to.y*step, z: body.to.z*step }, duration: body.duration };
        if (!headStep) headStep = stepAction;
        if (prevStep) prevStep.next = stepAction;
        prevStep = stepAction;
      }
      prevStep.next = body.next || null;
      prevStep.parallel = (action.parallel||[]).slice();
      if (action.next) prevStep.parallel.push(action.next);
      triggerOneShotAction(rec, headStep, startedAt);
    }
    return;
  }
  const targetRec = rec;
  const duration = Math.max(50, (action.duration || 1) * 1000);
  const existingOS = targetRec.__oneShot;
  const mergeable = existingOS && existingOS.startedAt === startedAt;
  const fromQuat = mergeable ? existingOS.fromQuat.clone() : targetRec.object3D.quaternion.clone();
  let toQuat = mergeable ? existingOS.toQuat.clone() : fromQuat.clone();
  if (action.relative && action.type === "rotateTo" && action.to) {
    const originQuat = targetRec.object3D.userData.__origin.quat;
    const oe = new THREE.Euler().setFromQuaternion(originQuat);
    const ne = new THREE.Euler(oe.x + deg2rad(action.to.x), oe.y + deg2rad(action.to.y), oe.z + deg2rad(action.to.z));
    toQuat = new THREE.Quaternion().setFromEuler(ne);
  }
  targetRec.__oneShot = { startedAt, duration, fromQuat, toQuat, nextAction: action.next || null, chainRec: rec };
}

// Simula el bucle de actualizacion: cuando "now" pasa el fin de un tween, aplica la orientacion final
// y dispara nextAction (igual que hace updateOneShots en el motor real).
function tick(rec) {
  const os = rec.__oneShot;
  if (!os) return false;
  if (now - os.startedAt >= os.duration) {
    rec.object3D.quaternion.copy(os.toQuat);
    rec.__oneShot = null;
    if (os.nextAction) triggerOneShotAction(os.chainRec, os.nextAction);
    return true;
  }
  return false;
}

const rec = makeRec(0);
triggerOneShotAction(rec, { type: "for", count: 5, body: { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 2 } }, now);

// Avanza el reloj simulado en pasos de 2.1s (algo mas que la duracion de cada tramo) y cuenta cuantos "hops" completos hubo.
let hops = 0;
for (let iter = 0; iter < 20 && rec.__oneShot; iter++) {
  now += 2100;
  if (tick(rec)) hops++;
}
const finalDeg = rad2deg(new THREE.Euler().setFromQuaternion(rec.object3D.quaternion).y);
console.log("Tramos completados:", hops, "(esperado: 5)");
console.log("Orientacion final:", finalDeg.toFixed(1), "grados (90 o -90 son equivalentes a 450 -- lo que importa es que dio 5 tramos)");
console.log(hops === 5 ? "OK: se encadenaron y completaron 5 tramos reales, uno tras otro" : "FAIL");

// Verifica tambien que cada salto individual fue realmente +90 (direccion correcta, no rebote)
const rec2 = makeRec(0);
triggerOneShotAction(rec2, { type: "for", count: 3, body: { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 1 } }, now);
let angles = [];
for (let iter = 0; iter < 10 && rec2.__oneShot; iter++) {
  now += 1100;
  if (tick(rec2)) angles.push(rad2deg(new THREE.Euler().setFromQuaternion(rec2.object3D.quaternion).y).toFixed(1));
}
console.log("Angulos tras cada tramo (3 pasos de +90):", angles.join(", "));
