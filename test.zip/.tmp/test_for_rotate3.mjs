import * as THREE from 'three';
function deg2rad(d){ return d*Math.PI/180; }

function makeRec(rotDeg) {
  const obj = new THREE.Object3D();
  obj.quaternion.setFromEuler(new THREE.Euler(0, deg2rad(rotDeg), 0));
  obj.userData.__origin = { pos: obj.position.clone(), quat: obj.quaternion.clone() };
  return { object3D: obj, __oneShot: null };
}
let now = 1000;
function triggerOneShotAction(rec, action, batchStartedAt) {
  if (!action || !action.type) return;
  const startedAt = batchStartedAt || now;
  if (action.type === "for") {
    const count = action.count, body = action.body;
    if (body && body.relative && body.to && count > 0) {
      let headStep = null, prevStep = null;
      for (let step = 1; step <= count; step++) {
        const stepAction = { type: body.type, target: body.target, relative: true, ease: body.ease,
          to: { x: body.to.x*step, y: body.to.y*step, z: body.to.z*step }, duration: body.duration };
        if (!headStep) headStep = stepAction;
        if (prevStep) prevStep.next = stepAction;
        prevStep = stepAction;
      }
      triggerOneShotAction(rec, headStep, startedAt);
    }
    return;
  }
  const targetRec = rec;
  const duration = Math.max(50, (action.duration || 1) * 1000);
  const fromQuat = targetRec.object3D.quaternion.clone();
  let toQuat = fromQuat.clone();
  if (action.relative && action.to) {
    const originQuat = targetRec.object3D.userData.__origin.quat;
    const oe = new THREE.Euler().setFromQuaternion(originQuat);
    const ne = new THREE.Euler(oe.x + deg2rad(action.to.x), oe.y + deg2rad(action.to.y), oe.z + deg2rad(action.to.z));
    toQuat = new THREE.Quaternion().setFromEuler(ne);
  }
  targetRec.__oneShot = { startedAt, duration, fromQuat, toQuat, nextAction: action.next || null, chainRec: rec };
}
function tick(rec) {
  const os = rec.__oneShot;
  if (!os) return false;
  if (now - os.startedAt >= os.duration) {
    rec.object3D.quaternion.copy(os.toQuat);
    rec.__oneShot = null;
    if (os.nextAction) triggerOneShotAction(os.chainRec, os.nextAction);
    return true;
  }
  return false;
}
const rec = makeRec(0);
const prevQ = new THREE.Quaternion();
let cumulativeDeg = 0;
triggerOneShotAction(rec, { type: "for", count: 5, body: { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 2 } }, now);
for (let iter = 0; iter < 20 && rec.__oneShot; iter++) {
  now += 2100;
  if (tick(rec)) {
    const stepAngleRad = prevQ.angleTo(rec.object3D.quaternion); // angulo (0..pi) entre orientacion anterior y actual
    cumulativeDeg += stepAngleRad * 180 / Math.PI;
    prevQ.copy(rec.object3D.quaternion);
  }
}
console.log("Suma de angulos de cada salto (magnitud, sin signo):", cumulativeDeg.toFixed(1), "grados (esperado: 5*90=450, dentro de margen por ambiguedad en 180)");
