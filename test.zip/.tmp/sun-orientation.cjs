function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }

function deg2rad(d){ return (d*Math.PI)/180; }

function sunPositionFromAngles(elevationDeg, azimuthDeg, radius) {
  const elev = deg2rad(elevationDeg), azim = deg2rad(azimuthDeg);
  const r = radius || 12;
  return {
    x: r * Math.cos(elev) * Math.sin(azim),
    y: r * Math.sin(elev),
    z: r * Math.cos(elev) * Math.cos(azim),
  };
}

function sunAnglesFromHour(hour) {
  const angle = (2 * Math.PI * (hour - 6)) / 24;
  const elevationDeg = 80 * Math.sin(angle);
  const azimuthDeg = ((hour / 24) * 360) % 360;
  const intensityFactor = clamp((elevationDeg + 10) / 20, 0.08, 1);
  return { elevationDeg, azimuthDeg, intensityFactor };
}

function sunAnglesFromRealDateTime(date, latitudeDeg) {
  const lat = deg2rad(latitudeDeg != null ? latitudeDeg : 40);
  const startOfYear = new Date(date.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((date - startOfYear) / 86400000);
  const decl = deg2rad(23.44 * Math.sin(deg2rad((360 / 365) * (dayOfYear - 81))));
  const hour = date.getHours() + date.getMinutes() / 60 + date.getSeconds() / 3600;
  const hourAngle = deg2rad(15 * (hour - 12));
  const elevRad = Math.asin(Math.sin(lat) * Math.sin(decl) + Math.cos(lat) * Math.cos(decl) * Math.cos(hourAngle));
  const elevationDeg = (elevRad * 180) / Math.PI;
  const azimuthDeg = ((hour / 24) * 360) % 360; // giro simple a lo largo del día -- no hace falta precisión geográfica en una escena ficticia
  const intensityFactor = clamp((elevationDeg + 10) / 20, 0.08, 1);
  return { elevationDeg, azimuthDeg, intensityFactor };
}

function computeSunHourOfDay(dt) {
  if (sceneEnvironment.sunMode === "realtime") {
    const now = new Date();
    return now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600;
  }
  if (sceneEnvironment.sunMode === "cycle") {
    dayCycleClock += dt;
    dayCycleTotalSec += dt;
    const dayLenSec = Math.max(10, (sceneEnvironment.dayDurationMin || 10) * 60);
    dayCycleClock = dayCycleClock % dayLenSec;
    return (dayCycleClock / dayLenSec) * 24;
  }
  return null;
}

function nightTintFactorFromElevation(elevationDeg) {
  return clamp((10 - elevationDeg) / 30, 0, 1);
}

function lerpColorHex(hexA, hexB, t) {
  const a = parseInt((hexA || "#000000").replace('#', ''), 16), b = parseInt((hexB || "#000000").replace('#', ''), 16);
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  const r = Math.round(ar + (br - ar) * t), g = Math.round(ag + (bg - ag) * t), bl = Math.round(ab + (bb - ab) * t);
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + bl).toString(16).slice(1);
}

function applyNightTint(elevationDeg) {
  const factor = nightTintFactorFromElevation(elevationDeg);
  const el = document.getElementById("nightTintOverlay");
  if (el) el.style.opacity = String(factor * 0.55);
  // El color de fondo/niebla también vira hacia un azul profundo de noche (no solo se oscurece
  // con el velo de arriba) -- salvo que haya una imagen de horizonte fija, que no tiene un día/
  // noche propio y se dejaría rara mezclada con un fondo que cambia de color detrás.
  if (!sceneEnvironment.horizonBase64) {
    const blended = lerpColorHex(sceneEnvironment.bgColor || "#0a0b0f", sceneEnvironment.nightBgColor || "#050912", factor);
    scene.background = new THREE.Color(blended);
    scene.fog.color.set(blended);
  }
}

function updateSunCycle(dt) {
  if (!sceneEnvironment.sunMode || sceneEnvironment.sunMode === "manual") return;
  let result;
  if (sceneEnvironment.sunMode === "realtime") {
    result = sunAnglesFromRealDateTime(new Date(), sceneEnvironment.latitudeDeg);
  } else {
    const hour = computeSunHourOfDay(dt);
    if (hour == null) return;
    result = sunAnglesFromHour(hour);
  }
  const { elevationDeg, intensityFactor } = result;
  // Orientación del escenario: en ciclo/hora real el acimut lo marca el reloj, no un slider directo
  // (a diferencia del modo manual) -- este desfase gira ese recorrido entero para elegir por qué
  // lado del escenario CONSTRUIDO amanece, sin tener que rotar cada objeto.
  const azimuthDeg = (result.azimuthDeg + (sceneEnvironment.sunOrientationOffsetDeg || 0)) % 360;
  dirLight.color.set(sceneEnvironment.sunColor || "#ffffff");
  dirLight.intensity = (sceneEnvironment.sunIntensity != null ? sceneEnvironment.sunIntensity : 1.4) * intensityFactor;
  const sunPos = sunPositionFromAngles(elevationDeg, azimuthDeg);
  dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);
  applyNightTint(elevationDeg);
}

module.exports = { updateSunCycle, sunPositionFromAngles };