
var PROJECT = {"objects":[{"id":"player","name":"Jugador","kind":"primitive","primitiveType":"box","colorHex":"#ffffff","opacity":1,"transform":{"position":[0,0,0],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"character","size":{"x":0.8,"y":1.6,"z":0.8},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":false,"kind":"text","radius":2,"prompt":"","text":"","url":"","choices":[],"onInteractAction":null,"onShotAction":null}},{"id":"target","name":"Objetivo","kind":"primitive","primitiveType":"box","colorHex":"#ff0000","opacity":1,"transform":{"position":[0,1.35,-10],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":1,"y":1,"z":1},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":false,"kind":"text","radius":2,"prompt":"","text":"","url":"","choices":[],"onInteractAction":null,"onShotAction":{"type":"fade","target":"self","to":0,"duration":0.2,"parallel":[]}}},{"id":"signEmpty","name":"Cartel vacio (solo dispara accion)","kind":"primitive","primitiveType":"box","colorHex":"#00ff00","opacity":1,"transform":{"position":[5,0,5],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":1,"y":1,"z":1},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":true,"kind":"text","radius":2,"prompt":"Interactuar","text":"","url":"","choices":[],"onInteractAction":{"type":"fade","target":"self","to":0.3,"duration":0.05,"parallel":[]},"onShotAction":null}},{"id":"signWithText","name":"Cartel con texto (debe abrir panel)","kind":"primitive","primitiveType":"box","colorHex":"#0000ff","opacity":1,"transform":{"position":[-5,0,5],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":1,"y":1,"z":1},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":true,"kind":"text","radius":2,"prompt":"Leer","text":"Aviso de prueba","url":"","choices":[],"onInteractAction":null,"onShotAction":null}},{"id":"signAskInput","name":"Cartel con texto CUYA accion es Preguntar (no debe abrir panel de cartel)","kind":"primitive","primitiveType":"box","colorHex":"#ffaa00","opacity":1,"transform":{"position":[-8,0,5],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":1,"y":1,"z":1},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":true,"kind":"text","radius":2,"prompt":"Hablar","text":"Este texto NO deberia verse en un panel aparte","url":"","choices":[],"onInteractAction":{"type":"askInput","promptText":"Como te llamas?","varName":"nombreDesdeCartel","allowFile":false},"onShotAction":null}},{"id":"imgBoard","name":"Tablon (objeto Imagen de prueba)","kind":"image","imageBase64":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=","imageFileName":"placeholder.png","transform":{"position":[0,0,8],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":1,"y":1.5,"z":0.05},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":false,"kind":"text","radius":2,"prompt":"","text":"","url":"","choices":[],"onInteractAction":null,"onShotAction":null}},{"id":"rotuloVar","name":"Rotulo (objeto Texto 3D de prueba)","kind":"text3d","text3d":{"text":"Texto original","color":"#ffffff","size":1,"boxWidth":472},"transform":{"position":[3,0,8],"quaternion":[0,0,0,1],"scale":[1,1,1]},"collider":{"kind":"none","size":{"x":2,"y":1,"z":0.1},"riskLabel":""},"facingOffsetDeg":0,"actions":[],"interactive":{"enabled":false,"kind":"text","radius":2,"prompt":"","text":"","url":"","choices":[],"onInteractAction":null,"onShotAction":null}}],"camera":{"position":{"x":0,"y":1.6,"z":5},"target":{"x":0,"y":1.6,"z":0}},"audio":{},"environment":{"nightSkyEnabled":false,"skyDateMode":"auto","skyManualDate":"","skyManualTime":"","skyLongitudeDeg":-3.7,"skyUtcOffsetHours":1,"moonTextureBase64":null,"moonTextureFileName":null,"nightBgColor":"#050912"},"groups":[]};

var canvas = document.getElementById("gcanvas");
var renderer = { render: function(cam){ camera.updateMatrixWorld(true); scene.updateMatrixWorld(true); }, setSize: function(){}, setPixelRatio: function(){}, shadowMap: { enabled: false, type: null }, domElement: { style:{}, addEventListener: function(){} } };
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
var scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0b0f);
scene.fog = new THREE.Fog(0x0a0b0f, 20, 60);
var BASE_FOV = 60;
function computeFov(aspect, baseFov){
  if (aspect >= 1) return baseFov;
  var baseFovRad = THREE.MathUtils.degToRad(baseFov);
  var vFovRad = 2 * Math.atan(Math.tan(baseFovRad/2) / aspect);
  return Math.min(THREE.MathUtils.radToDeg(vFovRad), 100);
}
var camera = new THREE.PerspectiveCamera(BASE_FOV, window.innerWidth/window.innerHeight, 0.1, 500);
camera.fov = computeFov(camera.aspect, BASE_FOV); camera.updateProjectionMatrix();
var hemi = new THREE.HemisphereLight(0xdfe8ff, 0x2a2416, 0.9); scene.add(hemi);
var dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
dirLight.position.set(6,10,4); dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048,2048);
dirLight.shadow.camera.left=-15; dirLight.shadow.camera.right=15; dirLight.shadow.camera.top=15; dirLight.shadow.camera.bottom=-15;
scene.add(dirLight);
var GROUND_SIZE = Math.max(10, (PROJECT.environment && PROJECT.environment.groundSize) || 40);
var SCENE_HALF_EXTENT = Math.max(5, (GROUND_SIZE/2) - 1);
var groundMat = new THREE.MeshStandardMaterial({color:0x1c2029, roughness:1});
var ground = new THREE.Mesh(new THREE.PlaneGeometry(GROUND_SIZE,GROUND_SIZE), groundMat);
ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
scene.add(new THREE.GridHelper(GROUND_SIZE,GROUND_SIZE,0x333947,0x21242e));
function resize(){ var w=window.innerWidth||1, h=window.innerHeight||1; renderer.setSize(w, h, false); camera.aspect = w/h; camera.fov = computeFov(camera.aspect, BASE_FOV); camera.updateProjectionMatrix(); }
function soltarTactilPorCambioDeOrientacion(){ touchLookId=null; resetTouchJoystick(); }
window.addEventListener("resize", resize);
window.addEventListener("orientationchange", function(){ soltarTactilPorCambioDeOrientacion(); setTimeout(resize,50); setTimeout(resize,300); });
if(window.visualViewport){ window.visualViewport.addEventListener("resize", function(){ soltarTactilPorCambioDeOrientacion(); resize(); }); }
resize();
function sunPositionFromAngles(elevationDeg, azimuthDeg, radius){
  var elev = deg2rad(elevationDeg), azim = deg2rad(azimuthDeg);
  var r = radius || 12;
  return { x: r*Math.cos(elev)*Math.sin(azim), y: r*Math.sin(elev), z: r*Math.cos(elev)*Math.cos(azim) };
}
function sunAnglesFromHour(hour){
  var angle = 2*Math.PI*(hour-6)/24;
  var elevationDeg = 80*Math.sin(angle);
  var azimuthDeg = (hour/24*360) % 360;
  var intensityFactor = clamp((elevationDeg+10)/20, 0.08, 1);
  return { elevationDeg: elevationDeg, azimuthDeg: azimuthDeg, intensityFactor: intensityFactor };
}
function sunAnglesFromRealDateTime(date, latitudeDeg){
  var lat = deg2rad(latitudeDeg != null ? latitudeDeg : 40);
  var startOfYear = new Date(date.getFullYear(), 0, 0);
  var dayOfYear = Math.floor((date - startOfYear) / 86400000);
  var decl = deg2rad(23.44 * Math.sin(deg2rad((360/365) * (dayOfYear - 81))));
  var hour = date.getHours() + date.getMinutes()/60 + date.getSeconds()/3600;
  var hourAngle = deg2rad(15 * (hour - 12));
  var elevRad = Math.asin(Math.sin(lat)*Math.sin(decl) + Math.cos(lat)*Math.cos(decl)*Math.cos(hourAngle));
  var elevationDeg = elevRad * 180 / Math.PI;
  var azimuthDeg = (hour/24*360) % 360;
  var intensityFactor = clamp((elevationDeg+10)/20, 0.08, 1);
  return { elevationDeg: elevationDeg, azimuthDeg: azimuthDeg, intensityFactor: intensityFactor };
}
var dayCycleClock = 0;
var dayCycleTotalSec = 0;
function computeSunHourOfDay(dt){
  if(PROJECT.environment && PROJECT.environment.sunMode === "realtime"){
    var now = new Date();
    return now.getHours() + now.getMinutes()/60 + now.getSeconds()/3600;
  }
  if(PROJECT.environment && PROJECT.environment.sunMode === "cycle"){
    dayCycleClock += dt;
    dayCycleTotalSec += dt;
    var dayLenSec = Math.max(10, (PROJECT.environment.dayDurationMin || 10) * 60);
    dayCycleClock = dayCycleClock % dayLenSec;
    return (dayCycleClock/dayLenSec) * 24;
  }
  return null;
}
function updateSunCycle(dt){
  var env = PROJECT.environment;
  if(!env || !env.sunMode || env.sunMode === "manual") return;
  var a;
  if(env.sunMode === "realtime"){
    a = sunAnglesFromRealDateTime(new Date(), env.latitudeDeg);
  } else {
    var hour = computeSunHourOfDay(dt);
    if(hour == null) return;
    a = sunAnglesFromHour(hour);
  }
  var azimuthDeg = (a.azimuthDeg + (env.sunOrientationOffsetDeg || 0)) % 360;
  dirLight.color.set(env.sunColor || "#ffffff");
  dirLight.intensity = (env.sunIntensity != null ? env.sunIntensity : 1.4) * a.intensityFactor;
  var sunPos = sunPositionFromAngles(a.elevationDeg, azimuthDeg);
  dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);
  applyNightTint(a.elevationDeg);
}
function nightTintFactorFromElevation(elevationDeg){ return clamp((10-elevationDeg)/30, 0, 1); }
function lerpColorHex(hexA, hexB, t){
  var a = parseInt((hexA || "#000000").replace("#",""), 16), b = parseInt((hexB || "#000000").replace("#",""), 16);
  var ar=(a>>16)&255, ag=(a>>8)&255, ab=a&255;
  var br=(b>>16)&255, bg=(b>>8)&255, bb=b&255;
  var r=Math.round(ar+(br-ar)*t), g=Math.round(ag+(bg-ag)*t), bl=Math.round(ab+(bb-ab)*t);
  return "#" + ((1<<24)+(r<<16)+(g<<8)+bl).toString(16).slice(1);
}
function applyNightTint(elevationDeg){
  var factor = nightTintFactorFromElevation(elevationDeg);
  var el = document.getElementById("nightTintOverlay");
  if(el) el.style.opacity = String(factor * 0.55);
  if(!PROJECT.environment.horizonBase64){
    var blended = lerpColorHex(PROJECT.environment.bgColor || "#0a0b0f", PROJECT.environment.nightBgColor || "#050912", factor);
    scene.background = new THREE.Color(blended);
    scene.fog.color.set(blended);
  }
}
function applyEnvironment(env){
  if(!env) return;
  if(env.horizonBase64){
    var img = new Image();
    img.onload = function(){ var tex = new THREE.Texture(img); tex.needsUpdate = true; scene.background = tex; };
    img.src = env.horizonBase64;
  } else {
    scene.background = new THREE.Color(env.bgColor || "#0a0b0f");
  }
  scene.fog.color.set(env.bgColor || "#0a0b0f");
  scene.fog.far = Math.max(10, env.fogFar || 60);
  scene.fog.near = scene.fog.far / 3;
  groundMat.color.set(env.groundColor || "#1c2029");
  dirLight.color.set(env.sunColor || "#ffffff");
  if(!env.sunMode || env.sunMode === "manual"){
    dirLight.intensity = env.sunIntensity != null ? env.sunIntensity : 1.4;
    var elevationDeg = env.sunElevationDeg != null ? env.sunElevationDeg : 54;
    var sunPos = sunPositionFromAngles(elevationDeg, env.sunAzimuthDeg != null ? env.sunAzimuthDeg : 56);
    dirLight.position.set(sunPos.x, sunPos.y, sunPos.z);
    applyNightTint(elevationDeg);
  }
}

function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
function deg2rad(d){ return d*Math.PI/180; }
function easeVal(p,kind){ if(kind==="smooth") return p*p*(3-2*p); return p; }
function lerp(a,b,p){ return a+(b-a)*p; }
function base64ToArrayBuffer(b64){ var binary=atob(b64); var bytes=new Uint8Array(binary.length); for(var i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i); return bytes.buffer; }
function evalSafeExpr(expr, vars){
  var s = String(expr==null ? "" : expr); var i = 0;
  function peek(){ return s[i]; }
  function skipWs(){ while(i<s.length && /\s/.test(s[i])) i++; }
  function toNum(v){ var n = typeof v==="number" ? v : parseFloat(v); return isNaN(n) ? 0 : n; }
  function truthy(v){ return typeof v==="string" ? (v!=="" && v!=="0") : !!v; }
  function addVals(a,b){ if(typeof a==="string" || typeof b==="string") return String(a==null?"":a)+String(b==null?"":b); return toNum(a)+toNum(b); }
  function compareVals(a,b,op){
    var r;
    if(typeof a==="string" || typeof b==="string"){
      var as=String(a==null?"":a), bs=String(b==null?"":b);
      if(op==="==") r=(as===bs); else if(op==="!=") r=(as!==bs); else if(op===">") r=(as>bs); else if(op==="<") r=(as<bs); else if(op===">=") r=(as>=bs); else r=(as<=bs);
    } else {
      var an=toNum(a), bn=toNum(b);
      if(op==="==") r=(an===bn); else if(op==="!=") r=(an!==bn); else if(op===">") r=(an>bn); else if(op==="<") r=(an<bn); else if(op===">=") r=(an>=bn); else r=(an<=bn);
    }
    return r?1:0;
  }
  function parseAtom(){
    skipWs(); var c = peek();
    if(c==="("){ i++; var v=parseExpr(); skipWs(); if(peek()===")") i++; return v; }
    if(c==='"' || c==="'"){
      var quote=c; i++; var start=i;
      while(i<s.length && s[i]!==quote) i++;
      var str=s.slice(start,i); if(peek()===quote) i++;
      return str;
    }
    if((c>="0" && c<="9") || c==="."){ var start2=i; while(i<s.length && ((s[i]>="0"&&s[i]<="9")||s[i]===".")) i++; return parseFloat(s.slice(start2,i)); }
    if(/[A-Za-z_]/.test(c||"")){ var start3=i; while(i<s.length && /[A-Za-z0-9_]/.test(s[i])) i++; var name=s.slice(start3,i); var val=vars?vars[name]:undefined; return val===undefined?0:val; }
    i++; return 0;
  }
  function parseUnary(){ skipWs(); if(peek()==="-"){ i++; return -toNum(parseUnary()); } if(peek()==="+"){ i++; return parseUnary(); } if(peek()==="!"){ i++; return truthy(parseUnary())?0:1; } return parseAtom(); }
  function parseTerm(){
    var v=parseUnary();
    for(;;){ skipWs(); var op=peek(); if(op==="*"||op==="/"||op==="%"){ i++; var rhs=parseUnary(); v=(op==="*")?(toNum(v)*toNum(rhs)):(op==="/")?(toNum(v)/(toNum(rhs)||1e-9)):(toNum(v)%(toNum(rhs)||1e-9)); } else break; }
    return v;
  }
  function parseAdditive(){
    var v=parseTerm();
    for(;;){ skipWs(); var op=peek(); if(op==="+"||op==="-"){ i++; var rhs=parseTerm(); v=(op==="+")?addVals(v,rhs):(toNum(v)-toNum(rhs)); } else break; }
    return v;
  }
  function parseCompare(){
    var v=parseAdditive(); skipWs();
    var two=s.substr(i,2), op=null;
    if(two===">="||two==="<="||two==="=="||two==="!="){ op=two; i+=2; }
    else if(peek()===">"||peek()==="<"){ op=peek(); i+=1; }
    if(op){ skipWs(); var rhs=parseAdditive(); v=compareVals(v,rhs,op); }
    return v;
  }
  function parseAnd(){
    var v=parseCompare();
    for(;;){ skipWs(); if(s.substr(i,2)==="&&"){ i+=2; var rhs=parseCompare(); v=(truthy(v)&&truthy(rhs))?1:0; } else break; }
    return v;
  }
  function parseOr(){
    var v=parseAnd();
    for(;;){ skipWs(); if(s.substr(i,2)==="||"){ i+=2; var rhs=parseAnd(); v=(truthy(v)||truthy(rhs))?1:0; } else break; }
    return v;
  }
  function parseExpr(){ return parseOr(); }
  try{ skipWs(); return s?parseExpr():0; } catch(e){ return 0; }
}
function interpolateVars(template, vars){
  return String(template==null?"":template).replace(/\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g, function(m,name){
    var v = vars?vars[name]:undefined; return encodeURIComponent(v==null?"":v);
  });
}
function interpolateVarsPlain(template, vars){
  return String(template==null?"":template).replace(/\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g, function(m,name){
    var v = vars?vars[name]:undefined; return v==null?"":String(v);
  });
}
function copiarTextoFallback(texto){
  try{
    var ta = document.createElement("textarea");
    ta.value = texto; ta.style.position="fixed"; ta.style.opacity="0"; ta.style.left="-9999px";
    document.body.appendChild(ta); ta.focus(); ta.select();
    var ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch(e){ return false; }
}
function copiarTexto(texto){
  if(window.isSecureContext && navigator.clipboard){
    return navigator.clipboard.writeText(texto).then(function(){ return true; }).catch(function(){ return copiarTextoFallback(texto); });
  }
  return Promise.resolve(copiarTextoFallback(texto));
}

function rad2deg(r){ return r*180/Math.PI; }

/* =========================================================================
   BOVEDA CELESTE NOCTURNA (estrellas y Luna reales, opcional por proyecto)
   =========================================================================
   Catalogo de ~757 estrellas reales (posiciones J2000 en grados, RA/Dec) que
   forman las lineas clasicas de las 88 constelaciones IAU, mas los propios
   segmentos de esas lineas -- adaptado de d3-celestial (c) Olaf Frohn, licencia
   MIT, a su vez sobre datos del catalogo Hipparcos. NIGHT_SKY_STARS es un
   array plano [ra,dec,mag, ra,dec,mag, ...]; "mag" aqui es una magnitud
   aproximada por rango de brillo de la CONSTELACION (1/2/3), no una fotometria
   exacta estrella a estrella -- ver README para como ampliarlo. Reservado
   tambien NIGHT_SKY_CONSTELLATIONS (nombre en espanol + segmentos por indice)
   para una futura identificacion de constelaciones con el puntero.
*/
var NIGHT_SKY_STARS = [30.975,42.33,2.0,17.433,35.621,2.0,9.832,30.861,2.0,2.097,29.09,2.0,14.302,23.418,2.0,11.835,24.267,2.0,9.639,29.312,2.0,9.22,33.719,2.0,354.534,43.268,2.0,345.48,42.326,2.0,355.102,44.334,2.0,354.391,46.458,2.0,14.188,38.499,2.0,12.454,41.079,2.0,17.375,47.242,2.0,24.498,48.628,2.0,356.509,46.42,2.0,142.311,-35.951,3.6,156.788,-31.068,3.6,164.179,-37.138,3.6,221.965,-79.045,3.6,245.087,-78.696,3.6,250.769,-77.517,3.6,248.363,-78.897,3.6,311.919,-9.496,2.8,313.163,-8.983,2.8,322.89,-5.571,2.8,331.446,-0.32,2.8,335.414,-1.387,2.8,337.208,-0.02,2.8,338.839,-0.117,2.8,343.154,-7.58,2.8,349.476,-9.182,2.8,347.362,-21.172,2.8,331.609,-13.87,2.8,334.209,-7.783,2.8,336.319,1.377,2.8,350.743,-20.101,2.8,355.441,-17.817,2.8,296.565,10.613,2.0,297.696,8.868,2.0,298.828,6.407,2.0,302.826,-0.822,2.0,298.118,1.006,2.0,291.375,3.115,2.0,286.353,13.864,2.0,286.562,-4.883,2.0,261.349,-56.378,3.6,262.775,-60.684,3.6,252.447,-59.041,3.6,254.655,-55.99,3.6,254.896,-53.16,3.6,262.96,-49.876,3.6,261.325,-55.53,3.6,42.496,27.261,2.0,31.793,23.462,2.0,28.66,20.808,2.0,28.383,19.294,2.0,89.882,44.947,2.0,79.172,45.998,2.0,76.629,41.234,2.0,74.248,33.166,2.0,81.573,28.608,2.0,89.93,37.213,2.0,89.882,54.285,2.0,75.492,43.823,2.0,75.62,41.076,2.0,206.816,17.457,2.0,208.671,18.398,2.0,213.915,19.182,2.0,217.958,30.371,2.0,218.019,38.308,2.0,225.487,40.391,2.0,228.876,33.315,2.0,221.247,27.074,2.0,220.287,13.728,2.0,214.096,46.088,2.0,213.366,51.788,2.0,216.299,51.851,2.0,67.709,-44.954,3.6,70.141,-41.864,3.6,70.514,-37.144,3.6,76.102,-35.483,3.6,74.322,53.752,2.8,75.855,60.442,2.8,73.513,66.343,2.8,57.59,71.332,2.8,57.38,65.526,2.8,52.267,59.94,2.8,94.712,69.32,2.8,105.017,76.977,2.8,134.622,11.858,2.8,131.171,18.154,2.8,130.821,21.468,2.8,131.667,28.765,2.8,124.129,9.185,2.8,194.002,38.315,2.8,188.436,41.358,2.8,95.675,-17.956,2.0,101.287,-16.716,2.0,105.756,-23.833,2.0,107.098,-26.393,2.0,105.43,-27.935,2.0,104.656,-28.972,2.0,95.078,-30.063,2.0,111.024,-29.303,2.0,104.034,-17.054,2.0,105.94,-15.633,2.0,103.547,-12.039,2.0,114.826,5.225,2.8,111.788,8.289,2.8,304.412,-12.508,2.8,305.253,-14.781,2.8,307.215,-17.814,2.8,311.524,-25.271,2.8,312.955,-26.919,2.8,321.667,-22.411,2.8,326.76,-16.127,2.8,325.023,-16.662,2.8,320.562,-16.834,2.8,316.487,-17.233,2.8,99.44,-43.196,2.0,95.988,-52.696,2.0,138.3,-69.717,2.0,153.434,-70.038,2.0,160.739,-64.394,2.0,158.006,-61.685,2.0,154.271,-61.332,2.0,139.273,-59.275,2.0,125.629,-59.51,2.0,119.195,-52.982,2.0,122.383,-47.337,2.0,131.176,-54.709,2.0,166.635,-62.424,2.0,167.142,-61.947,2.0,168.15,-60.318,2.0,167.148,-58.975,2.0,163.374,-58.853,2.0,28.599,63.67,2.0,21.454,60.235,2.0,14.177,60.717,2.0,10.127,56.537,2.0,2.295,59.15,2.0,170.252,-54.491,2.0,182.09,-50.722,2.0,187.01,-50.231,2.0,190.379,-48.96,2.0,204.972,-53.466,2.0,208.885,-47.288,2.0,207.404,-42.474,2.0,207.376,-41.688,2.0,211.671,-36.37,2.0,218.877,-42.158,2.0,224.79,-42.104,2.0,200.149,-36.712,2.0,219.896,-60.837,2.0,210.956,-60.373,2.0,182.913,-52.368,2.0,172.942,-59.442,2.0,307.395,62.994,2.8,311.322,61.839,2.8,319.645,62.586,2.8,325.877,58.78,2.8,333.759,57.044,2.8,332.714,58.201,2.8,337.293,58.415,2.8,342.42,66.2,2.8,354.837,77.632,2.8,322.165,70.561,2.8,40.825,3.236,2.0,38.969,5.593,2.0,37.04,8.46,2.0,41.236,10.114,2.0,44.929,8.907,2.0,45.57,4.09,2.0,39.871,0.329,2.0,34.837,-2.978,2.0,27.865,-10.335,2.0,26.017,-15.938,2.0,10.897,-17.987,2.0,4.857,-8.824,2.0,17.148,-10.182,2.0,21.006,-8.183,2.0,124.632,-76.92,3.6,158.867,-78.608,3.6,161.318,-80.47,3.6,184.587,-79.312,3.6,179.907,-78.222,3.6,229.379,-58.801,3.6,220.627,-64.975,3.6,230.844,-59.321,3.6,95.528,-33.436,3.6,87.74,-35.768,3.6,84.912,-34.074,3.6,82.803,-35.471,3.6,89.787,-42.815,3.6,197.497,17.529,3.6,197.968,27.878,3.6,186.734,28.268,3.6,284.681,-37.107,3.6,286.605,-37.063,3.6,287.368,-37.904,3.6,287.507,-39.341,3.6,287.087,-40.497,3.6,285.779,-42.095,3.6,282.396,-43.434,3.6,278.376,-42.312,3.6,233.232,31.359,2.8,231.957,29.106,2.8,233.672,26.715,2.8,235.686,26.296,2.8,237.399,26.068,2.8,239.397,26.878,2.8,240.361,29.851,2.8,182.103,-24.729,3.6,182.531,-22.62,3.6,183.952,-17.542,3.6,187.466,-16.515,3.6,188.597,-23.397,3.6,174.171,-9.802,3.6,171.153,-10.859,3.6,169.835,-14.778,3.6,164.944,-18.299,3.6,167.915,-22.826,3.6,170.841,-18.78,3.6,171.22,-17.684,3.6,176.191,-18.351,3.6,179.004,-17.151,3.6,191.93,-59.689,2.8,183.786,-58.749,2.8,186.65,-63.099,2.8,187.792,-57.113,2.8,318.234,30.227,2.0,311.553,33.97,2.0,305.557,40.257,2.0,296.244,45.131,2.0,292.427,51.73,2.0,289.276,53.368,2.0,310.358,45.28,2.0,299.077,35.083,2.0,292.68,27.96,2.0,308.303,11.303,3.6,309.387,14.595,3.6,309.909,15.912,3.6,311.662,16.124,3.6,310.865,15.075,3.6,64.007,-51.487,3.6,68.499,-55.045,3.6,83.406,-62.49,3.6,86.193,-65.736,3.6,88.525,-63.09,3.6,76.378,-57.473,3.6,268.382,56.873,2.8,269.151,51.489,2.8,262.608,52.301,2.8,263.067,55.173,2.8,288.139,67.662,2.8,275.189,71.338,2.8,257.197,65.715,2.8,245.998,61.514,2.8,240.472,58.565,2.8,231.232,58.966,2.8,211.097,64.376,2.8,188.371,69.788,2.8,172.851,69.331,2.8,275.264,72.733,2.8,297.043,70.268,2.8,318.956,5.248,3.6,318.62,10.007,3.6,317.585,10.132,3.6,76.962,-5.086,2.0,71.376,-3.255,2.0,69.08,-3.353,2.0,62.966,-6.838,2.0,59.507,-13.508,2.0,56.536,-12.102,2.0,55.812,-9.763,2.0,53.233,-9.458,2.0,44.107,-8.898,2.0,41.031,-13.859,2.0,41.276,-18.573,2.0,45.598,-23.625,2.0,49.879,-21.758,2.0,53.447,-21.633,2.0,56.712,-23.25,2.0,68.888,-30.562,2.0,66.009,-34.017,2.0,64.474,-33.798,2.0,57.364,-36.2,2.0,54.274,-40.275,2.0,49.982,-43.07,2.0,44.565,-40.305,2.0,40.167,-39.855,2.0,36.746,-47.704,2.0,34.127,-51.512,2.0,28.989,-51.609,2.0,24.428,-57.237,2.0,48.019,-28.988,3.6,42.273,-32.406,3.6,31.123,-29.297,3.6,93.719,22.507,2.0,95.74,22.514,2.0,100.983,25.131,2.0,107.785,30.245,2.0,113.649,31.888,2.0,116.329,28.026,2.0,113.981,26.896,2.0,110.031,21.982,2.0,106.027,20.57,2.0,99.428,16.399,2.0,101.322,12.896,2.0,109.523,16.54,2.0,345.22,-52.754,3.6,342.139,-51.317,3.6,340.667,-46.885,3.6,337.439,-43.749,3.6,332.058,-46.961,3.6,337.317,-43.496,3.6,333.904,-41.347,3.6,331.529,-39.543,3.6,328.482,-37.365,3.6,245.48,19.153,2.8,247.555,21.49,2.8,250.322,31.603,2.8,250.724,38.922,2.8,248.526,42.437,2.8,244.935,46.313,2.8,242.192,44.935,2.8,238.169,42.452,2.8,255.072,30.926,2.8,258.762,36.809,2.8,269.063,37.251,2.8,260.921,37.146,2.8,258.758,24.839,2.8,266.615,27.721,2.8,269.441,29.248,2.8,271.886,28.762,2.8,258.662,14.39,2.8,63.501,-42.294,3.6,40.639,-50.8,3.6,39.352,-52.543,3.6,40.165,-54.55,3.6,45.903,-59.738,3.6,44.699,-64.071,3.6,131.694,6.419,2.8,132.108,5.838,2.8,130.806,3.399,2.8,129.689,3.341,2.8,129.414,5.704,2.8,133.848,5.946,2.8,138.591,2.314,2.8,144.964,-1.143,2.8,141.897,-8.659,2.8,147.87,-14.847,2.8,152.647,-12.354,2.8,156.523,-16.836,2.8,162.406,-16.194,2.8,173.25,-31.858,2.8,178.227,-33.908,2.8,199.73,-23.172,2.8,211.593,-26.682,2.8,222.572,-27.96,2.8,6.438,-77.254,3.6,56.81,-74.239,3.6,39.897,-68.267,3.6,35.437,-68.659,3.6,28.734,-67.647,3.6,29.692,-61.57,3.6,309.392,-47.291,3.6,311.01,-51.921,3.6,313.702,-58.454,3.6,329.48,-54.993,3.6,319.967,-53.449,3.6,335.89,52.229,3.6,337.823,50.282,3.6,337.383,47.707,3.6,335.256,46.537,3.6,337.622,43.123,3.6,340.129,44.276,3.6,336.129,49.476,3.6,333.47,39.715,3.6,333.992,37.749,3.6,152.093,11.967,2.0,151.833,16.763,2.0,154.993,19.841,2.0,168.527,20.524,2.0,177.265,14.572,2.0,168.56,15.43,2.0,154.173,23.417,2.0,148.191,26.007,2.0,146.463,23.774,2.0,151.857,35.245,3.6,156.478,33.796,3.6,163.328,34.215,3.6,156.971,36.707,3.6,143.556,36.398,3.6,91.539,-14.935,3.6,89.101,-14.168,3.6,86.739,-14.822,3.6,83.183,-17.822,3.6,78.233,-16.206,3.6,76.365,-22.371,3.6,82.061,-20.759,3.6,86.116,-22.448,3.6,87.83,-20.879,3.6,78.308,-12.941,3.6,79.894,-13.177,3.6,226.018,-25.282,2.8,222.72,-16.042,2.8,229.252,-9.383,2.8,233.882,-14.79,2.8,234.256,-28.135,2.8,234.664,-29.778,2.8,237.74,-33.627,3.6,234.942,-34.412,3.6,230.452,-36.261,3.6,230.343,-40.648,3.6,224.633,-43.134,3.6,220.482,-47.388,3.6,228.071,-52.099,3.6,229.633,-47.875,3.6,230.67,-44.69,3.6,233.785,-41.167,3.6,240.031,-38.397,3.6,241.648,-36.802,3.6,94.906,59.011,3.6,104.319,58.423,3.6,111.678,49.212,3.6,125.709,43.188,3.6,135.16,41.783,3.6,139.711,36.803,3.6,140.264,34.393,3.6,281.193,37.605,2.8,281.095,39.613,2.8,279.235,38.784,2.8,283.626,36.899,2.8,284.736,32.69,2.8,282.52,33.363,2.8,92.56,-74.753,3.6,82.971,-76.341,3.6,73.797,-74.937,3.6,75.679,-71.314,3.6,312.492,-33.78,3.6,312.121,-43.989,3.6,320.19,-40.809,3.6,319.485,-32.172,3.6,315.323,-32.258,3.6,115.312,-9.551,2.8,122.148,-2.984,2.8,107.966,-0.493,2.8,97.204,-7.033,2.8,93.714,-6.275,2.8,101.965,2.412,2.8,95.942,4.593,2.8,98.226,7.333,2.8,100.244,9.896,2.8,176.402,-66.729,3.6,184.393,-67.961,3.6,189.296,-69.136,3.6,191.57,-68.108,3.6,195.568,-71.549,3.6,188.117,-72.133,3.6,241.623,-45.173,3.6,246.796,-47.555,3.6,244.96,-50.156,3.6,240.804,-49.23,3.6,216.73,-83.668,3.6,341.515,-81.382,3.6,325.369,-77.39,3.6,269.757,-9.774,2.8,266.973,2.707,2.8,265.868,4.567,2.8,263.734,12.56,2.8,254.417,9.375,2.8,247.728,1.984,2.8,243.586,-3.694,2.8,244.58,-4.692,2.8,249.29,-10.567,2.8,257.594,-15.725,2.8,247.785,-16.613,2.8,246.756,-18.456,2.8,246.026,-20.037,2.8,246.396,-23.447,2.8,260.502,-25.0,2.8,261.839,-29.867,2.8,91.893,14.768,2.0,88.596,20.276,2.0,90.98,20.139,2.0,92.985,14.209,2.0,90.596,9.647,2.0,88.793,7.407,2.0,81.283,6.35,2.0,73.724,10.151,2.0,74.637,1.714,2.0,73.563,2.441,2.0,72.802,5.605,2.0,72.46,6.961,2.0,72.653,8.9,2.0,74.093,13.514,2.0,76.142,15.404,2.0,77.425,15.597,2.0,78.635,-8.202,2.0,81.119,-2.397,2.0,83.002,-0.299,2.0,83.784,9.934,2.0,85.19,-1.943,2.0,86.939,-9.67,2.0,84.053,-1.202,2.0,306.412,-56.735,2.8,311.24,-66.203,2.8,302.182,-66.182,2.8,283.054,-62.188,2.8,275.807,-61.494,2.8,272.145,-63.669,2.8,266.433,-64.724,2.8,280.759,-71.428,2.8,300.148,-72.91,2.8,321.611,-65.366,2.8,332.497,33.178,2.0,340.751,30.221,2.0,345.944,28.083,2.0,3.309,15.184,2.0,346.19,15.205,2.0,341.673,12.173,2.0,340.365,10.831,2.0,332.55,6.198,2.0,326.046,9.875,2.0,342.501,24.602,2.0,341.633,23.566,2.0,331.753,25.345,2.0,326.161,25.645,2.0,56.08,32.288,2.0,58.533,31.884,2.0,59.741,35.791,2.0,59.464,40.01,2.0,56.298,42.578,2.0,55.731,47.788,2.0,54.122,48.193,2.0,51.081,49.861,2.0,46.199,53.506,2.0,42.674,55.895,2.0,43.564,52.763,2.0,47.267,49.613,2.0,47.374,44.858,2.0,47.042,40.956,2.0,47.822,39.612,2.0,46.294,38.84,2.0,44.69,39.663,2.0,44.916,41.033,2.0,61.646,50.351,2.0,63.724,48.409,2.0,62.165,47.712,2.0,41.05,49.228,2.0,25.915,50.689,2.0,6.571,-42.306,2.8,16.521,-46.718,2.8,22.091,-43.318,2.8,22.813,-49.073,2.8,17.096,-55.246,2.8,2.353,-45.747,2.8,102.048,-61.941,3.6,87.457,-56.167,3.6,86.821,-51.066,3.6,18.437,24.584,2.8,17.915,30.09,2.8,19.867,27.264,2.8,17.863,21.035,2.8,22.871,15.346,2.8,26.349,9.158,2.8,30.512,2.764,2.8,28.389,3.188,2.8,25.358,5.488,2.8,22.546,6.144,2.8,18.433,7.575,2.8,15.736,7.89,2.8,12.171,7.585,2.8,359.828,6.863,2.8,354.988,5.626,2.8,351.992,6.379,2.8,350.086,5.381,2.8,349.291,3.282,2.8,351.733,1.256,2.8,355.512,1.78,2.8,356.598,3.487,2.8,345.969,3.82,2.8,340.164,-27.044,2.8,344.413,-29.622,2.8,343.987,-32.54,2.8,343.131,-32.876,2.8,337.876,-32.346,2.8,332.096,-32.989,2.8,326.237,-33.026,2.8,326.934,-30.898,2.8,109.286,-37.097,2.8,113.845,-28.369,2.8,114.708,-26.804,2.8,117.324,-24.86,2.8,119.215,-22.88,2.8,121.886,-24.304,2.8,120.896,-40.003,2.8,117.022,-25.937,2.8,115.952,-28.955,2.8,130.026,-35.308,3.6,130.898,-33.186,3.6,132.633,-27.71,3.6,63.606,-62.474,3.6,64.121,-59.302,3.6,59.687,-61.4,3.6,56.05,-64.807,3.6,295.024,18.014,3.6,296.847,18.534,3.6,299.689,19.492,3.6,295.262,17.476,3.6,274.407,-36.762,2.0,276.043,-34.385,2.0,275.249,-29.828,2.0,276.993,-25.422,2.0,273.441,-21.059,2.0,290.66,-44.459,2.0,290.972,-40.616,2.0,285.653,-29.88,2.0,281.414,-26.991,2.0,298.815,-41.868,2.0,299.934,-35.276,2.0,298.96,-26.299,2.0,294.177,-24.884,2.0,291.319,-24.509,2.0,288.885,-25.257,2.0,283.816,-26.297,2.0,271.452,-30.424,2.0,286.735,-27.67,2.0,286.171,-21.741,2.0,287.441,-21.024,2.0,289.409,-18.953,2.0,290.418,-17.847,2.0,290.432,-15.955,2.0,284.433,-21.107,2.0,283.542,-22.745,2.0,239.713,-26.114,2.0,240.083,-22.622,2.0,241.359,-19.805,2.0,245.297,-25.593,2.0,247.352,-26.432,2.0,248.971,-28.216,2.0,252.541,-34.293,2.0,252.968,-38.047,2.0,253.646,-42.361,2.0,258.038,-43.239,2.0,264.33,-42.998,2.0,266.896,-40.127,2.0,265.622,-39.03,2.0,263.402,-37.104,2.0,14.652,-29.357,3.6,357.231,-28.13,3.6,349.706,-32.532,3.6,353.243,-37.818,3.6,278.802,-8.244,3.6,281.794,-4.748,3.6,280.568,-9.053,3.6,277.299,-14.566,3.6,236.547,15.422,3.6,235.388,19.67,3.6,237.185,18.142,3.6,239.113,15.662,3.6,233.701,10.539,3.6,236.067,6.426,3.6,237.704,4.478,3.6,264.397,-15.399,3.6,270.77,-8.18,3.6,275.327,-2.899,3.6,284.055,4.204,3.6,151.984,-0.372,3.6,148.127,-8.105,3.6,157.37,-2.739,3.6,157.573,-0.637,3.6,84.411,21.142,2.0,68.98,16.509,2.0,67.166,15.871,2.0,64.948,15.628,2.0,65.734,17.543,2.0,67.154,19.18,2.0,60.17,12.49,2.0,51.792,9.733,2.0,60.789,5.989,2.0,51.203,9.029,2.0,54.218,0.402,2.0,272.807,-45.954,3.6,276.743,-45.968,3.6,277.208,-49.071,3.6,28.27,29.579,3.6,32.386,34.987,3.6,34.329,33.847,3.6,252.166,-69.028,2.8,238.786,-63.431,2.8,229.727,-68.68,2.8,334.625,-60.26,3.6,349.357,-58.236,3.6,7.886,-62.958,3.6,5.018,-64.875,3.6,359.979,-65.577,3.6,336.833,-64.966,3.6,183.857,57.033,2.0,165.932,61.751,2.0,165.46,56.382,2.0,178.458,53.695,2.0,193.507,55.96,2.0,200.981,54.925,2.0,206.885,49.313,2.0,176.513,47.779,2.0,169.62,33.094,2.0,169.547,31.531,2.0,167.416,44.498,2.0,155.582,41.499,2.0,154.274,42.914,2.0,142.882,63.062,2.0,127.566,60.718,2.0,147.747,59.039,2.0,148.026,54.064,2.0,143.214,51.677,2.0,134.802,48.042,2.0,135.906,47.157,2.0,236.015,77.794,2.8,244.376,75.755,2.8,230.182,71.834,2.8,222.676,74.156,2.8,251.493,82.037,2.8,263.054,86.587,2.8,37.955,89.264,2.8,140.528,-55.011,2.8,149.216,-54.568,2.8,161.692,-49.42,2.8,153.684,-42.122,2.8,142.675,-40.467,2.8,136.999,-43.433,2.8,176.465,6.529,2.0,177.674,1.765,2.0,184.976,-0.667,2.0,190.415,-1.449,2.0,197.488,-5.539,2.0,201.298,-11.161,2.0,214.004,-6.0,2.0,220.765,-5.658,2.0,195.544,10.959,2.0,193.901,3.397,2.0,203.673,-0.596,2.0,210.412,1.544,2.0,221.562,1.893,2.0,135.612,-66.396,3.6,126.434,-66.137,3.6,121.983,-68.617,3.6,109.208,-67.957,3.6,107.187,-70.499,3.6,289.054,21.39,3.6,292.176,24.665,3.6,298.365,24.08,3.6,300.275,27.754,3.6,303.942,27.814,3.6];
var NIGHT_SKY_CONSTELLATIONS = [{"id":"And","es":"Andr\u00f3meda","rank":"1","seg":[[0,1],[1,2],[2,3],[4,5],[5,6],[6,2],[2,7],[7,8],[8,9],[8,10],[10,11],[1,12],[12,13],[13,14],[14,15],[10,16]]},{"id":"Ant","es":"M\u00e1quina Neum\u00e1tica","rank":"3","seg":[[17,18],[18,19]]},{"id":"Aps","es":"Ave del Para\u00edso","rank":"3","seg":[[20,21],[21,22],[22,23]]},{"id":"Aqr","es":"Acuario","rank":"2","seg":[[24,25],[25,26],[26,27],[27,28],[28,29],[29,30],[30,31],[31,32],[32,33],[26,34],[27,35],[29,36],[37,32],[32,38]]},{"id":"Aql","es":"\u00c1guila","rank":"1","seg":[[39,40],[40,41],[41,42],[42,43],[43,44],[44,45],[45,40],[40,44],[44,46]]},{"id":"Ara","es":"Altar","rank":"3","seg":[[47,48],[48,49],[49,50],[50,51],[51,52],[52,53]]},{"id":"Ari","es":"Carnero","rank":"1","seg":[[54,55],[55,56],[56,57]]},{"id":"Aur","es":"Cochero","rank":"1","seg":[[58,59],[59,60],[60,61],[61,62],[62,63],[63,58],[58,64],[64,59],[59,65],[65,66]]},{"id":"Boo","es":"Boyero","rank":"1","seg":[[67,68],[68,69],[69,70],[70,71],[71,72],[72,73],[73,74],[74,69],[69,75],[71,76],[76,77],[77,78],[78,76]]},{"id":"Cae","es":"Cincel","rank":"3","seg":[[79,80],[80,81],[81,82]]},{"id":"Cam","es":"Jirafa","rank":"2","seg":[[83,84],[84,85],[85,86],[86,87],[87,88],[85,89],[89,90]]},{"id":"Cnc","es":"Cangrejo","rank":"2","seg":[[91,92],[92,93],[93,94],[92,95]]},{"id":"CVn","es":"Lebreles","rank":"2","seg":[[96,97]]},{"id":"CMa","es":"Perro Mayor","rank":"1","seg":[[98,99],[99,100],[100,101],[101,102],[102,103],[103,104],[105,101],[99,106],[106,107],[107,108],[108,106]]},{"id":"CMi","es":"Perro Menor","rank":"2","seg":[[109,110]]},{"id":"Cap","es":"Capricornio","rank":"2","seg":[[111,112],[112,113],[113,114],[114,115],[115,116],[116,117],[117,118],[118,119],[119,120],[120,111]]},{"id":"Car","es":"Carina","rank":"1","seg":[[121,122],[122,123],[123,124],[124,125],[125,126],[126,127],[127,128],[128,129],[129,130],[130,131],[131,132],[132,128],[125,133],[133,134],[134,135],[135,136],[136,137],[137,126]]},{"id":"Cas","es":"Casiopea","rank":"1","seg":[[138,139],[139,140],[140,141],[141,142]]},{"id":"Cen","es":"Centauro","rank":"1","seg":[[143,144],[144,145],[145,146],[146,147],[147,148],[148,149],[149,150],[150,151],[151,152],[152,153],[150,154],[155,147],[147,156],[145,157],[157,158]]},{"id":"Cep","es":"Cefeo","rank":"2","seg":[[159,160],[160,161],[161,162],[162,163],[163,164],[164,165],[165,166],[166,167],[167,168],[168,161],[168,166]]},{"id":"Cet","es":"Ballena","rank":"1","seg":[[169,170],[170,171],[171,172],[172,173],[173,174],[174,169],[169,175],[175,176],[176,177],[177,178],[178,179],[179,180],[180,181],[181,182],[182,177]]},{"id":"Cha","es":"Camale\u00f3n","rank":"3","seg":[[183,184],[184,185],[185,186],[186,187],[187,184]]},{"id":"Cir","es":"Comp\u00e1s","rank":"3","seg":[[188,189],[189,190]]},{"id":"Col","es":"Paloma","rank":"3","seg":[[191,192],[192,193],[193,194],[192,195]]},{"id":"Com","es":"Pelo de Berenice","rank":"3","seg":[[196,197],[197,198]]},{"id":"CrA","es":"Corona Austral","rank":"3","seg":[[199,200],[200,201],[201,202],[202,203],[203,204],[204,205],[205,206]]},{"id":"CrB","es":"Corona Boreal","rank":"2","seg":[[207,208],[208,209],[209,210],[210,211],[211,212],[212,213]]},{"id":"Crv","es":"Cuervo","rank":"3","seg":[[214,215],[215,216],[216,217],[217,218],[218,215]]},{"id":"Crt","es":"Copa","rank":"3","seg":[[219,220],[220,221],[221,222],[222,223],[223,224],[224,225],[225,226],[226,227],[221,225]]},{"id":"Cru","es":"Cruz del Sur","rank":"2","seg":[[228,229],[230,231]]},{"id":"Cyg","es":"Cisne","rank":"1","seg":[[232,233],[233,234],[234,235],[235,236],[236,237],[238,234],[234,239],[239,240]]},{"id":"Del","es":"Delf\u00edn","rank":"3","seg":[[241,242],[242,243],[243,244],[244,245],[245,242]]},{"id":"Dor","es":"Pez dorado","rank":"3","seg":[[246,247],[247,248],[248,249],[249,250],[250,248],[248,251],[251,247]]},{"id":"Dra","es":"Drag\u00f3n","rank":"2","seg":[[252,253],[253,254],[254,255],[255,252],[252,256],[256,257],[257,258],[258,259],[259,260],[260,261],[261,262],[262,263],[263,264],[257,265],[256,266]]},{"id":"Equ","es":"Caballito","rank":"3","seg":[[267,268],[268,269]]},{"id":"Eri","es":"Er\u00eddano","rank":"1","seg":[[270,271],[271,272],[272,273],[273,274],[274,275],[275,276],[276,277],[277,278],[278,279],[279,280],[280,281],[281,282],[282,283],[283,284],[284,285],[285,286],[286,287],[287,288],[288,289],[289,290],[290,291],[291,292],[292,293],[293,294],[294,295],[295,296]]},{"id":"For","es":"Horno","rank":"3","seg":[[297,298],[298,299]]},{"id":"Gem","es":"Gemelos","rank":"1","seg":[[300,301],[301,302],[302,303],[303,304],[304,305],[305,306],[306,307],[307,308],[308,309],[309,310],[307,311]]},{"id":"Gru","es":"Grulla","rank":"3","seg":[[312,313],[313,314],[314,315],[315,316],[316,314],[317,318],[318,319],[319,320]]},{"id":"Her","es":"H\u00e9rcules","rank":"2","seg":[[321,322],[322,323],[323,324],[324,325],[325,326],[326,327],[327,328],[323,329],[324,330],[331,332],[332,330],[330,329],[329,333],[333,334],[334,335],[335,336],[337,322]]},{"id":"Hor","es":"Reloj","rank":"3","seg":[[338,339],[339,340],[340,341],[341,342],[342,343]]},{"id":"Hya","es":"Hidra","rank":"2","seg":[[344,345],[345,346],[346,347],[347,348],[348,344],[344,349],[349,350],[350,351],[351,352],[352,353],[353,354],[354,355],[355,356],[356,357],[357,358],[358,359],[359,360],[360,361]]},{"id":"Hyi","es":"Hidra Macho","rank":"3","seg":[[362,363],[363,364],[364,365],[365,366],[366,367]]},{"id":"Ind","es":"Indio","rank":"3","seg":[[368,369],[369,370],[370,371],[371,372],[372,368]]},{"id":"Lac","es":"Lagarto","rank":"3","seg":[[373,374],[374,375],[375,376],[376,377],[377,378],[378,375],[375,379],[379,373],[377,380],[380,381]]},{"id":"Leo","es":"Le\u00f3n","rank":"1","seg":[[382,383],[383,384],[384,385],[385,386],[386,387],[387,382],[384,388],[388,389],[389,390]]},{"id":"LMi","es":"Le\u00f3n Menor","rank":"3","seg":[[391,392],[392,393],[393,394],[394,391],[391,395]]},{"id":"Lep","es":"Conejo","rank":"3","seg":[[396,397],[397,398],[398,399],[399,400],[400,401],[401,402],[402,403],[403,404],[405,400],[400,406]]},{"id":"Lib","es":"Balanza","rank":"2","seg":[[407,408],[408,409],[409,410],[410,411],[411,412],[408,410]]},{"id":"Lup","es":"Lobo","rank":"3","seg":[[413,414],[414,415],[415,416],[416,417],[417,418],[418,419],[419,420],[420,421],[421,422],[422,423],[423,424],[416,422]]},{"id":"Lyn","es":"Lince","rank":"3","seg":[[425,426],[426,427],[427,428],[428,429],[429,430],[430,431]]},{"id":"Lyr","es":"Lira","rank":"2","seg":[[432,433],[433,434],[434,432],[432,435],[435,436],[436,437],[437,432]]},{"id":"Men","es":"Mesa","rank":"3","seg":[[438,439],[439,440],[440,441]]},{"id":"Mic","es":"Microscopio","rank":"3","seg":[[442,443],[443,444],[444,445],[445,446],[446,442]]},{"id":"Mon","es":"Unicornio","rank":"2","seg":[[447,448],[448,449],[449,450],[450,451],[449,452],[452,453],[453,454],[454,455]]},{"id":"Mus","es":"Mosca","rank":"3","seg":[[456,457],[457,458],[458,459],[459,460],[460,461],[461,458]]},{"id":"Nor","es":"Escuadra","rank":"3","seg":[[462,463],[463,464],[464,465],[465,462]]},{"id":"Oct","es":"Bast\u00f3n","rank":"3","seg":[[466,467],[467,468],[468,466]]},{"id":"Oph","es":"Ofiuco","rank":"2","seg":[[469,470],[470,471],[471,472],[472,473],[473,474],[474,475],[475,476],[476,477],[477,478],[473,477],[477,479],[479,480],[480,481],[481,482],[471,478],[478,483],[483,484]]},{"id":"Ori","es":"Ori\u00f3n","rank":"1","seg":[[485,486],[486,487],[487,488],[488,489],[489,490],[490,491],[491,492],[493,494],[494,495],[495,496],[496,497],[497,492],[492,498],[498,499],[499,500],[501,502],[502,503],[503,491],[491,504],[504,490],[490,505],[505,506],[505,507],[507,503]]},{"id":"Pav","es":"Pavo","rank":"2","seg":[[508,509],[509,510],[510,511],[511,512],[512,513],[513,514],[514,515],[515,516],[516,509],[509,517]]},{"id":"Peg","es":"Pegaso","rank":"1","seg":[[518,519],[519,520],[520,3],[3,521],[521,522],[522,523],[523,524],[524,525],[525,526],[522,520],[520,527],[527,528],[528,529],[529,530]]},{"id":"Per","es":"Perseo","rank":"1","seg":[[531,532],[532,533],[533,534],[534,535],[535,536],[536,537],[537,538],[538,539],[539,540],[540,541],[541,542],[542,543],[543,544],[544,545],[545,546],[546,547],[547,548],[548,544],[549,550],[550,551],[551,536],[542,552],[552,553]]},{"id":"Phe","es":"F\u00e9nix","rank":"2","seg":[[554,555],[555,556],[556,557],[557,558],[558,555],[555,559],[559,554]]},{"id":"Pic","es":"Caballete del Pintor","rank":"3","seg":[[560,561],[561,562]]},{"id":"Psc","es":"Peces","rank":"2","seg":[[563,564],[564,565],[565,563],[563,566],[566,567],[567,568],[568,569],[569,570],[570,571],[571,572],[572,573],[573,574],[574,575],[575,576],[576,577],[577,578],[578,579],[579,580],[580,581],[581,582],[582,583],[583,577],[580,584]]},{"id":"PsA","es":"Pez Austral","rank":"2","seg":[[585,586],[586,587],[587,588],[588,589],[589,590],[590,591],[591,592],[592,590],[590,585]]},{"id":"Pup","es":"Popa","rank":"2","seg":[[121,593],[593,594],[594,595],[595,596],[596,597],[597,598],[598,599],[599,131],[596,600],[600,601],[601,594]]},{"id":"Pyx","es":"Br\u00fajula","rank":"3","seg":[[599,602],[602,603],[603,604]]},{"id":"Ret","es":"Ret\u00edculo","rank":"3","seg":[[605,606],[606,607],[607,608],[608,605]]},{"id":"Sge","es":"Flecha","rank":"3","seg":[[609,610],[610,611],[612,610]]},{"id":"Sgr","es":"Sagitario","rank":"1","seg":[[613,614],[614,615],[615,616],[616,617],[618,619],[619,620],[620,621],[621,616],[622,623],[623,624],[624,625],[625,626],[626,627],[627,628],[628,621],[621,615],[615,629],[629,614],[614,620],[620,630],[630,628],[628,631],[631,632],[632,633],[633,634],[634,635],[631,636],[636,637],[637,628]]},{"id":"Sco","es":"Escorpi\u00f3n","rank":"1","seg":[[638,639],[639,640],[639,641],[641,642],[642,643],[643,644],[644,645],[645,646],[646,647],[647,648],[648,649],[649,650],[650,651]]},{"id":"Scl","es":"Escultor","rank":"3","seg":[[652,653],[653,654],[654,655]]},{"id":"Sct","es":"Escudo","rank":"3","seg":[[656,657],[657,658],[658,659],[659,656]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[660,661],[661,662],[662,663],[663,660],[660,664],[664,665],[665,666],[666,475]]},{"id":"Ser","es":"Serpiente (cabeza)","rank":"3","seg":[[478,667],[667,469],[469,668],[668,669],[669,670]]},{"id":"Sex","es":"Sextante","rank":"3","seg":[[671,672],[672,673],[673,674]]},{"id":"Tau","es":"Toro","rank":"1","seg":[[675,676],[676,677],[677,678],[678,679],[679,680],[680,62],[678,681],[681,682],[682,683],[682,684],[684,685]]},{"id":"Tel","es":"Telescopio","rank":"3","seg":[[686,687],[687,688]]},{"id":"Tri","es":"Tri\u00e1ngulo","rank":"3","seg":[[689,690],[690,691],[691,689]]},{"id":"TrA","es":"Tri\u00e1ngulo Austral","rank":"2","seg":[[692,693],[693,694],[694,692]]},{"id":"Tuc","es":"Tuc\u00e1n","rank":"3","seg":[[695,696],[696,697],[697,698],[698,699],[699,700],[700,695]]},{"id":"UMa","es":"Osa Mayor","rank":"1","seg":[[701,702],[702,703],[703,704],[704,701],[701,705],[705,706],[706,707],[704,708],[708,709],[709,710],[708,711],[711,712],[711,713],[702,714],[714,715],[715,716],[716,703],[703,717],[717,718],[718,719],[720,718]]},{"id":"UMi","es":"Osa Menor","rank":"2","seg":[[721,722],[722,723],[723,724],[724,721],[721,725],[725,726],[726,727]]},{"id":"Vel","es":"Vela","rank":"2","seg":[[132,728],[728,729],[729,730],[730,731],[731,732],[732,733],[733,131]]},{"id":"Vir","es":"Virgen","rank":"1","seg":[[734,735],[735,736],[736,737],[737,738],[738,739],[739,740],[740,741],[742,743],[743,737],[738,744],[744,745],[745,746]]},{"id":"Vol","es":"Pez Volador","rank":"3","seg":[[747,748],[748,749],[749,750],[750,751],[751,749],[749,747]]},{"id":"Vul","es":"Zorra","rank":"3","seg":[[752,753],[753,754],[754,755],[755,756]]}];
var NIGHT_SKY_DOME_R = 300; // radio del domo, dentro del far=500 de la camara
var NIGHT_SKY_LIGHT_LAYER = 2; // capa dedicada: solo la ilumina la luz de fase lunar
// Polo norte de la ecliptica en coordenadas ecuatoriales J2000 (RA=18h=270 grados,
// Dec=90-23.439291=66.560709 grados). El eje de rotacion real de la Luna esta inclinado
// solo ~1.54 grados respecto a este polo (frente a los ~5.14 grados del polo orbital), asi
// que se usa como aproximacion del "norte selenografico" para orientar la textura -- el
// error que esto introduce (libracion fisica/optica real, +-~8 grados de tambaleo) se ignora
// a proposito: es un efecto menor e imperceptible para un adorno de fondo en el cielo.
var ECLIPTIC_POLE_RA_DEG = 270.0, ECLIPTIC_POLE_DEC_DEG = 66.560709;

function julianDateUTC(date) { return date.getTime() / 86400000 + 2440587.5; }

function gmstDeg(jd) {
  var d = jd - 2451545.0;
  var g = 280.46061837 + 360.98564736629 * d;
  return ((g % 360) + 360) % 360;
}

// Convierte ascension recta/declinacion (grados, J2000) a altura/acimut (grados) para un
// instante (fecha juliana UT), latitud y longitud dadas -- formulas estandar de posicion
// horizontal. El acimut usa el mismo convenio que sunPositionFromAngles() de este proyecto
// (0 dispara hacia +Z, 90 hacia +X): no se corresponde con el norte geografico real de
// ningun escenario en concreto, ya que estos escenarios no tienen una orientacion geografica
// definida -- solo importa que el cielo gire de forma consistente y realista con el tiempo.
function equatorialToAltAz(raDeg, decDeg, jd, latDeg, lonDeg) {
  var lst = (gmstDeg(jd) + (lonDeg || 0)) % 360;
  var haDeg = ((lst - raDeg + 540) % 360) - 180;
  var ha = deg2rad(haDeg), dec = deg2rad(decDeg), lat = deg2rad(latDeg);
  var sinAlt = Math.sin(dec) * Math.sin(lat) + Math.cos(dec) * Math.cos(lat) * Math.cos(ha);
  var alt = Math.asin(clamp(sinAlt, -1, 1));
  var cosAlt = Math.cos(alt) || 1e-9;
  var cosAz = (Math.sin(dec) - Math.sin(alt) * Math.sin(lat)) / (cosAlt * Math.cos(lat) || 1e-9);
  var sinAz = (-Math.sin(ha) * Math.cos(dec)) / cosAlt;
  var az = Math.atan2(sinAz, clamp(cosAz, -1, 1));
  return { altDeg: rad2deg(alt), azDeg: (rad2deg(az) + 360) % 360 };
}

// Posicion geocentrica aparente del Sol, baja precision (~0.01 grados, Meeus cap.25 abreviado).
// Se usa SOLO para iluminar la Luna con su fase real -- es independiente del "sol artistico"
// (sunAnglesFromRealDateTime / modo manual-ciclo-realtime), que ambienta el escenario pero no
// pretende precision astronomica.
function sunEquatorialPosition(jd) {
  var d = jd - 2451545.0;
  var L = ((280.460 + 0.9856474 * d) % 360 + 360) % 360;
  var g = deg2rad(((357.528 + 0.9856003 * d) % 360 + 360) % 360);
  var lambda = deg2rad(L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g));
  var eps = deg2rad(23.439 - 0.0000004 * d);
  var raRad = Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda));
  var decRad = Math.asin(Math.sin(eps) * Math.sin(lambda));
  return { raDeg: (rad2deg(raRad) + 360) % 360, decDeg: rad2deg(decRad) };
}

// Posicion geocentrica de la Luna (serie truncada Meeus/Chapront, terminos principales,
// precision visual ~0.3 grados) + fraccion iluminada real a partir de la elongacion Luna-Sol.
function moonEquatorialPosition(jd) {
  var d = jd - 2451545.0;
  var Lp = ((218.3164477 + 13.17639648 * d) % 360 + 360) % 360;
  var D  = ((297.8501921 + 12.19074912 * d) % 360 + 360) % 360;
  var M  = ((357.5291092 + 0.98560028  * d) % 360 + 360) % 360;
  var Mp = ((134.9633964 + 13.06499295 * d) % 360 + 360) % 360;
  var F  = ((93.2720950  + 13.22935024 * d) % 360 + 360) % 360;
  var rD = deg2rad(D), rM = deg2rad(M), rMp = deg2rad(Mp), rF = deg2rad(F);
  var dL = 6.289 * Math.sin(rMp) - 1.274 * Math.sin(2*rD - rMp) + 0.658 * Math.sin(2*rD)
    - 0.186 * Math.sin(rM) - 0.059 * Math.sin(2*rD - 2*rMp) - 0.057 * Math.sin(2*rD - rM - rMp)
    + 0.053 * Math.sin(2*rD + rMp) + 0.046 * Math.sin(2*rD - rM) - 0.041 * Math.sin(rM - rMp)
    - 0.035 * Math.sin(rD) - 0.031 * Math.sin(rM + rMp) - 0.015 * Math.sin(2*rF - 2*rD)
    + 0.011 * Math.sin(rMp - 4*rD);
  var dB = 5.128 * Math.sin(rF) + 0.281 * Math.sin(rMp + rF) + 0.278 * Math.sin(rMp - rF)
    + 0.173 * Math.sin(2*rD - rF) + 0.055 * Math.sin(2*rD - rMp + rF) + 0.046 * Math.sin(2*rD - rMp - rF)
    + 0.033 * Math.sin(2*rD + rF) + 0.017 * Math.sin(2*rD + rMp + rF);
  var lambda = deg2rad(Lp + dL);
  var beta = deg2rad(dB);
  var eps = deg2rad(23.439 - 0.0000004 * d);
  var decRad = Math.asin(Math.sin(beta) * Math.cos(eps) + Math.cos(beta) * Math.sin(eps) * Math.sin(lambda));
  var y = Math.sin(lambda) * Math.cos(eps) - Math.tan(beta) * Math.sin(eps);
  var x = Math.cos(lambda);
  var raRad = Math.atan2(y, x);
  var elongDeg = ((D % 360) + 360) % 360;
  var illumFrac = (1 - Math.cos(deg2rad(elongDeg))) / 2;
  return {
    raDeg: (rad2deg(raRad) + 360) % 360,
    decDeg: rad2deg(decRad),
    illumFrac: illumFrac,
    waxing: elongDeg < 180,
    elongDeg: elongDeg,
  };
}

function moonPhaseName(elongDeg, illumFrac) {
  if (illumFrac < 0.02) return "Luna nueva";
  if (illumFrac > 0.98) return "Luna llena";
  var waxing = elongDeg < 180;
  if (illumFrac < 0.48) return waxing ? "Luna creciente" : "Luna menguante";
  if (illumFrac > 0.52) return waxing ? "Luna gibosa (creciente)" : "Luna gibosa (menguante)";
  return waxing ? "Cuarto creciente" : "Cuarto menguante";
}

// Fecha/hora simulada para sincronizar Luna y estrellas con el ciclo dia/noche rapido (Sol en
// modo "cycle"): usa el dia de calendario real de hoy pero la hora avanza al ritmo del reloj
// interno del ciclo (dayCycleClock/dayCycleTotalSec) en vez del reloj real.
function simulatedSkyDate() {
  var dayLenSec = Math.max(10, (PROJECT.environment.dayDurationMin || 10) * 60);
  var daysElapsed = Math.floor(dayCycleTotalSec / dayLenSec);
  var fracDay = dayCycleClock / dayLenSec;
  var base = new Date();
  base.setHours(0, 0, 0, 0);
  return new Date(base.getTime() + daysElapsed * 86400000 + fracDay * 86400000);
}
// Devuelve la fecha/hora que debe usarse para calcular el cielo: manual fija, simulada del
// ciclo rapido (Sol en modo "cycle"), o la del sistema en cualquier otro caso.
function nightSkyDateForNow() {
  if (PROJECT.environment.skyDateMode === "manual" && PROJECT.environment.skyManualDate) {
    var dp = PROJECT.environment.skyManualDate.split("-").map(Number);
    var tp = (PROJECT.environment.skyManualTime || "22:00").split(":").map(Number);
    var utcMs = Date.UTC(dp[0] || 2000, (dp[1] || 1) - 1, dp[2] || 1, tp[0] || 0, tp[1] || 0, 0);
    var offset = PROJECT.environment.skyUtcOffsetHours != null ? PROJECT.environment.skyUtcOffsetHours : 1;
    return new Date(utcMs - offset * 3600000);
  }
  if (PROJECT.environment.sunMode === "cycle") return simulatedSkyDate();
  return new Date();
}

var nightSkyGroup = null, nightSkyStarLayers = [], nightSkyMoonMesh = null, nightSkyMoonLight = null;
var nightSkyStarDirCache = null;
var nightSkyMoonTexture = null, nightSkyMoonFallbackTexture = null;
var nightSkyClockAccum = 0, nightSkyLastCalcAt = -999;
var nightSkyLastPhaseName = "";
var nightSkyRotGroup = null;
var nightSkyRotDeltaQuat = new THREE.Quaternion();
var nightSkyRotJdAtRecalc = 0;
var NIGHT_SKY_ROT_EPS_JD = 1 / 86400;
var _nightSkyRotTmpQuat = new THREE.Quaternion();

function buildFallbackMoonTexture() {
  var c = document.createElement("canvas"); c.width = 256; c.height = 256;
  var ctx = c.getContext("2d");
  ctx.fillStyle = "#dcd7cc"; ctx.fillRect(0, 0, 256, 256);
  var blobs = [[80,70,40],[152,58,28],[192,140,32],[68,162,36],[128,192,24],[40,118,20],[210,90,18]];
  blobs.forEach(function (b) {
    var g = ctx.createRadialGradient(b[0], b[1], 0, b[0], b[1], b[2]);
    g.addColorStop(0, "rgba(88,86,90,.5)"); g.addColorStop(1, "rgba(88,86,90,0)");
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b[0], b[1], b[2], 0, Math.PI * 2); ctx.fill();
  });
  for (var i = 0; i < 160; i++) {
    var x = Math.random() * 256, y = Math.random() * 256, r = 1 + Math.random() * 3;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(55,55,60," + (0.12 + Math.random() * 0.25) + ")"; ctx.fill();
  }
  var tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace || tex.colorSpace;
  return tex;
}

function makeNightStarLayer(count, sizePx, color, opacity) {
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(count * 3), 3));
  var mat = new THREE.PointsMaterial({ color: color, size: sizePx, sizeAttenuation: false, transparent: true, opacity: opacity, depthWrite: false, fog: false });
  var pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  pts.userData.baseOpacity = opacity;
  return pts;
}

function buildNightSky() {
  nightSkyGroup = new THREE.Group();
  nightSkyGroup.renderOrder = -1000;
  nightSkyGroup.visible = false;

  nightSkyRotGroup = new THREE.Group();
  nightSkyGroup.add(nightSkyRotGroup);

  var realIdx = { bright: [], mid: [], dim: [] };
  for (var i = 0; i < NIGHT_SKY_STARS.length; i += 3) {
    var mag = NIGHT_SKY_STARS[i + 2];
    (mag <= 2.2 ? realIdx.bright : (mag <= 3.0 ? realIdx.mid : realIdx.dim)).push(i);
  }
  var fillerRaDec = [];
  var FILLER_COUNT = 2200;
  for (var f = 0; f < FILLER_COUNT; f++) {
    var ra = Math.random() * 360;
    var dec = rad2deg(Math.asin(Math.random() * 2 - 1));
    fillerRaDec.push(ra, dec);
  }

  var layerBright = makeNightStarLayer(realIdx.bright.length, 3.2, 0xfff3d8, 0.95);
  var layerMid    = makeNightStarLayer(realIdx.mid.length,    2.3, 0xeef2ff, 0.85);
  var layerDim    = makeNightStarLayer(realIdx.dim.length,    1.7, 0xd7dcf5, 0.7);
  var layerFiller = makeNightStarLayer(FILLER_COUNT,          1.1, 0xaab0cf, 0.45);
  layerBright.userData.starIdx = realIdx.bright;
  layerMid.userData.starIdx = realIdx.mid;
  layerDim.userData.starIdx = realIdx.dim;
  layerFiller.userData.fillerRaDec = fillerRaDec;
  nightSkyStarLayers = [layerBright, layerMid, layerDim, layerFiller];
  nightSkyStarLayers.forEach(function (l) { nightSkyRotGroup.add(l); });

  var moonGeo = new THREE.SphereGeometry(NIGHT_SKY_DOME_R * 0.045, 32, 32);
  nightSkyMoonFallbackTexture = buildFallbackMoonTexture();
  var moonMat = new THREE.ShaderMaterial({
    uniforms: {
      map: { value: nightSkyMoonFallbackTexture },
      uLightDir: { value: new THREE.Vector3(1, 0, 0) },
      uAmbient: { value: 0.15 },
      uOpacity: { value: 1 },
    },
    vertexShader: [
      "varying vec3 vNormalObj;",
      "varying vec2 vUv;",
      "void main() {",
      "  vNormalObj = normal;",
      "  vUv = uv;",
      "  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);",
      "}",
    ].join("\n"),
    fragmentShader: [
      "uniform sampler2D map;",
      "uniform vec3 uLightDir;",
      "uniform float uAmbient;",
      "uniform float uOpacity;",
      "varying vec3 vNormalObj;",
      "varying vec2 vUv;",
      "void main() {",
      "  vec3 n = normalize(vNormalObj);",
      "  float ndotl = max(dot(n, normalize(uLightDir)), 0.0);",
      "  float shade = uAmbient + (1.0 - uAmbient) * ndotl;",
      "  vec4 tex = texture2D(map, vUv);",
      "  gl_FragColor = vec4(tex.rgb * shade, tex.a * uOpacity);",
      "}",
    ].join("\n"),
    transparent: true,
    fog: false,
  });
  nightSkyMoonMesh = new THREE.Mesh(moonGeo, moonMat);
  if (PROJECT.environment.moonTextureBase64) {
    (function () {
      var img = new Image();
      img.onload = function () {
        var tex = new THREE.Texture(img);
        tex.needsUpdate = true;
        nightSkyMoonTexture = tex;
        moonMat.uniforms.map.value = tex;
      };
      img.src = PROJECT.environment.moonTextureBase64;
    })();
  }
  nightSkyRotGroup.add(nightSkyMoonMesh);

  scene.add(nightSkyGroup);
}

function setNightSkyOpacity(factor) {
  nightSkyStarLayers.forEach(function (l) { l.material.opacity = l.userData.baseOpacity * factor; });
  if (nightSkyMoonMesh) nightSkyMoonMesh.material.uniforms.uOpacity.value = clamp(factor * 1.4, 0, 1);
}

function placeStarLayerByIndices(layer, jd, lat, lon) {
  var idxs = layer.userData.starIdx;
  var arr = layer.geometry.attributes.position.array;
  var visible = 0;
  for (var k = 0; k < idxs.length; k++) {
    var i = idxs[k];
    var hz = equatorialToAltAz(NIGHT_SKY_STARS[i], NIGHT_SKY_STARS[i + 1], jd, lat, lon);
    if (hz.altDeg < -1) continue;
    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);
    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;
    visible++;
  }
  layer.geometry.setDrawRange(0, visible);
  layer.geometry.attributes.position.needsUpdate = true;
}

function placeFillerLayer(layer, jd, lat, lon) {
  var raDec = layer.userData.fillerRaDec;
  var arr = layer.geometry.attributes.position.array;
  var visible = 0;
  for (var k = 0; k < raDec.length; k += 2) {
    var hz = equatorialToAltAz(raDec[k], raDec[k + 1], jd, lat, lon);
    if (hz.altDeg < -1) continue;
    var p = sunPositionFromAngles(hz.altDeg, hz.azDeg, NIGHT_SKY_DOME_R);
    arr[visible * 3] = p.x; arr[visible * 3 + 1] = p.y; arr[visible * 3 + 2] = p.z;
    visible++;
  }
  layer.geometry.setDrawRange(0, visible);
  layer.geometry.attributes.position.needsUpdate = true;
}

function refreshNightSkyStarDirCache(jd, lat, lon) {
  if (!nightSkyStarDirCache || nightSkyStarDirCache.length !== NIGHT_SKY_STARS.length) nightSkyStarDirCache = new Float32Array(NIGHT_SKY_STARS.length);
  for (var si = 0; si < NIGHT_SKY_STARS.length; si += 3) {
    var shz = equatorialToAltAz(NIGHT_SKY_STARS[si], NIGHT_SKY_STARS[si + 1], jd, lat, lon);
    if (shz.altDeg < 0) { nightSkyStarDirCache[si] = NaN; nightSkyStarDirCache[si + 1] = NaN; nightSkyStarDirCache[si + 2] = NaN; continue; }
    var sp = sunPositionFromAngles(shz.altDeg, shz.azDeg, 1);
    nightSkyStarDirCache[si] = sp.x; nightSkyStarDirCache[si + 1] = sp.y; nightSkyStarDirCache[si + 2] = sp.z;
  }
}

function updateNightSkyRotationSample(jd, lat, lon) {
  var hz1 = equatorialToAltAz(0, 0, jd, lat, lon);
  var hz2 = equatorialToAltAz(0, 0, jd + NIGHT_SKY_ROT_EPS_JD, lat, lon);
  var p1 = sunPositionFromAngles(hz1.altDeg, hz1.azDeg, 1);
  var p2 = sunPositionFromAngles(hz2.altDeg, hz2.azDeg, 1);
  var v1 = new THREE.Vector3(p1.x, p1.y, p1.z).normalize();
  var v2 = new THREE.Vector3(p2.x, p2.y, p2.z).normalize();
  nightSkyRotDeltaQuat.setFromUnitVectors(v1, v2);
  nightSkyRotJdAtRecalc = jd;
  if (nightSkyRotGroup) nightSkyRotGroup.quaternion.identity();
}

function recomputeNightSkyPositions() {
  var when = nightSkyDateForNow();
  var jd = julianDateUTC(when);
  var lat = PROJECT.environment.latitudeDeg != null ? PROJECT.environment.latitudeDeg : 40;
  var lon = PROJECT.environment.skyLongitudeDeg != null ? PROJECT.environment.skyLongitudeDeg : 0;

  placeStarLayerByIndices(nightSkyStarLayers[0], jd, lat, lon);
  placeStarLayerByIndices(nightSkyStarLayers[1], jd, lat, lon);
  placeStarLayerByIndices(nightSkyStarLayers[2], jd, lat, lon);
  placeFillerLayer(nightSkyStarLayers[3], jd, lat, lon);

  refreshNightSkyStarDirCache(jd, lat, lon);
  updateNightSkyRotationSample(jd, lat, lon);

  var moonEq = moonEquatorialPosition(jd);
  var moonHz = equatorialToAltAz(moonEq.raDeg, moonEq.decDeg, jd, lat, lon);
  var moonPos = sunPositionFromAngles(moonHz.altDeg, moonHz.azDeg, NIGHT_SKY_DOME_R * 0.9);
  nightSkyMoonMesh.position.set(moonPos.x, moonPos.y, moonPos.z);
  nightSkyMoonMesh.visible = moonHz.altDeg > -2;

  // Orientacion real del disco: antes el mesh se quedaba siempre con la rotacion por defecto de
  // la esfera (un trozo arbitrario y fijo de la textura, sin relacion con la Luna real). Aqui se
  // gira para que el eje local +X (centro de la textura equirectangular, u=0.5 -- el punto
  // subterrestre medio, sin libracion) apunte hacia el observador, y el eje local +Y (borde
  // superior de la textura, v=0 -- el polo norte de la Luna) apunte hacia la proyeccion del polo
  // norte de la ecliptica sobre el disco visible. Con eso queda fijada tanto la cara que se ve
  // como la inclinacion/roll del disco respecto al horizonte (angulo paralactico), que antes no
  // se calculaba en absoluto. NOTA: no se invierte la U de la textura -- u=0 queda a la izquierda
  // tal cual viene la imagen equirectangular.
  var moonPoleHz = equatorialToAltAz(ECLIPTIC_POLE_RA_DEG, ECLIPTIC_POLE_DEC_DEG, jd, lat, lon);
  var moonPolePt = sunPositionFromAngles(moonPoleHz.altDeg, moonPoleHz.azDeg, 1);
  var moonLen = Math.sqrt(moonPos.x * moonPos.x + moonPos.y * moonPos.y + moonPos.z * moonPos.z) || 1;
  var moonToObsX = -moonPos.x / moonLen, moonToObsY = -moonPos.y / moonLen, moonToObsZ = -moonPos.z / moonLen;
  var moonPoleDot = moonPolePt.x * moonToObsX + moonPolePt.y * moonToObsY + moonPolePt.z * moonToObsZ;
  var moonUpX = moonPolePt.x - moonToObsX * moonPoleDot, moonUpY = moonPolePt.y - moonToObsY * moonPoleDot, moonUpZ = moonPolePt.z - moonToObsZ * moonPoleDot;
  var moonUpLen = Math.sqrt(moonUpX * moonUpX + moonUpY * moonUpY + moonUpZ * moonUpZ);
  if (moonUpLen > 1e-6) {
    moonUpX /= moonUpLen; moonUpY /= moonUpLen; moonUpZ /= moonUpLen;
    var moonRgX = moonToObsY * moonUpZ - moonToObsZ * moonUpY,
        moonRgY = moonToObsZ * moonUpX - moonToObsX * moonUpZ,
        moonRgZ = moonToObsX * moonUpY - moonToObsY * moonUpX;
    var moonBasis = new THREE.Matrix4().makeBasis(
      new THREE.Vector3(moonToObsX, moonToObsY, moonToObsZ),
      new THREE.Vector3(moonUpX, moonUpY, moonUpZ),
      new THREE.Vector3(moonRgX, moonRgY, moonRgZ)
    );
    nightSkyMoonMesh.quaternion.setFromRotationMatrix(moonBasis);
  }

  var sunEq = sunEquatorialPosition(jd);
  var sunHz = equatorialToAltAz(sunEq.raDeg, sunEq.decDeg, jd, lat, lon);
  var lightPos = sunPositionFromAngles(sunHz.altDeg, sunHz.azDeg, NIGHT_SKY_DOME_R * 0.9 + 40);
  var mdx = lightPos.x - moonPos.x, mdy = lightPos.y - moonPos.y, mdz = lightPos.z - moonPos.z;
  var mdLen = Math.sqrt(mdx * mdx + mdy * mdy + mdz * mdz) || 1;
  nightSkyMoonMesh.material.uniforms.uLightDir.value.set(mdx / mdLen, mdy / mdLen, mdz / mdLen);

  nightSkyLastPhaseName = moonPhaseName(moonEq.elongDeg, moonEq.illumFrac);

  meteorCurrentInfo = activeMeteorShowerNow(when);
}

// Se llama cada frame (editor y Modo jugar), igual que updateSunCycle(). Recoloca el domo sobre
// la camara (como un skybox) todos los frames, pero solo recalcula posiciones astronomicas una
// vez por segundo real -- el cielo tarda minutos en moverse de forma perceptible, así que no
// hace falta mas resolucion y se ahorra trigonometria de ~3000 puntos cada frame.
function updateNightSky(dt) {
  if (!nightSkyGroup) buildNightSky();
  nightSkyClockAccum += dt;
  var dirLen = dirLight.position.length() || 1;
  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));
  var nightFactor = nightTintFactorFromElevation(elevDeg);
  var enabled = !!PROJECT.environment.nightSkyEnabled;
  nightSkyGroup.visible = enabled && nightFactor > 0.015;
  if (!nightSkyGroup.visible) return;
  nightSkyGroup.position.copy(camera.position);
  setNightSkyOpacity(nightFactor);
  updateMeteorShowers(dt);
  if (nightSkyLastCalcAt < 0 || nightSkyClockAccum - nightSkyLastCalcAt >= 1) {
    nightSkyLastCalcAt = nightSkyClockAccum;
    recomputeNightSkyPositions();
  }
  if (nightSkyRotGroup && nightSkyLastCalcAt >= 0) {
    var jdNow = julianDateUTC(nightSkyDateForNow());
    var frac = (jdNow - nightSkyRotJdAtRecalc) / NIGHT_SKY_ROT_EPS_JD;
    if (frac < 0) frac = 0;
    _nightSkyRotTmpQuat.set(0, 0, 0, 1).slerp(nightSkyRotDeltaQuat, frac);
    nightSkyRotGroup.quaternion.copy(_nightSkyRotTmpQuat);
  }
}


/* =========================================================================
   IDENTIFICACION DE CONSTELACIONES CON EL PUNTERO (bóveda celeste, fase 2)
   ========================================================================= */
var skyPointerRaycaster = new THREE.Raycaster();
var SKY_POINTER_MAX_BLOCK_DIST = 80; // si hay algo mas cerca que esto en la mira, no se considera "cielo despejado"
var SKY_POINTER_TOLERANCE_DEG = 9; // cono de tolerancia alrededor de la mira para "enganchar" una constelacion
var skyPointerGroup = null;
var skyPointerClockAccum = 0, skyPointerLastCalcAt = -999;
var skyPointerCurrentConst = null;

function ensureSkyPointerGroup() {
  if (skyPointerGroup) return;
  skyPointerGroup = new THREE.Group();
  var mat = new THREE.LineBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, fog: false, depthWrite: false });
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(0), 3));
  var line = new THREE.LineSegments(geo, mat);
  line.frustumCulled = false;
  line.renderOrder = -998;
  skyPointerGroup.add(line);
  skyPointerGroup.userData.lineMesh = line;
  skyPointerGroup.visible = false;
  nightSkyGroup.add(skyPointerGroup);
}

// Busca, entre TODAS las lineas de las 88 constelaciones, la mas cercana angularmente a la
// direccion de mira (aimDir, vector unitario). Usa nightSkyStarDirCache (vectores unitarios ya
// calculados en el ultimo recalculo del cielo -- ver recomputeNightSkyPositions) para que esto
// sea barato (solo productos escalares, sin trigonometria) y pueda llamarse a cada rato mientras
// el jugador mueve la mira.
function findConstellationUnderAim(aimDir) {
  if (!nightSkyStarDirCache) return null;
  var thresholdDot = Math.cos(deg2rad(SKY_POINTER_TOLERANCE_DEG));
  var bestConst = null, bestDot = thresholdDot;
  for (var c = 0; c < NIGHT_SKY_CONSTELLATIONS.length; c++) {
    var con = NIGHT_SKY_CONSTELLATIONS[c];
    for (var s = 0; s < con.seg.length; s++) {
      var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;
      var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];
      if (da === da) {
        var dot1 = da * aimDir.x + db * aimDir.y + dc * aimDir.z;
        if (dot1 > bestDot) { bestDot = dot1; bestConst = con; }
      }
      var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];
      if (ea === ea) {
        var dot2 = ea * aimDir.x + eb * aimDir.y + ec * aimDir.z;
        if (dot2 > bestDot) { bestDot = dot2; bestConst = con; }
      }
    }
  }
  return bestConst;
}

function hideSkyPointerLabel() {
  var el = document.getElementById("constellationPrompt");
  if (el) el.style.display = "none";
}
function showSkyPointerLabel(text) {
  var el = document.getElementById("constellationPrompt");
  if (!el) return;
  el.textContent = "✨ " + text;
  el.style.display = "block";
}

function showSkyPointerConstellation(con) {
  ensureSkyPointerGroup();
  if (!con) {
    skyPointerGroup.visible = false;
    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }
    return;
  }
  if (skyPointerCurrentConst === con) { skyPointerGroup.visible = true; return; }
  skyPointerCurrentConst = con;
  var positions = [];
  for (var s = 0; s < con.seg.length; s++) {
    var ia = con.seg[s][0] * 3, ib = con.seg[s][1] * 3;
    var da = nightSkyStarDirCache[ia], db = nightSkyStarDirCache[ia + 1], dc = nightSkyStarDirCache[ia + 2];
    var ea = nightSkyStarDirCache[ib], eb = nightSkyStarDirCache[ib + 1], ec = nightSkyStarDirCache[ib + 2];
    if (da !== da || ea !== ea) continue;
    positions.push(da * NIGHT_SKY_DOME_R, db * NIGHT_SKY_DOME_R, dc * NIGHT_SKY_DOME_R);
    positions.push(ea * NIGHT_SKY_DOME_R, eb * NIGHT_SKY_DOME_R, ec * NIGHT_SKY_DOME_R);
  }
  var mesh = skyPointerGroup.userData.lineMesh;
  mesh.geometry.dispose();
  mesh.geometry = new THREE.BufferGeometry();
  mesh.geometry.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(positions), 3));
  skyPointerGroup.visible = true;
  showSkyPointerLabel(con.es);
}

// Se llama cada frame en Modo jugar. "active" es el estado del interruptor del puntero (la misma
// tecla L que ya existe: en el editor, el puntero láser multijugador; en el juego exportado, uno
// nuevo dedicado solo a esto, ya que el exportado no tiene multijugador). Con la mira despejada
// (nada de la escena más cerca que SKY_POINTER_MAX_BLOCK_DIST) y apuntando cerca de una figura de
// constelacion, la resalta y muestra su nombre -- como un puntero de clase de astronomia.
function updateSkyPointer(dt, active) {
  if (!nightSkyGroup) return;
  skyPointerClockAccum += dt;
  if (!active || !nightSkyGroup.visible) {
    if (skyPointerGroup && skyPointerGroup.visible) skyPointerGroup.visible = false;
    if (skyPointerCurrentConst) { skyPointerCurrentConst = null; hideSkyPointerLabel(); }
    return;
  }
  if (skyPointerLastCalcAt >= 0 && skyPointerClockAccum - skyPointerLastCalcAt < 0.15) return;
  skyPointerLastCalcAt = skyPointerClockAccum;

  var whenPtr = nightSkyDateForNow();
  var latPtr = PROJECT.environment.latitudeDeg != null ? PROJECT.environment.latitudeDeg : 40;
  var lonPtr = PROJECT.environment.skyLongitudeDeg != null ? PROJECT.environment.skyLongitudeDeg : 0;
  refreshNightSkyStarDirCache(julianDateUTC(whenPtr), latPtr, lonPtr);

  var aimDir = new THREE.Vector3();
  camera.getWorldDirection(aimDir);

  var blockTargets = [];
  sceneObjects.forEach(function (rec) {
    if (playerRecordId && rec.id === playerRecordId) return;
    if (rec.object3D) blockTargets.push(rec.object3D);
  });
  var blocked = false;
  if (blockTargets.length) {
    skyPointerRaycaster.set(camera.position, aimDir);
    skyPointerRaycaster.far = SKY_POINTER_MAX_BLOCK_DIST;
    blocked = skyPointerRaycaster.intersectObjects(blockTargets, true).length > 0;
  }
  if (blocked) { showSkyPointerConstellation(null); return; }
  showSkyPointerConstellation(findConstellationUnderAim(aimDir));
}


/* =========================================================================
   LLUVIAS DE METEOROS (bóveda celeste, fase 2)
   =========================================================================
   Tabla de las lluvias anuales principales (radiante RA/Dec aproximado y
   rango de fechas activo, valores estándar redondeados -- no cambian de un
   año a otro más que en un par de días). El ZHR (tasa horaria cenital) es
   orientativo, se usa solo para pesar unas lluvias frente a otras, no como
   dato de observación real.
*/
var METEOR_SHOWERS = [
  { name: "Cuadrántidas",   raDeg: 230, decDeg: 49, startMonth: 12, startDay: 28, endMonth: 1,  endDay: 12, peakMonth: 1,  peakDay: 3,  zhr: 110 },
  { name: "Líridas",        raDeg: 271, decDeg: 34, startMonth: 4,  startDay: 16, endMonth: 4,  endDay: 25, peakMonth: 4,  peakDay: 22, zhr: 18 },
  { name: "Eta Acuáridas",  raDeg: 338, decDeg: -1, startMonth: 4,  startDay: 19, endMonth: 5,  endDay: 28, peakMonth: 5,  peakDay: 5,  zhr: 50 },
  { name: "Perseidas",      raDeg: 46,  decDeg: 58, startMonth: 7,  startDay: 17, endMonth: 8,  endDay: 24, peakMonth: 8,  peakDay: 12, zhr: 100 },
  { name: "Oriónidas",      raDeg: 95,  decDeg: 16, startMonth: 10, startDay: 2,  endMonth: 11, endDay: 7,  peakMonth: 10, peakDay: 21, zhr: 20 },
  { name: "Leónidas",       raDeg: 152, decDeg: 22, startMonth: 11, startDay: 6,  endMonth: 11, endDay: 30, peakMonth: 11, peakDay: 18, zhr: 15 },
  { name: "Gemínidas",      raDeg: 112, decDeg: 33, startMonth: 12, startDay: 4,  endMonth: 12, endDay: 17, peakMonth: 12, peakDay: 14, zhr: 150 },
  { name: "Úrsidas",        raDeg: 217, decDeg: 75, startMonth: 12, startDay: 17, endMonth: 12, endDay: 26, peakMonth: 12, peakDay: 22, zhr: 10 },
];
var METEOR_RATE_SCALE = 4; // ajuste de juego: sube/baja lo seguido que se ven fugaces respecto al ZHR real
var METEOR_MAX_ACTIVE = 6;
var METEOR_DOME_R = NIGHT_SKY_DOME_R * 0.95;

function dayOfYearApprox(month, day) {
  var cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  return cum[(month | 0) - 1] + (day | 0);
}

// Devuelve la lluvia activa "ganadora" ahora mismo (la de mayor actividad ponderada por ZHR, si
// hay varias solapadas) y su tasa de aparicion por segundo para el juego, o null si no hay ninguna
// activa en la fecha actual del cielo.
function activeMeteorShowerNow(date) {
  var doy = dayOfYearApprox(date.getMonth() + 1, date.getDate());
  var best = null, bestWeighted = 0, bestActivity = 0;
  for (var i = 0; i < METEOR_SHOWERS.length; i++) {
    var sh = METEOR_SHOWERS[i];
    var s = dayOfYearApprox(sh.startMonth, sh.startDay);
    var e = dayOfYearApprox(sh.endMonth, sh.endDay);
    var p = dayOfYearApprox(sh.peakMonth, sh.peakDay);
    var inRange = s <= e ? (doy >= s && doy <= e) : (doy >= s || doy <= e);
    if (!inRange) continue;
    var span = s <= e ? (e - s) : (366 - s + e);
    var distToPeak = Math.min(Math.abs(doy - p), 366 - Math.abs(doy - p));
    var halfSpan = Math.max(1, span / 2);
    var activity = clamp(1 - distToPeak / halfSpan, 0, 1);
    var weighted = activity * sh.zhr;
    if (weighted > bestWeighted) { bestWeighted = weighted; best = sh; bestActivity = activity; }
  }
  if (!best) return null;
  var ratePerSecond = clamp((bestWeighted / 3600) * METEOR_RATE_SCALE, 0, 0.25);
  return { shower: best, activity: bestActivity, ratePerSecond: ratePerSecond };
}

var meteorPool = [];
var meteorCurrentInfo = null; // { shower, activity, ratePerSecond } o null, refrescado junto al resto del cielo

function meteorMaterial() {
  return new THREE.LineBasicMaterial({ color: 0xfff2cf, transparent: true, opacity: 0, fog: false, depthWrite: false });
}

function ensureMeteorPool() {
  if (meteorPool.length) return;
  for (var i = 0; i < METEOR_MAX_ACTIVE; i++) {
    var geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(6), 3));
    var mesh = new THREE.LineSegments(geo, meteorMaterial());
    mesh.frustumCulled = false;
    mesh.visible = false;
    nightSkyGroup.add(mesh);
    meteorPool.push({ mesh: mesh, age: 0, duration: 0.4, active: false });
  }
}

function spawnMeteor(radiantRaDeg, radiantDecDeg, jd, lat, lon) {
  var hz = equatorialToAltAz(radiantRaDeg, radiantDecDeg, jd, lat, lon);
  var radiantDir = new THREE.Vector3();
  if (hz.altDeg > -20) {
    var rp = sunPositionFromAngles(hz.altDeg, hz.azDeg, 1);
    radiantDir.set(rp.x, rp.y, rp.z);
  } else {
    return; // radiante muy por debajo del horizonte, no merece la pena (rara vez visible igualmente)
  }
  var free = null;
  for (var i = 0; i < meteorPool.length; i++) { if (!meteorPool[i].active) { free = meteorPool[i]; break; } }
  if (!free) return;

  var arbitrary = Math.abs(radiantDir.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
  var axis = new THREE.Vector3().crossVectors(radiantDir, arbitrary).normalize();
  axis.applyAxisAngle(radiantDir, Math.random() * Math.PI * 2);
  var startAngle = deg2rad(15 + Math.random() * 45);
  var streakAngle = deg2rad(5 + Math.random() * 8);
  var startDir = radiantDir.clone().applyAxisAngle(axis, startAngle);
  var endDir = radiantDir.clone().applyAxisAngle(axis, startAngle + streakAngle);
  if (startDir.y < -0.05 && endDir.y < -0.05) return; // por debajo del horizonte, no se ve

  var arr = free.mesh.geometry.attributes.position.array;
  arr[0] = startDir.x * METEOR_DOME_R; arr[1] = startDir.y * METEOR_DOME_R; arr[2] = startDir.z * METEOR_DOME_R;
  arr[3] = endDir.x * METEOR_DOME_R;   arr[4] = endDir.y * METEOR_DOME_R;   arr[5] = endDir.z * METEOR_DOME_R;
  free.mesh.geometry.attributes.position.needsUpdate = true;
  free.mesh.visible = true;
  free.age = 0;
  free.duration = 0.35 + Math.random() * 0.25;
  free.active = true;
}

// Se llama cada frame desde updateNightSky(). La tasa de aparicion (meteorCurrentInfo) solo se
// recalcula una vez por segundo junto al resto del cielo (ver recomputeNightSkyPositions); aqui
// solo se tira "el dado" de aparicion (proceso de Poisson: probabilidad = tasa * dt) y se anima
// el desvanecido de las fugaces ya lanzadas.
function updateMeteorShowers(dt) {
  ensureMeteorPool();
  if (meteorCurrentInfo && meteorCurrentInfo.ratePerSecond > 0 && Math.random() < meteorCurrentInfo.ratePerSecond * dt) {
    var when = nightSkyDateForNow();
    var jd = julianDateUTC(when);
    var lat = sceneEnvironment.latitudeDeg != null ? sceneEnvironment.latitudeDeg : 40;
    var lon = sceneEnvironment.skyLongitudeDeg != null ? sceneEnvironment.skyLongitudeDeg : 0;
    spawnMeteor(meteorCurrentInfo.shower.raDeg, meteorCurrentInfo.shower.decDeg, jd, lat, lon);
  }
  for (var i = 0; i < meteorPool.length; i++) {
    var m = meteorPool[i];
    if (!m.active) continue;
    m.age += dt;
    var p = m.age / m.duration;
    if (p >= 1) { m.active = false; m.mesh.visible = false; continue; }
    var op = p < 0.15 ? (p / 0.15) : (1 - (p - 0.15) / 0.85);
    m.mesh.material.opacity = clamp(op, 0, 1);
  }
}


/* =========================================================================
   GRILLO NOCTURNO -- canto sintetizado por código (bóveda celeste, fase 2)
   ========================================================================= */
var cricketAudioCtx = null;
var cricketNextChirpMap = new Map(); // id de objeto -> proximo instante (AudioContext.currentTime) de canto
var CRICKET_MAX_SOUNDING = 8;
var CRICKET_HEAR_DIST = 14;

function ensureCricketAudioCtx() {
  if (cricketAudioCtx) return cricketAudioCtx;
  try {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    cricketAudioCtx = new Ctx();
  } catch (e) { cricketAudioCtx = null; }
  return cricketAudioCtx;
}

// Un "canto" de grillo real es un tren de 2-4 pulsos muy cortos y agudos (estridulación). Se
// sintetiza con osciladores cuadrados de vida brevísima -- nada de archivos de audio.
function playCricketChirp(ctx, vol) {
  var now = ctx.currentTime;
  var pulses = 2 + (Math.random() < 0.5 ? 0 : 1);
  for (var p = 0; p < pulses; p++) {
    var t0 = now + p * 0.03;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = "square";
    osc.frequency.value = 4200 + (Math.random() * 300 - 150);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(vol, t0 + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0005, t0 + 0.022);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(t0); osc.stop(t0 + 0.03);
  }
}

// Se llama cada frame (editor y Modo jugar), igual que updateWeatherSystems(). Recorre los objetos
// de la escena buscando prefabs "grillo" visibles; a los que les toque cantar (según su propio
// reloj individual, con algo de aleatoriedad para que no canten todos a la vez) les hace sonar un
// canto con el volumen segun distancia a la camara -- silencioso de dia.
function updateCricketSounds(dt) {
  var dirLen = dirLight.position.length() || 1;
  var elevDeg = rad2deg(Math.asin(clamp(dirLight.position.y / dirLen, -1, 1)));
  var nightFactor = nightTintFactorFromElevation(elevDeg);
  if (nightFactor < 0.2) return;
  var ctx = ensureCricketAudioCtx();
  if (!ctx) return;
  if (ctx.state === "suspended") { ctx.resume().catch(function () {}); }
  var listenerPos = camera.position;
  var sounded = 0;
  var worldPos = new THREE.Vector3();
  sceneObjects.forEach(function (rec) {
    if (sounded >= CRICKET_MAX_SOUNDING) return;
    if (rec.prefabType !== "grillo" || !rec.object3D || !rec.object3D.visible) return;
    var id = rec.id;
    var next = cricketNextChirpMap.get(id);
    if (next == null) { next = ctx.currentTime + Math.random() * 1.5; cricketNextChirpMap.set(id, next); }
    if (ctx.currentTime < next) return;
    rec.object3D.getWorldPosition(worldPos);
    var dist = listenerPos.distanceTo(worldPos);
    cricketNextChirpMap.set(id, ctx.currentTime + 0.6 + Math.random() * 0.9);
    if (dist > CRICKET_HEAR_DIST) return;
    var vol = clamp(1 - dist / CRICKET_HEAR_DIST, 0, 1) * 0.14 * nightFactor;
    if (vol < 0.003) return;
    playCricketChirp(ctx, vol);
    sounded++;
  });
}

function makeStdMat(colorHex){ return new THREE.MeshStandardMaterial({ color: colorHex, roughness:0.85, metalness:0.05, transparent:true, opacity:1, side:THREE.DoubleSide }); }
function addPart(group, mats, geo, color, x,y,z, rx,ry,rz){
  var mat = makeStdMat(color); mats.push(mat);
  var mesh = new THREE.Mesh(geo, mat); mesh.position.set(x,y,z);
  if(rx) mesh.rotation.x=rx; if(ry) mesh.rotation.y=ry; if(rz) mesh.rotation.z=rz;
  mesh.castShadow=true; mesh.receiveShadow=true; group.add(mesh); return mesh;
}
function createPrimitive(kind){
  var geo; var liftY=0.5;
  if(kind==="box") geo=new THREE.BoxGeometry(1,1,1);
  else if(kind==="sphere"){ geo=new THREE.SphereGeometry(0.6,24,16); liftY=0.6; }
  else if(kind==="cylinder") geo=new THREE.CylinderGeometry(0.5,0.5,1,24);
  else if(kind==="cone") geo=new THREE.ConeGeometry(0.5,1,24);
  else if(kind==="plane"){ geo=new THREE.PlaneGeometry(1.2,1.2); liftY=0; }
  else geo=new THREE.BoxGeometry(1,1,1);
  var mat=makeStdMat(0x8f97a8);
  var mesh=new THREE.Mesh(geo,mat); mesh.castShadow=true; mesh.receiveShadow=true;
  if(kind==="plane") mesh.rotation.x=-Math.PI/2;
  var group=new THREE.Group(); group.add(mesh); group.position.y=liftY;
  return { object3D:group, colorMaterials:[mat] };
}

function createPrefab(kind){
  var group=new THREE.Group(); var mats=[];
  var box=function(w,h,d){ return new THREE.BoxGeometry(w,h,d); };
  var cyl=function(rt,rb,h,seg){ return new THREE.CylinderGeometry(rt,rb,h,seg||16); };
  switch(kind){
    case "mesa":
      addPart(group,mats,box(1.2,0.06,0.7),0xb98a56,0,0.75,0);
      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,-0.55,0.375,-0.3);
      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,0.55,0.375,-0.3);
      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,-0.55,0.375,0.3);
      addPart(group,mats,box(0.06,0.75,0.06),0x5b3f28,0.55,0.375,0.3);
      break;
    case "silla":
      addPart(group,mats,box(0.45,0.06,0.45),0x6b7280,0,0.45,0);
      addPart(group,mats,box(0.45,0.5,0.06),0x6b7280,0,0.7,-0.2);
      addPart(group,mats,box(0.04,0.45,0.04),0x374151,-0.18,0.22,-0.18);
      addPart(group,mats,box(0.04,0.45,0.04),0x374151,0.18,0.22,-0.18);
      addPart(group,mats,box(0.04,0.45,0.04),0x374151,-0.18,0.22,0.18);
      addPart(group,mats,box(0.04,0.45,0.04),0x374151,0.18,0.22,0.18);
      break;
    case "escalera":
      addPart(group,mats,box(0.06,2,0.06),0xd9a441,-0.3,1,0);
      addPart(group,mats,box(0.06,2,0.06),0xd9a441,0.3,1,0);
      for(var i=0;i<6;i++) addPart(group,mats,box(0.66,0.05,0.06),0xd9a441,0,0.25+i*0.32,0);
      break;
    case "palet":
      addPart(group,mats,box(1,0.12,1.2),0x9c7b4f,0,0.06,0);
      for(var j=-1;j<=1;j++) addPart(group,mats,box(0.9,0.03,0.12),0x8a6a41,0,0.14,j*0.5);
      break;
    case "valla":
      addPart(group,mats,box(0.08,1,0.08),0xd9a441,-0.9,0.5,0);
      addPart(group,mats,box(0.08,1,0.08),0xd9a441,0.9,0.5,0);
      addPart(group,mats,box(1.9,0.08,0.08),0xe2434b,0,0.85,0);
      addPart(group,mats,box(1.9,0.08,0.08),0xffffff,0,0.55,0);
      break;
    case "extintor":
      addPart(group,mats,cyl(0.12,0.12,0.55,16),0xd21f2b,0,0.4,0);
      addPart(group,mats,cyl(0.03,0.05,0.15,12),0x2b2b2b,0,0.72,0);
      addPart(group,mats,box(0.16,0.04,0.06),0x2b2b2b,0,0.66,0.09);
      break;
    case "cable_suelto": {
      var segColor=0xff6b35;
      var pts=[[-0.6,-0.05],[-0.2,0.08],[0.15,-0.06],[0.5,0.04]];
      for(var k=0;k<pts.length-1;k++){
        var x1=pts[k][0], z1=pts[k][1], x2=pts[k+1][0], z2=pts[k+1][1];
        var dx=x2-x1, dz=z2-z1, len=Math.sqrt(dx*dx+dz*dz), ang=Math.atan2(dz,dx);
        addPart(group,mats,box(len,0.03,0.03),segColor,(x1+x2)/2,0.02,(z1+z2)/2,0,-ang,0);
      }
      break;
    }
    case "grillo": {
      var body = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), makeStdMat(0x2b2016));
      body.scale.set(1, 0.75, 1.6); body.position.set(0, 0.035, 0);
      body.castShadow = true; body.receiveShadow = true;
      mats.push(body.material); group.add(body);
      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, 0.015, 0.06, -0.05, 1.1, 0, 0.4);
      addPart(group, mats, new THREE.CylinderGeometry(0.003, 0.003, 0.08, 4), 0x2b2016, -0.015, 0.06, -0.05, 1.1, 0, -0.4);
      colliderSize = { x: 0.12, y: 0.08, z: 0.18 };
      break;
    }
    case "charco": {
      var matC=makeStdMat(0x3aa0ff); matC.opacity=0.55; mats.push(matC);
      var meshC=new THREE.Mesh(new THREE.CircleGeometry(0.55,24), matC);
      meshC.rotation.x=-Math.PI/2; meshC.position.y=0.011; meshC.receiveShadow=true;
      group.add(meshC);
      break;
    }
    case "personaje": {
      addPart(group,mats,new THREE.CapsuleGeometry(0.22,0.65,6,12),0x4fd1c5,0,0.55,0);
      addPart(group,mats,new THREE.SphereGeometry(0.15,16,12),0xf2c9a0,0,1.02,0);
      addPart(group,mats,box(0.3,0.22,0.05),0xff9f1c,0,0.62,0.19);
      break;
    }
    case "tablon": {
      addPart(group,mats,box(0.06,1.4,0.06),0x6b4a2b,-0.55,0.7,0);
      addPart(group,mats,box(0.06,1.4,0.06),0x6b4a2b,0.55,0.7,0);
      addPart(group,mats,box(1.3,0.9,0.05),0x8a6a41,0,1.1,0);
      addPart(group,mats,box(0.5,0.32,0.01),0xf0e6d2,-0.32,1.3,0.03);
      addPart(group,mats,box(0.5,0.32,0.01),0xf0e6d2,0.32,1.05,0.03);
      break;
    }
    case "papel": {
      addPart(group,mats,box(0.28,0.01,0.38),0xf5f0e4,0,0.02,0);
      break;
    }
    case "cajon": {
      addPart(group,mats,box(0.6,0.5,0.5),0x6b7280,0,0.25,0);
      addPart(group,mats,box(0.56,0.16,0.03),0x4b5563,0,0.35,0.26);
      addPart(group,mats,cyl(0.015,0.015,0.1,8),0x2b2b2b,0,0.35,0.3,Math.PI/2);
      break;
    }
    default:
      addPart(group,mats,box(1,1,1),0x8f97a8,0,0.5,0);
  }
  return { object3D:group, colorMaterials:mats };
}

var gltfLoader = new GLTFLoader();
function collectGltfColorMaterials(inner){
  var mats = [];
  inner.traverse(function(o){
    if(o.isMesh && o.material){
      var ms = Array.isArray(o.material) ? o.material : [o.material];
      ms.forEach(function(m){
        m.transparent = true;
        if(mats.indexOf(m)===-1) mats.push(m);
      });
    }
  });
  return mats;
}
function computeModelBounds(inner, mixer, clips){
  var hasSkinned = false;
  inner.traverse(function(o){ if(o.isSkinnedMesh) hasSkinned = true; });
  if(!hasSkinned || !mixer || !clips || !clips.length){
    return new THREE.Box3().setFromObject(inner);
  }
  var box = new THREE.Box3();
  inner.updateMatrixWorld(true);
  var action = mixer.clipAction(clips[0]);
  action.play();
  var steps = 12;
  var dur = clips[0].duration || 0;
  for(var i=0; i<=steps; i++){
    mixer.setTime(dur*i/steps);
    inner.updateMatrixWorld(true);
    inner.traverse(function(o){
      if(o.isSkinnedMesh && o.skeleton){
        o.skeleton.bones.forEach(function(b){ box.expandByPoint(b.getWorldPosition(new THREE.Vector3())); });
      }
    });
  }
  mixer.setTime(0);
  action.stop();
  mixer.update(0);
  if(box.isEmpty()) return new THREE.Box3().setFromObject(inner);
  box.expandByScalar(0.15);
  return box;
}
var sceneObjects = new Map();
var sceneOrder = [];
var objectGroups = new Map();
var playerRecordId = null;

function recomputeCheckpoints(rec){
  var originPos = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.pos.clone() : rec.object3D.position.clone();
  var originQuat = rec.object3D.userData.__origin ? rec.object3D.userData.__origin.quat.clone() : rec.object3D.quaternion.clone();
  if(!rec.object3D.userData.__origin) rec.object3D.userData.__origin = { pos: originPos.clone(), quat: originQuat.clone() };
  var cps = [{ t:0, pos:originPos.clone(), quat:originQuat.clone(), opacity:(rec.opacity!=null?rec.opacity:1), ease:"linear", flashDef:null }];
  for(var i=0;i<rec.actions.length;i++){
    var a = rec.actions[i];
    var prev = cps[cps.length-1];
    var dur = a.duration || 0;
    var next = { t:prev.t+dur, pos:prev.pos.clone(), quat:prev.quat.clone(), opacity:prev.opacity, ease:a.ease||"linear", flashDef:null };
    if(a.type==="moveTo"){
      if(a.relative) next.pos.copy(originPos).add(new THREE.Vector3(a.to.x,a.to.y,a.to.z));
      else next.pos.set(a.to.x,a.to.y,a.to.z);
    }
    if(a.type==="rotateTo"){
      if(a.relative){
        var oe = new THREE.Euler().setFromQuaternion(originQuat);
        next.quat.setFromEuler(new THREE.Euler(oe.x+deg2rad(a.to.x), oe.y+deg2rad(a.to.y), oe.z+deg2rad(a.to.z)));
      } else {
        next.quat.setFromEuler(new THREE.Euler(deg2rad(a.to.x),deg2rad(a.to.y),deg2rad(a.to.z)));
      }
    }
    if(a.type==="fade") next.opacity = a.to;
    if(a.type==="flash") next.flashDef = { color:a.color, repeat:a.repeat||3 };
    cps.push(next);
  }
  rec.checkpoints = cps;
  rec.totalDuration = cps[cps.length-1].t;
}

function evaluateRecord(rec, t){
  var cps = rec.checkpoints;
  if(!cps || cps.length<2) return null;
  var last = cps[cps.length-1].t;
  var tt = clamp(t,0,last||0);
  var i=0;
  while(i<cps.length-2 && cps[i+1].t < tt) i++;
  var segStart=cps[i], segEnd=cps[i+1];
  var segDur=(segEnd.t-segStart.t)||1e-6;
  var p = clamp((tt-segStart.t)/segDur,0,1);
  var pe = easeVal(p, segEnd.ease);
  var pos = segStart.pos.clone().lerp(segEnd.pos, pe);
  var quat = segStart.quat.clone().slerp(segEnd.quat, pe);
  var opacity = lerp(segStart.opacity, segEnd.opacity, pe);
  var flashIntensity=0, flashColor=null;
  if(segEnd.flashDef){ flashIntensity=Math.abs(Math.sin(p*Math.PI*segEnd.flashDef.repeat)); flashColor=segEnd.flashDef.color; }
  return { pos:pos, quat:quat, opacity:opacity, flashIntensity:flashIntensity, flashColor:flashColor };
}

var timelineDuration = 0.01;
function recomputeTimelineDuration(){
  var max=0;
  sceneObjects.forEach(function(rec){ max = Math.max(max, rec.totalDuration||0); });
  timelineDuration = Math.max(max, 0.01);
  recomputeChainTriggers();
}
var chainTriggers = [];
function recomputeChainTriggers(){
  var triggers = [];
  sceneObjects.forEach(function(rec){
    if(!rec.checkpoints) return;
    rec.actions.forEach(function(a, i){
      if(!a || !rec.checkpoints[i+1]) return;
      if(a.type === "setVariable" || a.type === "fetchUrl" || a.type === "copyToClipboard" || a.type === "if" || a.type === "for" || a.type === "screenMessage" || a.type === "askInput" || a.type === "setImageVar" || a.type === "setTextVar") triggers.push({ time: rec.checkpoints[i+1].t, chainRec: rec, action: a });
      if(a.next) triggers.push({ time: rec.checkpoints[i+1].t, chainRec: rec, action: a.next });
    });
  });
  triggers.sort(function(a,b){ return a.time - b.time; });
  chainTriggers = triggers;
}
function fireDueChainTriggers(fromT, toT){
  if(!chainTriggers.length) return;
  if(toT >= fromT){
    chainTriggers.forEach(function(tr){ if(tr.time > fromT && tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });
  } else {
    chainTriggers.forEach(function(tr){ if(tr.time > fromT || tr.time <= toT) triggerOneShotAction(tr.chainRec, tr.action); });
  }
}

var overlapState = new Map();
var eventCallback = null;
function runCollisionChecks(){
  var chars=[], zones=[];
  sceneObjects.forEach(function(rec){
    if(rec.collider.kind==="character") chars.push(rec);
    if(rec.collider.kind==="zone") zones.push(rec);
  });
  chars.forEach(function(c){
    var cPos = new THREE.Vector3(); c.object3D.getWorldPosition(cPos);
    var cBox = new THREE.Box3().setFromCenterAndSize(cPos, new THREE.Vector3(c.collider.size.x,c.collider.size.y,c.collider.size.z));
    zones.forEach(function(z){
      var zPos = new THREE.Vector3(); z.object3D.getWorldPosition(zPos);
      var zBox = new THREE.Box3().setFromCenterAndSize(zPos, new THREE.Vector3(z.collider.size.x,z.collider.size.y,z.collider.size.z));
      var overlapping = cBox.intersectsBox(zBox);
      var key = c.id+"|"+z.id;
      var was = overlapState.get(key) || false;
      if(overlapping && !was && eventCallback) eventCallback((z.collider.riskLabel||"Riesgo") + " - " + c.name + " entra en " + z.name);
      overlapState.set(key, overlapping);
    });
  });
}

function applyTimeToScene(t, excludeId){
  sceneObjects.forEach(function(rec){
    if(excludeId && rec.id===excludeId) return;
    var ev = evaluateRecord(rec, t);
    if(!ev) return;
    rec.object3D.position.copy(ev.pos);
    rec.object3D.quaternion.copy(ev.quat);
    rec.colorMaterials.forEach(function(m){ m.opacity=ev.opacity; m.visible = ev.opacity>0.01; });
    if(ev.flashIntensity>0.02 && rec.colorMaterials.length){
      var c=new THREE.Color(ev.flashColor||"#ff3b3b");
      rec.colorMaterials.forEach(function(m){ m.emissive=c; m.emissiveIntensity=ev.flashIntensity; });
    } else if(rec.colorMaterials.length){
      rec.colorMaterials.forEach(function(m){ if(m.emissiveIntensity) m.emissiveIntensity=0; });
    }
  });
  runCollisionChecks();
}

function medirLineasTexto(ctx, text, maxWidth){
  var parrafos = (text||"").split("\n");
  var lines = [];
  for(var p=0;p<parrafos.length;p++){
    var words = parrafos[p].split(/\s+/).filter(Boolean);
    if(!words.length){ lines.push(""); continue; }
    var line = "";
    for(var i=0;i<words.length;i++){
      var w = words[i];
      var test = line ? line+" "+w : w;
      if(ctx.measureText(test).width > maxWidth && line){ lines.push(line); line=w; } else line=test;
    }
    if(line) lines.push(line);
  }
  if(!lines.length) lines.push("");
  return lines;
}
function buildText3DTexture(text, color, boxWidth){
  var FONT_PX=56, LINE_HEIGHT=64, PADDING=20;
  var anchoLinea = Math.max(60, boxWidth || 472);
  var medir = document.createElement("canvas").getContext("2d");
  medir.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";
  var lines = medirLineasTexto(medir, text||"Texto", anchoLinea);
  var canvas = document.createElement("canvas");
  canvas.width = Math.ceil(anchoLinea + PADDING*2);
  canvas.height = Math.ceil(lines.length*LINE_HEIGHT + PADDING*2);
  var ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = color || "#ffffff";
  ctx.font = "bold " + FONT_PX + "px -apple-system, Arial, sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  var startY = canvas.height/2 - ((lines.length-1)*LINE_HEIGHT)/2;
  for(var j=0;j<lines.length;j++) ctx.fillText(lines[j], canvas.width/2, startY + j*LINE_HEIGHT);
  var texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  var REF_LINE_CANVAS_PX = LINE_HEIGHT + PADDING*2;
  return { texture: texture, aspect: canvas.width/REF_LINE_CANVAS_PX, heightFactor: canvas.height/REF_LINE_CANVAS_PX };
}
function buildLightObject(lightData){
  var ld = Object.assign({ color:"#fff2cc", intensity:1.2, distance:8, castShadow:false }, lightData||{});
  var light = new THREE.PointLight(new THREE.Color(ld.color), ld.intensity, ld.distance, 2);
  light.castShadow = !!ld.castShadow;
  if(light.castShadow) light.shadow.mapSize.set(512,512);
  return { object3D:light, colorMaterials:[] };
}
var WEATHER_TYPES = {
  rain_light: { count:220, fallSpeed:9,  color:"#9fc6ff", size:0.045, opacity:0.5,  driftX:0.4, driftZ:0.1, kind:"rain" },
  rain_heavy: { count:600, fallSpeed:14, color:"#bcdcff", size:0.05,  opacity:0.62, driftX:0.9, driftZ:0.2, kind:"rain" },
  storm:      { count:650, fallSpeed:15, color:"#cfe3ff", size:0.05,  opacity:0.65, driftX:1.7, driftZ:0.4, kind:"rain", lightning:true },
  hail:       { count:200, fallSpeed:16, color:"#eef3fb", size:0.11,  opacity:0.85, driftX:0.6, driftZ:0.2, kind:"rain" },
  snow_light: { count:170, fallSpeed:1.6,color:"#ffffff", size:0.09,  opacity:0.85, driftX:0.5, driftZ:0.5, kind:"snow" },
  snow_heavy: { count:480, fallSpeed:3.2,color:"#ffffff", size:0.1,   opacity:0.9,  driftX:2.2, driftZ:1.4, kind:"snow" },
};
var WEATHER_AREA_RADIUS = 10, WEATHER_AREA_HEIGHT = 16;
function buildWeatherObject(weatherData){
  var wd = Object.assign({ type:"rain_light" }, weatherData||{});
  var cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;
  var count = cfg.count;
  var positions = new Float32Array(count*3);
  var speeds = new Float32Array(count);
  var phases = new Float32Array(count);
  for(var i=0;i<count;i++){
    positions[i*3+0] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;
    positions[i*3+1] = Math.random() * WEATHER_AREA_HEIGHT;
    positions[i*3+2] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;
    speeds[i] = 0.75 + Math.random()*0.5;
    phases[i] = Math.random() * Math.PI * 2;
  }
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  var mat = new THREE.PointsMaterial({ color:new THREE.Color(cfg.color), size:cfg.size, transparent:true, opacity:cfg.opacity, depthWrite:false, sizeAttenuation:true });
  var points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  var group = new THREE.Group();
  group.add(points);
  group.userData.__weatherPoints = points;
  group.userData.__weatherSpeeds = speeds;
  group.userData.__weatherPhases = phases;
  group.userData.__weatherFlashTimer = 0;
  group.userData.__weatherNextFlash = 2 + Math.random()*4;
  group.userData.__weatherFlashActive = 0;
  return { object3D:group, colorMaterials:[mat], weatherData: wd };
}
var lightningLight = null;
function ensureLightningLight(){
  if(!lightningLight){
    lightningLight = new THREE.PointLight(0xdfe8ff, 0, 80, 1.5);
    lightningLight.position.set(0, 25, 0);
    scene.add(lightningLight);
  }
  return lightningLight;
}
var sharedWeatherAudioCtx = null;
function playThunderSound(){
  try {
    var AC = window.AudioContext || window.webkitAudioContext;
    if(!AC) return;
    if(!sharedWeatherAudioCtx) sharedWeatherAudioCtx = new AC();
    var ctx = sharedWeatherAudioCtx;
    var dur = 1.4;
    var buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate*dur), ctx.sampleRate);
    var data = buffer.getChannelData(0);
    for(var i=0;i<data.length;i++) data[i] = (Math.random()*2-1) * Math.pow(1 - i/data.length, 1.6);
    var src = ctx.createBufferSource();
    src.buffer = buffer;
    var filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1200, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + dur);
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.7, ctx.currentTime + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    src.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
    var delay = 0.25 + Math.random()*1.2;
    src.start(ctx.currentTime + delay);
  } catch(e) { /* WebAudio no disponible/bloqueado: sin sonido, sin romper nada */ }
}
function updateStormLightning(rec, dt){
  var ud = rec.object3D.userData;
  var light = ensureLightningLight();
  if(ud.__weatherFlashActive > 0){
    ud.__weatherFlashActive -= dt;
    light.intensity = Math.max(0, ud.__weatherFlashActive) * 14;
    if(ud.__weatherFlashActive <= 0){ ud.__weatherFlashActive = 0; light.intensity = 0; }
    return;
  }
  ud.__weatherFlashTimer += dt;
  if(ud.__weatherFlashTimer >= ud.__weatherNextFlash){
    ud.__weatherFlashTimer = 0;
    ud.__weatherNextFlash = 4 + Math.random()*9;
    ud.__weatherFlashActive = 0.12 + Math.random()*0.08;
    light.intensity = 14;
    playThunderSound();
  }
}
function updateWeatherSystems(dt){
  var t = performance.now() / 1000;
  sceneObjects.forEach(function(rec){
    if(rec.kind !== "weather" || !rec.object3D.visible) return;
    var points = rec.object3D.userData.__weatherPoints;
    if(!points) return;
    var wd = rec.weatherData || { type:"rain_light" };
    var cfg = WEATHER_TYPES[wd.type] || WEATHER_TYPES.rain_light;
    var pos = points.geometry.attributes.position.array;
    var speeds = rec.object3D.userData.__weatherSpeeds;
    var phases = rec.object3D.userData.__weatherPhases;
    var count = pos.length/3;
    var isSnow = cfg.kind === "snow";
    for(var i=0;i<count;i++){
      var idx = i*3;
      pos[idx+1] -= cfg.fallSpeed * speeds[i] * dt;
      pos[idx+0] += cfg.driftX * dt * (isSnow ? Math.sin(t+phases[i]) : 1);
      pos[idx+2] += cfg.driftZ * dt * (isSnow ? Math.cos(t*0.7+phases[i]) : 1);
      if(pos[idx+1] < 0){
        pos[idx+1] = WEATHER_AREA_HEIGHT;
        pos[idx+0] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;
        pos[idx+2] = (Math.random()*2-1) * WEATHER_AREA_RADIUS;
      }
      var lim = WEATHER_AREA_RADIUS * 1.3;
      if(pos[idx+0] > lim) pos[idx+0] = -lim; else if(pos[idx+0] < -lim) pos[idx+0] = lim;
      if(pos[idx+2] > lim) pos[idx+2] = -lim; else if(pos[idx+2] < -lim) pos[idx+2] = lim;
    }
    points.geometry.attributes.position.needsUpdate = true;
    if(cfg.lightning) updateStormLightning(rec, dt);
  });
}
function buildText3DObject(text, color, size, boxWidth){
  var built = buildText3DTexture(text, color, boxWidth);
  var mat = new THREE.MeshBasicMaterial({ map:built.texture, transparent:true, side:THREE.DoubleSide, opacity:1, polygonOffset:true, polygonOffsetFactor:-4, polygonOffsetUnits:-4 });
  mat.alphaTest = 0.5;
  var s = size || 1;
  var mesh = new THREE.Mesh(new THREE.PlaneGeometry(built.aspect*s, built.heightFactor*s), mat);
  var group = new THREE.Group(); group.add(mesh); group.position.y = 1.2;
  return { object3D:group, colorMaterials:[mat], mesh:mesh };
}
function buildImagePlaneObject(dataUrl, height, onReady){
  var img = new Image();
  img.onload = function(){
    var texture = new THREE.Texture(img); texture.needsUpdate = true;
    var aspect = (img.width/img.height) || 1;
    var h = height || 1.5;
    var w = h*aspect;
    var mat = new THREE.MeshBasicMaterial({ map:texture, transparent:true, side:THREE.DoubleSide });
    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;
    mat.alphaTest = 0.5;
    var mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,h), mat);
    var group = new THREE.Group(); group.add(mesh); group.position.y = h/2;
    onReady({ object3D:group, colorMaterials:[mat], mesh:mesh, aspect:aspect });
  };
  img.onerror = function(){ onReady(null); };
  img.src = dataUrl;
}
function swapImageTexture(rec, dataUrl, onDone){
  buildImagePlaneObject(dataUrl, null, function(built){
    if(!built){ if(onDone) onDone(false); return; }
    var mesh = rec.object3D.children[0];
    mesh.geometry.dispose();
    if(mesh.material.map) mesh.material.map.dispose();
    mesh.material.dispose();
    mesh.geometry = built.mesh.geometry;
    mesh.material = built.mesh.material;
    rec.colorMaterials = [mesh.material];
    rec.imageBase64 = dataUrl;
    if(onDone) onDone(true);
  });
}
function buildVideoPlaneObject(dataUrl, height, onReady){
  var videoEl = document.createElement("video");
  videoEl.src = dataUrl; videoEl.loop = true; videoEl.muted = false; videoEl.playsInline = true; videoEl.crossOrigin = "anonymous";
  videoEl.pause();
  function finishV(){
    var texture = new THREE.VideoTexture(videoEl);
    texture.minFilter = THREE.LinearFilter; texture.magFilter = THREE.LinearFilter;
    var aspect = (videoEl.videoWidth/videoEl.videoHeight) || (16/9);
    var h = height || 1.5;
    var w = h*aspect;
    var mat = new THREE.MeshBasicMaterial({ map:texture, side:THREE.DoubleSide, transparent:true });
    mat.polygonOffset = true; mat.polygonOffsetFactor = -4; mat.polygonOffsetUnits = -4;
    mat.alphaTest = 0.5;
    var mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,h), mat);
    var group = new THREE.Group(); group.add(mesh); group.position.y = h/2;
    onReady({ object3D:group, colorMaterials:[mat], mesh:mesh, aspect:aspect, videoEl:videoEl });
  }
  videoEl.addEventListener("loadedmetadata", finishV, { once:true });
  videoEl.addEventListener("error", function(){ onReady(null); }, { once:true });
}
function toggleVideoPlayback(rec){
  if(!rec.videoEl) return;
  if(rec.videoEl.paused){ rec.videoEl.play().catch(function(){}); if(typeof feedToast==="function") feedToast("Video: " + rec.name); }
  else { rec.videoEl.pause(); if(typeof feedToast==="function") feedToast("Video: " + rec.name); }
}

function buildExtrudeShape(nodes){
  var shape = new THREE.Shape();
  if(!nodes || nodes.length < 2){ shape.moveTo(-0.5,-0.5); shape.lineTo(0.5,-0.5); shape.lineTo(0.5,0.5); shape.lineTo(-0.5,0.5); shape.closePath(); return shape; }
  shape.moveTo(nodes[0].x, nodes[0].y);
  for(var i=1; i<=nodes.length; i++){
    var prev = nodes[i-1];
    var curr = nodes[i % nodes.length];
    if(prev.handleOut || curr.handleIn){
      var c1x = prev.x + (prev.handleOut ? prev.handleOut.x : 0);
      var c1y = prev.y + (prev.handleOut ? prev.handleOut.y : 0);
      var c2x = curr.x + (curr.handleIn ? curr.handleIn.x : 0);
      var c2y = curr.y + (curr.handleIn ? curr.handleIn.y : 0);
      shape.bezierCurveTo(c1x,c1y,c2x,c2y,curr.x,curr.y);
    } else {
      shape.lineTo(curr.x, curr.y);
    }
  }
  return shape;
}
function buildPathCurve(pathNodes, closed){
  var pts = pathNodes.map(function(n){ return new THREE.Vector3(n.x,n.y,n.z); });
  return new THREE.CatmullRomCurve3(pts, !!closed, "catmullrom", 0.5);
}
function buildSweepFrames(curve, steps){
  var frames = [];
  var worldUp = new THREE.Vector3(0,1,0);
  for(var i=0; i<=steps; i++){
    var t = i/steps;
    var point = curve.getPointAt(t);
    var tangent = curve.getTangentAt(t).clone().normalize();
    var right = new THREE.Vector3().crossVectors(worldUp, tangent);
    if(right.lengthSq() < 1e-6){
      right = new THREE.Vector3().crossVectors(new THREE.Vector3(1,0,0), tangent);
      if(right.lengthSq() < 1e-6) right = new THREE.Vector3().crossVectors(new THREE.Vector3(0,0,1), tangent);
    }
    right.normalize();
    var up = new THREE.Vector3().crossVectors(tangent, right).normalize();
    frames.push({ point:point, right:right, up:up });
  }
  return frames;
}
function buildExtrudeAlongPathGeometry(nodes, pathData){
  var profilePts = buildExtrudeShape(nodes).getPoints(Math.max(12, nodes.length*8));
  var closed = !!pathData.closed;
  var curve = buildPathCurve(pathData.nodes, closed);
  var steps = Math.max(16, pathData.nodes.length*12);
  var frames = buildSweepFrames(curve, steps);
  var positions = [];
  var uvs = [];
  var indices = [];
  var profCount = profilePts.length;
  var ringCount = frames.length;
  var profileCum = [0];
  for(var pk=1; pk<=profCount; pk++){
    var pa = profilePts[pk-1], pb = profilePts[pk % profCount];
    profileCum.push(profileCum[pk-1] + Math.hypot(pb.x-pa.x, pb.y-pa.y));
  }
  var profileLen = Math.max(profileCum[profCount], 0.5) || 1;
  var frameCum = [0];
  for(var fk=1; fk<frames.length; fk++){ frameCum.push(frameCum[fk-1] + frames[fk].point.distanceTo(frames[fk-1].point)); }
  frames.forEach(function(f, i){
    var v = frameCum[i] / profileLen;
    profilePts.forEach(function(p, j){
      var wp = new THREE.Vector3().addVectors(f.point, f.right.clone().multiplyScalar(p.x)).add(f.up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      uvs.push(profileCum[j] / profileLen, v);
    });
  });
  for(var i=0; i<ringCount-1; i++){
    for(var j=0; j<profCount; j++){
      var jNext = (j+1) % profCount;
      var a = i*profCount+j, b = i*profCount+jNext, c = (i+1)*profCount+jNext, d = (i+1)*profCount+j;
      indices.push(a,b,c, a,c,d);
    }
  }
  var positionCountBeforeCaps = positions.length/3;
  if(!closed){
    var minX=Infinity, maxX=-Infinity, minY=Infinity, maxY=-Infinity;
    profilePts.forEach(function(p){ minX=Math.min(minX,p.x); maxX=Math.max(maxX,p.x); minY=Math.min(minY,p.y); maxY=Math.max(maxY,p.y); });
    function capUV(p){ return [ (p.x-minX)/Math.max(maxX-minX,0.001), (p.y-minY)/Math.max(maxY-minY,0.001) ]; }
    var startBase = positionCountBeforeCaps;
    profilePts.forEach(function(p){
      var wp = new THREE.Vector3().addVectors(frames[0].point, frames[0].right.clone().multiplyScalar(p.x)).add(frames[0].up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      var uv = capUV(p); uvs.push(uv[0], uv[1]);
    });
    var endBase = startBase + profCount;
    var lastFrame = frames[frames.length-1];
    profilePts.forEach(function(p){
      var wp = new THREE.Vector3().addVectors(lastFrame.point, lastFrame.right.clone().multiplyScalar(p.x)).add(lastFrame.up.clone().multiplyScalar(p.y));
      positions.push(wp.x, wp.y, wp.z);
      var uv = capUV(p); uvs.push(uv[0], uv[1]);
    });
    var capTris = THREE.ShapeUtils.triangulateShape(profilePts, []);
    capTris.forEach(function(tri){ indices.push(startBase+tri[0], startBase+tri[2], startBase+tri[1]); });
    capTris.forEach(function(tri){ indices.push(endBase+tri[0], endBase+tri[1], endBase+tri[2]); });
  }
  var geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}
function buildExtrudeGeometry(extrudeData){
  if(extrudeData.path && extrudeData.path.nodes && extrudeData.path.nodes.length >= 2){
    return buildExtrudeAlongPathGeometry(extrudeData.nodes, extrudeData.path);
  }
  var shape = buildExtrudeShape(extrudeData.nodes);
  var depth = Math.max(0.02, extrudeData.depth || 0.3);
  var bevelEnabled = !!extrudeData.bevelEnabled;
  var bevelSize = Math.max(0.005, Math.min(extrudeData.bevelSize || 0.05, depth/2 - 0.005));
  return new THREE.ExtrudeGeometry(shape, { depth:depth, bevelEnabled:bevelEnabled, bevelThickness:bevelSize, bevelSize:bevelSize, bevelSegments: bevelEnabled?3:1, curveSegments:16 });
}
function buildExtrudeObject(extrudeData){
  var geo = buildExtrudeGeometry(extrudeData);
  var mat = makeStdMat(0x8f97a8);
  var mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true; mesh.receiveShadow = true;
  var group = new THREE.Group(); group.add(mesh);
  return { object3D:group, colorMaterials:[mat] };
}

function applyTextureToRecord(rec, dataUrl){
  if(!dataUrl) return;
  var tex = new THREE.TextureLoader().load(dataUrl);
  if(THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(rec.textureRepeatX||1, rec.textureRepeatY||1);
  rec.colorMaterials.forEach(function(m){ m.map = tex; m.needsUpdate = true; });
}
function addReconstructed(o, object3D, colorMaterials, videoEl, mixer, clips){
  object3D.position.fromArray(o.transform.position);
  object3D.quaternion.fromArray(o.transform.quaternion);
  object3D.scale.fromArray(o.transform.scale);
  if(o.colorHex && colorMaterials.length) colorMaterials.forEach(function(m){ m.color.set(o.colorHex); });
  var opacidad = (o.opacity!=null ? o.opacity : 1);
  if(colorMaterials.length) colorMaterials.forEach(function(m){ m.opacity = opacidad; m.visible = opacidad > 0.01; });
  scene.add(object3D);
  var rec = { id:o.id, name:o.name, kind:o.kind, object3D:object3D, colorMaterials:colorMaterials, opacity:opacidad, collider:o.collider, facingOffsetDeg:o.facingOffsetDeg||0, actions:o.actions||[], checkpoints:null, totalDuration:0, mixer:mixer||null, clips:clips||[], videoEl:videoEl||null, groupId:o.groupId||null, textureRepeatX:o.textureRepeatX||1, textureRepeatY:o.textureRepeatY||1, cameraPathData:o.cameraPathData||null, weatherData:o.weatherData||null, text3d:o.text3d||null, imageBase64:o.imageBase64||null, videoBase64:o.videoBase64||null, interactive:o.interactive||{enabled:false,kind:"text",radius:2,prompt:"Interactuar",text:"",url:"",choices:[],onInteractAction:null} };
  if(o.textureBase64) applyTextureToRecord(rec, o.textureBase64);
  sceneObjects.set(rec.id, rec);
  sceneOrder.push(rec.id);
  recomputeCheckpoints(rec);
  if(rec.collider.kind==="character" && !playerRecordId) playerRecordId = rec.id;
}

function buildScene(project, onReady){
  var pending=0, done=0;
  function finish(){
    sceneObjects.forEach(function(r){ recomputeCheckpoints(r); });
    (project.groups||[]).forEach(function(g){ objectGroups.set(g.id, { id:g.id, name:g.name, memberIds:g.memberIds.slice() }); });
    recomputeTimelineDuration();
    onReady();
  }
  project.objects.forEach(function(o){
    if(o.kind==="gltf" && o.gltfBase64){
      pending++;
      gltfLoader.parse(base64ToArrayBuffer(o.gltfBase64), "", function(gltf){
        var inner = gltf.scene || gltf.scenes[0];
        inner.traverse(function(m){ if(m.isMesh){ m.castShadow=true; m.receiveShadow=true; } });
        var colorMats = collectGltfColorMaterials(inner);
        var clips = gltf.animations || [];
        var mixer = clips.length ? new THREE.AnimationMixer(inner) : null;
        var mbox = computeModelBounds(inner, mixer, clips);
        var msize = new THREE.Vector3(); mbox.getSize(msize);
        var maxDim = Math.max(msize.x, msize.y, msize.z) || 1;
        var scaleFactor = maxDim > 0 ? 1.6/maxDim : 1;
        inner.scale.setScalar(scaleFactor);
        var mbox2 = computeModelBounds(inner, mixer, clips);
        inner.position.y -= mbox2.min.y;
        if(mixer) mixer.update(0);
        var group=new THREE.Group(); group.add(inner);
        addReconstructed(o, group, colorMats, null, mixer, clips);
        done++; if(done===pending) finish();
      }, function(){ done++; if(done===pending) finish(); });
    } else if(o.kind==="image" && o.imageBase64){
      pending++;
      buildImagePlaneObject(o.imageBase64, null, function(built){
        if(built) addReconstructed(o, built.object3D, built.colorMaterials);
        done++; if(done===pending) finish();
      });
    } else if(o.kind==="video" && o.videoBase64){
      pending++;
      buildVideoPlaneObject(o.videoBase64, null, function(built){
        if(built) addReconstructed(o, built.object3D, built.colorMaterials, built.videoEl);
        done++; if(done===pending) finish();
      });
    } else if(o.kind==="text3d"){
      var t3 = o.text3d || { text:"Texto", color:"#ffffff", size:1 };
      var builtT = buildText3DObject(t3.text, t3.color, t3.size, t3.boxWidth);
      addReconstructed(o, builtT.object3D, builtT.colorMaterials);
    } else if(o.kind==="extrude" && o.extrudeData){
      var builtE = buildExtrudeObject(o.extrudeData);
      addReconstructed(o, builtE.object3D, builtE.colorMaterials);
    } else if(o.kind==="primitive"){
      var built=createPrimitive(o.primitiveType);
      addReconstructed(o, built.object3D, built.colorMaterials);
    } else if(o.kind==="prefab"){
      var built2=createPrefab(o.prefabType);
      addReconstructed(o, built2.object3D, built2.colorMaterials);
    } else if(o.kind==="light"){
      var builtL=buildLightObject(o.lightData);
      addReconstructed(o, builtL.object3D, builtL.colorMaterials);
    } else if(o.kind==="camerapath"){
      addReconstructed(o, new THREE.Group(), []);
    } else if(o.kind==="weather"){
      var builtW=buildWeatherObject(o.weatherData);
      addReconstructed(o, builtW.object3D, builtW.colorMaterials);
    }
  });
  if(pending===0) finish();
}

var playYaw=0, playPitch=-0.25;
var playKeys={w:false,a:false,s:false,d:false,shift:false,space:false,arrowUp:false,arrowDown:false,arrowLeft:false,arrowRight:false};
var firstPersonMode=false;
var npcClockTime=0;
var WALK_SPEED=3.2, RUN_SPEED=6.2, CHASE_RADIUS=4.5, GRAVITY=-18, JUMP_SPEED=6.5, TURN_SPEED=2.4;
var playCamDist = CHASE_RADIUS;
var started=false;
var playScore=0;
var gameVariables={};
var networkActionsAllowed=false;
var networkGateAsked=false;
var interactionPanelOpen=false;
var askInputActive=false;
var MAX_ASK_ARCHIVO_BYTES=350*1024;
var screenMsgDismissFn=null;
var nearestInteractiveId=null;
var playVelY=0, playGrounded=true;
function isTouchDevice(){ return (window.matchMedia && window.matchMedia("(pointer: coarse)").matches) || ("ontouchstart" in window) || (navigator.maxTouchPoints||0)>0; }
var touchJoystickId=null, touchJoystickVec={x:0,y:0}, touchLookId=null, touchLookLast={x:0,y:0};

function feedToast(text){
  var feed=document.getElementById("feed");
  var div=document.createElement("div"); div.className="toast"; div.textContent=text;
  feed.prepend(div);
  while(feed.children.length>4) feed.removeChild(feed.lastChild);
  setTimeout(function(){ if(div.parentNode) div.remove(); }, 5000);
}
eventCallback = feedToast;

function escGameHtml(s){
  return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function updateScoreDisplay(){
  var el=document.getElementById("score");
  if(el) el.textContent = "Puntuacion: " + playScore;
}
function updateInteractPrompt(){
  var el=document.getElementById("interactPrompt");
  var btn=document.getElementById("touchInteractBtn");
  var showTouchBtn = isTouchDevice() && !interactionPanelOpen && !!nearestInteractiveId;
  if(interactionPanelOpen || !nearestInteractiveId){ el.style.display="none"; if(btn) btn.style.display="none"; return; }
  var rec=sceneObjects.get(nearestInteractiveId);
  if(!rec || !rec.interactive || !rec.interactive.enabled){ el.style.display="none"; if(btn) btn.style.display="none"; return; }
  el.textContent = "[E] " + (rec.interactive.prompt || "Interactuar");
  el.style.display = isTouchDevice() ? "none" : "block";
  if(btn) btn.style.display = showTouchBtn ? "flex" : "none";
}
function updateShotPrompt(){
  var el=document.getElementById("shotPrompt");
  var btn=document.getElementById("touchShootBtn");
  if(!el) return;
  var rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;
  if(!rec || !rec.interactive || !rec.interactive.onShotAction){ el.style.display="none"; if(btn) btn.style.display="none"; return; }
  el.textContent = "🎯 [F] Disparar";
  el.style.display = isTouchDevice() ? "none" : "block";
  if(btn) btn.style.display = isTouchDevice() ? "flex" : "none";
}
function attemptShoot(){
  if(interactionPanelOpen || droneModeActive || cameraPathActive) return;
  var rec = nearestShotTargetId ? sceneObjects.get(nearestShotTargetId) : null;
  if(!rec || !rec.interactive || !rec.interactive.onShotAction) return;
  triggerOneShotAction(rec, rec.interactive.onShotAction);
  feedToast("🎯 " + rec.name);
}
function playOneShotSound(base64, volume){
  if(!base64) return;
  try{
    var audio = new Audio(base64);
    audio.volume = (volume===undefined || volume===null || isNaN(volume)) ? 1 : volume;
    audio.play().catch(function(){});
  } catch(e){}
}
function collectFetchUrls(){
  var urls = []; var seen = {};
  function scan(a){
    if(!a) return;
    if(a.type==="fetchUrl" && a.url && !seen[a.url]){ seen[a.url]=true; urls.push(a.url); }
    if(a.next) scan(a.next);
    (a.parallel||[]).forEach(scan);
  }
  sceneObjects.forEach(function(rec){
    (rec.actions||[]).forEach(scan);
    if(rec.interactive){
      scan(rec.interactive.onInteractAction);
      scan(rec.interactive.onShotAction);
      (rec.interactive.choices||[]).forEach(function(c){ scan(c.action); });
    }
  });
  return urls;
}
function gateNetworkActions(){
  if(networkGateAsked) return Promise.resolve(networkActionsAllowed);
  networkGateAsked = true;
  var urls = collectFetchUrls();
  if(!urls.length){ networkActionsAllowed = false; return Promise.resolve(false); }
  return new Promise(function(resolve){
    var overlay = document.createElement("div");
    overlay.style.cssText = "position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:2000; display:flex; align-items:center; justify-content:center;";
    var box = document.createElement("div");
    box.style.cssText = "background:#181b22; border:1px solid #333947; border-radius:8px; padding:18px; width:min(480px,92vw); color:#eee; font-family:inherit;";
    box.innerHTML = '<h3 style="margin-top:0;">🌐 Este escenario quiere conectarse a internet</h3>' +
      '<p style="font-size:13px; opacity:.85;">Alguna accion de este proyecto envia o recibe datos de:</p>' +
      '<ul style="font-size:12.5px; opacity:.9; max-height:140px; overflow:auto; padding-left:18px; margin:8px 0;">' +
      urls.map(function(u){ return '<li style="word-break:break-all; margin-bottom:4px;">' + String(u).replace(/</g,"&lt;") + '</li>'; }).join("") +
      '</ul>' +
      '<p style="font-size:12.5px; opacity:.7;">Si no confias en el origen de este escenario, deniegalo -- el juego sigue funcionando igual, solo sin esas acciones concretas.</p>' +
      '<div style="display:flex; gap:8px; margin-top:12px;">' +
      '<button type="button" id="netGateAllow" style="flex:1; padding:8px; border-radius:6px; border:1px solid #3a6a3a; background:#1c2b1c; color:#eee; cursor:pointer;">Permitir</button>' +
      '<button type="button" id="netGateDeny" style="flex:1; padding:8px; border-radius:6px; border:1px solid #444; background:#22252d; color:#eee; cursor:pointer;">Denegar</button>' +
      '</div>';
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    document.getElementById("netGateAllow").addEventListener("click", function(){ networkActionsAllowed = true; overlay.remove(); resolve(true); });
    document.getElementById("netGateDeny").addEventListener("click", function(){ networkActionsAllowed = false; overlay.remove(); resolve(false); });
  });
}
function triggerOneShotAction(rec, action, batchStartedAt){
  if(!action || !action.type || action.type==="none") return;
  var startedAt = batchStartedAt || performance.now();
  if(action.type==="sound"){
    playOneShotSound(action.soundBase64, action.volume);
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="toggleVideo"){
    var videoRecs = [rec];
    if(action.target==="player") videoRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if(action.target==="__group__"){
      var gV = rec.groupId ? objectGroups.get(rec.groupId) : null;
      videoRecs = gV ? gV.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];
    } else if(action.target && action.target!=="self") {
      var foundV = sceneObjects.get(action.target);
      if(!foundV){ console.warn("Don Claude 3D: accion video con objetivo no encontrado -- no se ejecuta."); videoRecs = []; }
      else videoRecs = [foundV];
    }
    videoRecs.forEach(function(r){ if(r.kind==="video") toggleVideoPlayback(r); });
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="setVariable"){
    var val = evalSafeExpr(action.expr, gameVariables);
    if(action.varName) gameVariables[action.varName] = val;
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="setImageVar"){
    var chainOnImg = function(){
      if(action.next) triggerOneShotAction(rec, action.next);
      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });
    };
    var dataUrlImg = action.varName ? gameVariables[action.varName] : null;
    var targetImgRec = action.target ? sceneObjects.get(action.target) : null;
    if(!dataUrlImg || typeof dataUrlImg!=="string" || dataUrlImg.indexOf("data:image")!==0 || !targetImgRec || targetImgRec.kind!=="image"){
      chainOnImg();
      return;
    }
    swapImageTexture(targetImgRec, dataUrlImg, chainOnImg);
    return;
  }
  if(action.type==="setTextVar"){
    var textVarVal = action.varName ? gameVariables[action.varName] : undefined;
    var targetTxtRec = action.target ? sceneObjects.get(action.target) : null;
    if(textVarVal!==undefined && targetTxtRec && targetTxtRec.kind==="text3d" && targetTxtRec.object3D && targetTxtRec.object3D.children[0]){
      var textVarStr = String(textVarVal);
      targetTxtRec.text3d.text = textVarStr;
      var meshTV = targetTxtRec.object3D.children[0];
      var builtTV = buildText3DTexture(textVarStr, targetTxtRec.text3d.color, targetTxtRec.text3d.boxWidth);
      var oldTexTV = meshTV.material.map;
      meshTV.material.map = builtTV.texture;
      meshTV.material.needsUpdate = true;
      if(oldTexTV) oldTexTV.dispose();
      var sTV = targetTxtRec.text3d.size || 1;
      meshTV.geometry.dispose();
      meshTV.geometry = new THREE.PlaneGeometry(builtTV.aspect*sTV, builtTV.heightFactor*sTV);
    }
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="fetchUrl"){
    var chainOn = function(){
      if(action.next) triggerOneShotAction(rec, action.next);
      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    };
    gateNetworkActions().then(function(allowed){
      if(!allowed || !action.url){ chainOn(); return; }
      var urlFinal = interpolateVars(action.url, gameVariables);
      if(urlFinal.indexOf("mailto:")===0){
        window.open(urlFinal, "_blank", "noopener,noreferrer");
        chainOn();
        return;
      }
      var method = action.method==="POST" ? "POST" : "GET";
      var parts = urlFinal.split("?");
      var fetchPromise = method==="POST"
        ? fetch(parts[0], { method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded"}, body: parts[1]||"" })
        : fetch(urlFinal);
      fetchPromise.then(function(res){ return res.text(); }).then(function(text){
        if(action.responseMode==="label"){
          var targetRecsF = [rec];
          if(action.target==="player") targetRecsF = [sceneObjects.get(playerRecordId)].filter(Boolean);
          else if(action.target && action.target!=="self" && action.target!=="__group__"){ var f = sceneObjects.get(action.target); targetRecsF = f ? [f] : []; }
          targetRecsF.forEach(function(r){
            if(r.kind!=="text3d" || !r.object3D || !r.object3D.children[0]) return;
            r.text3d.text = text;
            var meshT = r.object3D.children[0];
            var builtT = buildText3DTexture(text, r.text3d.color, r.text3d.boxWidth);
            var oldTexT = meshT.material.map;
            meshT.material.map = builtT.texture;
            meshT.material.needsUpdate = true;
            if(oldTexT) oldTexT.dispose();
            var sT = r.text3d.size || 1;
            meshT.geometry.dispose();
            meshT.geometry = new THREE.PlaneGeometry(builtT.aspect*sT, builtT.heightFactor*sT);
          });
        } else if(action.responseMode==="imagen"){
          var targetRecsImg = [rec];
          if(action.target==="player") targetRecsImg = [sceneObjects.get(playerRecordId)].filter(Boolean);
          else if(action.target && action.target!=="self" && action.target!=="__group__"){ var fi = sceneObjects.get(action.target); targetRecsImg = fi ? [fi] : []; }
          targetRecsImg = targetRecsImg.filter(function(r){ return r.kind==="image"; });
          if(!targetRecsImg.length || text.indexOf("data:image")!==0) return;
          return new Promise(function(resolve){
            var pendingImg = targetRecsImg.length;
            targetRecsImg.forEach(function(r){ swapImageTexture(r, text, function(){ pendingImg--; if(pendingImg===0) resolve(); }); });
          });
        } else if(action.responseMode==="variables" && action.varMap){
          var parsed = null;
          try{ parsed = JSON.parse(text); } catch(e){ parsed = null; }
          var lines = String(action.varMap).split("\n");
          if(parsed && typeof parsed==="object"){
            lines.forEach(function(line){
              var eq = line.indexOf("=");
              if(eq<0) return;
              var field = line.slice(0,eq).trim(), varName = line.slice(eq+1).trim();
              if(!field || !varName) return;
              var v = field.split(".").reduce(function(o,k){ return (o && typeof o==="object") ? o[k] : undefined; }, parsed);
              if(v!==undefined) gameVariables[varName] = v;
            });
          } else if(lines[0]){
            var eq0 = lines[0].indexOf("=");
            var firstVar = (eq0>=0 ? lines[0].slice(eq0+1) : lines[0]).trim();
            if(firstVar) gameVariables[firstVar] = text;
          }
        }
      }).catch(function(){}).finally(chainOn);
    });
    return;
  }
  if(action.type==="copyToClipboard"){
    copiarTexto(interpolateVarsPlain(action.text, gameVariables));
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="if"){
    var condVal = evalSafeExpr(action.expr, gameVariables);
    var isTrue = typeof condVal==="string" ? (condVal!=="" && condVal!=="0") : !!condVal;
    var branch = isTrue ? action.then : action.else;
    if(branch) triggerOneShotAction(rec, branch, startedAt);
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="for"){
    var countRaw = evalSafeExpr(String(action.count!=null ? action.count : "0"), gameVariables);
    var count = Math.max(0, Math.min(1000, Math.floor(typeof countRaw==="number" ? countRaw : (parseFloat(countRaw)||0))));
    var body = action.body;
    if(body && (body.type==="moveTo" || body.type==="rotateTo") && body.relative && body.to && count>0){
      if(action.varName) gameVariables[action.varName] = count-1;
      var headStep = null, prevStep = null;
      for(var step=1; step<=count; step++){
        var stepAction = {
          type: body.type, target: body.target, relative: true, ease: body.ease,
          to: { x: body.to.x*step, y: body.to.y*step, z: body.to.z*step },
          duration: body.duration
        };
        if(!headStep) headStep = stepAction;
        if(prevStep) prevStep.next = stepAction;
        prevStep = stepAction;
      }
      var extras = (action.parallel||[]).slice();
      if(action.next) extras.push(action.next);
      prevStep.next = body.next || null;
      prevStep.parallel = extras;
      triggerOneShotAction(rec, headStep, startedAt);
      return;
    }
    for(var __fi=0; __fi<count; __fi++){
      if(action.varName) gameVariables[action.varName] = __fi;
      if(body) triggerOneShotAction(rec, body, startedAt);
    }
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="screenMessage"){
    showScreenMessage(interpolateVarsPlain(action.text, gameVariables), action.autoDismissSec||0, function(){
      if(action.next) triggerOneShotAction(rec, action.next);
      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });
    });
    return;
  }
  if(action.type==="askInput"){
    showAskInput(interpolateVarsPlain(action.promptText, gameVariables), action.varName, action.allowFile, action.fileVarName, function(){
      if(action.next) triggerOneShotAction(rec, action.next);
      (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa); });
    });
    return;
  }
  if(action.type==="cameraPath"){
    var cpRec = rec;
    if(action.target && action.target!=="self" && action.target!=="player" && action.target!=="__group__"){
      var foundCp = sceneObjects.get(action.target);
      if(!foundCp){ console.warn("Don Claude 3D: accion recorrido de camara con objetivo no encontrado -- no se ejecuta."); cpRec = null; }
      else cpRec = foundCp;
    }
    if(cpRec) playCameraPath(cpRec);
    if(action.next) triggerOneShotAction(rec, action.next);
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="playClip"){
    var clipRecs = [rec];
    if(action.target==="player") clipRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if(action.target==="__group__"){
      var gC = rec.groupId ? objectGroups.get(rec.groupId) : null;
      clipRecs = gC ? gC.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];
    } else if(action.target && action.target!=="self") {
      var foundC = sceneObjects.get(action.target);
      if(!foundC){ console.warn("Don Claude 3D: accion animacion con objetivo no encontrado -- no se ejecuta."); clipRecs = []; }
      else clipRecs = [foundC];
    }
    var clipDurationMs = Math.max(50, (action.duration||1)*1000);
    clipRecs.forEach(function(r, idx){
      if(!r.mixer || !r.clips || !r.clips.length) return;
      var clip = r.clips.find(function(c){ return c.name===action.clipName; }) || r.clips[0];
      if(!clip) return;
      if(r.__activeClipAction) r.__activeClipAction.stop();
      var clipAction = r.mixer.clipAction(clip);
      clipAction.reset();
      clipAction.setLoop(action.loop ? THREE.LoopRepeat : THREE.LoopOnce, action.loop ? Infinity : 1);
      clipAction.clampWhenFinished = !action.loop;
      clipAction.play();
      r.__activeClipAction = clipAction;
      r.__oneShotClip = { startedAt: startedAt, durationMs: action.loop ? null : clipDurationMs, nextAction: idx===0 ? (action.next||null) : null, chainRec: rec };
    });
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  if(action.type==="spin"){
    var spinRecs = [rec];
    if(action.target==="player") spinRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
    else if(action.target==="__group__"){
      var gS = rec.groupId ? objectGroups.get(rec.groupId) : null;
      spinRecs = gS ? gS.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];
    } else if(action.target && action.target!=="self") {
      var foundSpin = sceneObjects.get(action.target);
      if(!foundSpin){ console.warn("Don Claude 3D: accion girar con objetivo no encontrado (referencia rota) -- no se ejecuta."); spinRecs = []; }
      else spinRecs = [foundSpin];
    }
    if(!spinRecs.length) return;
    var axisVec = action.axis==="x" ? new THREE.Vector3(1,0,0) : action.axis==="z" ? new THREE.Vector3(0,0,1) : new THREE.Vector3(0,1,0);
    var speedRad = deg2rad(action.speed||0);
    var durationMsSpin = Math.max(50, (action.duration||1)*1000);
    spinRecs.forEach(function(r, idx){
      r.__spin = { axisVec:axisVec, speedRad:speedRad, startedAt:startedAt, durationMs:durationMsSpin, nextAction: idx===0 ? (action.next||null) : null, chainRec: rec };
    });
    (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
    return;
  }
  var targetRecs = [rec];
  var groupRigid = null;
  if(action.target==="player") targetRecs = [sceneObjects.get(playerRecordId)].filter(Boolean);
  else if(action.target==="__group__"){
    var g = rec.groupId ? objectGroups.get(rec.groupId) : null;
    targetRecs = g ? g.memberIds.map(function(mid){ return sceneObjects.get(mid); }).filter(Boolean) : [rec];
    if(action.type==="moveTo" && action.to){
      groupRigid = { tipo:"mover", delta: new THREE.Vector3(action.to.x,action.to.y,action.to.z).sub(rec.object3D.position) };
    } else if(action.type==="rotateTo" && action.to){
      var toQuatG = new THREE.Quaternion().setFromEuler(new THREE.Euler(deg2rad(action.to.x),deg2rad(action.to.y),deg2rad(action.to.z)));
      var deltaQuatG = toQuatG.clone().multiply(rec.object3D.quaternion.clone().invert());
      groupRigid = { tipo:"rotar", deltaQuat:deltaQuatG, ancla: rec.object3D.position.clone() };
    }
  }
  else if(action.target && action.target!=="self") {
    var found = sceneObjects.get(action.target);
    if(!found){ console.warn("Don Claude 3D: accion con objetivo no encontrado (referencia rota) -- no se ejecuta."); targetRecs = []; }
    else targetRecs = [found];
  }
  if(!targetRecs.length) return;
  var duration = Math.max(50, (action.duration||1)*1000);
  targetRecs.forEach(function(targetRec, idx){
    var existingOS = targetRec.__oneShot;
    var mergeable = existingOS && existingOS.startedAt === startedAt;
    var fromPos = mergeable ? existingOS.fromPos.clone() : targetRec.object3D.position.clone();
    var fromQuat = mergeable ? existingOS.fromQuat.clone() : targetRec.object3D.quaternion.clone();
    var fromOpacity = mergeable ? existingOS.fromOpacity : (targetRec.colorMaterials.length ? targetRec.colorMaterials[0].opacity : 1);
    var toPos = mergeable ? existingOS.toPos.clone() : fromPos.clone();
    var toQuat = mergeable ? existingOS.toQuat.clone() : fromQuat.clone();
    var toOpacity = mergeable ? existingOS.toOpacity : fromOpacity;
    var flashDef = mergeable ? existingOS.flashDef : null;
    var mergedDuration = mergeable ? Math.max(existingOS.duration, duration) : duration;
    if(groupRigid && groupRigid.tipo==="mover"){
      toPos = fromPos.clone().add(groupRigid.delta);
    } else if(groupRigid && groupRigid.tipo==="rotar"){
      var rel = fromPos.clone().sub(groupRigid.ancla).applyQuaternion(groupRigid.deltaQuat);
      toPos = groupRigid.ancla.clone().add(rel);
      toQuat = groupRigid.deltaQuat.clone().multiply(fromQuat);
    } else if(action.relative && action.type==="moveTo" && action.to){
      var originPos = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.pos : targetRec.object3D.position;
      toPos = originPos.clone().add(new THREE.Vector3(action.to.x, action.to.y, action.to.z));
    } else if(action.relative && action.type==="rotateTo" && action.to){
      var originQuat = targetRec.object3D.userData.__origin ? targetRec.object3D.userData.__origin.quat : targetRec.object3D.quaternion;
      var oe = new THREE.Euler().setFromQuaternion(originQuat);
      var ne = new THREE.Euler(oe.x+deg2rad(action.to.x), oe.y+deg2rad(action.to.y), oe.z+deg2rad(action.to.z));
      toQuat = new THREE.Quaternion().setFromEuler(ne);
    } else {
      if(action.type==="moveTo" && action.to) toPos.set(action.to.x, action.to.y, action.to.z);
      if(action.type==="rotateTo" && action.to) toQuat.setFromEuler(new THREE.Euler(deg2rad(action.to.x), deg2rad(action.to.y), deg2rad(action.to.z)));
    }
    if(action.type==="fade") toOpacity = action.to;
    if(action.type==="flash") flashDef = { color: action.color, repeat: action.repeat||3 };
    targetRec.__oneShot = { startedAt: startedAt, duration: mergedDuration, fromPos:fromPos, toPos:toPos, fromQuat:fromQuat, toQuat:toQuat, fromOpacity:fromOpacity, toOpacity:toOpacity, ease:"smooth", flashDef:flashDef, nextAction: idx===0 ? (action.next||null) : (mergeable ? existingOS.nextAction : null), chainRec: rec };
  });
  (action.parallel||[]).forEach(function(pa){ triggerOneShotAction(rec, pa, startedAt); });
}
function updateSpins(dt){
  var toChainSpin = [];
  sceneObjects.forEach(function(rec){
    var sp = rec.__spin;
    if(!sp) return;
    rec.object3D.rotateOnAxis(sp.axisVec, sp.speedRad*dt);
    if(performance.now()-sp.startedAt >= sp.durationMs){
      if(sp.nextAction) toChainSpin.push({ chainRec: sp.chainRec, nextAction: sp.nextAction });
      rec.__spin = null;
    }
  });
  toChainSpin.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });
}
function updateOneShotClips(dt){
  var toChainClip = [];
  sceneObjects.forEach(function(rec){
    var oc = rec.__oneShotClip;
    if(!oc) return;
    if(rec.mixer) rec.mixer.update(dt);
    if(oc.durationMs!==null && performance.now()-oc.startedAt >= oc.durationMs){
      if(oc.nextAction) toChainClip.push({ chainRec: oc.chainRec, nextAction: oc.nextAction });
      rec.__oneShotClip = null;
    }
  });
  toChainClip.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });
}
function updateOneShotAnimations(){
  var nowMs = performance.now();
  var toChain = [];
  sceneObjects.forEach(function(rec){
    var os = rec.__oneShot;
    if(!os) return;
    var p = clamp((nowMs-os.startedAt)/os.duration, 0, 1);
    var pe = easeVal(p, os.ease);
    rec.object3D.position.copy(os.fromPos).lerp(os.toPos, pe);
    if(!os.fromQuat.equals(os.toQuat)){
      rec.object3D.quaternion.copy(os.fromQuat).slerp(os.toQuat, pe);
    }
    if(rec.colorMaterials.length){
      var op = lerp(os.fromOpacity, os.toOpacity, pe);
      rec.colorMaterials.forEach(function(m){ m.opacity=op; m.visible = op>0.01; });
    }
    if(os.flashDef){
      var intensity = Math.abs(Math.sin(p*Math.PI*os.flashDef.repeat));
      if(intensity>0.02 && rec.colorMaterials.length){
        var c=new THREE.Color(os.flashDef.color||"#ff3b3b");
        rec.colorMaterials.forEach(function(m){ m.emissive=c; m.emissiveIntensity=intensity; });
      } else if(rec.colorMaterials.length){
        rec.colorMaterials.forEach(function(m){ if(m.emissiveIntensity) m.emissiveIntensity=0; });
      }
    }
    if(p>=1){
      if(os.nextAction) toChain.push({ chainRec: os.chainRec, nextAction: os.nextAction });
      rec.__oneShot = null;
    }
  });
  toChain.forEach(function(c){ triggerOneShotAction(c.chainRec, c.nextAction); });
}
function openInteractionLink(rec){
  var url=(rec.interactive.url||"").trim();
  if(!url){ feedToast("AVISO " + rec.name + ": no tiene ninguna URL configurada."); return; }
  window.open(url, "_blank", "noopener,noreferrer");
  feedToast("Abriendo enlace: " + rec.name);
  triggerOneShotAction(rec, rec.interactive.onInteractAction);
}
function openInteractionPanel(id){
  var rec=sceneObjects.get(id);
  if(!rec || !rec.interactive || !rec.interactive.enabled) return;
  if(rec.kind==="video"){ toggleVideoPlayback(rec); return; }
  if(rec.interactive.kind==="link"){ openInteractionLink(rec); return; }
  if(rec.interactive.kind==="text"){
    var oia=rec.interactive.onInteractAction;
    var bareText=!(rec.interactive.text && rec.interactive.text.trim());
    var ownsOverlay = oia && (oia.type==="askInput" || oia.type==="screenMessage");
    if(bareText || ownsOverlay){
      triggerOneShotAction(rec, oia);
      return;
    }
  }
  interactionPanelOpen=true;
  document.getElementById("interactPrompt").style.display="none";
  if(rec.interactive.kind==="text") triggerOneShotAction(rec, rec.interactive.onInteractAction);
  var panel=document.getElementById("interactPanel");
  var html = '<div class="box"><h4>' + escGameHtml(rec.name) + "</h4>";
  html += "<p>" + escGameHtml(rec.interactive.text || "(sin texto)") + "</p>";
  var isChoice = rec.interactive.kind==="choice" && rec.interactive.choices.length;
  if(isChoice){
    rec.interactive.choices.forEach(function(c,i){
      html += '<div class="opt" data-idx="' + i + '">' + (i+1) + ". " + escGameHtml(c.label || "Opcion " + (i+1)) + "</div>";
    });
    html += '<div class="optSub">Toca una opcion, o pulsa su numero (Esc para cerrar sin elegir)</div>';
  } else {
    html += '<button type="button" class="actBtn" id="interactContinueBtn">Continuar</button>';
    html += '<div class="optSub">Toca el boton, o pulsa E o Esc para continuar</div>';
  }
  html += "</div>";
  panel.innerHTML = html;
  panel.dataset.forId = id;
  panel.style.display = "flex";
  if(isChoice){
    Array.prototype.forEach.call(panel.querySelectorAll(".opt"), function(el){
      el.addEventListener("click", function(){ chooseInteractionOption(parseInt(el.dataset.idx,10)); });
    });
  } else {
    var contBtn = document.getElementById("interactContinueBtn");
    if(contBtn) contBtn.addEventListener("click", closeInteractionPanel);
  }
}
function closeInteractionPanel(){
  interactionPanelOpen=false;
  var panel=document.getElementById("interactPanel");
  panel.style.display="none";
  panel.innerHTML="";
}
function chooseInteractionOption(index){
  var panel=document.getElementById("interactPanel");
  var rec=sceneObjects.get(panel.dataset.forId);
  if(!rec || !rec.interactive || rec.interactive.kind!=="choice"){ closeInteractionPanel(); return; }
  var choice=rec.interactive.choices[index];
  if(!choice) return;
  var pts=choice.points||0;
  playScore += pts;
  updateScoreDisplay();
  feedToast((pts>=0?"OK ":"AVISO ") + rec.name + ": " + choice.label + " (" + (pts>=0?"+":"") + pts + " pts)");
  triggerOneShotAction(rec, choice.action);
  closeInteractionPanel();
}
function showScreenMessage(text, autoDismissSec, onDone){
  var panel=document.getElementById("screenMsgOverlay");
  if(!panel){ if(onDone) onDone(); return; }
  var done=false;
  var finish=function(){
    if(done) return;
    done=true;
    screenMsgDismissFn=null;
    panel.style.display="none";
    panel.innerHTML="";
    if(onDone) onDone();
  };
  var html='<div class="box"><p>' + escGameHtml(text) + "</p>";
  if(!autoDismissSec){
    html += '<button type="button" class="actBtn" id="screenMsgCloseBtn">Continuar</button>';
    html += '<div class="sub">Toca el boton, o pulsa E o Esc para continuar</div>';
  }
  html += "</div>";
  panel.innerHTML = html;
  panel.style.display = "flex";
  if(autoDismissSec){
    setTimeout(finish, Math.max(200, autoDismissSec*1000));
  } else {
    var btn=document.getElementById("screenMsgCloseBtn");
    if(btn) btn.addEventListener("click", finish);
    screenMsgDismissFn = finish;
  }
}
function showAskInput(promptText, varName, allowFile, fileVarName, onDone){
  askInputActive = true;
  if(document.pointerLockElement===canvas) document.exitPointerLock();
  var panel=document.getElementById("askInputOverlay");
  var pendingFileDataUrl=null;
  var finish=function(){
    askInputActive=false;
    panel.style.display="none";
    panel.innerHTML="";
    if(started && !isTouchDevice()){
      var req=canvas.requestPointerLock();
      if(req && typeof req.catch==="function") req.catch(function(){ document.getElementById("clickToStart").style.display="flex"; });
    }
    if(onDone) onDone();
  };
  var html='<div class="box"><p>' + escGameHtml(promptText||"") + "</p>";
  html += '<input type="text" id="askInputText" style="width:100%;box-sizing:border-box;padding:8px;border-radius:6px;border:1px solid #2a2f3d;background:#0f1116;color:#e8e8ee;margin-bottom:8px;" maxlength="500">';
  if(allowFile){
    html += '<p class="sub" id="askInputFileInfo">Sin archivo adjunto.</p>';
    html += '<input type="file" id="askInputFile" accept="image/*" style="display:none;">';
    html += '<button type="button" class="small" id="askInputFileTrigger" style="margin-bottom:8px;">Adjuntar imagen</button>';
  }
  html += '<div class="flexRow"><button type="button" class="actBtn" id="askInputSend" style="flex:1;">Enviar</button><button type="button" class="small" id="askInputCancel" style="flex:1;">Cancelar</button></div>';
  html += '<div class="sub">Enter para enviar, Esc para cancelar</div></div>';
  panel.innerHTML = html;
  panel.style.display = "flex";
  var textEl=document.getElementById("askInputText");
  textEl.focus();
  if(allowFile){
    document.getElementById("askInputFileTrigger").addEventListener("click", function(){ document.getElementById("askInputFile").click(); });
    document.getElementById("askInputFile").addEventListener("change", function(e){
      var file=e.target.files[0];
      var info=document.getElementById("askInputFileInfo");
      if(!file) return;
      if(file.size > MAX_ASK_ARCHIVO_BYTES){
        if(info) info.textContent = "Demasiado grande (max. " + Math.round(MAX_ASK_ARCHIVO_BYTES/1024) + "KB) -- no se adjunta.";
        pendingFileDataUrl=null;
        e.target.value="";
        return;
      }
      var reader=new FileReader();
      reader.onload=function(){ pendingFileDataUrl=reader.result; if(info) info.textContent="Adjunto: " + file.name; };
      reader.onerror=function(){ if(info) info.textContent="No se pudo leer el archivo."; };
      reader.readAsDataURL(file);
    });
  }
  var doSend=function(){
    if(varName) gameVariables[varName]=textEl.value;
    if(allowFile && fileVarName && pendingFileDataUrl) gameVariables[fileVarName]=pendingFileDataUrl;
    finish();
  };
  document.getElementById("askInputSend").addEventListener("click", doSend);
  document.getElementById("askInputCancel").addEventListener("click", finish);
  textEl.addEventListener("keydown", function(e){
    e.stopPropagation();
    if(e.key==="Enter"){ e.preventDefault(); doSend(); }
    else if(e.key==="Escape"){ e.preventDefault(); finish(); }
  });
}

var bgMusicEl = null;
function startBgMusic(){
  if(!PROJECT.audio || !PROJECT.audio.musicBase64) return;
  bgMusicEl = new Audio(PROJECT.audio.musicBase64);
  bgMusicEl.loop = true;
  bgMusicEl.volume = PROJECT.audio.volume!==undefined ? PROJECT.audio.volume : 0.5;
  bgMusicEl.play().catch(function(){});
}
document.getElementById("touchJoystick").style.display = isTouchDevice() ? "block" : "none";
document.getElementById("touchJumpBtn").style.display = isTouchDevice() ? "flex" : "none";
document.getElementById("touchViewBtn").style.display = isTouchDevice() ? "flex" : "none";
document.getElementById("touchDroneBtn").style.display = isTouchDevice() ? "flex" : "none";
document.getElementById("playInstructions").style.display = isTouchDevice() ? "none" : "block";
var autoplayCameraPathDone = false;
document.getElementById("clickToStart").addEventListener("click", function(){
  document.getElementById("clickToStart").style.display="none";
  if(bgMusicEl) bgMusicEl.play().catch(function(){}); else startBgMusic();
  started=true;
  if(!autoplayCameraPathDone){
    autoplayCameraPathDone = true;
    var acp = null;
    sceneObjects.forEach(function(r){ if(!acp && r.kind==="camerapath" && r.cameraPathData && r.cameraPathData.autoplay) acp = r; });
    if(acp) playCameraPath(acp);
  }
  if(isTouchDevice()) return;
  var reqInit=canvas.requestPointerLock();
  if(reqInit && typeof reqInit.catch==="function") reqInit.catch(function(){ document.getElementById("clickToStart").style.display="flex"; });
});
document.addEventListener("pointerlockchange", function(){
  if(isTouchDevice()) return;
  if(started && document.pointerLockElement!==canvas){ if(!askInputActive) document.getElementById("clickToStart").style.display="flex"; if(bgMusicEl) bgMusicEl.pause(); sceneObjects.forEach(function(r){ if(r.videoEl) r.videoEl.pause(); }); }
});
document.addEventListener("mousemove", function(e){
  if(!started || document.pointerLockElement!==canvas || cameraPathActive) return;
  playYaw -= (e.movementX||0)*0.0022;
  playPitch -= (e.movementY||0)*0.0022;
  playPitch = clamp(playPitch,-1.0,1.0);
});
var touchJoystickEl = document.getElementById("touchJoystick");
var touchJoystickKnobEl = document.getElementById("touchJoystickKnob");
var TOUCH_JOYSTICK_RADIUS = 46;
touchJoystickEl.addEventListener("touchstart", function(e){
  var t=e.changedTouches[0]; touchJoystickId=t.identifier; e.preventDefault();
}, { passive:false });
function updateTouchJoystickFromTouch(t){
  var rect=touchJoystickEl.getBoundingClientRect();
  var cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
  var dx=t.clientX-cx, dy=t.clientY-cy;
  var dist=Math.hypot(dx,dy);
  if(dist>TOUCH_JOYSTICK_RADIUS){ dx=(dx/dist)*TOUCH_JOYSTICK_RADIUS; dy=(dy/dist)*TOUCH_JOYSTICK_RADIUS; }
  touchJoystickKnobEl.style.transform = "translate(" + dx + "px," + dy + "px)";
  touchJoystickVec = { x: clamp(dx/TOUCH_JOYSTICK_RADIUS,-1,1), y: clamp(-dy/TOUCH_JOYSTICK_RADIUS,-1,1) };
}
function resetTouchJoystick(){ touchJoystickId=null; touchJoystickVec={x:0,y:0}; touchJoystickKnobEl.style.transform="translate(0,0)"; }
canvas.addEventListener("touchstart", function(e){
  if(!started || touchLookId!==null) return;
  var t=e.changedTouches[0]; touchLookId=t.identifier; touchLookLast={x:t.clientX,y:t.clientY};
}, { passive:true });
window.addEventListener("touchmove", function(e){
  if(!started) return;
  for(var i=0;i<e.changedTouches.length;i++){
    var t=e.changedTouches[i];
    if(t.identifier===touchJoystickId){ updateTouchJoystickFromTouch(t); e.preventDefault(); }
    else if(t.identifier===touchLookId){
      var dx=t.clientX-touchLookLast.x, dy=t.clientY-touchLookLast.y;
      if(!cameraPathActive){ playYaw -= dx*0.0055; playPitch -= dy*0.0055; playPitch = clamp(playPitch,-1.0,1.0); }
      touchLookLast={x:t.clientX,y:t.clientY}; e.preventDefault();
    }
  }
}, { passive:false });
function releaseTouch(e){
  for(var i=0;i<e.changedTouches.length;i++){
    var t=e.changedTouches[i];
    if(t.identifier===touchJoystickId) resetTouchJoystick();
    if(t.identifier===touchLookId) touchLookId=null;
  }
}
window.addEventListener("touchend", releaseTouch);
window.addEventListener("touchcancel", releaseTouch);
document.getElementById("touchInteractBtn").addEventListener("touchstart", function(e){
  e.preventDefault(); e.stopPropagation();
  if(nearestInteractiveId) openInteractionPanel(nearestInteractiveId);
});
document.getElementById("touchShootBtn").addEventListener("touchstart", function(e){
  e.preventDefault(); e.stopPropagation();
  attemptShoot();
});
var touchJumpBtnEl = document.getElementById("touchJumpBtn");
touchJumpBtnEl.addEventListener("touchstart", function(e){ e.preventDefault(); playKeys.space=true; });
touchJumpBtnEl.addEventListener("touchend", function(e){ e.preventDefault(); playKeys.space=false; });
touchJumpBtnEl.addEventListener("touchcancel", function(){ playKeys.space=false; });
function updateCameraPathCaption(){
  var el = document.getElementById("cameraPathCaption");
  if(!el) return;
  if(cameraPathActive && cameraPathActive.caption){ el.textContent = cameraPathActive.caption; el.style.display="block"; }
  else { el.style.display="none"; }
}
function playCameraPath(rec){
  if(!rec || rec.kind!=="camerapath") return;
  var cpd = rec.cameraPathData;
  if(!cpd || !cpd.path || !cpd.path.nodes || cpd.path.nodes.length<2) return;
  rec.object3D.updateMatrixWorld(true);
  var worldPts = cpd.path.nodes.map(function(n){ return rec.object3D.localToWorld(new THREE.Vector3(n.x,n.y,n.z)); });
  var curve = new THREE.CatmullRomCurve3(worldPts, !!cpd.path.closed, "catmullrom", 0.5);
  cameraPathActive = { curve:curve, duration:Math.max(0.5, cpd.duration||6), elapsed:0, caption:cpd.caption||"", lookAtTargetId:cpd.lookAtTargetId||null, wasFirstPerson:firstPersonMode, wasDrone:droneModeActive };
  droneModeActive = false;
  nearestInteractiveId = null; updateInteractPrompt();
  nearestShotTargetId = null; updateShotPrompt();
  updateCameraPathCaption();
  feedToast("🎥 " + rec.name);
}
function endCameraPath(){
  if(!cameraPathActive) return;
  var cp = cameraPathActive;
  cameraPathActive = null;
  droneModeActive = cp.wasDrone;
  firstPersonMode = cp.wasFirstPerson;
  updateCameraPathCaption();
}
function toggleFirstPerson(){
  if(cameraPathActive) return;
  firstPersonMode=!firstPersonMode;
  playPitch=-0.25;
  playCamDist = CHASE_RADIUS;
  var p=sceneObjects.get(playerRecordId);
  if(p) p.colorMaterials.forEach(function(m){ m.visible=!(firstPersonMode||droneModeActive); });
}
function toggleDroneMode(){
  if(cameraPathActive) return;
  droneModeActive=!droneModeActive;
  var p=sceneObjects.get(playerRecordId);
  if(droneModeActive){ droneCamPos.copy(camera.position); nearestInteractiveId=null; nearestShotTargetId=null; }
  if(p) p.colorMaterials.forEach(function(m){ m.visible=!(firstPersonMode||droneModeActive); });
  updateInteractPrompt(); updateShotPrompt();
  var btn=document.getElementById("touchDroneBtn");
  if(btn) btn.classList.toggle("activo", droneModeActive);
  var downBtn=document.getElementById("touchDroneDownBtn");
  if(downBtn) downBtn.style.display = (droneModeActive && isTouchDevice()) ? "flex" : "none";
  feedToast(droneModeActive ? "🛸 Modo dron: ACTIVADO" : "🚶 Modo dron: desactivado");
}
document.getElementById("touchViewBtn").addEventListener("touchstart", function(e){
  e.preventDefault(); e.stopPropagation(); toggleFirstPerson();
});
document.getElementById("touchDroneBtn").addEventListener("touchstart", function(e){
  e.preventDefault(); e.stopPropagation(); toggleDroneMode();
});
var touchDroneDownBtnEl = document.getElementById("touchDroneDownBtn");
touchDroneDownBtnEl.addEventListener("touchstart", function(e){ e.preventDefault(); playKeys.shift=true; });
touchDroneDownBtnEl.addEventListener("touchend", function(e){ e.preventDefault(); playKeys.shift=false; });
touchDroneDownBtnEl.addEventListener("touchcancel", function(){ playKeys.shift=false; });
window.addEventListener("keydown", function(e){
  var k=e.key.toLowerCase();
  if(askInputActive){
    // askInputText tiene su propio listener de keydown (con stopPropagation) para Enter/Esc --
    // esto es solo red de seguridad para cuando el foco esta en otro control del overlay.
    return;
  }
  if(screenMsgDismissFn && (k==="e" || k==="escape")){ screenMsgDismissFn(); return; }
  if(interactionPanelOpen){
    if(k>="1" && k<="4"){ chooseInteractionOption(parseInt(k,10)-1); }
    else if(k==="e" || k==="escape"){ closeInteractionPanel(); }
    return;
  }
  if(k==="w") playKeys.w=true; if(k==="a") playKeys.a=true; if(k==="s") playKeys.s=true; if(k==="d") playKeys.d=true;
  if(k==="arrowup"){ playKeys.arrowUp=true; e.preventDefault(); }
  if(k==="arrowdown"){ playKeys.arrowDown=true; e.preventDefault(); }
  if(k==="arrowleft"){ playKeys.arrowLeft=true; e.preventDefault(); }
  if(k==="arrowright"){ playKeys.arrowRight=true; e.preventDefault(); }
  if(k==="shift") playKeys.shift=true;
  if(k===" " || k==="spacebar"){ playKeys.space=true; e.preventDefault(); }
  if(k==="v") toggleFirstPerson();
  if(k==="c") toggleDroneMode();
  if(k==="e"){ if(nearestInteractiveId) openInteractionPanel(nearestInteractiveId); }
  if(k==="f") attemptShoot();
  if(k==="r") location.reload();
  if(k==="l"){ skyPointerActivo = !skyPointerActivo; }
});
window.addEventListener("keyup", function(e){
  var k=e.key.toLowerCase();
  if(k==="w") playKeys.w=false; if(k==="a") playKeys.a=false; if(k==="s") playKeys.s=false; if(k==="d") playKeys.d=false;
  if(k==="arrowup") playKeys.arrowUp=false;
  if(k==="arrowdown") playKeys.arrowDown=false;
  if(k==="arrowleft") playKeys.arrowLeft=false;
  if(k==="arrowright") playKeys.arrowRight=false;
  if(k==="shift") playKeys.shift=false;
  if(k===" " || k==="spacebar") playKeys.space=false;
});

function collidesSolidAt(x, y, z, half, excludeId){
  var eps = 0.05;
  var cBox = new THREE.Box3(new THREE.Vector3(x-half.x, y, z-half.z), new THREE.Vector3(x+half.x, y+half.y*2, z+half.z));
  var hit = false;
  sceneObjects.forEach(function(rec){
    if(hit || rec.id===excludeId || rec.collider.kind!=="solid") return;
    var oBox = new THREE.Box3().setFromObject(rec.object3D);
    if(y >= oBox.max.y - eps) return;
    if(cBox.intersectsBox(oBox)) hit = true;
  });
  return hit;
}
function resolveMoveWithCollision(player, dir, dist){
  var size = player.collider.size || { x:0.5, y:1.2, z:0.5 };
  var half = { x:size.x/2, y:size.y/2, z:size.z/2 };
  var pos = player.object3D.position;
  var y = pos.y;
  var nx = pos.x + dir.x*dist;
  if(!collidesSolidAt(nx, y, pos.z, half, player.id) && computeHeadClearance(nx, pos.z, y, player.id) >= size.y) pos.x = nx;
  var nz = pos.z + dir.z*dist;
  if(!collidesSolidAt(pos.x, y, nz, half, player.id) && computeHeadClearance(pos.x, nz, y, player.id) >= size.y) pos.z = nz;
}
var groundRaycaster = new THREE.Raycaster();
var cameraRaycaster = new THREE.Raycaster();
var shotRaycaster = new THREE.Raycaster();
var SHOT_MAX_DISTANCE = 60;
var nearestShotTargetId = null;
var droneModeActive = false;
var skyPointerActivo = false;
var droneCamPos = new THREE.Vector3();
var DRONE_SPEED = 5;
var cameraPathActive = null;
function objectForMeshRuntime(mesh){
  var o = mesh, found = null;
  while(o && !found){
    sceneObjects.forEach(function(rec, id){ if(rec.object3D === o) found = id; });
    o = o.parent;
  }
  return found;
}
function computeGroundHit(x, z, fromY, excludeId){
  groundRaycaster.set(new THREE.Vector3(x, fromY+0.6, z), new THREE.Vector3(0,-1,0));
  groundRaycaster.far = 60;
  var targets = [ground];
  sceneObjects.forEach(function(rec){
    if(rec.id===excludeId) return;
    if(rec.collider.kind==="solid" || rec.collider.kind==="ground") targets.push(rec.object3D);
  });
  var hits = groundRaycaster.intersectObjects(targets, true);
  return hits.length ? { y:hits[0].point.y, object:hits[0].object } : null;
}
function computeGroundY(x, z, fromY, excludeId){
  var hit = computeGroundHit(x, z, fromY, excludeId);
  return hit ? hit.y : null;
}
function raycastGroundAgainstObject(x, z, fromY, obj){
  groundRaycaster.set(new THREE.Vector3(x, fromY+5, z), new THREE.Vector3(0,-1,0));
  groundRaycaster.far = 20;
  var hits = groundRaycaster.intersectObject(obj, true);
  return hits.length ? hits[0].point.y : null;
}
function computeHeadClearance(x, z, feetY, excludeId){
  var startY = feetY + 0.25;
  groundRaycaster.set(new THREE.Vector3(x, startY, z), new THREE.Vector3(0,1,0));
  groundRaycaster.far = 3;
  var targets = [];
  sceneObjects.forEach(function(rec){
    if(rec.id===excludeId) return;
    if(rec.collider.kind==="ground") targets.push(rec.object3D);
  });
  if(!targets.length) return Infinity;
  var hits = groundRaycaster.intersectObjects(targets, true);
  return hits.length ? (hits[0].point.y - feetY) : Infinity;
}
function updatePlayer(dt){
  if(!playerRecordId) return;
  var player = sceneObjects.get(playerRecordId);
  if(!player) return;
  var prevClockTime = npcClockTime;
  npcClockTime += dt;
  if(timelineDuration>0.02 && npcClockTime>timelineDuration) npcClockTime = npcClockTime % timelineDuration;
  fireDueChainTriggers(prevClockTime, npcClockTime);
  applyTimeToScene(npcClockTime, playerRecordId);
  if(cameraPathActive){
    var cp = cameraPathActive;
    cp.elapsed += dt;
    var tCp = clamp(cp.elapsed/cp.duration, 0, 1);
    var posCp = cp.curve.getPointAt(tCp);
    camera.position.copy(posCp);
    var lookCp;
    if(cp.lookAtTargetId){
      var lookRec = sceneObjects.get(cp.lookAtTargetId);
      lookCp = lookRec ? lookRec.object3D.getWorldPosition(new THREE.Vector3()) : posCp.clone().add(cp.curve.getTangentAt(tCp));
    } else { lookCp = posCp.clone().add(cp.curve.getTangentAt(tCp)); }
    camera.lookAt(lookCp);
    if(tCp>=1) endCameraPath();
  } else if(!interactionPanelOpen && !askInputActive && droneModeActive){
    if(playKeys.arrowLeft) playYaw += TURN_SPEED*dt;
    if(playKeys.arrowRight) playYaw -= TURN_SPEED*dt;
    var droneForward = new THREE.Vector3(0,0,-1).applyEuler(new THREE.Euler(playPitch,playYaw,0,"YXZ"));
    var droneRight = new THREE.Vector3(1,0,0).applyEuler(new THREE.Euler(0,playYaw,0));
    var dMoveZ=0, dMoveX=0, dMoveY=0;
    if(playKeys.w || playKeys.arrowUp) dMoveZ+=1; if(playKeys.s || playKeys.arrowDown) dMoveZ-=1; if(playKeys.d) dMoveX+=1; if(playKeys.a) dMoveX-=1;
    if(playKeys.space) dMoveY+=1; if(playKeys.shift) dMoveY-=1;
    dMoveZ += touchJoystickVec.y; dMoveX += touchJoystickVec.x;
    var droneDir = new THREE.Vector3().addScaledVector(droneForward, dMoveZ).addScaledVector(droneRight, dMoveX).addScaledVector(new THREE.Vector3(0,1,0), dMoveY);
    if(droneDir.lengthSq()>0.0001) droneCamPos.addScaledVector(droneDir.normalize(), DRONE_SPEED*dt);
    camera.position.copy(droneCamPos);
    camera.rotation.order="YXZ";
    camera.rotation.set(playPitch, playYaw, 0);
  } else if(!interactionPanelOpen && !askInputActive){
    if(playKeys.arrowLeft) playYaw += TURN_SPEED*dt;
    if(playKeys.arrowRight) playYaw -= TURN_SPEED*dt;
    var forwardVec = new THREE.Vector3(0,0,-1).applyEuler(new THREE.Euler(0,playYaw,0));
    var rightVec = new THREE.Vector3(1,0,0).applyEuler(new THREE.Euler(0,playYaw,0));
    var moveZ=0, moveX=0;
    if(playKeys.w || playKeys.arrowUp) moveZ+=1; if(playKeys.s || playKeys.arrowDown) moveZ-=1; if(playKeys.d) moveX+=1; if(playKeys.a) moveX-=1;
    moveZ += touchJoystickVec.y; moveX += touchJoystickVec.x;
    var joyMag = Math.hypot(touchJoystickVec.x, touchJoystickVec.y);
    var inputLen = Math.hypot(moveX,moveZ);
    if(inputLen>0.001){
      var dir = new THREE.Vector3().addScaledVector(forwardVec, moveZ/inputLen).addScaledVector(rightVec, moveX/inputLen);
      dir.normalize();
      var speed = (playKeys.shift || joyMag>0.75) ? RUN_SPEED : WALK_SPEED;
      resolveMoveWithCollision(player, dir, speed*dt);
      player.object3D.position.x = clamp(player.object3D.position.x,-SCENE_HALF_EXTENT,SCENE_HALF_EXTENT);
      player.object3D.position.z = clamp(player.object3D.position.z,-SCENE_HALF_EXTENT,SCENE_HALF_EXTENT);
      var targetQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,-1), dir);
      if(player.facingOffsetDeg) targetQuat.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), deg2rad(player.facingOffsetDeg)));
      player.object3D.quaternion.slerp(targetQuat, clamp(dt*10,0,1));
    }
    if(player.mixer && player.clips && player.clips.length){
      if(!player.__playerClipAction){
        var wanted=(player.actions||[]).find(function(a){ return a.type==="playClip"; });
        var clip=(wanted && player.clips.find(function(c){ return c.name===wanted.clipName; })) || player.clips[0];
        if(clip) player.__playerClipAction = player.mixer.clipAction(clip).play();
      }
      if(player.__playerClipAction){
        player.__playerClipAction.paused = !(inputLen>0.001);
        player.mixer.update(dt);
      }
    }
    if(player.__standObj && player.__standObj.parent){
      var carriedY = raycastGroundAgainstObject(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.__standObj);
      if(carriedY!==null && player.__standPrevY!=null){ player.object3D.position.y += (carriedY - player.__standPrevY); }
    }
    var groundHit = computeGroundHit(player.object3D.position.x, player.object3D.position.z, player.object3D.position.y, player.id);
    var gY = groundHit ? groundHit.y : null;
    var closeToGround = gY!==null && (player.object3D.position.y - gY) < 0.25;
    if(playKeys.space && playGrounded && closeToGround){ playVelY = JUMP_SPEED; playGrounded=false; }
    if(playGrounded && closeToGround){
      player.object3D.position.y = lerp(player.object3D.position.y, gY, clamp(dt*15,0,1));
      playVelY = 0;
    } else {
      playVelY += GRAVITY*dt;
      player.object3D.position.y += playVelY*dt;
      if(gY!==null && player.object3D.position.y<=gY && playVelY<=0){ player.object3D.position.y=gY; playVelY=0; playGrounded=true; }
      else { playGrounded=false; }
    }
    if(playGrounded && groundHit){ player.__standObj = groundHit.object; player.__standPrevY = groundHit.y; }
    else { player.__standObj = null; player.__standPrevY = null; }
    var pivot = player.object3D.position.clone().add(new THREE.Vector3(0,1.35,0));
    if(firstPersonMode){
      camera.position.copy(pivot);
      camera.rotation.order="YXZ";
      camera.rotation.set(playPitch, playYaw, 0);
    } else {
      var camDir = new THREE.Vector3().setFromSpherical(new THREE.Spherical(1, Math.PI/2-playPitch, playYaw));
      var camTargets = [];
      sceneObjects.forEach(function(rec){
        if(rec.id===playerRecordId) return;
        if(rec.collider.kind==="solid" || rec.collider.kind==="ground") camTargets.push(rec.object3D);
      });
      var camUpRef = Math.abs(camDir.y) > 0.98 ? new THREE.Vector3(1,0,0) : new THREE.Vector3(0,1,0);
      var camRight = new THREE.Vector3().crossVectors(camDir, camUpRef).normalize();
      var camUp2 = new THREE.Vector3().crossVectors(camRight, camDir).normalize();
      var FAN_SPREAD = 0.4;
      var sampleOffsets = [[0,0],[1,0],[-1,0],[0,1],[0,-1],[0.7,0.7],[0.7,-0.7],[-0.7,0.7],[-0.7,-0.7]];
      var rawCamDist = CHASE_RADIUS;
      for (var si=0; si<sampleOffsets.length; si++){
        var rx=sampleOffsets[si][0], ry=sampleOffsets[si][1];
        var samplePoint = pivot.clone().addScaledVector(camDir, CHASE_RADIUS).addScaledVector(camRight, rx*FAN_SPREAD).addScaledVector(camUp2, ry*FAN_SPREAD);
        var sampleDir = samplePoint.sub(pivot).normalize();
        cameraRaycaster.set(pivot, sampleDir);
        cameraRaycaster.far = CHASE_RADIUS;
        var hits = cameraRaycaster.intersectObjects(camTargets, true);
        if(hits.length) rawCamDist = Math.min(rawCamDist, Math.max(0.5, hits[0].distance-0.3));
      }
      playCamDist = lerp(playCamDist, rawCamDist, clamp(dt*10,0,1));
      var camDist = playCamDist;
      var tentative = pivot.clone().addScaledVector(camDir, camDist);
      var camFloorY = computeGroundY(tentative.x, tentative.z, pivot.y+2, playerRecordId);
      if(camFloorY!==null && camDir.y < -0.001){
        var maxDistFloor = (camFloorY+0.15-pivot.y)/camDir.y;
        camDist = Math.max(0.5, Math.min(camDist, maxDistFloor));
      }
      cameraRaycaster.set(pivot, new THREE.Vector3(0,1,0));
      cameraRaycaster.far = CHASE_RADIUS + 1.5;
      var camCeilingHits = cameraRaycaster.intersectObjects(camTargets, true);
      if(camCeilingHits.length && camDir.y > 0.001){
        var maxDistCeil = (camCeilingHits[0].point.y-0.2-pivot.y)/camDir.y;
        camDist = Math.max(1.2, Math.min(camDist, maxDistCeil));
      }
      camera.position.copy(pivot).addScaledVector(camDir, camDist);
      camera.lookAt(pivot);
    }
  }
  if(droneModeActive || cameraPathActive){
    nearestInteractiveId = null; updateInteractPrompt();
    nearestShotTargetId = null; updateShotPrompt();
  } else {
  var nearest=null, nearestDist=Infinity;
  sceneObjects.forEach(function(rec){
    if(rec.id===playerRecordId) return;
    if(!rec.interactive || !rec.interactive.enabled) return;
    var d = rec.object3D.position.distanceTo(player.object3D.position);
    if(d <= (rec.interactive.radius||2) && d < nearestDist){ nearest=rec; nearestDist=d; }
  });
  nearestInteractiveId = nearest ? nearest.id : null;
  updateInteractPrompt();
  var shotTargets=[];
  sceneObjects.forEach(function(rec){
    if(rec.id===playerRecordId) return;
    if(!rec.interactive || !rec.interactive.onShotAction) return;
    if(rec.colorMaterials.length && rec.colorMaterials.every(function(m){ return !m.visible; })) return;
    shotTargets.push(rec.object3D);
  });
  nearestShotTargetId = null;
  if(shotTargets.length){
    var shotDir = new THREE.Vector3();
    camera.getWorldDirection(shotDir);
    shotRaycaster.set(camera.position, shotDir);
    shotRaycaster.far = SHOT_MAX_DISTANCE;
    var shotHits = shotRaycaster.intersectObjects(shotTargets, true);
    if(shotHits.length) nearestShotTargetId = objectForMeshRuntime(shotHits[0].object);
  }
  updateShotPrompt();
  }
}

var lastT = performance.now();
function tick(){
  var now = performance.now();
  var dt = clamp((now-lastT)/1000, 0, 0.05);
  lastT = now;
  updateSunCycle(dt);
  updateNightSky(dt);
  updateWeatherSystems(dt);
  updateCricketSounds(dt);
  updateOneShotAnimations();
  updateSpins(dt);
  updateOneShotClips(dt);
  if(playerRecordId) updatePlayer(dt);
  else { var prevClockTime2 = npcClockTime; npcClockTime += dt; if(timelineDuration>0.02 && npcClockTime>timelineDuration) npcClockTime = npcClockTime % timelineDuration; fireDueChainTriggers(prevClockTime2, npcClockTime); applyTimeToScene(npcClockTime, null); }
  updateSkyPointer(dt, skyPointerActivo);
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}


applyEnvironment(PROJECT.environment);
var RESULTS = { steps: [] };
function step(name, fn) { try { fn(); RESULTS.steps.push({ name: name, ok: true }); } catch (e) { RESULTS.steps.push({ name: name, ok: false, error: (e && e.stack) || String(e) }); } }
// Version async de step(), para las pruebas que disparan una accion cuyo efecto llega en un
// microtask (p. ej. setImageVar -- construir la textura pasa por el FakeImage del arnes, que ahora
// resuelve el onload en un microtask de verdad, como en un navegador real, no en el acto).
async function stepAsync(name, fn) { try { await fn(); RESULTS.steps.push({ name: name, ok: true }); } catch (e) { RESULTS.steps.push({ name: name, ok: false, error: (e && e.stack) || String(e) }); } }
function nextTick() { return new Promise(function (resolve) { queueMicrotask(resolve); }); }

buildScene(PROJECT, async function () {
  // --- Escena lista (síncrono: sólo primitivas) ---

  step("panel vacio no bloquea y dispara su accion", function () {
    var rec = sceneObjects.get("signEmpty");
    var before = rec.colorMaterials[0].opacity;
    openInteractionPanel("signEmpty");
    if (interactionPanelOpen) throw new Error("interactionPanelOpen quedó a true tras interactuar con un cartel de texto vacío (debería ejecutar la acción y no abrir panel).");
    var afterOneShot = rec.__oneShot;
    if (!afterOneShot) throw new Error("El cartel vacío no disparó ninguna acción (se esperaba un fundido de opacidad).");
  });

  step("panel con texto SI bloquea y se cierra con E/Esc", function () {
    var rec = sceneObjects.get("signWithText");
    openInteractionPanel("signWithText");
    if (!interactionPanelOpen) throw new Error("interactionPanelOpen debería ser true tras interactuar con un cartel CON texto (lectura de cartel).");
    closeInteractionPanel();
    if (interactionPanelOpen) throw new Error("closeInteractionPanel() no dejó interactionPanelOpen en false.");
  });

  step("cartel con texto CUYA accion es 'Preguntar' NO abre el panel de cartel (evita dos overlays a la vez)", function () {
    // Bug real detectado jugando la partida exportada: si el cartel tiene texto Y su accion es
    // askInput/screenMessage, antes se abria el panel de "leer cartel" A LA VEZ que la ventanita de
    // la propia accion -- dos overlays superpuestos. Debe comportarse como el cartel vacio: dispara
    // la accion al instante, sin panel de cartel de por medio.
    askInputActive = false; // por si un test anterior lo dejo a medias
    openInteractionPanel("signAskInput");
    if (interactionPanelOpen) throw new Error("interactionPanelOpen quedo a true -- el panel de 'leer cartel' no deberia abrirse cuando la accion es 'Preguntar' (se solaparia con su propia ventanita).");
    if (!askInputActive) throw new Error("askInput deberia haberse disparado igualmente (askInputActive deberia ser true).");
    // Limpieza: cerramos el askInput abierto para no afectar a los pasos siguientes.
    document.getElementById("askInputCancel").__fire("click");
    if (askInputActive) throw new Error("El askInput de este test no se cerro correctamente (askInputActive deberia volver a false).");
  });

  step("disparo (F) a 10m impacta y dispara onShotAction (huida/fundido)", function () {
    playerRecordId = "player";
    firstPersonMode = true;
    playYaw = 0; playPitch = 0;
    // Un par de "frames" para que cámara y matrices de la escena se asienten, igual que en el juego real.
    for (var i = 0; i < 2; i++) { updatePlayer(0.016); renderer.render(scene, camera); }
    if (nearestShotTargetId !== "target") throw new Error("El objetivo a 10m en línea recta no fue detectado por el rayo de disparo (nearestShotTargetId=" + nearestShotTargetId + ").");
    attemptShoot();
    var rec = sceneObjects.get("target");
    if (!rec.__oneShot) throw new Error("attemptShoot() no generó ninguna animación de una vez sobre el objetivo.");
  });

  step("tras completarse el fundido, el objetivo deja de ser alcanzable (no fantasma)", function () {
    // Simulamos el paso del tiempo hasta que el fundido (duration 0.2s) termine.
    for (var i = 0; i < 30; i++) { updateOneShotAnimations(); }
    // performance.now() avanza solo con el reloj real; forzamos que "termine" reescribiendo el estado
    // directamente si tras 30 pasadas inmediatas (mismo instante) el oneShot no ha progresado --
    // en su lugar, comprobamos el estado esperado tras opacidad 0 manualmente:
    var rec = sceneObjects.get("target");
    // Forzamos el final del fundido (equivalente a que pase el tiempo real) para probar el filtro:
    rec.colorMaterials.forEach(function (m) { m.opacity = 0; m.visible = false; });
    rec.__oneShot = null;
    updatePlayer(0.016);
    if (nearestShotTargetId === "target") throw new Error("El objetivo totalmente desvanecido SIGUE siendo alcanzable por el rayo de disparo (bug del 'fantasma disparable').");
  });

  step("screenMessage: no bloquea, y el next solo se dispara al cerrar (no al mostrarse)", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.quien = "Sergio";
    gameVariables.msgSeen = 0;
    var action = {
      type: "screenMessage", text: "Hola {{quien}}", autoDismissSec: 0,
      next: { type: "setVariable", varName: "msgSeen", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (askInputActive) throw new Error("screenMessage no debe activar askInputActive (no bloquea moverse).");
    if (gameVariables.msgSeen === 1) throw new Error("El 'next' se disparo antes de cerrar el mensaje (deberia esperar al cierre, automatico o manual).");
    document.getElementById("screenMsgCloseBtn").__fire("click");
    if (gameVariables.msgSeen !== 1) throw new Error("El 'next' no se disparo al cerrar el mensaje en pantalla.");
  });

  step("askInput: bloquea mientras esta abierto, guarda la variable y dispara next al enviar", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.nombreJugador = "";
    gameVariables.afterAsk = 0;
    var action = {
      type: "askInput", promptText: "Como te llamas?", varName: "nombreJugador", allowFile: false,
      next: { type: "setVariable", varName: "afterAsk", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (!askInputActive) throw new Error("askInput deberia activar askInputActive mientras esta abierto (bloquea moverse).");
    document.getElementById("askInputText").value = "Sergio";
    document.getElementById("askInputSend").__fire("click");
    if (askInputActive) throw new Error("askInputActive deberia volver a false tras enviar la respuesta.");
    if (gameVariables.nombreJugador !== "Sergio") throw new Error("La variable no guardo el texto introducido (valor: '" + gameVariables.nombreJugador + "').");
    if (gameVariables.afterAsk !== 1) throw new Error("El 'next' no se disparo tras enviar el askInput.");
  });

  step("askInput: Cancelar tambien cierra, desbloquea y SIGUE la secuencia (next), pero SIN guardar la variable", function () {
    // Ojo: Cancelar SI dispara el 'next' (igual que Enviar) -- si no lo hiciera, cancelar dejaria
    // colgada para siempre cualquier secuencia encadenada despues de la pregunta (p. ej. un ascensor
    // que deberia seguir bajando aunque el jugador no responda). Lo unico que cambia es que NO se
    // sobrescribe la variable con el texto sin enviar.
    var rec = sceneObjects.get("signEmpty");
    gameVariables.nombreJugador = "valorPrevio";
    gameVariables.afterAsk = 0;
    var action = {
      type: "askInput", promptText: "Como te llamas?", varName: "nombreJugador", allowFile: false,
      next: { type: "setVariable", varName: "afterAsk", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    document.getElementById("askInputText").value = "Otro nombre";
    document.getElementById("askInputCancel").__fire("click");
    if (askInputActive) throw new Error("askInputActive deberia volver a false tras Cancelar.");
    if (gameVariables.nombreJugador !== "valorPrevio") throw new Error("Cancelar NO deberia sobrescribir la variable con el texto sin enviar.");
    if (gameVariables.afterAsk !== 1) throw new Error("Cancelar deberia igualmente disparar el 'next' -- si no, una secuencia encadenada se quedaria colgada para siempre si el jugador cancela.");
  });

  await stepAsync("setImageVar: cambia la textura de un objeto de Imagen desde una variable y dispara next", async function () {
    var rec = sceneObjects.get("signEmpty");
    var board = sceneObjects.get("imgBoard");
    var meshBefore = board.object3D.children[0];
    var matBefore = meshBefore.material;
    var mapBefore = meshBefore.material.map;
    gameVariables.fotoJugador = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
    gameVariables.afterImg = 0;
    var action = {
      type: "setImageVar", varName: "fotoJugador", target: "imgBoard",
      next: { type: "setVariable", varName: "afterImg", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    // La textura nueva llega en un microtask (FakeImage), como en un navegador real -- esperamos a
    // que se drene antes de comprobar el resultado.
    await nextTick();
    var meshAfter = board.object3D.children[0];
    if (meshAfter.material === matBefore) throw new Error("setImageVar no reemplazo el material del objeto de Imagen (sigue siendo el mismo).");
    if (!meshAfter.material.map || meshAfter.material.map === mapBefore) throw new Error("setImageVar no genero una textura nueva distinta de la anterior.");
    if (board.imageBase64 !== gameVariables.fotoJugador) throw new Error("setImageVar no actualizo rec.imageBase64 con el data URL de la variable.");
    if (gameVariables.afterImg !== 1) throw new Error("El 'next' no se disparo tras cambiar la imagen.");
  });

  step("setImageVar: variable vacia o destino invalido no rompe nada y sigue la secuencia", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.fotoVacia = "";
    gameVariables.afterImg2 = 0;
    var action = {
      type: "setImageVar", varName: "fotoVacia", target: "imgBoard",
      next: { type: "setVariable", varName: "afterImg2", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterImg2 !== 1) throw new Error("Con variable vacia, el 'next' deberia dispararse igualmente (no debe quedarse colgado).");
  });

  step("setTextVar: cambia el texto de un rotulo desde una variable, sin red, y dispara next", function () {
    var rec = sceneObjects.get("signEmpty");
    var label = sceneObjects.get("rotuloVar");
    var meshBefore = label.object3D.children[0];
    var mapBefore = meshBefore.material.map;
    gameVariables.nombreParaRotulo = "Sergio";
    gameVariables.afterTxt = 0;
    var action = {
      type: "setTextVar", varName: "nombreParaRotulo", target: "rotuloVar",
      next: { type: "setVariable", varName: "afterTxt", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (label.text3d.text !== "Sergio") throw new Error("setTextVar no actualizo text3d.text (valor: '" + label.text3d.text + "').");
    var meshAfter = label.object3D.children[0];
    if (!meshAfter.material.map || meshAfter.material.map === mapBefore) throw new Error("setTextVar no genero una textura nueva para el rotulo.");
    if (gameVariables.afterTxt !== 1) throw new Error("El 'next' no se disparo tras setTextVar.");
  });

  step("setTextVar: destino invalido no rompe nada y sigue la secuencia", function () {
    var rec = sceneObjects.get("signEmpty");
    gameVariables.afterTxt2 = 0;
    var action = {
      type: "setTextVar", varName: "nombreParaRotulo", target: "imgBoard", // imgBoard NO es text3d -- destino invalido a proposito
      next: { type: "setVariable", varName: "afterTxt2", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterTxt2 !== 1) throw new Error("Con destino invalido, el 'next' deberia dispararse igualmente (no debe quedarse colgado ni romper).");
  });

  step("texto multilinea: la geometria crece en ALTO segun el numero de lineas (no se aplasta)", function () {
    var rec = sceneObjects.get("signEmpty");
    var label = sceneObjects.get("rotuloVar");
    // Estado previo: el rotulo quedo con "Sergio" (1 sola linea) tras el test anterior de setTextVar.
    var meshUnaLinea = label.object3D.children[0];
    var altoUnaLinea = meshUnaLinea.geometry.parameters.height;
    var anchoUnaLinea = meshUnaLinea.geometry.parameters.width;
    if (Math.abs(altoUnaLinea - 1) > 1e-9) throw new Error("Con 1 sola linea, el alto de la geometria deberia ser exactamente 1*size (regresion en rotulos existentes). Valor: " + altoUnaLinea);

    gameVariables.textoLargo = "Linea uno\nLinea dos\nLinea tres";
    gameVariables.afterTxt3 = 0;
    var action = {
      type: "setTextVar", varName: "textoLargo", target: "rotuloVar",
      next: { type: "setVariable", varName: "afterTxt3", expr: "1" },
    };
    triggerOneShotAction(rec, action);
    if (gameVariables.afterTxt3 !== 1) throw new Error("El 'next' no se disparo tras setTextVar con texto multilinea.");
    var meshMultilinea = label.object3D.children[0];
    var altoMultilinea = meshMultilinea.geometry.parameters.height;
    var anchoMultilinea = meshMultilinea.geometry.parameters.width;
    // 3 lineas: heightFactor = (3*LINE_HEIGHT+PADDING*2)/(LINE_HEIGHT+PADDING*2) = (3*64+40)/(64+40) = 232/104
    var esperado = 232 / 104;
    if (Math.abs(altoMultilinea - esperado) > 1e-9) throw new Error("El alto de la geometria con 3 lineas no crecio como se esperaba (bug de aplastamiento). Esperado: " + esperado + ", obtenido: " + altoMultilinea);
    if (!(altoMultilinea > altoUnaLinea)) throw new Error("El alto con 3 lineas deberia ser mayor que con 1 sola linea -- el texto se esta aplastando en vez de crecer hacia abajo.");
    // Regresion de distorsion: el ANCHO de la caja (boxWidth fijo) NO debe encogerse al crecer las
    // lineas -- si el ancho usara canvas.width/canvas.height (que se reduce con mas lineas) en vez de
    // canvas.width/REF, la textura se estira (letras angostas y alargadas hacia arriba).
    if (Math.abs(anchoMultilinea - anchoUnaLinea) > 1e-9) throw new Error("El ancho de la geometria NO deberia cambiar entre 1 y 3 lineas (mismo boxWidth) -- si cambia, el texto se distorsiona (encogido en horizontal, alargado en vertical). 1 linea: " + anchoUnaLinea + ", 3 lineas: " + anchoMultilinea);
  });

  var okAll = RESULTS.steps.every(function (s) { return s.ok; });
  __onDone(okAll, RESULTS.steps);
});
