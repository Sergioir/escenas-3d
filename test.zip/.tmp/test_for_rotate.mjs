import * as THREE from 'three';

function deg2rad(d){ return d*Math.PI/180; }
function rad2deg(r){ return r*180/Math.PI; }

// Replica minima del objeto rec y triggerOneShotAction para moveTo/rotateTo + el nuevo "for".
function makeRec(rotDeg) {
  const obj = new THREE.Object3D();
  obj.quaternion.setFromEuler(new THREE.Euler(0, deg2rad(rotDeg), 0));
  obj.userData.__origin = { pos: obj.position.clone(), quat: obj.quaternion.clone() };
  return { object3D: obj, __oneShot: null };
}

function triggerOneShotAction(rec, action, batchStartedAt) {
  if (!action || !action.type) return;
  const startedAt = batchStartedAt || 1;
  if (action.type === "for") {
    const count = action.count;
    const body = action.body;
    if (body && (body.type === "moveTo" || body.type === "rotateTo") && body.relative && body.to && count > 0) {
      const amplified = Object.assign({}, body, { to: { x: body.to.x * count, y: body.to.y * count, z: body.to.z * count } });
      triggerOneShotAction(rec, amplified, startedAt);
    } else {
      for (let i = 0; i < count; i++) triggerOneShotAction(rec, body, startedAt);
    }
    return;
  }
  // moveTo/rotateTo (simplificado: sin grupo/merge de vecinos, solo el propio rec)
  const targetRec = rec;
  const duration = Math.max(50, (action.duration || 1) * 1000);
  const existingOS = targetRec.__oneShot;
  const mergeable = existingOS && existingOS.startedAt === startedAt;
  const fromQuat = mergeable ? existingOS.fromQuat.clone() : targetRec.object3D.quaternion.clone();
  let toQuat = mergeable ? existingOS.toQuat.clone() : fromQuat.clone();
  if (action.relative && action.type === "rotateTo" && action.to) {
    const originQuat = targetRec.object3D.userData.__origin.quat;
    const oe = new THREE.Euler().setFromQuaternion(originQuat);
    const ne = new THREE.Euler(oe.x + deg2rad(action.to.x), oe.y + deg2rad(action.to.y), oe.z + deg2rad(action.to.z));
    toQuat = new THREE.Quaternion().setFromEuler(ne);
  }
  targetRec.__oneShot = { startedAt, duration, fromQuat, toQuat };
}

// Caso 1: OLD behavior (repetir literalmente N veces la MISMA rotacion relativa) -> deberia dar SOLO 90 (el bug de Sergio)
const recOld = makeRec(0);
for (let i = 0; i < 5; i++) {
  triggerOneShotAction(recOld, { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 2 }, 999);
}
const finalOldDeg = rad2deg(new THREE.Euler().setFromQuaternion(recOld.__oneShot.toQuat).y);
console.log("Repetir 5x sin fix (simulando bug):", finalOldDeg.toFixed(1), "grados (esperado bug: 90)");

// Caso 2: NEW behavior via "for" con el fix -> debe dar 450 grados (5 x 90) en la MISMA duracion (2s)
const recNew = makeRec(0);
triggerOneShotAction(recNew, { type: "for", count: 5, body: { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 2 } }, 1000);
const finalNewDeg = rad2deg(new THREE.Euler().setFromQuaternion(recNew.__oneShot.toQuat).y);
const durationSec = recNew.__oneShot.duration / 1000;
console.log("for x5 CON fix:", finalNewDeg.toFixed(1), "grados en", durationSec, "s (esperado: 450 en 2s)");
console.log(Math.abs(finalNewDeg - 450) < 0.01 && durationSec === 2 ? "OK: el cilindro ahora gira 5x en la misma duracion" : "FAIL");

// Caso 3: for con count=2 (para no confundir con el otro reporte) -> 180 grados
const rec2 = makeRec(0);
triggerOneShotAction(rec2, { type: "for", count: 2, body: { type: "rotateTo", relative: true, to: { x: 0, y: 90, z: 0 }, duration: 1 } }, 2000);
const final2Deg = rad2deg(new THREE.Euler().setFromQuaternion(rec2.__oneShot.toQuat).y);
console.log("for x2:", final2Deg.toFixed(1), "grados (esperado: 180)", Math.abs(final2Deg-180)<0.01 ? "OK" : "FAIL");
