# Pruebas automatizadas — Don Claude 3D

Suite de regresión en Node.js para el motor (editor + juego exportado, todo en `index.html`) y para
el backend PHP del multijugador (`multi/*.php`). Pensada para pillar, antes de subir una versión a
GitHub, el tipo de fallo que más veces ha roto esta app: código que se implementó (o se corrigió) en
una de las dos copias del motor — la del editor en vivo y la del juego exportado — pero no en la otra.

## Cómo ejecutarla

```sh
cd test
npm install   # una vez -- instala three (motor 3D) y @php-wasm/node (PHP real vía WebAssembly)
npm test      # o: node run-all.mjs
```

No hace falta ni navegador ni PHP instalado en la máquina: el motor se ejecuta con el paquete `three`
tal cual corre en un navegador (sin WebGL real — no comprobamos píxeles, sino posiciones, colisiones,
disparos, paneles...), y el PHP corre en un intérprete real compilado a WebAssembly.

## Qué comprueba cada fichero

- **`syntax-and-parity.mjs`** — Sintaxis válida del editor en vivo Y del juego exportado (este último
  generado de verdad ejecutando `buildStandaloneGameHtml()`/`buildStandaloneGameRuntimeSrc()` tal
  como están HOY en `index.html`, no una copia aparte). Además comprueba que ~66 funciones del motor
  consideradas críticas (física, disparo, interactivo, bóveda nocturna, meteoros, grillo, carga de
  modelos...) existen con el mismo nombre en las dos copias — ver `critical-runtime-functions.json`.

- **`engine-functional.mjs`** — Ejecuta el CÓDIGO REAL del juego exportado (extraído de `index.html`,
  no reimplementado) sobre un proyecto de prueba sintético, y comprueba comportamientos concretos:
  - Un cartel interactivo con texto vacío ejecuta su acción sin abrir panel ni bloquear el juego.
  - Un cartel con texto SÍ abre el panel (bloquea) y se cierra con E/Esc.
  - Un cartel cuya acción es `askInput`/`screenMessage` NO abre además el panel genérico de cartel
    (regresión de los dos overlays superpuestos a la vez).
  - Disparar (F) a un objetivo en línea recta lo detecta e inicia su acción (huida/animación).
  - Un objetivo totalmente desvanecido (opacidad 0) deja de ser alcanzable por el disparo (regresión
    del bug del "fantasma disparable").
  - `screenMessage` no bloquea el juego y dispara su `next` solo al cerrarse.
  - `askInput` bloquea mientras está abierto, guarda la variable y sigue la cadena tanto al enviar
    como al cancelar (cancelar no debe dejar la secuencia colgada).
  - `setImageVar`/`setTextVar` cambian la imagen/texto de un objeto desde una variable sin red, y no
    rompen la cadena si la variable está vacía o el destino no es del tipo esperado.
  - Un rótulo de texto 3D con varias líneas crece en ALTO según el número de líneas (no se aplasta) y
    mantiene el mismo ANCHO de caja que con una sola línea (no se distorsiona/estira).

- **`gltf-scale-regression.mjs`** — Construye un esqueleto sintético con una "bind pose" aplastada a
  propósito (el mismo caso raro que sufría `CesiumMan.glb`) y comprueba que `computeModelBounds()`
  calcula el tamaño real a partir de la animación, no de la pose en reposo — regresión del bug por el
  que un personaje con esqueleto se exportaba minúsculo/descolocado y no se podía ni ver ni acertar.

- **`js-sun-orientation-functional.mjs`** — Comprueba que la "orientación del escenario" del Sol
  (modos ciclo/hora real) rota su posición sin cambiar la altura (Y) ni el radio en el plano XZ, que
  90° gira exactamente un cuarto de vuelta, y que 360° equivale a 0°.

- **`js-fusion-carga-functional.mjs`** — Comprueba la fusión de 3 vías al CARGAR cambios en una sala
  compartida (no solo al guardar): ediciones locales sin guardar sobreviven junto a las ajenas,
  conflictos reales sobre el mismo objeto avisan y mantienen la versión ya guardada, y sin ediciones
  locales de por medio la carga refleja fielmente el servidor.

- **`php-lint.mjs`** — Sintaxis válida de los `.php` del multijugador, con un intérprete PHP real
  (WebAssembly), sin ejecutar su lógica (que espera peticiones HTTP reales, sesión, ficheros de datos).

- **`php-fusion-guardados-functional.mjs`**, **`php-sala-version-functional.mjs`**,
  **`php-validarpin-functional.mjs`** — Ejecutan la lógica real de `multi/proyecto.php` (vía el mismo
  intérprete PHP en WebAssembly) para la fusión de guardados concurrentes, el versionado de sala, y la
  validación del PIN de edición ("Pulsar para editar").

## Limitaciones (a tener en cuenta)

- No hay comprobación de renderizado real (píxeles, WebGL) ni de audio.
- No hay prueba funcional de extremo a extremo del backend PHP (peticiones HTTP reales, ficheros de
  datos bajo `multi/data/`, WebRTC) — solo se valida que el código PHP compila sin errores de sintaxis.
  Para probar el multijugador de verdad hace falta un hosting con PHP real (ver el README principal).
- El chequeo de "paridad de funciones" es una lista curada (`critical-runtime-functions.json`) de lo
  que se considera crítico para el juego jugable, no todas las funciones del editor — el resto de
  funciones del editor (paneles, gizmos, undo, portapapeles...) se listan solo informativamente al
  final de `syntax-and-parity.mjs`. Si se añade una función de motor/jugabilidad nueva que deba vivir
  en las dos copias, conviene añadirla también a esa lista.
